import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", "86_64", (int) (byte) 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("TGE...", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "mixmd modm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(".pl_9517_1560227656                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".pl_9517_1560227656                                                                                                                                                        " + "'", str1.equals(".pl_9517_1560227656                                                                                                                                                        "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("444444444444MACosx444444444444jAVAvIRTUALmACHINE", "Sun.lwawt.macosx.LWCToolkit", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio" + "'", str1.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "mac OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                    ", " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                 macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, 600.0d, (double) 47);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/runrandooppl955622656/target/classes:/users/sophie/documents/defects4j/framework/lib/testgeneration/generation/randoop-currentjar", (java.lang.CharSequence) "EN");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Mac51.0 51.0OS51.0 51.0X", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c51.0 51.0OS51.0 51.0XaM" + "'", str2.equals("c51.0 51.0OS51.0 51.0XaM"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixmd modm");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444" + "'", str2.equals("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 0 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(23L, (long) 31, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 170 + "'", int1 == 170);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sophiex86_64", 209, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 46, "                                                                                                                                                                                                                                                                                                 ::::::::EN          1.7                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                              " + "'", str3.equals("                                              "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...cosx.LWCToolkit", 185, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" ::::::::EN          1.7", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ::::::::EN          1.7" + "'", str2.equals(" ::::::::EN          1.7"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        float[] floatArray4 = new float[] { '4', (short) 100, (short) 100, (short) 100 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sophiesophiesophiesopsun.awt.CGraphicsEnvironment", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double[] doubleArray2 = new double[] { 8L, '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("4", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x86_64x", "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64x" + "'", str2.equals("x86_64x"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio", "SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio" + "'", str2.equals("Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        long[] longArray3 = new long[] { (short) 0, (byte) 10, 100L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (-1), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Machine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444mac");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "N/L", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users//Users/sophie/Library/Java/Extensions:/Librar", "X86_6...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", "...cosx.LWCToolkit", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 198, 0.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 198.0d + "'", double3 == 198.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sun.lw4wt.m4cosx.LWCToolkit", 170, "http://java.oracle.com");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit" + "'", str3.equals("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.awt.CGraphicsEnvironment", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "mac OS X", (int) (short) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 170, 12);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "racle Corporation" + "'", str8.equals("racle Corporation"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("         Oracle Corporationironment", "macOSX", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 48, 209L, 183L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 48L + "'", long3 == 48L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "", 7, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Mac OS X", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaa", 272, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa#########################################################################################################################################################################################################################################################################" + "'", str3.equals("aaaaaaa#########################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "racle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(34, 31, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX", "10.14.3MAC");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', (int) (short) 10, 100);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v" + "'", str6.equals("ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoopx86_64xpl_95x86_64xx86_64x_x86_64x56022x86_64x656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentx86_64xjar", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoopx86_64xpl_95x86_64xx86_64x_x86_64x56022x86_64x656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentx86_64xjar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoopx86_64xpl_95x86_64xx86_64x_x86_64x56022x86_64x656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentx86_64xjar"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("racle Corporation", "                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", "", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "                                                                                                                                                                                              mac OS X", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Oracle#Corporation", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               1.7", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual" + "'", str3.equals("444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJA" + "'", str1.equals("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJA"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users//Users/sophie/Library/Java/Extensions:/Librar", "1", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX", "1.7.0_80", 198);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie" + "'", str6.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/users/sophie/documents/defects4j/tmp/runrandooppl955622656/target/classes:/users/sophie/documents/defects4j/framework/lib/testgeneration/generation/randoop-currentjar", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("XSOcam", 31, 185);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, 185, 3201);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3201 + "'", int3 == 3201);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1" + "'", str1.equals("1"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("EN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("..", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie" + "'", str2.equals("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("EN");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                    10.14.3mac", "sun.awt.CGmixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specificatio", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("                                   ", (java.lang.Object[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "::::::::EN");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("mixed mode", "/", 18);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("macosx", strArray14, strArray17);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "::::::::en", 183, (int) (short) -1);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray17);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "macosx" + "'", str20.equals("macosx"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 12L, (double) (-1.0f), (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Oracle#Corporation", "Java Platform API Specificatio", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/v          1.7.0_80-b15          ", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      /v          1.7.0_80-b15                " + "'", str2.equals("      /v          1.7.0_80-b15                "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String[] strArray4 = new java.lang.String[] { "x86_64", "10.14.3", "mac os x", "en" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "x86_6410.14.3mac os xen" + "'", str7.equals("x86_6410.14.3mac os xen"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("...cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsoc..." + "'", str1.equals("tiklooTCWL.xsoc..."));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 48L, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X", "                                    10.14.3mac", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X" + "'", str3.equals("hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("mac OS X", "#", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac OS X" + "'", str3.equals("mac OS X"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/", (int) ' ', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_6", "lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444", 209);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6" + "'", str3.equals("x86_6"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 4, (long) 18, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn/Users//Users/sophie/Library/Java/Extensions:/Librar", "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", 28, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie" + "'", str3.equals("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("444444444444MACosx444444444444jAVAvIRTUALmACHINE", "mixmd modm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444MACosx444444444444jAVAvIRTUALmACHINE" + "'", str2.equals("444444444444MACosx444444444444jAVAvIRTUALmACHINE"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("44444444444444451.04444444444444444", "444444444...", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE", "Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", "444444444444mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("     ", "/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                    ", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("X86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX", (java.lang.Object[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("::::::::en", strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                                                                                                    " + "'", str6.equals("                                                                                                    "));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/USERS/SOPHIE", "macOSXaaaa:aaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) '#', (-1));
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "x86_64" + "'", str6.equals("x86_64"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x86_64" + "'", str8.equals("x86_64"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", "", "444444444444mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.7");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("avaJ lautriV enihcaM noitacificepS", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "macosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Oracle#Corporation", (int) (short) 10, 48);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poration" + "'", str3.equals("poration"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 0, (long) (byte) -1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        long[] longArray2 = new long[] { 12, 48 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 12L + "'", long5 == 12L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("444444444444MAC os x444444444444jAVA vIRTUAL mACHINE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444MAC os x444444444444jAVA vIRTUAL mACHINE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("          Mac OS X          ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          Mac OS X          " + "'", str2.equals("          Mac OS X          "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "########################/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/########################                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("::::::::EN", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("racle Corporation", "########################/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/########################", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                 macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                                                  macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("x86_64x", "..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64x" + "'", str2.equals("x86_64x"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", (int) (short) 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ", "                                                    ");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray5, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, ' ');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "x86_64");
        boolean boolean14 = org.apache.commons.lang3.StringUtils.startsWithAny("...essalc/tegra...", strArray13);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str9.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 12, 0.0f, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("avaJ lautriV enihcaM noitacificepS", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "avaJ lautriV enihcaM noitacificepS" + "'", str2.equals("avaJ lautriV enihcaM noitacificepS"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("::::::::en", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "########################/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/########################                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("machine virtual x444444444444java os 444444444444mac", "hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X", "noitacificepS enihcaM lautriV avaJ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "machine virtual x444444444444java os 444444444444mac" + "'", str4.equals("machine virtual x444444444444java os 444444444444mac"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio", "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle#Corporation", 28, 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("          Mac OS X          ", "444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE" + "'", str2.equals("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("444444444444MACosx444444444444jAVAvIRTUALmACHINE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444MACosx444444444444jAVAvIRTUALmACHINE" + "'", str1.equals("444444444444MACosx444444444444jAVAvIRTUALmACHINE"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double[] doubleArray2 = new double[] { 8L, '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656                                                                                                                                                        ", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oitacificepS IPA mroftalP avaJ" + "'", str1.equals("oitacificepS IPA mroftalP avaJ"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("X86_6...", 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_6..." + "'", str3.equals("X86_6..."));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("en", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("########################/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/########################", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                                                                                                                                                                                                                                              sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                               ", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                              sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                               " + "'", str2.equals("                                                                                                                                                                                                                                                                                              sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                               "));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 0, 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 80 + "'", int3 == 80);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " ::::::::EN          1.7", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("#", 183);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mac os x", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "aaaaaaa", "...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Machine Virtual X444444444444Java OS 444444444444mac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC" + "'", str1.equals("MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444444mac OS X444444444444", "osx444444444444jAVAvIRTUALmACHINE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64x");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "macOSX");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("chineal Ma Virtuavac OS X444444444444Ja444444444444m");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("          1.7.0_80-b15          ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("n", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SOPHIE", "sunvawtvCGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunvawtvCGraphicsEnvironment" + "'", str2.equals("sunvawtvCGraphicsEnvironment"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/runrandooppl955622656/target/classes:/users/sophie/documents/defects4j/framework/lib/testgeneration/generation/randoop-currentjar" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/runrandooppl955622656/target/classes:/users/sophie/documents/defects4j/framework/lib/testgeneration/generation/randoop-currentjar"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64x");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "x86_6...", 35, 48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "mixed mode");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64x", strArray4, strArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("                                ", strArray1, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Macmixed mode mixed modeOSmixed mode mixed modeX" + "'", str8.equals("Macmixed mode mixed modeOSmixed mode mixed modeX"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "x86_64x" + "'", str9.equals("x86_64x"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "                                " + "'", str10.equals("                                "));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 44);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Users//Users/sophie/Library/Java/Extensions:/Librar", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 44, (long) (byte) 0, (long) 49);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 15, (float) 35, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     " + "'", str2.equals("mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     "));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("http://java.oracle.com", "ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com" + "'", str2.equals("http://java.oracle.com"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NE", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("51.0", 209);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                      51.0                                                                                                       " + "'", str2.equals("                                                                                                      51.0                                                                                                       "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sophie", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444" + "'", str2.equals("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("::::::::EN", "          Mac OS X          ", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("oitacificepS IPA mroftalP avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oitacificepS IPA mroftalP avaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                                                                                                              mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                              mac os x" + "'", str1.equals("                                                                                                                                                                                              mac os x"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("n", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444", (java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 600);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("hi!", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.7.0_80-b15", "x86_6410.14.3mac os xen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_6410.14.3mac os xen" + "'", str2.equals("x86_6410.14.3mac os xen"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) ' ', (int) (byte) -1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", strArray4);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny("M c2 .80-b11 2 .80-b11OS2 .80-b11 2 .80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/v          1.7.0_80-b15          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/v          1.7.0_80-b15" + "'", str1.equals("/v          1.7.0_80-b15"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                      51.0                                                                                                       ", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                      51.0                                                                                                       " + "'", str3.equals("                                                                                                      51.0                                                                                                       "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concatWith("                                   ", (java.lang.Object[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "::::::::EN");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("mixed mode", "/", 18);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("macosx", strArray14, strArray17);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("Machine Virtual X444444444444Java OS 444444444444mac", strArray9, strArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "macosx" + "'", str20.equals("macosx"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_6...", "sophiex86_64", 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.concatWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.Object[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                                                                                                                      ", strArray2, strArray7);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x86_6..." + "'", str8.equals("x86_6..."));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "                                                                                                                                                                                                      " + "'", str9.equals("                                                                                                                                                                                                      "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mac OS X", " ::::::::EN          1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "      /v          1.7.0_80-b15                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64x");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("MacOSX", (long) 15);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15L + "'", long2 == 15L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X", "..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("n", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("", "..");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("://java.oracle.com/", "                                                                                                      51.0                                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 3201);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", 23, "51X86_6...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Virtual Machine Specification", "                                ", 7);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("\n", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\n" + "'", str6.equals("\n"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "########################/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/########################                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphic" + "'", str2.equals("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphic"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, 0.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_6...", "...cosx.LWCToolkit", 600);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6..." + "'", str3.equals("x86_6..."));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "", (int) ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10.14.3MAC");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE", "/Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("            sunvawtvCGraphicsEnvironment            ", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("44444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Macmixed mode mixed modeOSmixed mode mixed modeX");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 48 + "'", int1 == 48);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("...arget/classe..", "...arget/classe..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJA", (double) 185);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 185.0d + "'", double2 == 185.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 80, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                    1.7.0_80-b15" + "'", str3.equals("                                                                    1.7.0_80-b15"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("NE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: NE is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie", "c51.0 51.0OS51.0 51.0XaM");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", (int) (byte) 0, 3201);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("86_64", "444444444444MACosx444444444444jAVAvIRTUALmACHINE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio", 185, 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio" + "'", str4.equals("/Users/sophie/Documents/defects4j/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 48, 80);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "uTF-8Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR", "...cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        long[] longArray3 = new long[] { (short) 0, (byte) 10, 100L };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("javavirtualmachinespecification", "", "444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "javavirtualmachinespecification" + "'", str3.equals("javavirtualmachinespecification"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Machine Virtual X444444444444Java OS 444444444444mac");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "51.0", (int) (short) 0, 34);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0" + "'", str4.equals("51.0"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(185, (int) (short) 1, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 185 + "'", int3 == 185);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("::::::::EN", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN" + "'", str2.equals("::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mac OS ", "mac os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(".pl_9517_1560227656                                                                                                                                                        ", "n");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("sunvawtvCGraphicsEnvironment", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("X", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphic", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("UTF-8Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("UTF-8Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "SOPHIE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("x86_6", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN" + "'", str1.equals("::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", 198, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen" + "'", str3.equals("enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("X86_6...", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio" + "'", str2.equals("/Users/sophie/Documents/defects4j/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 183, 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/runrandooppl955622656/target/classes:/users/sophie/documents/defects4j/framework/lib/testgeneration/generation/randoop-currentjar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Sun.lw4wt.m4cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("51.0", "44444444444444451.04444444444444444", "macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("444444444444mac OS X444444444444Java Virtual Machine", "sophiex86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac OS X444444444444Java Virtual Machine" + "'", str2.equals("mac OS X444444444444Java Virtual Machine"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "MacOSX");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "1.7");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty(" ::::::::EN          1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "::::::::EN          1.7" + "'", str1.equals("::::::::EN          1.7"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4625 + "'", int2 == 4625);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, 52L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("en", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_64x", 28, 34);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "mixmd modm", "/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 80, 0.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 80.0f + "'", float3 == 80.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80-b15", "/Users/sophie/Documents/defects4j/tmp/run_randoopx86_64xpl_95x86_64xx86_64x_x86_64x56022x86_64x656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentx86_64xjar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("444444444444mac OS X444444444444Java Virtual Machine", "mixed mode", "                                                                                                                                                                                              mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444mac OS X444444444444Java Virtual Machine" + "'", str3.equals("444444444444mac OS X444444444444Java Virtual Machine"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 15L, (double) 97, (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.0d + "'", double3 == 15.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                                                                                                                                                                              mac OS X");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("                                   ", "Macmixed mode mixed modeOSmixed mode mixed modeX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "444444444444MAC os x444444444444jAVA vIRTUAL mACHINE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("pecifiction chine Virtul v", (int) (byte) 100, "/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmppecifiction chine Virtul v/Users/sophie/Documents/defects4j/tmp" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmppecifiction chine Virtul v/Users/sophie/Documents/defects4j/tmp"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.awt.CGmixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.awt.CGmixed mode is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN44444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                                                                                                                                                                                                              sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                               ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("mixmd modm", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                          mixmd modm" + "'", str2.equals("                                                                                          mixmd modm"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Mac OS X", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment", "/USE...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("86_64", 44, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE", "Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn/Users//Users/sophie/Library/Java/Extensions:/Librar", "", "::::::::EN          1.7");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v4cq2n2x4n4fc4gn/T/4ac/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreOS/Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jre /Library/Java/JavaVirtual4achines/jdk474_84jdk/4ontents/Home/jreX/var/folders/_v/6v597zmn4_v");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ca4/T/ng4cf4n4x2n2qc4v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ca4/T/ng4cf4n4x2n2qc4v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ca4/T/ng4cf4n4x2n2qc4v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno" + "'", str1.equals("v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ca4/T/ng4cf4n4x2n2qc4v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ca4/T/ng4cf4n4x2n2qc4v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ca4/T/ng4cf4n4x2n2qc4v_4nmz795v6/v_/sredlof/rav/Xerj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/ erj/emoH/stnetno4/kdj48_474kdj/senihca4lautriVavaJ/avaJ/yrarbiL/SOerj/emoH/stnetno"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                    10.14.3MAC", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 209, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJaJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJav" + "'", str3.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJaJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJav"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 209);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                 " + "'", str2.equals("                                                                                                                                                                                                                 "));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("hine Virtual X444444444444Java OS 444444444444", "sunvawtvCGraphicsEnvironment", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7", "/users/sophie/documents/defects4j/tmp/runrandooppl955622656/target/classes:/users/sophie/documents/defects4j/framework/lib/testgeneration/generation/randoop-currentjar", 170);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "::::::::EN");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE" + "'", str1.equals("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(209);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("mp/runrandooppl95562265", "sophiex86_64", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.Object[] objArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(objArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/USERS/SOPHIE", "      /v          1.7.0_80-b15                ", 35, 600);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE      /v          1.7.0_80-b15                " + "'", str4.equals("/USERS/SOPHIE      /v          1.7.0_80-b15                "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("         Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment", 23, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("10.14.3", 3201, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("X86_6...", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("..", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".." + "'", str3.equals(".."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "M c2 .80-b11 2 .80-b11OS2 .80-b11 2 .80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        double[] doubleArray2 = new double[] { 8L, '4' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.0d + "'", double4 == 52.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.0d + "'", double6 == 8.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "sophiex86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double[] doubleArray4 = new double[] { (byte) 1, (-1), (byte) 0, (short) -1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80." + "'", str2.equals("Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80."));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("chineal Ma Virtuavac OS X444444444444Ja444444444444m");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "chineal Ma Virtuavac OS X444444444444Ja444444444444m" + "'", str1.equals("chineal Ma Virtuavac OS X444444444444Ja444444444444m"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "", (int) ' ');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie", strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit", strArray1, strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit" + "'", str8.equals("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 27, (double) 272, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::EN" + "'", str2.equals("::::::::EN"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sophie", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/USERS/SOPHI", "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("osx444444444444jAVAvIRTUALmACHI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X", "mixedmode", "x86_6");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("x86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie/users/sophie", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", 3201);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randooppl_95_56022656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE" + "'", str1.equals("444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Machine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444mac", "", "NE");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("tiklooTCWL.xsoc...", "444444444444mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sophiesophiesophiesopsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "machine virtual x444444444444java os 444444444444mac");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_6", 6, "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/x86_6" + "'", str3.equals("/x86_6"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                          mixmd modm", 7, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("51.0", (java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac51.0 51.0OS51.0 51.0X" + "'", str3.equals("Mac51.0 51.0OS51.0 51.0X"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS X" + "'", str4.equals("Mac OS X"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN", "hine Virtual X444444444444Java OS 444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN" + "'", str2.equals("::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Macmixed mode mixed modeOSmixed mode mixed modeX", "::::::::en", "x86_6...", 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Macmixed mode mixed modeOSmixed mode mixed modeX" + "'", str4.equals("Macmixed mode mixed modeOSmixed mode mixed modeX"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Specification Machine Virtual Java", "://java.oracle.com/", "...arget/classe...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/USERS/SOPHI", "/USERS/SOPHIE      /v          1.7.0_80-b15                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHI" + "'", str2.equals("/USERS/SOPHI"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(600, 198, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 600 + "'", int3 == 600);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("444444444444MACosx444444444444jAVAvIRTUALmACHINE", "444444444444mac OS X444444444444Java Virtual Machin");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("SOPHIE", "51X86_6...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "", 49, 29);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("tiklooTCWL.xsoc...", "444444444444mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "TGE...", "TGE...", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("SOPHIE", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SOPHIE" + "'", str2.equals("SOPHIE"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("TGE...", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("         Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment", "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", "/Users/sophie/Documents/defects4j/tmppecifiction chine Virtul v/Users/sophie/Documents/defects4j/tmp");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         sere Peepe4om API nt/osesoeps4UOoeoe/sere Peepe4om API nt/osesoeps4U sere Peepe4om API nt/osesoeps4UC4ot4oeps4Uso4Um/Up" + "'", str3.equals("         sere Peepe4om API nt/osesoeps4UOoeoe/sere Peepe4om API nt/osesoeps4U sere Peepe4om API nt/osesoeps4UC4ot4oeps4Uso4Um/Up"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "...arget/classe..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("     ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio", "", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                    10.14.3mac", "Sun.lw4wt.m4cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lw4wt.m4cosx.LWCToolkit" + "'", str2.equals("Sun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/.:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS " + "'", str1.equals("mac OS "));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("SOPHIE", "444444444444mac OS X444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("44444444444444451.04444444444444444", "1.7.0_80");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(183.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("1.7", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie", "", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                 ::::::::EN          1.7                                                                                                                                                                                                                                                                                                ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...cosx.L\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("mac OS X", "hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment", "/L");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment" + "'", str2.equals("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 3201, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 27, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                              mac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/users/sophie", 4, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", "machine virtual x444444444444java os 444444444444mac", 183);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                          mixmd modm", "::::::::EN          1.7");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("NE", "mac OS ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NE" + "'", str3.equals("NE"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 80);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                " + "'", str2.equals("                                                                                "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("444444444444MAC os x444444444444jAVA vIRTUAL mACHINE", "mixmd modm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("4sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle#Corporation", (double) 48L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 48.0d + "'", double2 == 48.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                                                    ", 23, 185);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Macmixed mode mixed modeOSmixed mode mixed modeX", "", 4625);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 48 + "'", int3 == 48);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 46, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaa", "/x86_6", "         Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaa" + "'", str3.equals("aaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, (double) 600, 48.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 600.0d + "'", double3 == 600.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("          1.7.0_80-b15          ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual", "\n", 49);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("hi!", "x86_64");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray8, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("444444444444mac OS X444444444444Java Virtual Machine", strArray4, strArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, ' ', 600, 23);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str12.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "444444444444mac OS X444444444444Java Virtual Machine" + "'", str15.equals("444444444444mac OS X444444444444Java Virtual Machine"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("x");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", (int) '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str3.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                          mixmd modm", "X86_6...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE...", "sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment", "x86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE..." + "'", str3.equals("...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE..."));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n", "Machine Virtual X444444444444Java OS 444444444444mac", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("TGE...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 18, (int) (byte) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                                                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE...", 3201);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE..." + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE..."));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("::::::::EN          1.7", "", "X86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN44444444444444444444444444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                ", 48, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                " + "'", str3.equals("                                                                                "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hine Virtual X444444444444Java OS 444444444444", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hine Virtual X444444444444Java OS 444444444444" + "'", str2.equals("hine Virtual X444444444444Java OS 444444444444"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment", "/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment" + "'", str2.equals("sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mac OS X", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJaJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("..", "/USERS/SOPHIE      /v          1.7.0_80-b15                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("::::::::en", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::en" + "'", str2.equals("::::::::en"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                                                    1.7.0_80-b15", "sophiex86_64", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                                                                              mac os x", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) ' ', (int) (byte) -1);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656                                                                                                                                                        ");
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656                                                                                                                                                        ", strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "::::::::en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX", 183, "Specification Machine Virtual Java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Specification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JaX86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX" + "'", str3.equals("Specification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JaX86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VM", "x86_6...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "                                                    ", (int) (byte) 10);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str4.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/uSERS//uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Specification Machine Virtual Java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Specifi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/USE...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaXSOcam");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 272, (long) 185, (long) 48);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 272L + "'", long3 == 272L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b15", 32, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15/var/folders/_v/6v59" + "'", str3.equals("1.7.0_80-b15/var/folders/_v/6v59"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/USE...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "javavirtualmachinespecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("M c2 .80-b11 2 .80-b11OS2 .80-b11 2 .80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                ", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed mode", "/", 18);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("macosx", strArray4, strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "macosx" + "'", str10.equals("macosx"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }
}

