import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        char[] charArray6 = new char[] { 'a', 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444Java Virtual Machine", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                4", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64x", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "N/L");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X", (java.lang.CharSequence) "Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { 'a', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444Java Virtual Machine", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::EN", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Sun.lw4...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 29, 35L, 15L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444444444451.04444444444444444                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mac os x", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("sun.awt.CGraphicsEnvironment", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/v          1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656", "sunvawtvcgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("mac os x", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("tnemnorivnEscihparGC.twa.nusposeihposeihposeihpo          51b-08_0.7.1          ", 3201);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3201 + "'", int2 == 3201);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit", "44444444444444451.04444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit" + "'", str2.equals("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                               1.7", "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x", "/Users/sophie");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "ORACLE#CORPORATION", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("osxjAVAvIRTUALmACHI", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "osxjAVAvIRTUALmACHI" + "'", str8.equals("osxjAVAvIRTUALmACHI"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("noitacificepS enihcaM lautriV avaJ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str2.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit", 15L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15L + "'", long2 == 15L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("racle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("chineal Ma Virtuavac OS X444444444444Ja444444444444m", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chineal Ma Virtuavac OS X444444444444Ja444444444444m" + "'", str3.equals("chineal Ma Virtuavac OS X444444444444Ja444444444444m"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sophiex86_64", "                                    10.14.3mac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophiex86_6" + "'", str2.equals("sophiex86_6"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", "Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("24.80-b11", "10.14.34aaaaaaaaaaaaaaaaaaaaaaaa", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaa#########################################################################################################################################################################################################################################################################", "/USERS/SOPHI");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        long[] longArray3 = new long[] { (byte) -1, ' ', (short) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("mac OS ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Sun.lwawt.macosx.LWCToolkit", 183, 178);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("mc os x", "/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEtmpNE/NErunNE_NErandoopNE.NEplNE_NE9517NE_NE1560227656NE/NEtargetNE/NEclassesNE:/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEframeworkNE/NElibNE/NEtestNE_NEgenerationNE/NEgenerationNE/NErandoopNE-NEcurrentNE.NEjar", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJA", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL####TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JA" + "'", str3.equals("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL####TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JA"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/users/sophie", "Java HotSpot(TM) 64-Bit Server VM", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie" + "'", str3.equals("/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", 46, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X" + "'", str1.equals("X"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.awt.CGmixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444::::::::EN44444444444444444444444444444444"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie", "M c2 .80-b11 2 .80-b11OS2 .80-b11 2 .80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit", "                                                                                 aaaaaaa                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("         Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment", "Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X", 26);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "         Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment" + "'", str5.equals("         Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X", (int) (byte) 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", charSequence2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Mac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0X", "                                                                                                                                                                                mc os x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "UTF-8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "MachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC" + "'", str1.equals("MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("::::::::EN          1.7", 3, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.Class<?> wildcardClass4 = byteArray1.getClass();
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(48.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x8", "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/#########################################################################################################################", 167);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("10.14.3MAC", "/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("51X86_6...", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              51X86_6..." + "'", str2.equals("              51X86_6..."));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("         Oracle Corporationironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporationironment" + "'", str1.equals("Oracle Corporationironment"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                    ", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 10);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mac OS ", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 49);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny("sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment                                                    sunvawtvCGraphicsEnvironment", strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach(":", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + ":" + "'", str12.equals(":"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, (int) '#', 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 183, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Ja...", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificati", 0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaamc os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificati" + "'", str3.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificati"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "           1.7.0_80-B15            ", "/Users/10.14.3MAC/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/10.14.3MAC/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/USE...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USE..." + "'", str1.equals("/USE..."));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        char[] charArray14 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtual Machine", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          1.7.0_80-b15          ", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR", charArray14);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/10.14.3MAC/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/10.14.3MAC/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJA", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 29 + "'", int20 == 29);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt.CGraphicsEnvironmen", (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 27, (float) 15, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                44444444444444444444444444444sun.awt.CGmixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API S", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API S" + "'", str2.equals("Java Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API S"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio", "uTF-8Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                                                                                                                                                              mac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SOPHIE", 3201);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           SOPHIE" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           SOPHIE"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Uss/sph/Dcs/dfcs4j/p/_dp.pl_9517_1560227656/g/clsss:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 147 + "'", int1 == 147);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("n/l", 600);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/l" + "'", str2.equals("n/l"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("ORACLE#CORPORATION", (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("mixmd modm", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        char[] charArray10 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("UTF-8Java HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("              x86_64               ", "mac OS");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mac", 209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("mac OS ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"mac OS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN::::::::EN", "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJA", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("                                    10.14.3mac", "javavirtualmachinespecification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", (java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mac OS ", "mac OS X", 48, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mac OS mac OS X" + "'", str4.equals("mac OS mac OS X"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("", 3201);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("c51.0 51.0OS51.0 51.0XaM", 209, "mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac2c51.0 51.0OS51.0 51.0XaMmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24" + "'", str3.equals("mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac2c51.0 51.0OS51.0 51.0XaMmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("              51X86_6...", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        char[] charArray5 = new char[] { 'a', 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444Java Virtual Machine", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                   ", charArray5);
        java.lang.Class<?> wildcardClass9 = charArray5.getClass();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 272, (long) 1, 31L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 272L + "'", long3 == 272L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" ::::::::EN          1.7", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7" + "'", str2.equals(" ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEtmpNE/NErunNE_NErandoopNE.NEplNE_NE9517NE_NE1560227656NE/NEtargetNE/NEclassesNE:/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEframeworkNE/NElibNE/NEtestNE_NEgenerationNE/NEgenerationNE/NErandoopNE-NEcurrentNE.NEjar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/users/sophie", " ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("", "UTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VM", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("noitacificepS enihcaM lautriV ava", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("51X86_6...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"51X86_6...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJhi!noitacificepS enihcaM lautriV avaJ", "                                                                                 aaaaaaa                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3200, (double) 147, (double) 80.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3200.0d + "'", double3 == 3200.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                       /                        ", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       /                        " + "'", str2.equals("                       /                        "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444", "ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OSSun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444" + "'", str2.equals("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "Sun.lwawt.macosx.LWCToolkit", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxracle Corporation", (java.lang.CharSequence) "Mac");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "10.14.3MAC");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tnemnorivnEscihparGC.twa.nus" + "'", str1.equals("tnemnorivnEscihparGC.twa.nus"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("JavaVirtualMachineSpecification", "Java Virtual Machine Specification");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 6, 167);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Specification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JaX86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX", "x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sunvawtvCGraphicsEnvironment", (java.lang.CharSequence) "                                                                                                                                                                                              mac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.4wt.CGr4phicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.4WT.cgR4PHICSeNVIRONMENT" + "'", str1.equals("SUN.4WT.cgR4PHICSeNVIRONMENT"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("              51X86_6...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51X86_6..." + "'", str1.equals("51X86_6..."));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", ".p/jL/aija/Ou//iO/O                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String[] strArray5 = new java.lang.String[] { "x86_64", "10.14.3", "mac os x", "en" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6);
        java.lang.String[] strArray8 = null;
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaa##########################################################################################...", strArray6, strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "                                                                                                                                                                                              mac OS X", 29, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "x86_6410.14.3mac os xen" + "'", str7.equals("x86_6410.14.3mac os xen"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "aaaaaaa##########################################################################################..." + "'", str9.equals("aaaaaaa##########################################################################################..."));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        float[] floatArray6 = new float[] { 'a', 170, (byte) 10, 'a', 0L, 10.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 170.0f + "'", float7 == 170.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 170.0f + "'", float9 == 170.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 170.0f + "'", float10 == 170.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("s/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "#", "://j   .      .  m/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users//Users/sophie/Library/Java/Extensions:/Librar", "                                                                                                                                          mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Users/sophie/Library/Java/Extensions:/Librar" + "'", str2.equals("/Users//Users/sophie/Library/Java/Extensions:/Librar"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                                 ", "", "/Uss/sph/Dcs/dfcs4j/p/_dp.pl_9517_1560227656/g/clsss:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 600);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                 " + "'", str4.equals("                                                                                                 "));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.4wt.CGr4phicsEnvironment", "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("           1.7.0_80-b15            ", 183, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("               46_68x              ", "mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode", (int) ' ');
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "UTF-8", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny("sunvawtvcgraphicsenvironment", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("..", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophiex86_64", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 31, 6L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("http://java.oracle.com", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", '4');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 12, 1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X", "           1.7.0_80-B15            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("noitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV ava", "              51X86_6...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV ava" + "'", str2.equals("noitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV avanoitacificepS enihcaM lautriV ava"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7", "/Users/sophie/Documents/defects4j/tmppecifictionchineVirtulv/Users/sophie/Documents/defects4j/tmp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("", "aaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X" + "'", str1.equals("X"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "US");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("::::::::en", "/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("sun.a", "/v          1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7" + "'", str3.equals("                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx                               1.7"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           SOPHIE", (java.lang.CharSequence) "Sun.lw4...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray13 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtual Machine", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          1.7.0_80-b15          ", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny("e/Documents/defects4j/tmppecifiction chine Virtul v/Users/sophie/Documents/defects4j/tmp", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 31 + "'", int18 == 31);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("UTF-8Java HotSpot(TM) 64-Bit Server VM", "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8Java HotSpot(TM) 64-B" + "'", str2.equals("UTF-8Java HotSpot(TM) 64-B"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/def", 44, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("     ", "                                                                 macOSXaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     " + "'", str3.equals("     "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie" + "'", str1.equals("/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x", (java.lang.CharSequence) "/users/sophie");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x" + "'", charSequence2.equals("mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR" + "'", str2.equals("ASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("tnemnorivnEscihparGC.twa.nusposeihposeihposeihpo          51b-08_0.7.1          ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users//Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Platform API Specification", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("10.14.3mac", "Java Platform API S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 12, (float) '4', 183.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "1.7.0_80", (int) (short) 100);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR" + "'", str6.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray13 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("10.14.3", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "86_64", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444451.04444444444444444", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                    10.14.3MAC");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                       /                        ", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       /                        " + "'", str3.equals("                       /                        "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ...MP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGE...", "/users//users/sophie/library/java/extensions:/librar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.awt.CGraphicsEnvironmen", (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 272L, (double) 198L, (double) 8L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X", "", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X" + "'", str3.equals("Mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users//Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("RS/SOPHI");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "", (int) ' ');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny("/Users/sophie", strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX", "10.14.3MAC");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80-b15/var/folders/_v/6v59", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 255");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                    10.14.3mac", "mac OS X444444444444Java Virtual Machine", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", "Java Platform API SpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVir", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaXSOcam", "Sun.lw4...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                          ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("lautriV avaJ444444444444X SO cam444444444444eihpos/sresU/autriV avaJ444444444444X SO cam444444444444", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 171");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("osx444444444444jAVAvIRTUALmACHI", "Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "osx444444444444jAVAvIRTUALmACHI" + "'", str2.equals("osx444444444444jAVAvIRTUALmACHI"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("macosx", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      macosx" + "'", str2.equals("                      macosx"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("noitacificepS enihcaM lautriV ava", "Oracle Corporationironment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hine Virtual X444444444444Java OS 444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual", "Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "uTF-8Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("SOPHIE");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        float[] floatArray1 = new float[] { 10 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("24.80-b11", "                               1.7", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/USERS/SOPHI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophi" + "'", str1.equals("/users/sophi"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(178, 10, 80);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 183L, 18.0f, (float) 3L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 183.0f + "'", float3 == 183.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophiesophiesophiesopsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX" + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio", "hineVirtualX444444444444JavaOS444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Machine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444macMachine Virtual X444444444444Java OS 444444444444mac", "", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3MAC", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("osx444444444444jAVAvIRTUALmACHI", "OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("OPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        float[] floatArray1 = new float[] { 10 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        double[] doubleArray4 = new double[] { (byte) 1, (-1), (byte) 0, (short) -1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment", "Mac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("mac OS mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac OS mac OS X" + "'", str2.equals("mac OS mac OS X"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun.awt.CGmixed mode", "                                         mac os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGmixed mode" + "'", str2.equals("sun.awt.CGmixed mode"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("osx444444444444jAVAvIRTUALmACHINEosx444444444444", "4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun....");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users//Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("M c2 .80-b11 2 .80-b11OS2 .80-b11 2 .80-b11X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M C2 .80-B11 2 .80-B11OS2 .80-B11 2 .80-B11X" + "'", str1.equals("M C2 .80-B11 2 .80-B11OS2 .80-B11 2 .80-B11X"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/#########################################################################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("444444444444mac OS X444444444444", "...arget/classe...", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphicsEnvironment", "USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/USE...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("..");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                          /Users/sophie                                          " + "'", str2.equals("                                          /Users/sophie                                          "));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "              51X86_6...", "4sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("noitacificepS enihcaM lautriV avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitacificepS enihcaM lautriV avaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/USE...", "racle Corporation", "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USE..." + "'", str3.equals("/USE..."));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIE      /v          1.7.0_80-b15                ", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR", 28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC", (double) 8.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtual Machine");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656                                                                                                                                                        ", "                                                                         4                          ", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss" + "'", str3.equals("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str1.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.LWCToolkit", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("noitacificepS enihcaM lautriV avaJ", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "tnemnorivnEscihparGC.twa.nus");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOPHIE      /v          1.7.0_80-b15                ", "/users/sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11                          " + "'", str2.equals("24.80-b11                          "));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11X", "JavaVirtualMachineSpecification", "              51X86_6...");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444MACosx444444444444jAVAvIRTUALmACHINE", "                                    10.14.3mac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444MACosx444444444444jAVAvIRTUALmACHINE" + "'", str2.equals("444444444444MACosx444444444444jAVAvIRTUALmACHINE"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users//Users/sophie/Library/Java/Extensions:/Librar", 47, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users//Users/sophie/Library/Java/Extensions:/Librar" + "'", str3.equals("/Users//Users/sophie/Library/Java/Extensions:/Librar"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJA", "           1.7.0_80-B15            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJA" + "'", str2.equals("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJA"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.Class<?> wildcardClass6 = shortArray1.getClass();
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                                                                                                                                                                              mac os x", "http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ".pl_9517_1560227656                                                                                                                                                        ", (java.lang.CharSequence) "86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        long[] longArray2 = new long[] { 12, 48 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.Class<?> wildcardClass4 = longArray2.getClass();
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 12L + "'", long3 == 12L);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10.14.34aaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtual Machin");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("javavirtualmachinespecification", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR" + "'", str2.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("444444444444mac OS X444444444444Java Virtual Machin", "         Oracle Corporationironment", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                  a                                                                                 ", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("          1.7.0_80-b15          ", "                                    10.14.3mac");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################################################################" + "'", str3.equals("####################################################################################################"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, (float) 2, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hineVirtualX444444444444JavaOS444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("::::::::en", 3, "/USERS/SOPHIE      /v          1.7.0_80-b15                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::en" + "'", str3.equals("::::::::en"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", "Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1, 0.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac2c51.0 51.0OS51.0 51.0XaMmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac2c51.0 51.0os51.0 51.0xammac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac24" + "'", str1.equals("mac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac2c51.0 51.0os51.0 51.0xammac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac24.80-b11 24.80-b11os24.80-b11 24.80-b11xmac24"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("          1.7.0_80-b15          ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("uTF-8Java HotSpot(TM) 64-Bit Server VM", 185);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 185 + "'", int2 == 185);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/USERS/SOPHI", "Java Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API SpecificatioJava Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHI" + "'", str2.equals("/USERS/SOPHI"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophi" + "'", str1.equals("/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophi"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("...cosx.LWCToolkit", "444444444444mac os x444444444444java virtual machine", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("UTF-8Java HotSpot(TM) 64-Bit Server VM", "4sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("UTF-8Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                       /                        ", "macOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        int[] intArray3 = new int[] { 35, 12, (byte) 0 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444mac os x444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "Java Virtual Machine Specification", 8);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1", strArray4, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concatWith("", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "444444444444mac os x444444444444" + "'", str10.equals("444444444444mac os x444444444444"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("N/L");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"N/L\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmppecifiction chine Virtul v/Users/sophie/Documents/defects4j/tmp", "                                                                                                                                          mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("444444444444mac OS X444444444444Java Virtual Machine", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a Virtual Machine" + "'", str2.equals("a Virtual Machine"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        int[] intArray4 = new int[] { 18, 2, 100, (-1) };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x", "10.14.3mac", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444MAC os x444444444444jAVA vIRTUAL mACHINE", "10.14.3mac");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", strArray5, strArray8);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "...arget/classe..");
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("://j   .      .  m/", strArray5, strArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "444444444444MAC os x444444444444jAVA vIRTUAL mACHINE" + "'", str10.equals("444444444444MAC os x444444444444jAVA vIRTUAL mACHINE"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str11.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.0", "                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn/Users//Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR", 29, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR" + "'", str3.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...essalc/tegra...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("Java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop                                   pl_95                                                                      _                                   56022                                   656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current                                   jar"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        double[] doubleArray4 = new double[] { (byte) 1, (-1), (byte) 0, (short) -1 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/#########################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("          1.7.0_80-b15          ophiesophiesophiesopsun.awt.CGraphic", "10.14.3", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                   ", "sophie", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("TGE...", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TGE..." + "'", str2.equals("TGE..."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x" + "'", str4.equals("x"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/USERS/SOPHI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("RS/SOPHI", "              x86_64               ", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, 6L, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mc os x", 167, "Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/mc os xMac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/" + "'", str3.equals("Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/mc os xMac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64xx86_64xx86_64xXSOcamx86_64xx86_64xx86_64xx", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 80, (double) 48L, (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("UTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("UTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "x86_6410.14.3mac os xen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Specification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JaX86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Specification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JaX86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX" + "'", str1.equals("Specification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JavaSpecification Machine Virtual JaX86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mp/runrandooppl95562265", "TGE...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("mac OS mac OS X", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int[] intArray4 = new int[] { 18, 2, 100, (-1) };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("RAJaTNERRUC-POODNAR/NOITARENEG/NOITARENEGaTSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRATaaaaLPaPOODNARaNUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRES");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RAJaTNERRUC-POODNAR/NOITARENEG/NOITARENEGaTSET/BIL/KROWEMARF/J4STCEFED/STNEMUCOD/EIHPOS/SRESU/:SESSALC/TEGRATaaaaLPaPOODNARaNUR/PMT/J4STCEFED/STNEMUCOD/EIHPOS/SRES\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("s/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "  mixmd modm", 167);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac51.0 51.0OS51.0 51.0X", "444444444444mac OS X444444444444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "osx444444444444jAVAvIRTUALmACHINE");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "X86_64XX86_64XX86_64XXSOCAMX86_64XX86_64XX86_64XX");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Mac51.0 51.0OS51.0 51.0X" + "'", str6.equals("Mac51.0 51.0OS51.0 51.0X"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        char[] charArray13 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtual Machine", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray13);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "://java.oracle.com/", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mac OS mac OS X", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie" + "'", str1.equals("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("                                                                                                                                                                                                                                                                                                 ::::::::EN          1.7                                                                                                                                                                                                                                                                                                ", "Sun.lw4wt.m4cosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X", 170, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "     uTF-8Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("4sun.lwawt.macosx.LWCToolkit", "         4Oracle4 4Corporationironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        int[] intArray1 = new int[] { 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...COSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.lwctoolkit" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.lwctoolkit"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                            Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment                                   ", "", "/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie", 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                            Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment                                   " + "'", str4.equals("                                            Java Platform API SpecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment                                   "));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", ".p/jL/aija/Ou//iO/O                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss" + "'", str2.equals("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", (java.lang.CharSequence) "         sere Peepe4om API nt/osesoeps4UOoeoe/sere Peepe4om API nt/osesoeps4U sere Peepe4om API nt/osesoeps4UC4ot4oeps4Uso4Um/Up");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                               1.7", "Java Platform API SpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVir");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               1.7" + "'", str2.equals("                               1.7"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', (int) '#', (-1));
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "XSOcam");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "x86_64" + "'", str8.equals("x86_64"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Java Platform API Specification", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        char[] charArray12 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("10.14.3", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "86_64", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny("44444444444444451.04444444444444444                                                                                                                                                      ", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, 52L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen4444444444444444", "n/l");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String[] strArray5 = new java.lang.String[] { "x86_64", "10.14.3", "mac os x", "en" };
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "mixed mode");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64x", strArray9, strArray11);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray11, "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR");
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("444444444...                                                                                     ", strArray6, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Macmixed mode mixed modeOSmixed mode mixed modeX" + "'", str13.equals("Macmixed mode mixed modeOSmixed mode mixed modeX"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "x86_64x" + "'", str14.equals("x86_64x"));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaa#########################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("UTF-8Java HotSpot(TM) 64-Bit Server VM", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("UTF-8Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 170, "444444444...                                                                                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar4" + "'", str3.equals("4/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar4"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.", 0, 183);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/ophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                      51.0                                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("...essalc/tegra...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...essalc/tegra...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444mac os x444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "Java Virtual Machine Specification", 8);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "444444444444mac os x444444444444" + "'", str9.equals("444444444444mac os x444444444444"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(" ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7 ::::::::EN          1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: " + "'", str1.equals("7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: "));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/USERS/SOPHIE      /v          1.7.0_80-b15                ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             mac/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreos/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrex", (long) 170);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 170L + "'", long2 == 170L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        int[] intArray1 = new int[] { 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.Class<?> wildcardClass4 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL####TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL####TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JA" + "'", str1.equals("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL####TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JA"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4sun.lwawt.macosx.LWCToolkit/Users/sophie4sun....", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun....4sun.lwawt.macosx.LWCToolkit/Users/sophie" + "'", str2.equals("sun....4sun.lwawt.macosx.LWCToolkit/Users/sophie"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, 0.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        char[] charArray7 = new char[] { 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444Java Virtual Machine", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNaRANDOOPaPLaaaaTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTaGENERATION/GENERATION/RANDOOP-CURRENTaJAR", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "::::::::EN", charArray7);
        java.lang.Class<?> wildcardClass13 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("jv Pltform API Specifiction", "7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: ", "macOSX", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jv Pltform API Specifiction" + "'", str4.equals("jv Pltform API Specifiction"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("racle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"racle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(" ::::::::EN          1.7", ".pl_9517_1MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                    10.14.3mac");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        char[] charArray3 = new char[] { '#' };
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "NE", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("UTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VMUTF-8Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("osx444444444444jAVAvIRTUALmACHINEosx444444444444j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"osx444444444444jAVAvIRTUALmACHINEosx444444444444j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie/Library/Ja...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.4wt.CGr4phicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.4wt.cgr4phicsenvironment" + "'", str1.equals("sun.4wt.cgr4phicsenvironment"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x", "osx444444444444jAVAvIRTUALmACHINEosx444444444444j", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x" + "'", str3.equals("mac24.80-b11 24.80-b11os24.80-b11 24.80-b11x"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("poration", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "poration" + "'", str2.equals("poration"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("444444444444mac OS X444444444444Java Virtual Machin", "                                          /Users/sophie                                          ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        char[] charArray5 = new char[] { '#' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("XSOcam", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny("            sunvawtvCGraphicsEnvironment            ", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.lwctoolkit" + "'", str1.equals("sun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444::::::::EN444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444451.04444444444444444                                                                                                                                                      ", "Mac2a.80-b11 2a.80-b11OS2a.80-b11 2a.80-b11X                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sunvawtvCGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                44444444444444444444444444444sun.awt.CGmixed mode", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                44444444444444444444444444444sun.awt.CGmixed mode" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                44444444444444444444444444444sun.awt.CGmixed mode"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("SERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPLTARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS" + "'", str1.equals("MAC OS"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("chineal Ma Virtuavac OS X444444444444Ja444444444444m", (int) '#', 3200);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                      51.0                                                                                                       ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/#var#/#folders#/#_#v#/#6#v#597#zmn#4#_#v#31#cq#2#n#2#x#1#n#4#fc#0000#gn#/#T#/#ophie" + "'", str4.equals("/#var#/#folders#/#_#v#/#6#v#597#zmn#4#_#v#31#cq#2#n#2#x#1#n#4#fc#0000#gn#/#T#/#ophie"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/users/sophi", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophi" + "'", str2.equals("/users/sophi"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "aaaaaaa##########################################################################################...", "n/l");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             mac/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreos/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre /library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrex", "machine virtual x444444444444java os 444444444444mac");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "hine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X                                    10.14.3machine Virtual X444444444444Java OS 444444444444hine Virtual X444444444444JavaMac51.0 51.0OS51.0 51.0X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4626 + "'", int1 == 4626);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/v          1.7.0_80-b15          ", (int) 'a', "86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "86_6486_6486_6486_6486_6486_6486_6486_6486_6486_6486_6486_6486_/v          1.7.0_80-b15          " + "'", str3.equals("86_6486_6486_6486_6486_6486_6486_6486_6486_6486_6486_6486_6486_/v          1.7.0_80-b15          "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                          mixmd modm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                          mixmd mod" + "'", str1.equals("                                                                                          mixmd mod"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("osx444444444444jAVAvIRTUALmACHINE", "pecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "osx444444444444jAVAvIRTUALmACHINE" + "'", str2.equals("osx444444444444jAVAvIRTUALmACHINE"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                               1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7f + "'", float1 == 1.7f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NE", "           1.7.0_80-b15            ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.String[] strArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss", strArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        char[] charArray6 = new char[] { '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaa", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mac OS X", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("tnemnorivnEscihparGC.twa.nusposeihposeihposeihpo          51b-08_0.7.1          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tnemnorivnEscihparGC.twa.nusposeihposeihposeihpo          51b-08_0.7.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sophie");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "10.14.3MAC");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny("sun....4sun.lwawt.macosx.LWCToolkit/Users/sophie", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/10.14.3MAC/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/10.14.3MAC/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str6.equals("/Users/10.14.3MAC/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/10.14.3MAC/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str8.equals("/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                4", "x86_6410.14.3mac os xen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Mac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0X", "Y/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                                                                                          mac OS X", "sunvawtvcgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.4wt.CGr4phicsEnvironment" + "'", str4.equals("sun.4wt.CGr4phicsEnvironment"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str6.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "                                                4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                4" + "'", str1.equals("                                                4"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray14 = new char[] { '4', ' ', '4', '#', '#', '4' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny("444444444444mac OS X444444444444", charArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "444444444444mac OS X444444444444Java Virtual Machine", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray14);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          1.7.0_80-b15          ", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray14);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...cosx.LWCToolkit", charArray14);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray14);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API SJava Platform API S", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                    :                                                                                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/T/NG0000CF4N1X2N2QC13V_4NMZ795V6/V_/SREDLOF/RAV/", "51X86_6...", 209);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                ", "     ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/v_4nmz795v6/v_   v_4nmz795v6/v_/", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("Java Platform API Specificatio", "1.7.0_80-b15/var/folders/_v/6v59");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN#RANDOOP#PL#95#56#22#656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST#GENERATION/GENERATION/RANDOOP-CURRENT#JAR"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64", "hi!", 0, 47);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("mixed mode", 2, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("racle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporationracle Corporation", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "racle Corp" + "'", str2.equals("racle Corp"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specificatio", "Java HotSpot(TM) 64-Bit Server VM", "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn/Users//Users/sophie/Library/Java/Extensions:/Librar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Usnns/snnhnn/Dncumnnns/dnfncnsnj/nnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnn" + "'", str3.equals("/Usnns/snnhnn/Dncumnnns/dnfncnsnj/nnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnnnnnnnnnnnnunlnnnchnnnnnnncnfncnnnn"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Mac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0X" + "'", str1.equals("Mac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0XsophieMac51.0 51.0OS51.0 51.0X"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("::::::::EN", "mc os x");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "::::::::EN" + "'", str2.equals("::::::::EN"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironmen" + "'", str1.equals("sun.awt.cgraphicsenvironmen"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("              x86_64               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("osx444444444444jAVAvIRTUALmACHINEosx444444444444j", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("24.80-B11", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("4444444444444444444444444444444444444444444444", "444444444444MAC OS X444444444444JAVA VIRTUAL MACHINE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: 7.1          NE:::::::: ", "MAC OS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) 48L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 48.0f + "'", float3 == 48.0f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", "########################/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/########################");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656                                                                                                                                                        ", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                                                                                                                                                                              mac os x", "Oracle Corporationironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MACHINE VIRTUAL X444444444444JAVA OS 444444444444MAC");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("sun.awt.CGmixed mode", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGmixed mode" + "'", str2.equals("sun.awt.CGmixed mode"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                          mixmd mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.a", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("mixed mode", "/v          1.7.0_80-b15          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        char[] charArray6 = new char[] { '#' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://java.oracle.comhttp://javaSun.lw4wt.m4cosx.LWCToolkit", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaa", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual", "\n", 49);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss" + "'", str1.equals("Users/sophie/Documents/defectsj/tmp/run_randoop.pl_9517_1560227656ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("macOSXaaaa:aaaaaaaaaaaaaaaaaaaaaaaaa", "sun.4wt.cgr4phicsenvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("24.80-b11                          ", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("#", 80);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("sun....4sun.lwawt.macosx.LWCToolkit/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun....4sun.lwawt.macosx.LWCToolkit/Users/sophie" + "'", str1.equals("sun....4sun.lwawt.macosx.LWCToolkit/Users/sophie"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasun.lwawt.macosx.LWCToolkitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("RS/SOPHI");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) '#', (-1));
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny("         Oracle Corporationironment", strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.concatWith(" ::::::::EN          1.7", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "x86_64" + "'", str9.equals("x86_64"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/TMP/RUNRANDOOPPL955622656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTSJ/FRAMEWORK/LIB/TESTGENERATION/GENERATION/RANDOOP-CURRENTJAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b11", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("4444444444444444444444444444444444444444444444", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                                                                                                                              mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("pecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment", "                                                                                                                                                                                                                                                                                              sun.lwawt.macosx.LWCToolkit                                                                                                                                                                                                                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment" + "'", str2.equals("pecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Specification Machine Virtual Java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("e/Documents/defects4j/tmppecifiction chine Virtul v/Users/sophie/Documents/defects4j/tmp", 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophieJava HotSpot(TM) 64-Bit Server VM/users/sophie", "         4Oracle4 4Corporationironment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", "MAC OS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Sun.lwawt.macosx.LWCToolkit", "MACHINE VIRTUAL X4444444444X44MAC", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_64");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "MachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen4444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("                                                                                    :                                                                                     ", "/Users/sophie/Library/Ja...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("      /v          1.7.0_80-b15                ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                          /Users/sophie                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("TGE...", "            sunvawtvCGraphicsEnvironment            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OS ac OSSun.lwawt.macosx.LWCToolkit", "sun.4wt.CGr4phicsEnvironment", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hineVirtualX444444444444JavaOS444444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("jv Pltform API Specifiction", "osx444444444444jAVAvIRTUALmACHI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", 147);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX", "444444444...                                                                                     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreOS/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jreX"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("...cosx.LWCToolkit", "Mac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/mc os xMac/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre /Library/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                 aaaaaaa                                                                                  ", 6.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/OPHIE" + "'", str1.equals("/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/OPHIE"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.4wt.cgr4phicsenvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("mp/runrandooppl95562265");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mp/runrandooppl9556226" + "'", str1.equals("mp/runrandooppl9556226"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(6.0d, (double) 183L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 183.0d + "'", double3 == 183.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "macosx");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxracle Corporation", "poration");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxracle Cor" + "'", str2.equals("osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxracle Cor"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444444444444MAC os x444444444444jAVA vIRTUAL mACHINE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444MAC os x444444444444jAVA vIRTUAL mACHINE" + "'", str1.equals("444444444444MAC os x444444444444jAVA vIRTUAL mACHINE"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "                                                                                                                                                                          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "RS/SOPHI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_9517_1560227656/TARGET/CLAS10.14.3macDOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac2c51.0 51.0OS51.0 51.0XaMmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24.80-b11 24.80-b11OS24.80-b11 24.80-b11Xmac24");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_6", 3200, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaa" + "'", str3.equals("x86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa86_6aaaaaaaaaaaaa"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "mixed mode");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64x", strArray2, strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Macmixed mode mixed modeOSmixed mode mixed modeX" + "'", str6.equals("Macmixed mode mixed modeOSmixed mode mixed modeX"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "x86_64x" + "'", str7.equals("x86_64x"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/10.14.3MAC/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/10.14.3MAC/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concatWith("NE", (java.lang.Object[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 3200, 56);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEtmpNE/NErunNE_NErandoopNE.NEplNE_NE9517NE_NE1560227656NE/NEtargetNE/NEclassesNE:/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEframeworkNE/NElibNE/NEtestNE_NEgenerationNE/NEgenerationNE/NErandoopNE-NEcurrentNE.NEjar" + "'", str3.equals("/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEtmpNE/NErunNE_NErandoopNE.NEplNE_NE9517NE_NE1560227656NE/NEtargetNE/NEclassesNE:/NEUsersNE/NE10NE.NE14NE.NE3NEMACNE/NEDocumentsNE/NEdefectsNE4NEjNE/NEframeworkNE/NElibNE/NEtestNE_NEgenerationNE/NEgenerationNE/NErandoopNE-NEcurrentNE.NEjar"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracle#Corporation", "sun.4wt.CGr4phicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle#Corpora" + "'", str2.equals("Oracle#Corpora"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...cosx.lwctoolkit", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("####################################################################################################");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users//Users/sophie/Library/Java/Extensions:/Librar", 24, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users//Users/sophie/Library/Java/Extensions:/Librar" + "'", str3.equals("/Users//Users/sophie/Library/Java/Extensions:/Librar"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("::::::::en", 6, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "::::::::en" + "'", str3.equals("::::::::en"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("pecificationOracleJava Platform API Specification Java Platform API SpecificationCorporationironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PECIFICATIONoRACLEjAVA pLATFORM api sPECIFICATION jAVA pLATFORM api sPECIFICATIONcORPORATIONIRONMENT" + "'", str1.equals("PECIFICATIONoRACLEjAVA pLATFORM api sPECIFICATION jAVA pLATFORM api sPECIFICATIONcORPORATIONIRONMENT"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophiesophiesophiesopsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophiesophiesophiesopsun.awt.CGraphicsEnvironment" + "'", str1.equals("sophiesophiesophiesopsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) ".pl_9517_1560227656                                                                                                                                                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".pl_9517_1560227656                                                                                                                                                        " + "'", str1.equals(".pl_9517_1560227656                                                                                                                                                        "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxracle Corporation", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxrcle Corportion" + "'", str2.equals("osx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosx444444444444jAVAvIRTUALmACHINEosxrcle Corportion"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        float[] floatArray6 = new float[] { 'a', 170, (byte) 10, 'a', 0L, 10.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 170.0f + "'", float7 == 170.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 170.0f + "'", float9 == 170.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 147, (float) ' ', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ophie", "444444444444mac OS X444444444444Java Virtua/Users/sophie444444444444mac OS X444444444444Java Virtual");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE" + "'", str1.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/4/Documents/defects4j/tmp/run_randoop.pl_9517_1560227656/target/classes:/Users/4/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "enJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJava Platform API SpecificatioenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationenJavaVirtualMachineSpecificationen", 178);
        org.junit.Assert.assertNotNull(strArray3);
    }
}

