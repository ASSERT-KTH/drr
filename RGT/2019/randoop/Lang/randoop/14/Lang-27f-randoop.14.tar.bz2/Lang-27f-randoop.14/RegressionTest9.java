import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                                  IH");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IH" + "'", str1.equals("IH"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                  IH");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test003");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI..." + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI..."));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("AWT.MACOSX.LWCTO", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("51.01                                                                                            ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.01                                                                                            " + "'", str2.equals("51.01                                                                                            "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("########################################################################################1.7.0_80-B15", (int) '4', "24/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124/80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########################################################################################1.7.0_80-B15" + "'", str3.equals("########################################################################################1.7.0_80-B15"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test008");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                  444444444444444444444444444444                                                                                  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 194 + "'", int1 == 194);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHI!HAVA(TM) SEI!HI", " S! ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHI!HAVA(TM) SEI!HI" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHI!HAVA(TM) SEI!HI"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "ava(tm) se");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test012");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test013");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specificatio", 5, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatio" + "'", str3.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!H HhtSpht(M) Hh-Bit SHh!Hh VM" + "'", str1.equals("!H HhtSpht(M) Hh-Bit SHh!Hh VM"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test017");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!hi...", "/moc.elcaro.avaj//:ptth", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI                                              ...", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "ava(tm) se");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI                                              ..." + "'", str4.equals("HI                                              ..."));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test019");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, (long) 50, (long) 3500);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3500L + "'", long3 == 3500L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test020");
        char[] charArray11 = new char[] { ' ', '4', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24/80-b11                                                                                        ", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us", charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                  IH", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "    /Hhi!Hhi!H    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test022");
        double[] doubleArray1 = new double[] { 33.0d };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.0d + "'", double2 == 33.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.0d + "'", double3 == 33.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test023");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("mixed mode4444", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test024");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4444hi4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64\n", "              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64\n" + "'", str2.equals("X86_64X86_64X86_64X86_64X86_64X86_64X86_64X86_64\n"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test028");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.71.71.71.71.71.71.71.71.71.71.", "##############################################10.14.3###############################################", 90);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71." + "'", str3.equals("1.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "ava(tm)se");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390", 113, ") 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ") 64-BIT SERVER VM) 64/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390) 64-BIT SERVER VM) 64-" + "'", str3.equals(") 64-BIT SERVER VM) 64/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390) 64-BIT SERVER VM) 64-"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Hhi!Hhi!H", "awt.macosx.LWCTo");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test033");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "r", "", 20);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("IHIHIHIHIHIHIH", 5, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test035");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("...", "Java Virtual Machine Specific");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7HI!HI!o1.7HI!HI!H", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7HI!HI!o1.7HI!HI!H" + "'", str3.equals("1.7HI!HI!o1.7HI!HI!H"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test038");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Mac OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "US");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "JH!HHhtSpht(M)Hh-BitSHh!HhVM");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str8.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Oracle Corporation", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHI!HAVA(TM) SEI!HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "51.                                                                                                                         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("#################################################################################      HI      #################################################################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################      HI      #################################################################################" + "'", str2.equals("#################################################################################      HI      #################################################################################"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH", 0, "mixed mode4444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH" + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444" + "'", str2.equals("Ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java Virtual Machine Specificatioaa1.7.0_80aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ORACLE CORPORATION", 2540);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLE CORPORATION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("ORACLE CORPORATION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test046");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 5, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test047");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Mac OS X");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "US");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "1.7.0_80-b15");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Mac OS X");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "US");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Hhi!", strArray15, strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle corporation", strArray8, strArray15);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str4.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str13.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Hhi!" + "'", str19.equals("Hhi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "oracle corporation" + "'", str20.equals("oracle corporation"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test048");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, 50, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test050");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("!#!#!#!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test052");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(51.0f, 0.0f, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test053");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test054");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHI!HAVA(TM) SEI!HI", (java.lang.CharSequence) "i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 133 + "'", int2 == 133);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("      HI      ", 80, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa      HI      " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa      HI      "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java virtual machihi!hava(tm) sei!hi##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("java virtual machihi!hava(tm) sei!hi##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("7.1", "aaaausaaaa", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.1" + "'", str3.equals("7.1"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test058");
        char[] charArray7 = new char[] { ' ', '4', ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "I!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test059");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("Java Virtual Machine Specificatioaa1.7.0_80aa", "/MOC.ELCARO.AVAJ//:PTTH");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51.0", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) 'a', (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "HI!HAVA(TM) SEI!HI", (int) (byte) 0, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "510" + "'", str11.equals("510"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", "JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str3.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("andoop-current.jar", "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test064");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("      HI      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test065");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("en", "ususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususus", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test066");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test067");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("", "!ihH", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test068");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("\n");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                      ", "JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SHI!JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test071");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/moc.elcaro...", "10.14", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elc10.14", "oracle corporatiooracle oracle corporatiooracle c");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                         http://java.oracle.com/                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                         http://java.oracle.com/                                                                          " + "'", str1.equals("                                                                         http://java.oracle.com/                                                                          "));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test074");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100.0f, (double) 10.14f, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.140000343322754d + "'", double3 == 10.140000343322754d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test075");
        char[] charArray8 = new char[] { ' ', '4', ' ', '4' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", 133);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                     " + "'", str2.equals("                                                                                                                                     "));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7", "Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "http://java.oracle.com/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test079");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("oracle corporationoracle corporS");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test080");
        int[] intArray2 = new int[] { 'a', ' ' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("-FT", "uTF-8", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("java virtual machihi!hava(tm) sei!hi##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "al machihi!hava(tm) sei!hi##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("al machihi!hava(tm) sei!hi##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test084");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '#');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("24.80-b11", strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test085");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                     ", "51Oracle Corporation0       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environm", "24/80-b11                                                                                        ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hI!HI!HI!!#!#!#HI!HI!HI!", "JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!HI!!#!#!#HI!HI!HI!" + "'", str2.equals("hI!HI!HI!!#!#!#HI!HI!HI!"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "51.0", 7, 7);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment" + "'", str7.equals("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment" + "'", str8.equals("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment" + "'", str9.equals("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test089");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Hh");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hh\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test090");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHI!HAVA(TM) SEI!HI", "                                                                                            10.15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test091");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("ususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususus", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test092");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test093");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("!!!!", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test094");
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray2, strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny("MV hH!hHS tiB-hH )M(thpSthH H!Hjaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test095");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("##############################################10.14.3###############################################", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("...I!HI...", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test097");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 18, 0L, 2139L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2139L + "'", long3 == 2139L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test098");
        java.lang.String[] strArray2 = new java.lang.String[] {};
        java.lang.String[] strArray3 = new java.lang.String[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray2, strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaa", "                                                                                                    ");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH", strArray9, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray2, strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH" + "'", str13.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Mac OS X" + "'", str14.equals("Mac OS X"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test099");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass6 = byteArray2.getClass();
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0_80-b#####5", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", 39);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5" + "'", str3.equals("0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test101");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10108_156022839", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            " + "'", str2.equals("                                            "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test105");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("Hhi!", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Hhi!" + "'", str5.equals("Hhi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SHI!JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) S", "mixed mode4444", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test107");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) (short) 0, 49.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "AA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aA" + "'", str1.equals("aA"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("I!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("I!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test110");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test111");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444", 80, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us" + "'", str3.equals("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test113");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Lby/Jv/JvVuMhs/jdk.7._8.jdk/s/Hm/j#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Lby/Jv/JvVuMhs/jdk.7._8.jdk/s/Hm/j#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "oracle corporatiooracle oracle corporatiooracle c");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "HI!HAVA(TM) SEI!HI##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi                                              ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test117");
        char[] charArray13 = new char[] { ' ', '4', ' ', '4' };
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny("10.14.3", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray13);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444HI4444", charArray13);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "!!!!!!!!!!!", charArray13);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "!#!#!#!", charArray13);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny("##########################################################################################ava(tm) se", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaUSaaaa", 0, "i!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaUSaaaa" + "'", str3.equals("aaaaUSaaaa"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test120");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("S", "aaaausaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("7.1", "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed mode4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Hh!Hh VM####################", 194);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hh!Hh VM####################" + "'", str2.equals("Hh!Hh VM####################"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test128");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("corporation oracle");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test129");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test130");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4444444andoop-current.jar44444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test131");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0_80-b#####5", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI...######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI...######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI...######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("0.15", ") 64-BIT SERVER VM) 64/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390) 64-BIT SERVER VM) 64-", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.15" + "'", str3.equals("0.15"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test135");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("...aaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test136");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 16, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444" + "'", str3.equals("4444444444444444"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("51.                                                                                                                         ", "a", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.                                                                                                                         " + "'", str3.equals("51.                                                                                                                         "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test139");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "mixed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test140");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str1.equals("hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environm", "    /Hhi!Hhi!H    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environm" + "'", str2.equals("(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environm"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test143");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444andoop-current.jar44444444", (int) 'a', 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test144");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("      HI      ", 80);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("andoop-current.jar", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test147");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("AVA(TM) SE!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!h", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test148");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.15", (float) 50);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.15f + "'", float2 == 0.15f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " SHh!Hh VM####################", "Nes/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test150");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 170, 0.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.0d + "'", double3 == 170.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test151");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray11 = new char[] { ' ', '4', ' ', '4' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JH!HHhtSpht(M)Hh-BitSHh!HhVM", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray11);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "o", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test152");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("#Hhi!#!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test154");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X", (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test155");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("US24/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124", "", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test156");
        char[] charArray12 = new char[] { ' ', '4', ' ', '4' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny("10.14.3", charArray12);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444HI4444", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.com/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!" + "'", str1.equals("!"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_64", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                      mixed mode                                                                                          ", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaamixedamodeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaamixedamodeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test160");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test161");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "-FT");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390", "                                                                                                                                                                                                               4444hi4444");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("Hh", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sopHhe/Documents/defectsHhj/tmp/run_rndoop.pl_10108_1560228390" + "'", str4.equals("/Users/sopHhe/Documents/defectsHhj/tmp/run_rndoop.pl_10108_1560228390"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test163");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test164");
        double[] doubleArray6 = new double[] { ' ', (-1L), (byte) 0, 'a', 97.0d, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 97.0d + "'", double10 == 97.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("AVA(TM) SE", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AVA(TM) SE" + "'", str2.equals("AVA(TM) SE"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test166");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru", "!ihH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test168");
        short[] shortArray4 = new short[] { (short) 10, (short) 100, (byte) 1, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                           ...", "hi...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test170");
        short[] shortArray4 = new short[] { (short) 10, (short) 100, (byte) 1, (byte) 100 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test171");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444", "                                                                                                                                                                                                               4444hi4444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444" + "'", str2.equals("USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("US24/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124", "                    ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Hh!Hh VM####################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hh!Hh VM####################" + "'", str2.equals("Hh!Hh VM####################"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test175");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr0_80-b#####5", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test176");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT", "jH!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("HI!", "i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("AWT.MACOSX.LWCTO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AWT.MACOSX.LWCTO" + "'", str1.equals("AWT.MACOSX.LWCTO"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("IH", "hi                                              ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test180");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(7.0f, 7.0f, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaa/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTJH!H HhtSpht(M) Hh-Bit SHh!Hh VMsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", "\n", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("n", "Java Virtual Machine Specificatioaa1.7.0_80aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("", "                                                                                  444444444444444444444444444444                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test185");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(170.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test186");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "i!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test188");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test189");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI..", "HI...", 16);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!!......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI.." + "'", str4.equals("!!......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI.."));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr", "Java Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJavax86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\nJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390/trget/clsses:/Users/sophie/Documents/defects4j/frmework/lib/test_genertion/genertion/rndoop-current.jr"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI!HAVA(TM) SEI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hava(tm) sei!hi" + "'", str1.equals("hi!hava(tm) sei!hi"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test192");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { ' ', '4', ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 0, 2139);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test194");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                      mixed mode", "!!!!!!!!!!!", "Java Virtual Machine Specificati", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                      mixed mode" + "'", str4.equals("                                                                      mixed mode"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test195");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test196");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test198");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("ORACLE CORPORATION                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test199");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0.15");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.15f + "'", float1.equals(0.15f));
    }
}

