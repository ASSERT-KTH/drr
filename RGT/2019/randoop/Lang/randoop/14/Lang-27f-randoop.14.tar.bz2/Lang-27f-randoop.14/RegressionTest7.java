import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X", "                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X" + "'", str2.equals("hi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!" + "'", str1.equals("i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("HI                                              ...", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us", 3493);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str2.equals("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "IH");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("##########################################################################################ava(tm) se", 26, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("ES )MT(AVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ES )MT(AVA" + "'", str1.equals("ES )MT(AVA"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "H!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server V", "HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaa", "                                                                                                    ");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("                                                                                          ", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "aaaaaaaaaa" + "'", str5.equals("aaaaaaaaaa"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "en", (int) (byte) -1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#Hhi!#!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#Hhi!#!" + "'", str1.equals("#Hhi!#!"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("4444hi4444", "                                                                                            10.15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 3500);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", ".0_8", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                      mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "AVA(TM)mixed modeSE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                               oracle corporation", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ".0_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        char[] charArray9 = new char[] { ' ', '4', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "AVA(TM) SE", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".0_8", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39 + "'", int14 == 39);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Virtual Machine Specificatio", (long) 69);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 69L + "'", long2 == 69L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.71.71.71.71.71.71.71.71.71.71.44444444444444444444444444444444444444444444444444444444444444444444", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "71.71.71.71.71.71.71.71.71.7" + "'", str2.equals("71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                          ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        double[] doubleArray6 = new double[] { 0, (short) 0, 10L, (-1L), 0L, '#' };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.0d + "'", double12 == 35.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                              ", 135);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              " + "'", str2.equals("                              "));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("24/80-b11                                                                                        ", "USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java Virtual Machine Specificatioaa1.7.0_80aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "51.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("UTF-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-FTU" + "'", str1.equals("-FTU"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ava(tm) se");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                 ", (float) 24);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 24.0f + "'", float2 == 24.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("HI                                            ...", 31, "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI                                            ..." + "'", str3.equals("HI                                            ..."));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specificatioaa1.7.0_80aa", 31, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Lby/Jv/JvVuMhs/jdk.7._8.jdk/s/Hm/j#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" SHh!Hh VM####################", (int) '#', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      SHh!Hh VM####################" + "'", str3.equals("      SHh!Hh VM####################"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("1.7.0_80", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Nes/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "AVA(TM) SE!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!h", "aaaaaaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Nes/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("Nes/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("andoop-Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(2139L, 35L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("IHIHIHIHIHIHIH", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IHIHIHIHIHIHIH" + "'", str2.equals("IHIHIHIHIHIHIH"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        int[] intArray4 = new int[] { (byte) 1, 20, 100, 135 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 135 + "'", int5 == 135);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "                              ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390", "                                                                                          mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################################################" + "'", str3.equals("#######################################################"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU" + "'", str1.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HI...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi..." + "'", str1.equals("hi..."));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################...", "Hhi!", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################..." + "'", str3.equals("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################..."));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, (long) 6, 2139L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2139L + "'", long3 == 2139L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("!ihH", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ihH" + "'", str2.equals("!ihH"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize(charSequence0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("4444444andoop-current.jar44444444", "0_8", 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT", "I!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server V", "oracle corporatio", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str4.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#####", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_156022839");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("hi!hi!hi!h", 39, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Mac OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("I!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "I!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("I!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("r", "", (int) '#');
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           ", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           " + "'", str6.equals("H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           "));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.71.71.71.71.71.71.71.71.71.71.");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                           ...", strArray3, strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concatWith("                               oracle corporation", (java.lang.Object[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                           ..." + "'", str5.equals("                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                           ..."));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "s" + "'", str1.equals("s"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "o", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("!", (int) 'a', 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!" + "'", str3.equals("!"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("aaa1.7.0_80aaa", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     !#!#!#", 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("uTF-8", "!#!#!#!", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "                    ", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                      ", "!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                      " + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                      "));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str2.equals("hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHh");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                 ", 31, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit", "AVA(TM) SE!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.71.71.71.71.71.71.71.71.71.71.", "JH!H HhtSpht(M) Hh-Bit SHh!Hh VM", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71." + "'", str3.equals("1.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "51Oracle Corporation0       ", (java.lang.CharSequence) "i!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.1" + "'", str1.equals("0.1"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("AVA(TM) SE!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi...!hi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/Users/sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444", "1.7jH!H", "cORPORATION oRACLE", 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444" + "'", str4.equals("Ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("!H HhtSpht(M) Hh-Bit SHh!Hh VM", "0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "    /Hhi!Hhi!H    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                  S                                                                                                 !                                                                                                  ", 49, "ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                  S                                                                                                 !                                                                                                  " + "'", str3.equals("                                                                                                  S                                                                                                 !                                                                                                  "));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        float[] floatArray6 = new float[] { (short) 100, 0.0f, (short) 1, 32, (byte) 0, 1015 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1015.0f + "'", float8 == 1015.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("cORPORATION oRACLE", "IH");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 80 + "'", int1 == 80);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        int[] intArray4 = new int[] { 170, (-1), 97, (short) -1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 170 + "'", int6 == 170);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 170 + "'", int7 == 170);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { ' ', '4', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JH!HHhtSpht(M)Hh-BitSHh!HhVM", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle corporation", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("jAVA hOTsPOT(tm) 64-bIT sERVER vm", " SHh!Hh VM", "aaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str4.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "51.01                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                                                                                                                                                                                               4444hi4444", "ah!haa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                               4444hi4444" + "'", str2.equals("                                                                                                                                                                                                               4444hi4444"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("AVA(TM) SE RUNTIME ENVIRONMEN!#!#!#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AVA(TM) SE RUNTIME ENVIRONMEN!#!#!#" + "'", str1.equals("AVA(TM) SE RUNTIME ENVIRONMEN!#!#!#"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaa", "SU");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/moc.elcaro.avaj//:ptth", "...aaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                  444444444444444444444444444444                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("!", "h!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(43, 26, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 43 + "'", int3 == 43);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("IHIHIHIHIHIHIH");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"IHIHIHIHIHIHIH\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("#################################################################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajH!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { ' ', '4', ' ', '4' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 39, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/", 1015);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str2.equals("http://java.oracle.com/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ", "ususususususasususususus", "7.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 " + "'", str3.equals("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ".0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444" + "'", str1.equals("USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!USHI!444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("##########################################################################################ava(tm) se", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                      ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("sun.awt.CGraphicsEnvironment", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 28");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                           ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("                                    Java(TM) SE Ru", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI                                              ...", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Hh!Hh VM####################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Java Virtual Machine Specificatioaa1.7.0_80aaa", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("#######################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI########################################################################", 50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI########################################################################" + "'", str2.equals("#######################################################################HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI########################################################################"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SU", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaSUaaaa" + "'", str3.equals("aaaaSUaaaa"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!", "AVA(TM) SE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!" + "'", str2.equals("hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        int[] intArray2 = new int[] { 10, 16 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SHI!JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) S", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                            ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            " + "'", str3.equals("                            "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!", "/Lby/Jv/JvVuMhs/jdk.7._8.jdk/s/Hm/j#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("51.01                   ", "ush");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#", " SHh!Hh VM", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environm", "jH!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("0_8aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "#######################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14", 69, "/moc.elcaro...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elc10.14" + "'", str3.equals("/moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elc10.14"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Virtual Machine Specification", "24.80-b11");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI...", strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java Virtual Machine Specification" + "'", str5.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java Virtual Machine Specification" + "'", str7.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("i!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!" + "'", str2.equals("i!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        char[] charArray9 = new char[] { ' ', '4', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("10.14.3", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\n", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.0", "Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny("1.7.0_80-b15", strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        long[] longArray6 = new long[] { (short) 100, (byte) 100, 'a', (short) 1, (byte) 100, 18 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 39);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 1015);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("uTF-", (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        short[] shortArray2 = new short[] { (byte) 1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/MOC.ELCARO.AVAJ//:PTTH", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10108_156022839");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/MOC.ELCARO.AVAJ//:PTTH" + "'", charSequence2.equals("/MOC.ELCARO.AVAJ//:PTTH"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("51.01                                                                                            ", "##########################################################################################ava(tm) se");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.01" + "'", str2.equals("51.01"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environmen" + "'", str1.equals("Java(TM) SE Runtime Environmen"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("SHh!Hh VM####################", "hi!hi!hi!h", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SHh!Hh VM####################" + "'", str3.equals("SHh!Hh VM####################"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("51.01                   ", "Java(TM) SE Runtime Environment", 1015, 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.01                   Java(TM) SE Runtime Environment" + "'", str4.equals("51.01                   Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("444444444444444444444444444444", "Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT", "71.71.71.71.71.71.71.71.71.7", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("!!!!!!!!!!!", "!#!#!#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("us");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("oracle corporation", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JH!H HhtSpht(M) Hh-Bit SHh!Hh VM", "/moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elcaro.../moc.elc10.14");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/moc.elcaro...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("#Hhi!#!", "...h!Hh......h!Hh......h!Hh......h!Hh......h!Hh......h!Hh......h!Hh......h!Hh......h!Hh......h!Hh...######################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i" + "'", str2.equals("i"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        long[] longArray1 = new long[] { 3500 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3500L + "'", long2 == 3500L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3500L + "'", long3 == 3500L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3500L + "'", long4 == 3500L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 3500, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3500 + "'", int3 == 3500);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specificatio", "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Virtual Machine Specificatioaa1.7.0_80aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa08_0.7.1aaoitacificepS enihcaM lautriV avaJ" + "'", str1.equals("aa08_0.7.1aaoitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ", "n", "46_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       "));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve" + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("      HI      ", "51.01                   Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS XHI!HI!", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS XHI!HI!                                                " + "'", str2.equals("1.7HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS XHI!HI!                                                "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" SHh!Hh VM", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " SHh!Hh VM" + "'", str2.equals(" SHh!Hh VM"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 ", " SHh!Hh VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 " + "'", str2.equals("                                HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI                                 "));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 1, 32, 170);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 170 + "'", int3 == 170);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HI...", "HI!HI!HI!HI!HI!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI..." + "'", str2.equals("HI..."));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_10108_156022839", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            " + "'", str2.equals("                            "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################...", "...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################..." + "'", str2.equals("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################..."));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "HI...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("!#!#!#HI!HI!HI!", "", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("i!ihi!hi!ihi!hi!ihi!hi!ihi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################...", "HI", "!#!#!#HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA VIRTUAL MAC!#!#!#HI!HI!HI!HI!HAVA(TM) SEI!HI#############################################################..." + "'", str3.equals("JAVA VIRTUAL MAC!#!#!#HI!HI!HI!HI!HAVA(TM) SEI!HI#############################################################..."));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS XHI!HI!                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.15", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.15" + "'", str3.equals("0.15"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI                                              ...", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("!ihH", 3500, 3493);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCTJH!H HhtSpht(M) Hh-Bit SHh!Hh VMsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCT", 6, 16);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "awt.macosx.LWCTo" + "'", str3.equals("awt.macosx.LWCTo"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51.0", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) 'a', (int) (short) 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "HI!HAVA(TM) SEI!HI", (int) (byte) 0, (int) (byte) 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 14, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                                                                                                                                                               4444hi4444", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                               4444hi4444" + "'", str2.equals("                                                                                                                                                                                                               4444hi4444"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!", "51Oracle Corporation0...I!HI...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        char[] charArray10 = new char[] { ' ', '4', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24/80-b11                                                                                        ", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                              ", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("46_68x");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JAVA VIRTUAL MAC!#!#!#HI!HI!HI!HI!HAVA(TM) SEI!HI#############################################################...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 113 + "'", int1 == 113);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("S", 32, "oracle corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle corporationoracle corporS" + "'", str3.equals("oracle corporationoracle corporS"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "AVA(TM)mixed modeSE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.71.71.71.71.71.71.71.71.71.71.", '4');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 49, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71." + "'", str3.equals("1.71.71.71.71.71.71.71.71.71.71."));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71." + "'", str4.equals("1.71.71.71.71.71.71.71.71.71.71."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("US", 49, "24/80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US24/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124" + "'", str3.equals("US24/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                               oracle corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(".0_", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" ", (int) (byte) 1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4444444andoop-current.jar44444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444andoop-current.jar44444444" + "'", str2.equals("4444444andoop-current.jar44444444"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("cORPORATION oRACLE");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cJava(TM) SE Runtime EnvironmenORPORATIONJava(TM) SE Runtime Environmen Java(TM) SE Runtime EnvironmenoJava(TM) SE Runtime EnvironmenRACLE" + "'", str3.equals("cJava(TM) SE Runtime EnvironmenORPORATIONJava(TM) SE Runtime Environmen Java(TM) SE Runtime EnvironmenoJava(TM) SE Runtime EnvironmenRACLE"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "Java Virtual Machine Specification", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("/Users/sophie", "/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                    Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru                                     ", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.concatWith("Andoop-Sun.awt.CGraphicsEnvironment", (java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 170 + "'", int4 == 170);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Andoop-Sun.awt.CGraphicsEnvironment" + "'", str5.equals("Andoop-Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(" s! ", "!ihH", (-1), 194);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!ihH" + "'", str4.equals("!ihH"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Virtual Machine Specification", "", "hi                                              ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specification" + "'", str3.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 14, (float) 2139);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2139.0f + "'", float3 == 2139.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     !#!#!#", "1.7jH!H");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("i!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Java Virtual Machine Specificati");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ".0_", "JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SHI!JAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) SE RUNTIME ENVIRONMENTJAVA(TM) S");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { ' ', '4', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JH!HHhtSpht(M)Hh-BitSHh!HhVM", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle corporation", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specificatioaa1.7.0_80aaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "444444444444444444444444444444444444444444444444HI!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("AA", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AA   " + "'", str3.equals("AA   "));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...", "aaaaSUaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaausaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 5, 14.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1015, 3500, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3500 + "'", int3 == 3500);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444444444444444444444/Hhi!Hhi!H", "0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                               oracle corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 217);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "    /Hhi!Hhi!H    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    /Hhi!Hhi!H    " + "'", str1.equals("    /Hhi!Hhi!H    "));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Hhi!", 0);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Java(TM) SE Runtime Environment");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("51.0", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle Corporation", strArray4, strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "JAVA VIRTUAL MACHINE SPECIFICATION");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Oracle Corporation" + "'", str10.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("JAVA VIRTUAL MAC!#!#!#HI!HI!HI!HI!HAVA(TM) SEI!HI#############################################################...", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("ususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususususus", (float) 2139);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2139.0f + "'", float2 == 2139.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 1 + "'", byte9 == (byte) 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("##############################################10.14.3###############################################", "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################10.14.3###############################################" + "'", str2.equals("##############################################10.14.3###############################################"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        float[] floatArray6 = new float[] { '4', (-1L), 32L, 2, 5, 1015.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1015.0f + "'", float7 == 1015.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1015.0f + "'", float8 == 1015.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1015.0f + "'", float9 == 1015.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1015.0f + "'", float10 == 1015.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                  S                                                                                                 !                                                                                                  ", 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                  S                                                                                                 !                                                                                                  " + "'", str3.equals("                                                                                                  S                                                                                                 !                                                                                                  "));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("corporation oracle", "aaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "corporation oracle" + "'", str2.equals("corporation oracle"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/moc.elcaro...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "UTF-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("####", "#######################################################", 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####" + "'", str3.equals("####"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                            ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("HI                                            ...");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI                                              ..." + "'", str3.equals("HI                                              ..."));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HI                                            ..." + "'", str4.equals("HI                                            ..."));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI...", 49, "ususususususasususususus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI..." + "'", str3.equals("...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI..."));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#" + "'", str1.equals("!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Virtual Machine Specificatioaa1.7.0_80aaa", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatioaa1.7.0_80aaa" + "'", str3.equals("Java Virtual Machine Specificatioaa1.7.0_80aaa"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hi!hhi!hi!hHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X", (float) 194);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 194.0f + "'", float2 == 194.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", "ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   " + "'", str2.equals("hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        long[] longArray1 = new long[] { (byte) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X", "                                                                                                  IH", "JAVA VIRTUAL MAC!#!#!#HI!HI!HI!HI!HAVA(TM) SEI!HI#############################################################...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "JAVA(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t", "                                                                                  444444444444444444444444444444                                                                                  ", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("51Oracle Corporation0       ", "aaa1.7.0_80aaa", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51Oracle Corporation0       " + "'", str3.equals("51Oracle Corporation0       "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("JAVA(TM) SE RUNTIME ENVIRONMENT", "1.7.0_8", 0, 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_8" + "'", str4.equals("1.7.0_8"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("     ", "oracle corporationoracle corporS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("!!!!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!!!!" + "'", str1.equals("!!!!"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java(TM) SE Runtime Environment", 10, (int) (short) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24/80-b11                                                                                        ", strArray1, strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "HI!" + "'", str8.equals("HI!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "24/80-b11                                                                                        " + "'", str9.equals("24/80-b11                                                                                        "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_156022839");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_156022839" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_156022839"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("x86_64");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("...IH!", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...IH!" + "'", str2.equals("...IH!"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...) 64-Bit Serve");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                    ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "AVA(TM)SE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 1 + "'", byte11 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "", "JavaPlatformAPISpecification");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("n", "SHh!Hh VM####################", "Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!Hhi!hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t", 2139, "IHJava Virtual Machine Specifi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t" + "'", str3.equals("Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "!#!ihH#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS" + "'", str3.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...", "hi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   ", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Mac OS X");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "US");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Hhi!", strArray7, strArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny("n", strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str5.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Hhi!" + "'", str11.equals("Hhi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SHh!Hh VM####################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 29 + "'", int1 == 29);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Hhi!", "rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Virtual Machine Specification", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine SpecificationJava Virtual Machine Specification"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("4444444444444444444444444/Hhi!Hhi!H", "!!!!", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 176, (long) 90);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 176L + "'", long3 == 176L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Hhi!Hhi!H", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", (java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", charSequence2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 28L, 18.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        short[] shortArray6 = new short[] { (short) 10, (byte) 100, (short) 1, (byte) 100, (byte) 0, (byte) 1 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "                                                                                          mixed mode", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("oracle corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           " + "'", str2.equals("                           "));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" SHh!Hh VM####################", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " SHh!Hh VM####################" + "'", str2.equals(" SHh!Hh VM####################"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("Java(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environment", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.71.71.71.71.71.71.71.71.71.71.", "!hi...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("I!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("!AVA(TM)SE!##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "51.                                                                                                                         ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "!AVA(TM)SE!##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str4.equals("!AVA(TM)SE!##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ANDOOP-sUN.AWT.cgRAPHICSeNVIRONMENT", "                                                                                       AAAAAAAAAA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaSUaaaa", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("IH", "", "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "IH" + "'", str3.equals("IH"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#", "H!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           Java(TM) SE Runtime EnvironmentH!H HhtSpht(M) Hh-Bit SHh!Hh VM                                                                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("10.14", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14" + "'", str2.equals("10.14"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHh", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (java.lang.CharSequence) "Java(TM) SE Runtime Environmen");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2540 + "'", int2 == 2540);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("AVA(TM)SE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava(tm)se" + "'", str1.equals("ava(tm)se"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '#');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("24.80-b11", strArray4);
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("s", strArray4, strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "s" + "'", str7.equals("s"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Hhi!", "/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny("JH!HHhtSpht(M)Hh-BitSHh!HhVM", strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", strArray3, strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#", 217, 32);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str9.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "!AVA(TM)SE!##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!IH!Ih", "4444444444444444444444444/Hhi!Hhi!H", "#####");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("51.0", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("a", strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ", strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 44 + "'", int7 == 44);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "oracle corporationoracle corporS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("r", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("...IH!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...IH!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 217, (float) 97L, (float) 29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 29.0f + "'", float3 == 29.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUS", "aaaaaaaaaaaaaaaaaaaaaaaaaaa...", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("ah!haa", 2139);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ah!haa" + "'", str2.equals("ah!haa"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("JAVA VIRTUAL MACHIHI!HAVA(TM) SEI!HI#############################################################...", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/moc.elcaro.avaj//:ptth" + "'", str2.equals("/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specificatioaa1.7.0_80aa", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "ES )MT(AVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        float[] floatArray6 = new float[] { 100, (short) 100, (short) 0, 170, 10.0f, 100.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 170.0f + "'", float7 == 170.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 170.0f + "'", float10 == 170.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 170.0f + "'", float11 == 170.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 170.0f + "'", float12 == 170.0f);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51.01                                                                                            ", "ah!haa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        short[] shortArray2 = new short[] { (byte) 1, (short) -1 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        double[] doubleArray6 = new double[] { ' ', (-1L), (byte) 0, 'a', 97.0d, 0.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 97.0d + "'", double7 == 97.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 97.0d + "'", double11 == 97.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("hi!", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI                                            ...", "                                                                                       aaaaaaaaaa", 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("10.14.3", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\n", 506, "Java Virtual Machine Specificati");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJavax86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\nJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava " + "'", str3.equals("Java Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJavax86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\nJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava Virtual Machine SpecificatiJava "));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("51Oracle Corporation0...I!HI...", 30, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "." + "'", str3.equals("."));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("x86_64", 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                    ", "", 135);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "Java Virtual Machine Specificati");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 1 + "'", byte8 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aa!aAVA(TM)aSEa!aa##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 30, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa!aAVA(TM)aSEa!aa##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str3.equals("aa!aAVA(TM)aSEa!aa##########################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajH!H HhtSpht(M) Hh-Bit SHh!Hh VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajH!H HhtSpht(M) Hh-Bit SHh!Hh VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { ' ', '4', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JH!HHhtSpht(M)Hh-BitSHh!HhVM", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ah!haa", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajH!H HhtSpht(M) Hh-Bit SHh!Hh VM", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.15", "a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(") 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ") 64-BIT SERVER VM" + "'", str1.equals(") 64-BIT SERVER VM"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("andoop-current.jar", "", (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("10.14", strArray3, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray9);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.14" + "'", str8.equals("10.14"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "andoop-current.jar" + "'", str10.equals("andoop-current.jar"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("h!", "aa08_0.7.1aaoitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Corporation Oracle", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HIaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "http://java.oracle.com/");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "51Oracle Corporation0", 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("hI                                            ...", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 22");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                    Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru                                     ", "!#!#!#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("mixed mode4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Mac OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str5.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !ihH");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("oracle corporationoracle corporS", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporationoracle corporS" + "'", str2.equals("oracle corporationoracle corporS"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 10.0f, 30.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t" + "'", str2.equals("Sun.awt.CGraphicsEnvironment/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390/t"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHh");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("!#!#!#!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(") 64-BIT SERVER VM", "51.0hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "...I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI......I!HI..");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ") 64-BIT SERVER VM" + "'", str3.equals(") 64-BIT SERVER VM"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("!#!ihH#", "ususususususasususususus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!#!ihH#" + "'", str2.equals("!#!ihH#"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime EnvironmentJava(TM) SE Runtime Environm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("!#!ihH#", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                           ...", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       ..." + "'", str2.equals("       ..."));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2139.0f, (double) 34, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51Oracle Corporation0       ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { ' ', '4', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "AVA(TM) SE", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "J/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390ava/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390(/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390TM/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390)/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390SE/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390R/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390untime/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390 /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390E/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390nvironment", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        float[] floatArray6 = new float[] { 100, (short) 100, (short) 0, 170, 10.0f, 100.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 170.0f + "'", float7 == 170.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 170.0f + "'", float8 == 170.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "I!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("i!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7HI!HI!o1.7HI!HI!", "hi!", "    /Hhi!Hhi!H    ", 24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7HI!HI!o1.7HI!HI!" + "'", str4.equals("1.7HI!HI!o1.7HI!HI!"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        int[] intArray2 = new int[] { 'a', ' ' };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru", 14);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                               oracle corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Corporation Oracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("", "AA   ", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("", "                                                                      mixed mode", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 " + "'", str2.equals("                                                                                                 "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AA   ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("!", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajH!H HhtSpht(M) Hh-Bit SHh!Hh VM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("n");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("/Lby/Jv/JvVuMhs/jdk.7._8.jdk/s/Hm/j#####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "corporation oracle");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("ush", "i!Hhi!hi!Hhi!hi!", 50);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "####", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("i!Hhi!hi!Hhi!hi!", 16, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i!Hhi!hi!Hhi!hi!" + "'", str3.equals("i!Hhi!hi!Hhi!hi!"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("/Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_10108_1560228390", "HI                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("                                                                                                  S                                                                                                 !                                                                                                  ", "oracle corporationoracle corporS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, (float) 100, 4.4444443E29f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("####", "HI                                            ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####" + "'", str2.equals("####"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3500, (float) 33L, (float) 3500);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3500.0f + "'", float3 == 3500.0f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("51Oracle Corporation0...I!HI...", "                                hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi                           ...", "", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51Oracle Corporation0...I!HI..." + "'", str4.equals("51Oracle Corporation0...I!HI..."));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Hhi!Hhi!H");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "hI!HI!HI!!#!#!#HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/hI!HI!HI!!#!#!#HI!HI!HI!HhihI!HI!HI!!#!#!#HI!HI!HI!!hI!HI!HI!!#!#!#HI!HI!HI!HhihI!HI!HI!!#!#!#HI!HI!HI!!hI!HI!HI!!#!#!#HI!HI!HI!H" + "'", str3.equals("/hI!HI!HI!!#!#!#HI!HI!HI!HhihI!HI!HI!!#!#!#HI!HI!HI!!hI!HI!HI!!#!#!#HI!HI!HI!HhihI!HI!HI!!#!#!#HI!HI!HI!!hI!HI!HI!!#!#!#HI!HI!HI!H"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Hhi!Hhi!H");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        char[] charArray10 = new char[] { ' ', '4', ' ', '4' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIHI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("10.14.3", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "ava(tm) se", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 1 + "'", byte7 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(176, 30, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 176 + "'", int3 == 176);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 " + "'", str2.equals("rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 "));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("awt.macosx.LWCTo", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1), (float) ' ', (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkit", "51.01                   Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        char[] charArray9 = new char[] { ' ', '4', ' ', '4' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny("!H HhtSpht(M) Hh-Bit SHh!Hh VM", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "71.71.71.71.71.71.71.71.71.7", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hI                                            ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JAVA(TM) SE RUNTIME ENVIRONMEN!#!#!#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("cORPORATION oRACLE", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cORPORATION oRACLE" + "'", str2.equals("cORPORATION oRACLE"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "AA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "rary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#######################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("andoop-Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "andoop-Sun.awt.CGraphicsEnvironment" + "'", str1.equals("andoop-Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("hI!HI!HI!!#!#!#HI!HI!HI!", "US24/80-b1124/80-b1124/80-b1124/80-b1124/80-b1124");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "JH!HHhtSpht(M)Hh-BitSHh!HhVM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\n", "10.15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/moc.elcaro...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/moc.elcaro..." + "'", str1.equals("/moc.elcaro..."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          7.1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          1.7                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          1.7                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, (long) 10, (long) 43);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43L + "'", long3 == 43L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/J444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("##########################################################################################ava(tm) se", "JavaPlatformAPISpecification", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             " + "'", str1.equals("             "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "Mac OS X");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "US");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "1.7.0_80-b15");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        float[] floatArray6 = new float[] { '4', (-1L), 32L, 2, 5, 1015.0f };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1015.0f + "'", float7 == 1015.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1015.0f + "'", float8 == 1015.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           ", ".0_8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        short[] shortArray4 = new short[] { (byte) 10, (short) 0, (byte) 1, (short) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "hi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi..." + "'", str1.equals("hi..."));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("JavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X24/80-b11HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.awt.CGraphicsEnvironment", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "AVA(TM) SE RUNTIME ENVIRONMEN!#!#!#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("##############################################10.14.3###############################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##############################################10.14.3###############################################" + "'", str2.equals("##############################################10.14.3###############################################"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Hhi!Hhi!H", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Hhi!Hhi!H" + "'", str2.equals("/Hhi!Hhi!H"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3493, (double) 5, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                         http://java.oracle.com/                                                                          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("SHh!Hh VM####################", 26, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.14f, 7.0d, 16.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("51.01                   Java(TM) SE Runtime Environment", "AVA(TM) SE", (int) (byte) 1, 217);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "5AVA(TM) SE" + "'", str4.equals("5AVA(TM) SE"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "JH!HHhtSpht(M)Hh-BitSHh!HhVM", 7);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 26, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 26");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 4, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 24.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.0d + "'", double3 == 24.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!H" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!H"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("ih", 32, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us!!!!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/0938220651_80101_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "hI                                            ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                    Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru                                     ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                    Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru                                     " + "'", str2.equals("                                    Java(TM) SE Ru/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_10108_1560228390Java(TM) SE Ru                                     "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!ushi!us", "HIMac OS X", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophie", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HIMac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("awt.macosx.LWCTo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AWT.MACOSX.LWCTO" + "'", str1.equals("AWT.MACOSX.LWCTO"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("!#!#!#!", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!#!#!#!" + "'", str2.equals("!#!#!#!"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64\n", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 5, (long) 33, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("1.7.0_80-b15", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI...");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("##########################################################################################ava(tm) se", "I!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", "sun.lwawt.macosx.CPrinterJob");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("US", strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51a0" + "'", str7.equals("51a0"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHh", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHh" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHh"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.7jH!H");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/Library/J444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/J444444444444444444444444444444" + "'", str1.equals("/Library/J444444444444444444444444444444"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                               oracle corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre####################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre#################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################### is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("51.01                   ", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.01                   " + "'", str2.equals("51.01                   "));
    }
}

