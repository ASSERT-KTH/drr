import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("d\n", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###############################################d\n################################################" + "'", str3.equals("###############################################d\n################################################"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "                     1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("  #4444   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "  #4444   " + "'", str1.equals("  #4444   "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("2a-1a2  -8", "Java HotSpM", (int) '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2a-1a2  -8" + "'", str6.equals("2a-1a2  -8"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.344444444444444444444444444444", "#4444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.344444444444444444444444444444" + "'", str2.equals("1.344444444444444444444444444444"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("edom dexim", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "4444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2a-1a2  ");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                          Java HotSpM", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4aa                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen", "1.0a8.0a10.0a-1.0", 1100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("             Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             Oracle Corporatio" + "'", str1.equals("             Oracle Corporatio"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                                  ###############################                                   ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("MpStoH avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sUN.AWT.cgRAPHICSeNVIRONMENT", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oRACLE cORPORATION", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "hi!", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        char[] charArray4 = new char[] { '4', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", charArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 37, 209);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 37");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4#a" + "'", str6.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4#a" + "'", str9.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("  UTF-8   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(32.0d, 417.0d, 1.3444444444444446d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 417.0d + "'", double3 == 417.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("     4#a################################     ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     4#a################################     " + "'", str2.equals("     4#a################################     "));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 5, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 137, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "69", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_8", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("i!", "a4#a4#a4#a4#a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.3444443941116333d, 1.3444444444444446d, 1.1d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1d + "'", double3 == 1.1d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("a4#a4#a4#a4#a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ", "##", "en");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "2.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("             Oracle Corporatio", 29, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             Oracle Corporatio" + "'", str3.equals("             Oracle Corporatio"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(27, 1560, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1560 + "'", int3 == 1560);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(31.0f, 0.0f, (float) 75);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 52, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", (java.lang.CharSequence) "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("001a0a1-a001a1", (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("pStoH avaJ");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("2a-1a2", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "class[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444..." + "'", str3.equals("44444444444444444444444444444..."));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        double[] doubleArray1 = new double[] { 2 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 69, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (-1), (int) (short) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 75, 67);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0" + "'", str3.equals("2.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", "2a-1a2  -8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.0 8.0 10.0 -1.0", "10.14.3", " CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 8.0 10.0 -1.0" + "'", str3.equals("1.0 8.0 10.0 -1.0"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("2a-1a2  -8", "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2  -8" + "'", str2.equals("2a-1a2  -8"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                       100410041                                 ", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                       100410041                                 ", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       100410041                                 " + "'", str3.equals("                       100410041                                 "));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("edom dexim", 10, "    ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "edom dexim" + "'", str3.equals("edom dexim"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("oRACLE cORPORATION", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.3", "\nd", "-1#10#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("pStoH avaJ                            ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10 100", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100" + "'", str2.equals("10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM" + "'", str1.equals("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a100a-1a0a100" + "'", str1.equals("1a100a-1a0a100"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 31, (int) (byte) 10);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 67, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 67");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2a-1a2" + "'", str13.equals("2a-1a2"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", charSequence2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "-1#10#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        double[] doubleArray5 = new double[] { 97L, 2L, (short) -1, 10L, 'a' };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97.042.04-1.0410.0497.0" + "'", str8.equals("97.042.04-1.0410.0497.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97.0#2.0#-1.0#10.0#97.0" + "'", str10.equals("97.0#2.0#-1.0#10.0#97.0"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100", (java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "FC0000GN/t/4_V31CQ2N2X1N4/VAR/FOLDERS/_V/6V597ZMN", (java.lang.CharSequence) "2.0", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("class [Ljava.lang.String;", "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "x86_64", 1450);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("141004-1404100", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141004-..." + "'", str2.equals("141004-..."));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA", "  ", 73);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "     4#a################################     ", (int) (short) 0, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.0", "1.0a8.0a10.0a-1.0", (int) (byte) 10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.01.0a8.0a10.0a-1.0" + "'", str4.equals("1.01.0a8.0a10.0a-1.0"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("141004-1404100", "10a100");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Java(TM) SE Runtime Environment");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a.oracle.com/", strArray4, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "141004-1404100", (java.lang.CharSequence[]) strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', 69, 49);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 96, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "a.oracle.com/" + "'", str8.equals("a.oracle.com/"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 22, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.344444444444444444444444444444", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#a" + "'", str10.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4', (int) (short) 100, 52);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.9", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    " + "'", str2.equals("    "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.344444444444444444444444444444", "JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15", 93, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.344444444444444444444444444444JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15" + "'", str4.equals("1.344444444444444444444444444444JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.0a8.0a10.0a-1.0                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "2");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.1", "", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        short[] shortArray3 = new short[] { (short) -1, (byte) 10, (short) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("444444444444444444444444444444444444444444444444444444444444444444444444444", "10 100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar", "0.0", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_8", "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", (int) (short) 0, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM.0_8" + "'", str4.equals("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM.0_8"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 10, 4);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Oracle Corporation");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 0, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM.0_8");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM.0_8");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1i100i-1i0i100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("97.042.04-1.0410.0497.0", "                              4#a4#4#a4#                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.042.04-1.0410.0497.0" + "'", str2.equals("97.042.04-1.0410.0497.0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle", (int) (byte) -1, "0.9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle" + "'", str3.equals("Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                           " + "'", str1.equals("                                                                                                                           "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("001a011#100#-1#0#100", "1.344444444444444444444444444444", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...", (java.lang.CharSequence) "1.344444444444444444444444444444JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwawt.macosx.CPrinterJo", "pStoH avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "ttp://java.oracle.com/", (java.lang.CharSequence) "#4444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("noitaroproC elcarO", 1450);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("    ", 0, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    " + "'", str3.equals("    "));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "511.7.0_80-b15.1.7.0_80-b150");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.0a8.0a10.0a-1.0", "################################     a     4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str2.equals("1.0a8.0a10.0a-1.0"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '4', (double) 71, (double) 1.3f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 71.0d + "'", double3 == 71.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                  ###############################                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  ###############################                                   " + "'", str2.equals("                                  ###############################                                   "));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "001a01", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, 0.0f, (float) 6L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("d");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "d" + "'", str1.equals("d"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "44444444444444444444444444444...", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("noitaroproC elcarO", "", "pStoH avaJ                            ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J" + "'", str2.equals("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.8", "2a-1a2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.0a8.0a10.0a-1.0", "################################     a     4#");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4, 0.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "Oracle Corporation", 417);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100", (java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(69, 11, 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 137 + "'", int3 == 137);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###########################", (java.lang.CharSequence) "                                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(63.0f, (float) 5, (float) 8L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("44444444444444444444444444444...", "4# # #4# #4", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444..." + "'", str3.equals("44444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444..."));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-14-1410410", (java.lang.CharSequence) "1.4##############################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "4", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1i100i-1i0i100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1i100i-1i0i100" + "'", str1.equals("1i100i-1i0i100"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("pStoH avaJ", "1.344444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8, 417.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 417.0f + "'", float3 == 417.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("     pStoH avaJ                                 ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     pStoH avaJ                                 " + "'", str2.equals("     pStoH avaJ                                 "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 71, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 71 + "'", int3 == 71);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "4#a4#4#a4#");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("  #4444   ", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51B-08_0.7.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("51B-08_0.7.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio", "class[Ljava.lang.String;", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#a4aaaa", "       sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4aaaa" + "'", str2.equals("#a4aaaa"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "                                                    ", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "  ", (java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle Corporation", (int) (short) -1, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Java(TM) SE Runtime Environment");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("4", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4" + "'", str8.equals("4"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#### C#########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"### C#########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("edom dexim", "             Oracle Corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "       1.31.71.61.71.31.6       ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", "                                 100410041                                 ", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("141004-1404100", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141004-1404100" + "'", str2.equals("141004-1404100"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/", "0.0", "oracle Corporation");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("001a011#100#-1#0#100", (float) 1560);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1560.0f + "'", float2 == 1560.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.81.81.81.81.81.81.81.81.8", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 69 + "'", int6 == 69);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "###############################################d\n################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4#a", "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 75);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "  UTF-8   ", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4#a" + "'", str6.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10a-1a0a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10A-1A0A10" + "'", str1.equals("10A-1A0A10"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        short[] shortArray3 = new short[] { (short) -1, (byte) 10, (short) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#10#-1" + "'", str6.equals("-1#10#-1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.0");
        java.math.BigDecimal bigDecimal3 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.0");
        java.math.BigDecimal bigDecimal5 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.0");
        java.math.BigDecimal bigDecimal7 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.0");
        java.math.BigDecimal[] bigDecimalArray8 = new java.math.BigDecimal[] { bigDecimal1, bigDecimal3, bigDecimal5, bigDecimal7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray8);
        org.junit.Assert.assertNotNull(bigDecimal1);
        org.junit.Assert.assertNotNull(bigDecimal3);
        org.junit.Assert.assertNotNull(bigDecimal5);
        org.junit.Assert.assertNotNull(bigDecimal7);
        org.junit.Assert.assertNotNull(bigDecimalArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.00.00.00.0" + "'", str9.equals("0.00.00.00.0"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophiesophiesophiesophiesophiesophiesophiesophiesoph", "1a100a-1a0a100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        char[] charArray7 = new char[] { '#', '4', 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 10, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpM", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                  Java HotSpM", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                               100410041                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                               100410041                               " + "'", str1.equals("                               100410041                               "));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, 37, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", "2#-1#2");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        char[] charArray4 = new char[] { '4', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4#a" + "'", str6.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 8L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4aa", "2a-1a2", (int) 'a');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) '4', 38);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.0a8.0a10.0a-1.0", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Platform API Specification", "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                      ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#444a4a", 38, "4444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444#444a4a4444444444444444" + "'", str3.equals("444444444444444#444a4a4444444444444444"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str2.equals("############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "#4444", 38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n", (java.lang.CharSequence) "1i100i-1i0i100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) -1, (long) 73, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 73L + "'", long3 == 73L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJo", "001a01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                    ", "mixed mode", "############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("mac os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, (int) (short) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("2a-1a2", "!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2" + "'", str2.equals("2a-1a2"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("2a-1a2  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "Oracle Corporation", "104100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############/Us00s/sh0/D1um0s/d0f01s4j/m/0u_04d.0_51031_1560278052" + "'", str3.equals("############/Us00s/sh0/D1um0s/d0f01s4j/m/0u_04d.0_51031_1560278052"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { '#', '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', 28, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("noitaroproC elcarO", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("4#a################################", "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 137, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "69", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444", 1100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15", 18, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "97.042.04-1.0410.0497.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 209, (long) 22, 73L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 22L + "'", long3 == 22L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        short[] shortArray3 = new short[] { (short) 100, (byte) 100, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100410041" + "'", str5.equals("100410041"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        char[] charArray5 = new char[] { '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4", charArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 38, (int) (short) -1);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("oracle Corporation", "#a4aaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Corporation" + "'", str2.equals("oracle Corporation"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.01.0a8.0a10.0a-1.0", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', '4', 'a', 'a' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    /     ", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "     pStoH avaJ                                  ", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray9);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 38, 137);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 38");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesoph", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(96, 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("       sophie", "Java Virtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("  UTF-8   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  UTF-8   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("140014001", 5, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "140014001" + "'", str3.equals("140014001"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("pStoH avaJ                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"pStoH avaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        double[] doubleArray1 = new double[] { 2 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 69, (int) (short) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 5, (int) (byte) 1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0" + "'", str3.equals("2.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1a100a-1a0a100", "", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "97.0a2.0a-1.0a10.0a97.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4 a", "###############################", "edom dexim");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 a" + "'", str3.equals("4 a"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 801, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 801 + "'", int3 == 801);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 137, "1.7.0_8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM" + "'", str2.equals("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...a/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...c/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...O/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...S/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...X/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...", (java.lang.CharSequence) "                                                                                               69");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "       sophie");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 18, (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4#a################################", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        char[] charArray8 = new char[] { '#', '4', 'a', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4#a", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "2a-1a2", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', 1100, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "d\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0.9                             ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#1004#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#1004#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("10#1004#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("001a011#100#-1#0#100", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                 " + "'", str1.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                 "));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.Class<?> wildcardClass8 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15", (java.lang.CharSequence) "104100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "2#-1#2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "oracle corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) -1 };
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "                                                                                               69");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                                69");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.31.71.61.71.31.6", "Oaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.31.71.61.71.31.6" + "'", str2.equals("1.31.71.61.71.31.6"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                               69");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                               69" + "'", str1.equals("                                                                                               69"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1i100i-1i0i100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (float) 38);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 38.0f + "'", float2 == 38.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("sun.lwawt.macosx.CPrinterJo", "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", 137);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str3.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JAVA HOTSPOT(TM) 64-BIT SERVER V", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("104100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("97.0#2.0#-1.0#10.0#97.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0#2.0#-1.0#10.0#97.0" + "'", str1.equals("97.0#2.0#-1.0#10.0#97.0"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sophiesophiesophiesophiesophiesophiesophiesophiesoph", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_...", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) 'a', (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 100, 100);
        int int20 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        int int23 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 69 + "'", int20 == 69);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "                                               \nd1.3                                                ", 209);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                   ###############################                                  ", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER V", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\nd1.3", 75, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 63, (float) 63, (float) 31);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sophie", 93, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("d\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"d\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaa" + "'", str1.equals("aaaaaaaaa"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "JAVA HOTSPOT(TM) 64-BIT SERVER V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        char[] charArray3 = new char[] { '#', '#' };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "#4#" + "'", str6.equals("#4#"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.81.81.81.81.81.81.81.81.8", "1.7.0_80-b15", "aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "d\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("             ", 137);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                         " + "'", str2.equals("                                                                                                                                         "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "4#a4#4#a4#", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "2a-1a2  -8", (java.lang.CharSequence) "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################################", "Java Platform API Specification", 35);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.341.741.641.741.341.6", "1.0a8.0a10.0a-1.0                                                                                ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.341.741.641.741.341.6" + "'", str3.equals("1.341.741.641.741.341.6"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("-1#10#-1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#10#-1" + "'", str2.equals("-1#10#-1"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n", "                              4#a4#4#a4#                               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                         ", "Java Platform API Specification", "                                            Mac OS X                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                         " + "'", str3.equals("                                                                         "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray9 = new char[] { '#', '4', 'a', 'a' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    /     ", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "2", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "141004-...", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"j/tmp/run_randoop.pl4/Users/sophie/Documents/defects\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 0, (double) 4L, 29.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.0d + "'", double3 == 29.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim", "1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444444444444444444444444444444444444444444444444444444444444444", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                         ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("    /     ", "     pStoH avaJ                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /     " + "'", str2.equals("    /     "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#####################################################################", (float) 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "pStoH avaJ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-b11", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 137, 96);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "###################Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66 + "'", int2 == 66);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.341.741.641.741.341.6", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Virtual Machine Specification", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "2-12");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 0, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-14-1410410" + "'", str11.equals("-14-1410410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a-1a10a10" + "'", str13.equals("-1a-1a10a10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                         ", (java.lang.CharSequence) "pStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 10, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "users/sophie" + "'", str1.equals("users/sophie"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 1560, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#100#-1#0#100" + "'", str10.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                 100410041                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java HotSpM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                                                      Java HotSpM", 35);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "1.344444444444444444444444444444");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "10#100", (int) (byte) 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n", "2#-1#2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n" + "'", str2.equals("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) " ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("#a4aaaa", "1.0a8.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4aaaa" + "'", str2.equals("#a4aaaa"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("2#-1#2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2#-1#2" + "'", str1.equals("2#-1#2"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10a-1a0a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("2a-1a2");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4 a", "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", 144);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", (java.lang.CharSequence) "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.7.0_80-b15");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "511.7.0_80-b15.1.7.0_80-b150" + "'", str3.equals("511.7.0_80-b15.1.7.0_80-b150"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava", (java.lang.CharSequence) "             Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 409 + "'", int2 == 409);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 49, 28);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "100410041", "a.oracle.com/", 22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "511.7.0_80-b15.1.7.0_80-b150");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", (int) '4', 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                 ", 1560, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#####################################################################", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.0", "1.3", "1.341.741.641.741.341.6                                                                             ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", (int) (short) 1, "mac os x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str3.equals("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean5 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        java.lang.String str9 = javaVersion7.toString();
        java.lang.String str10 = javaVersion7.toString();
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean12 = javaVersion7.atLeast(javaVersion11);
        java.lang.String str13 = javaVersion11.toString();
        boolean boolean14 = javaVersion4.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.3" + "'", str10.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.1" + "'", str13.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        java.lang.String str4 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = javaVersion1.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str1.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4 a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4 " + "'", str1.equals("4 "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                         4#a################################    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 6, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "2#-1#2", (java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 13, (long) 13, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 13L + "'", long3 == 13L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("2a-1a2  -8", "69");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2  -8" + "'", str2.equals("2a-1a2  -8"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "Java HotSp");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MpStoH avaJ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("104100", "     pStoH avaJ                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104100" + "'", str2.equals("104100"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.Class<?> wildcardClass8 = longArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 100, 32);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2a-1a2" + "'", str10.equals("2a-1a2"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2#-1#2" + "'", str13.equals("2#-1#2"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100410041", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "\nd");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        char[] charArray7 = new char[] { '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     1a100a-1a0a100", charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 97, 10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "d", charArray7);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                         ", charArray7);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4#a" + "'", str9.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4#a" + "'", str12.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                       100410041                                 ", 2, "###################Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       100410041                                 " + "'", str3.equals("                       100410041                                 "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "e", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                          Java HotSpM", "pStoH avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pStoH avaJ" + "'", str2.equals("pStoH avaJ"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "1a100a-1a0a100");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("                                                    ", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "                                                    " + "'", str7.equals("                                                    "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 801);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("2a-1a2  ", "", "1.341.741.641.741.341.6                                                                             ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100", 93, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100" + "'", str3.equals("10 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("2a-1a22a-1a22a-1a22a-1a22a-1a2");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("e");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("                                                          Java HotSpM", strArray2, strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                                          Java HotSpM" + "'", str5.equals("                                                          Java HotSpM"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                               \nd1.3                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "d1.3" + "'", str1.equals("d1.3"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("69", "1.6", 144);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#4#", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("HI!", 417);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10#1004#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("2a-1a2", "/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA", 45);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("#", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                         4#a################################    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a################################" + "'", str1.equals("4#a################################"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 38, (double) 31L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4444 + "'", int1.equals(4444));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                    ", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                    " + "'", str2.equals("                                                    "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4444", 75);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444                                                                       " + "'", str2.equals("4444                                                                       "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 71);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                                  Java HotSpM", "", 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                  Java HotSpM" + "'", str3.equals("                                                                                  Java HotSpM"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1#100#-1#0#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#100#-1#0#100" + "'", str1.equals("1#100#-1#0#100"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "  ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10L, (double) 0, (double) 18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (java.lang.CharSequence) "i!", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "", "-14-1410410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410J-14-1410410" + "'", str3.equals("-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410J-14-1410410"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("10 100", "###############################", 3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("################################################################################################################################################", strArray4, strArray9);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 32, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "################################################################################################################################################" + "'", str10.equals("################################################################################################################################################"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1a-1a10a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a-1a10a10" + "'", str1.equals("-1a-1a10a10"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oracle Co\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10 100", (long) 1560);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560L + "'", long2 == 1560L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 29, 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use..." + "'", str3.equals("...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use..."));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 69 + "'", int4 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "69" + "'", str6.equals("69"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "69" + "'", str8.equals("69"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mac OS X", (java.lang.CharSequence) "     pStoH avaJ                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 0, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1#-1#10#10" + "'", str11.equals("-1#-1#10#10"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        char[] charArray7 = new char[] { '#', '4', 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 10, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#444a4a" + "'", str15.equals("#444a4a"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "###########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################" + "'", str2.equals("###########################"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "################################", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER V");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 8, 3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100410041", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":", (java.lang.CharSequence) "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("2-12");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2-12" + "'", str1.equals("2-12"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Sophiesophiesophiesophiesophiesophiesophiesophiesoph", (java.lang.CharSequence) "4#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                 140014001                       ", "140014001", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java HotSp");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("2a-1a22a-1a22a-1a22a-1a22a-1a2", 1100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       2a-1a22a-1a22a-1a22a-1a22a-1a2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       2a-1a22a-1a22a-1a22a-1a22a-1a2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4#a################################     ", 0, 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects" + "'", str1.equals("j/tmp/run_randoop.pl4/Users/sophie/Documents/defects"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "d");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", "i!", 49);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sUN.AWT.cgRAPHICSeNVIRONMENT", "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 144);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8", strArray5, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8" + "'", str10.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.341.741.641.741.341.6", "1.0a8.0a10.0a-1.0                                                                                ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.341.741.641.741.341.6" + "'", str4.equals("1.341.741.641.741.341.6"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410J-14-1410410", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                            Mac OS X                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", (java.lang.CharSequence) "1.01.0a8.0a10.0a-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(":", "sophiesophiesophiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("69", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("http://java.oracle.com/", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("en", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charSequence1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 31, Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("2a-1a2  -8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2  -8" + "'", str2.equals("2a-1a2  -8"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", (java.lang.CharSequence) "     4#a################################     ", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "511.7.0_80-b15.1.7.0_80-b150", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "hi!");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10#100");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 75, (int) (short) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "69" + "'", str14.equals("69"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10 100", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 100" + "'", str2.equals("10 100"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        short[] shortArray6 = new short[] { (short) 10, (byte) 1, (short) -1, (short) 10, (byte) 0, (short) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a1a-1a10a0a100" + "'", str8.equals("10a1a-1a10a0a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a1a-1a10a0a100" + "'", str10.equals("10a1a-1a10a0a100"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "97.0a2.0a-1.0a10.0a97.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                      ", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                      " + "'", str2.equals("                                                                      "));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("140014001", "users/sophie", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        short[] shortArray3 = new short[] { (short) 100, (byte) 100, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100410041" + "'", str5.equals("100410041"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("4#a################################", "Java HotSp", 45);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.0a8.0a10.0a-1.0", (java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray1, strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str8.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.341.741.641.741.341.6                                                                             ", "2a-1a2  -8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.341.741.641.741.341.6                                                                             " + "'", str2.equals("1.341.741.641.741.341.6                                                                             "));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4444444444444444444444444444444444444444444444444444444444444444444", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2a-1a2" + "'", str9.equals("2a-1a2"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "24-142" + "'", str11.equals("24-142"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("  UTF-8   ", 209);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 209 + "'", int2 == 209);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                 140014001                       ", (java.lang.CharSequence) "2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", (java.lang.CharSequence) "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", "                                   ###############################                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

