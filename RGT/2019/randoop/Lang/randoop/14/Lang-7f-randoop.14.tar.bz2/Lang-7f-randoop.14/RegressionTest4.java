import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava", (java.lang.CharSequence) "511.7.0_80-b15.1.7.0_80-b150", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        try {
            float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\nd1.3", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               \nd1.3                                                " + "'", str2.equals("                                               \nd1.3                                                "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 35L, (double) 417, (double) 49);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 417.0d + "'", double3 == 417.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "4#a################################", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 10, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10.14.3", "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "", (int) (byte) -1, 1450);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                            Mac OS X                                             ", "4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444", 96);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1100 + "'", int2 == 1100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("     4#a################################     ", "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     4#a################################     " + "'", str2.equals("     4#a################################     "));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/..." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/..."));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31L, (float) 71, (float) 35L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 71.0f + "'", float3 == 71.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 69, (float) 4, 2.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4#a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a" + "'", str1.equals("4#a"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4444", charSequence1, 71);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0", "1.0a8.0a10.0a-1.0                                                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 0, (int) (byte) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-14-1410410" + "'", str11.equals("-14-1410410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1a-1a10a10" + "'", str13.equals("-1a-1a10a10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("    /     ", "                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    /     " + "'", str2.equals("    /     "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("2a-1a2", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a22a-1a22a-1a22a-1a22a-1a2" + "'", str2.equals("2a-1a22a-1a22a-1a22a-1a22a-1a2"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("###############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############################" + "'", str1.equals("###############################"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "4#a################################");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                                                                               69", (int) (short) 100, 144);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4#", "                                                                         ", 28);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4#" + "'", str5.equals("4#"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(51.0d, (-1.0d), (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", 1560);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "4#a################################", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("69", "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "69" + "'", str2.equals("69"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MpStoH avaJ", (java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("\n", "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double[] doubleArray1 = new double[] { 2 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 31, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0" + "'", str3.equals("2.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2.0" + "'", str7.equals("2.0"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sophiesophiesophiesophiesophiesophiesophiesophiesoph");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophiesophiesophiesophiesophiesophiesophiesophiesoph\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "                                                                                                                                                                                                                                                                                                                                                                                                                                 ", (int) (short) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4#a################################     ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("2.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0" + "'", str10.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0" + "'", str12.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                               69", (java.lang.CharSequence) "x86_64", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.lwawt.macosx.LWCToolkit", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                                                      Java HotSpM", 35);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                                                          Java HotSpM", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sophiesophiesophiesophiesophiesophiesophiesophiesoph", "  ", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test049");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.Class<?> wildcardClass2 = javaVersion0.getClass();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/", "10a-1a0a10", "                               100410041                               ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 73, (double) 'a', (double) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "Java HotSpM", "1.81.81.81.81.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.9                             ", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9                             " + "'", str2.equals("0.9                             "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", 100, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophiesophiesophiesophiesophiesophiesophiesophiesoph", "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophiesophiesophiesophiesophiesophiesophiesophiesoph" + "'", str3.equals("sophiesophiesophiesophiesophiesophiesophiesophiesoph"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################Java HotSpot(TM) 64-Bit Server VM", "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                          Java HotSpM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpM" + "'", str1.equals("Java HotSpM"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "2a-1a2", (java.lang.CharSequence) "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 801 + "'", int2 == 801);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "oracle Corporation", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.0 8.0 10.0 -1.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 8.0 10.0 -1.0" + "'", str2.equals("1.0 8.0 10.0 -1.0"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4 a", 63, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4 a" + "'", str3.equals("4 a"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_8", (java.lang.CharSequence) "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                 140014001                       ", (int) (byte) 1, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...a/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...c/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...O/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...S/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...X/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 140014001                       " + "'", str3.equals("                                 140014001                       "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 10, 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.344444444444444444444444444444", 144, "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa" + "'", str1.equals("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                               100410041                               ", "1.7.0_8", "1.341.741.641.741.341.6                                                                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               100410041                               " + "'", str3.equals("                               100410041                               "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10a100", "                                                                                              1.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                 100410041                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("97.042.04-1.0410.0497.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str2.equals("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "  ", 73);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...", (int) (byte) 10, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO" + "'", str2.equals(" CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-14-1410410", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, (long) 137, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 137L + "'", long3 == 137L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER V", (java.lang.CharSequence) " CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 144, (float) 'a', (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 144.0f + "'", float3 == 144.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "2a-1a22a-1a22a-1a22a-1a22a-1a2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a22a-1a22a-1a22a-1a22a-1a2" + "'", str2.equals("2a-1a22a-1a22a-1a22a-1a22a-1a2"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                               100410041                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100410041" + "'", str1.equals("100410041"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("       sophie", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       sophie" + "'", str2.equals("       sophie"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                 ", "Java HotSp", 5);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a100", (java.lang.CharSequence) "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 38);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaa" + "'", str1.equals("aaaaaaaaa"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "001a01", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", (java.lang.CharSequence) "Java Virtual Machine Specification", 1450);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                               ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("    /     ", '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.6", (java.lang.CharSequence[]) strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "    /     " + "'", str6.equals("    /     "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "    /     " + "'", str7.equals("    /     "));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "ttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Java Platform API Specification" + "'", charSequence2.equals("Java Platform API Specification"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.341.741.641.741.341.6                                                                             ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sUN.AWT.cgRAPHICSeNVIRONMENT", (double) 29);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.0d + "'", double2 == 29.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oaaaaa Caapaaatiaa", "##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oaaaaa Caapaaatiaa" + "'", str2.equals("Oaaaaa Caapaaatiaa"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hi!", "                                                         4#a################################     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("2a-1a22a-1a22a-1a22a-1a22a-1a2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2a-1a22a-1a22a-1a22a-1a22a-1a2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Java Virtual Machine Specification", "                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                               69");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                               69" + "'", str1.equals("                                                                                               69"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4#a################################", "Java HotSp", 45);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 2, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("e", "   ", 45);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.31.71.61.71.31.6");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                         4#a################################     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                         4#a################################     " + "'", str1.equals("                                                         4#a################################     "));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "pStoH avaJ", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("             Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             Oracle Corporation" + "'", str1.equals("             Oracle Corporation"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "4#");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        double[] doubleArray5 = new double[] { 97L, 2L, (short) -1, 10L, 'a' };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0a2.0a-1.0a10.0a97.0" + "'", str9.equals("97.0a2.0a-1.0a10.0a97.0"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', 35L, (long) 96);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!", "0.9                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "     4#a################################     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JAVA HOTSPOT(TM) 64-BIT SERVER VM", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.31.71.61.71.31.6", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       1.31.71.61.71.31.6       " + "'", str2.equals("       1.31.71.61.71.31.6       "));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("\nd", "                                 140014001                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nd" + "'", str2.equals("\nd"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) 'a', (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 100, 100);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int22 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int23 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "69" + "'", str21.equals("69"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 69 + "'", int22 == 69);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.6", "Java HotSpM");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 67, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "97.0a2.0a-1.0a10.0a97.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac os x" + "'", str1.equals("mac os x"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.0a8.0a10.0a-1.0                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "                                               \nd1.3                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("       sophie", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_...", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "10a1a-1a10a0a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 45, 100.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 1100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_64", "-1a-1a10a10", 38);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesoph", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4#a################################44444444444444444444444444444444444444444444444444444444444444444", (int) (short) -1, "                     1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a################################44444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4#a################################44444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("             Oracle Corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "                       100410041                                 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.341.741.641.741.341.6", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.341.741.641.741.341.6" + "'", str2.equals("1.341.741.641.741.341.6"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.0a8.0a10.0a-1.0                                                                                ", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a8.0a10.0a-1.0                                                                                " + "'", str2.equals("1.0a8.0a10.0a-1.0                                                                                "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mac OS X", "mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie", 67.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 67.0d + "'", double2 == 67.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "noitaroproC elcarO", (int) ' ', 1560);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 1, (float) 35, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sophie", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "edom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.341.741.641.741.341.6                                                                             ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.341.741.641.741.341.6                                                                             " + "'", str2.equals("1.341.741.641.741.341.6                                                                             "));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 2, 2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0" + "'", str12.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0" + "'", str14.equals("0.0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.6", 96, 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("001a01", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "2a-1a2  -8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ttp://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2a-1a2  ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11", 73);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                              4#a4#4#a4#                               ", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8, (float) 10L, (float) 6L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "mac os x", 137);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Sophiesophiesophiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophiesophiesophiesophiesophiesophiesophiesophiesop" + "'", str1.equals("Sophiesophiesophiesophiesophiesophiesophiesophiesop"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                               \nd1.3                                                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               \nd1.3                                                " + "'", str2.equals("                                               \nd1.3                                                "));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("             ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("     pStoH avaJ                                  ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10a1a-1a10a0a100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4#a################################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "2a-1a22a-1a22a-1a22a-1a22a-1a2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a################################" + "'", str3.equals("4#a################################"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 100, 209);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4aa", (java.lang.CharSequence) "4 a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("2a-1a2  -8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2a-1a2  -8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaa", "                                                                                      Java HotSpM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaa", "             Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa" + "'", str2.equals("aaaaaaaaa"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a-1a10a10", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1a-1a10a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Sophiesophiesophiesophiesophiesophiesophiesophiesoph", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sophiesophiesophiesophiesophiesophiesophiesophiesoph" + "'", str2.equals("Sophiesophiesophiesophiesophiesophiesophiesophiesoph"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_...", "                               100410041                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("001a01", "1#100#-1#0#100", (int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "001a011#100#-1#0#100" + "'", str4.equals("001a011#100#-1#0#100"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http://java.oracle.com/", 137);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 1100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("141004-1404100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141004-1404100" + "'", str2.equals("141004-1404100"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest4.test208");
//        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserDir();
//        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
//        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getUserHome();
//        java.lang.Class<?> wildcardClass3 = file2.getClass();
//        java.io.File file4 = org.apache.commons.lang3.SystemUtils.getJavaHome();
//        java.io.File file5 = org.apache.commons.lang3.SystemUtils.getUserDir();
//        java.io.File[] fileArray6 = new java.io.File[] { file0, file1, file2, file4, file5 };
//        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(fileArray6);
//        org.junit.Assert.assertNotNull(file0);
//        org.junit.Assert.assertNotNull(file1);
//        org.junit.Assert.assertNotNull(file2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(file4);
//        org.junit.Assert.assertNotNull(file5);
//        org.junit.Assert.assertNotNull(fileArray6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str7.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    " + "'", str1.equals("                                                    "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str2.equals("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                         4#a################################     ", "Mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 69);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.lwawt.macosx.CPrinterJob is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "edom dexim", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1L, 0.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.0a8.0a10.0a-1.0", (java.lang.CharSequence) "ttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim", 1, 801);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             " + "'", str1.equals("             "));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("4");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, (int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4#a################################     ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", "4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 32, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str1.equals("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                               100410041                               ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.6", "Java HotSpM");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("MpStoH avaJ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("http://java.oracle.com/", "104100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "US", (java.lang.CharSequence) "MpStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4#a");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "###########################", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        boolean boolean12 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion[] javaVersionArray14 = new org.apache.commons.lang3.JavaVersion[] { javaVersion1, javaVersion5, javaVersion6, javaVersion7, javaVersion9, javaVersion13 };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(javaVersionArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) javaVersionArray14, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(javaVersionArray14);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) javaVersionArray14, '#', 4, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.3" + "'", str11.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertNotNull(javaVersionArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.31.71.61.71.31.6" + "'", str15.equals("1.31.71.61.71.31.6"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.341.741.641.741.341.6" + "'", str17.equals("1.341.741.641.741.341.6"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.31.71.61.71.31.6" + "'", str18.equals("1.31.71.61.71.31.6"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "2", (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("################################     a     4#", "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################     a     4#" + "'", str3.equals("################################     a     4#"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("2a-1a2  ", "                                  ###############################                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2  " + "'", str2.equals("2a-1a2  "));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-14-1410410", (java.lang.CharSequence) "4#a", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", (java.lang.CharSequence) "###################Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4#a################################", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "oracle Corporation", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                      " + "'", str1.equals("                                                                      "));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.Class<?> wildcardClass8 = longArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2a-1a2" + "'", str10.equals("2a-1a2"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2#-1#2" + "'", str13.equals("2#-1#2"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2a-1a2" + "'", str15.equals("2a-1a2"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "  #4444   ", (java.lang.CharSequence) "###########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4aa", 38, "                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4aa                                   " + "'", str3.equals("4aa                                   "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1.0", (java.lang.CharSequence) "2-12");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "4 a", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str2.equals("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("2a-1a2", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String[] strArray1 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "hi!");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "Java HotSpot(TM) 64-Bit Server VM", (int) (short) 10, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.3", 73, (-1));
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "", (int) '#', (int) (short) 1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', (int) (short) -1, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("141004-1404100", 0, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141004-1404100" + "'", str3.equals("141004-1404100"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("2.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                  ###############################                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.0 8.0 10.0 -1.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("pStoH avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pStoH avaJ" + "'", str1.equals("pStoH avaJ"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1L), 1.3f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  ", 73, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("2a-1a22a-1a22a-1a22a-1a22a-1a2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "###################Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", "4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "MpStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 28, (float) '4', 31.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                          Java HotSpM", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        char[] charArray4 = new char[] { '4', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "2.0", charArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4#a" + "'", str6.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("pStoH avaJ", 1450);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pStoH avaJ" + "'", str2.equals("pStoH avaJ"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4#a4#4#a4#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                     1a100a-1a0a100", "                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     1a100a-1a0a100" + "'", str2.equals("                     1a100a-1a0a100"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("###########################", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################" + "'", str2.equals("###########################"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oracle Corporation", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "###########################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#### C#########" + "'", str3.equals("#### C#########"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                       100410041                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100410041" + "'", str1.equals("100410041"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("pStoH avaJ", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pStoH avaJ" + "'", str2.equals("pStoH avaJ"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                 140014001                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "140014001" + "'", str1.equals("140014001"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "#### C#########", (java.lang.CharSequence) "pStoH avaJ                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                               69", (java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.0" + "'", str9.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_...", "1.1", "4 a", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_..." + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_..."));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "4#");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 4#");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "104100" + "'", str8.equals("104100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 100" + "'", str10.equals("10 100"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 100, 75);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) (short) 100, (int) (byte) 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 49, (float) 417);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.1", "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "1.341.741.641.741.341.6                                                                             ", 22);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sUN.AWT.cgRAPHICSeNVIRONMENT", "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 144);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sophiesophiesophiesophiesophiesophiesophiesophiesoph", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "FC0000GN/t/4_V31CQ2N2X1N4/VAR/FOLDERS/_V/6V597ZMN" + "'", str1.equals("FC0000GN/t/4_V31CQ2N2X1N4/VAR/FOLDERS/_V/6V597ZMN"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("\n", "#### C#########", 38);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n" + "'", str3.equals("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.344444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/..." + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/..."));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("       sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "       sophie" + "'", str1.equals("       sophie"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4#", "4#a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("US", 27, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "             Oracle Corporation", 144);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J" + "'", str2.equals("1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "1.3");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.3");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("a.oracle.com/", "pStoH avaJ                            ", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a.oracle.com/" + "'", str3.equals("a.oracle.com/"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 45, (int) (byte) -1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ', 4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n", 28, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001a0a1-a001a1" + "'", str1.equals("001a0a1-a001a1"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                                                      Java HotSpM", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...a/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...c/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...O/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...S/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...X/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "                       100410041                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                      ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "     4#a################################     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0", 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4#a################################", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "                       100410041                                 ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                      Java HotSpM", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                  Java HotSpM" + "'", str2.equals("                                                                                  Java HotSpM"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("     pStoH avaJ                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     pStoH avaJ                                 " + "'", str1.equals("     pStoH avaJ                                 "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("\nd", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nd" + "'", str2.equals("\nd"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        int[] intArray3 = new int[] { '#', (-1), 67 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 67 + "'", int4 == 67);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSp", 13, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-14-1410410", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "1.1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-14-1410410" + "'", str4.equals("-14-1410410"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str2.equals("4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("################################", "Java Platform API Specification", 35);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "001a011#100#-1#0#100");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "################################" + "'", str5.equals("################################"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 28, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 28 + "'", int3 == 28);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                         4#a################################    ", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                         4#a################################    " + "'", str2.equals("                                                         4#a################################    "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "################################", "                              4#a4#4#a4#                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1#100#-1#0#100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#100#-1#0#100" + "'", str2.equals("1#100#-1#0#100"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    " + "'", str1.equals("                                                    "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "pStoH avaJ                            ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aa" + "'", str11.equals("4aa"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "#####################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                               \nd1.3                                                ", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               \nd1.3                                                " + "'", str3.equals("                                               \nd1.3                                                "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4#a4#4#a4#", (java.lang.CharSequence) "pStoH avaJ                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "UTF-8", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n", "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("################################", "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "                                 100410041                                 ", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        char[] charArray7 = new char[] { '#', '4', 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 10, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                 ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#444a4a" + "'", str15.equals("#444a4a"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.0");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 29, (float) 3, (float) 1560);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1560.0f + "'", float3 == 1560.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 0, 37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a100" + "'", str10.equals("10a100"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0", 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "4#a4#4#a4#", 100, (int) (short) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("       sophie", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "       sophie" + "'", str11.equals("       sophie"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oracle Corporation", 801, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4#a4#4#a4#");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("4#a4#4#a4#");
        java.lang.Class<?> wildcardClass7 = strArray6.getClass();
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "sun.awt.CGraphicsEnvironment");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("UTF-8", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTF-8" + "'", str11.equals("UTF-8"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "                                                                                               69", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        char[] charArray3 = new char[] { '4', 'a' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 45, (int) (short) -1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4#a" + "'", str5.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4#a" + "'", str8.equals("4#a"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "Java Virtual Machine Specification", 49);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mac os x");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA" + "'", str5.equals("/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mac os x", (java.lang.CharSequence) "                              4#a4#4#a4#                               ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Sophiesophiesophiesophiesophiesophiesophiesophiesop", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                            Mac OS X                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        char[] charArray6 = new char[] { '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     1a100a-1a0a100", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 97, 10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "pStoH avaJ", charArray6);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4#a" + "'", str8.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4#a" + "'", str11.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 0, (int) (short) 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', (int) (byte) 10, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-14-1410410" + "'", str11.equals("-14-1410410"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-14-1410410" + "'", str13.equals("-14-1410410"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "4 a", 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.0", "                       100410041                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0" + "'", str2.equals("1.0"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                              4#a4#4#a4#                               ", "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn", 0, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn                      " + "'", str4.equals("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn                      "));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a4#a4#a4#a4#a", (java.lang.CharSequence) "2#-1#2", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 75, (int) (short) -1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class [Ljava.lang.String;", "d");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0" + "'", str1.equals("0.0"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                     1a100a-1a0a100", "1.341.741.641.741.341.6                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                     1a100a-1a0a100" + "'", str2.equals("                     1a100a-1a0a100"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        double[] doubleArray1 = new double[] { 2 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 69, (int) (short) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0" + "'", str3.equals("2.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.7.0_8", "sun.lwawt.macosx.CPrinterJob", "ttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_8" + "'", str3.equals("1.7.0_8"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oaaaaa Caapaaatiaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", (int) (byte) 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "hi!");
        java.lang.Class<?> wildcardClass13 = strArray10.getClass();
        int int14 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4#a################################44444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence[]) strArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray6, strArray10);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "d", (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Mac OS X" + "'", str17.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1560.0f, (float) (short) 10, (float) 11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1560.0f + "'", float3 == 1560.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                              4#a4#4#a4#                               ", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                              4#a4#4#a4#                               " + "'", str4.equals("                              4#a4#4#a4#                               "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\nd", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double[] doubleArray1 = new double[] { 2 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', (int) (short) 1, (int) (byte) 1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 27, 71);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0" + "'", str3.equals("2.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2.0" + "'", str6.equals("2.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15", "#####################################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                  ###############################                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                   ###############################                                  " + "'", str1.equals("                                   ###############################                                  "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 63, (float) 6L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 63.0f + "'", float3 == 63.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "2a-1a2  -8", (java.lang.CharSequence) "4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   " + "'", str1.equals("utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   4  utf-8   "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4#", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(3, 35, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, (double) (short) -1, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-14-1410410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14-1410410" + "'", str1.equals("-14-1410410"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_...", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_..."));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.341.741.641.741.341.6                                                                             ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.341.741.641.741.341.6                                                                             " + "'", str2.equals("1.341.741.641.741.341.6                                                                             "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 11, 8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "511.7.0_80-b15.1.7.0_80-b150", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 0L, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("noitaroproC elcarO", "                                   ###############################                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcarO" + "'", str2.equals("noitaroproC elcarO"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn" + "'", str1.equals("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "69" + "'", str5.equals("69"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                                                                                                                                                 ", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                         4#a################################     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                         4#a################################     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("\nd");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "d\n" + "'", str1.equals("d\n"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4#a4#4#a4#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray4 = new char[] { '#', '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 137, 0);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                               100410041                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                 140014001                       ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.40014001E8d + "'", double1.equals(1.40014001E8d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/..." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/..."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 11, 22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("24.80-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                   ###############################                                  ", "10a1a-1a10a0a100", "51.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "2.0", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio", "a4#a4#a4#a4#a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 801, 2L, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("mac os x", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "oracle Corporation", (java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "4#a################################", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.4", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4##############################################################################################" + "'", str3.equals("1.4##############################################################################################"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, (float) 69, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0" + "'", str7.equals("0.0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "pStoH avaJ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                         4#a################################    ", (double) 144);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 144.0d + "'", double2 == 144.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15" + "'", str1.equals("JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4 a", (java.lang.CharSequence) "97.042.04-1.0410.0497.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        double[] doubleArray5 = new double[] { 97L, 2L, (short) -1, 10L, 'a' };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 0, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97.042.04-1.0410.0497.0" + "'", str8.equals("97.042.04-1.0410.0497.0"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, 1.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a100" + "'", str1.equals("10a100"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("class [Ljava.lang.String;", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class[Ljava.lang.String;" + "'", str2.equals("class[Ljava.lang.String;"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(1, (int) (short) 100, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10#100", "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 29, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10#1004#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str4.equals("10#1004#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects", (java.lang.CharSequence) "104100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################Java HotSpot(TM) 64-Bit Server VM", "                                                                         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        java.lang.String str5 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean7 = javaVersion2.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        java.lang.String str12 = javaVersion10.toString();
        java.lang.String str13 = javaVersion10.toString();
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean15 = javaVersion10.atLeast(javaVersion14);
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean17 = javaVersion9.atLeast(javaVersion14);
        boolean boolean18 = javaVersion6.atLeast(javaVersion14);
        boolean boolean19 = javaVersion0.atLeast(javaVersion14);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.3" + "'", str12.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.3" + "'", str13.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1i100i-1i0i100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", "", "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_8", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "                       100410041                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(" ", "51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ", "1i100i-1i0i100");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                  Java HotSpM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 93 + "'", int1 == 93);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "class[Ljava.lang.String;", (java.lang.CharSequence) "001a01", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA", "2a-1a2", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA" + "'", str3.equals("/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim" + "'", str1.equals("Aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#100#-1#0#100" + "'", str10.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#100#-1#0#100" + "'", str12.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/", (int) (byte) 100, 93);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaavaJ", "###########################", 1450);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("################################################################################################################################################", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...a/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...c/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...O/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...S/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...X/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################################################################" + "'", str2.equals("################################################################################################################################################"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironment", "97.042.04-1.0410.0497.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "4 a", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', (int) (byte) 100, 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###################Java HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 417, 801);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 417");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str1.equals("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
    }
}

