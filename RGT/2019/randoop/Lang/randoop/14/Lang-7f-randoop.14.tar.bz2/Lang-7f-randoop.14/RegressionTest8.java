import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4# # #4# #4", 1450, 417);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4# # #4# #4" + "'", str3.equals("4# # #4# #4"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("44444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444..." + "'", str1.equals("44444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444..."));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                              4#a################################     ", 1560);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        org.apache.commons.lang3.JavaVersion[][][] javaVersionArray0 = new org.apache.commons.lang3.JavaVersion[][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(javaVersionArray0);
        org.junit.Assert.assertNotNull(javaVersionArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1100, (-1), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2, 35.0d, (double) 0.9f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use...", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1.equals(4.0f));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use..." + "'", str1.equals("...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use..."));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass4 = javaVersion0.getClass();
        java.lang.String str5 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean7 = javaVersion0.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        java.lang.String str10 = javaVersion8.toString();
        java.lang.String str11 = javaVersion8.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean13 = javaVersion8.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str16 = javaVersion15.toString();
        boolean boolean17 = javaVersion14.atLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean19 = javaVersion14.atLeast(javaVersion18);
        boolean boolean20 = javaVersion8.atLeast(javaVersion18);
        boolean boolean21 = javaVersion6.atLeast(javaVersion18);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.3" + "'", str10.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.3" + "'", str11.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.4" + "'", str16.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "24-142");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("...SOPHIE/dOCUMENTS/DEFECTS4J/TM...");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444444444444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 6, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.0a8.0a10.0a-1.0                                                                                ", "JAVA HOTSPOT(TM) 64-BIT SERVER VM", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0a8.0a10.0a-1.0                                                                                " + "'", str3.equals("1.0a8.0a10.0a-1.0                                                                                "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("97.0#2.0#-1.0#10.0#97.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.0a8.0a10.0a-1.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4#a################################", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "2a-1a22a-1a22a-1a22a-1a22a-1a2", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java HotSpM", (java.lang.CharSequence) "/vr/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        char[] charArray7 = new char[] { '#', '4', 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 10, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpM", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.6", charArray7);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 93, 48);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.0f, 63.0d, 38.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkit", (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("######", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "69", (java.lang.CharSequence) "                                 140014001                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean5 = javaVersion0.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str9 = javaVersion8.toString();
        boolean boolean10 = javaVersion7.atLeast(javaVersion8);
        java.lang.Class<?> wildcardClass11 = javaVersion7.getClass();
        boolean boolean12 = javaVersion0.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("             Oracle Corporatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.Class<?> wildcardClass12 = byteArray2.getClass();
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        short[] shortArray3 = new short[] { (short) -1, (byte) 10, (short) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) 'a', 0);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                                            ", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("en", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 49, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444" + "'", str3.equals("444444444444444444"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4aa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4aa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("SUN.AWT.cgRAPHICSeNVIRONMENT", "############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "Mac OS X", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str4.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                    ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...", (java.lang.CharSequence) "97.0a2.0a-1.0a10.0a97.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "44444444444444444444444444444...4# J44444444444444444444444444444...4# a44444444444444444444444444444...4# v44444444444444444444444444444...4# a44444444444444444444444444444...4#  44444444444444444444444444444...4# P44444444444444444444444444444...4# l44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# f44444444444444444444444444444...4# o44444444444444444444444444444...4# r44444444444444444444444444444...4# m44444444444444444444444444444...4#  44444444444444444444444444444...4# A44444444444444444444444444444...4# P44444444444444444444444444444...4# I44444444444444444444444444444...4#  44444444444444444444444444444...4# S44444444444444444444444444444...4# p44444444444444444444444444444...4# e44444444444444444444444444444...4# c44444444444444444444444444444...4# i44444444444444444444444444444...4# f44444444444444444444444444444...4# i44444444444444444444444444444...4# c44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# i44444444444444444444444444444...4# o44444444444444444444444444444...4# n44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", charSequence2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("oracle corporation", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ora" + "'", str2.equals("ora"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "US", (java.lang.CharSequence) "4 a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 8, 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", "", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("SUN.AWT.cgRAPHICSeNVIRONMENT                  ", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT                  " + "'", str2.equals("SUN.AWT.cgRAPHICSeNVIRONMENT                  "));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("noitaroproC elcarO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "44444444444444444444444444444...4#                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...4#                                                                  " + "'", str2.equals("...4#                                                                  "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("oRACLE cORPORATION", "2a-1a22a-1a22a-1a22a-1a22a-1a2");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.341.741.641.741.341.6                                                                             ", "", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("################################     a     4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################     a     4" + "'", str1.equals("################################     a     4"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "4aa                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                              4#a4#4#a4#                               ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 38, 3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 408, 9);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("p-current.jar", 69, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "2.0", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51031_1560278052/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", (java.lang.CharSequence[]) strArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                               69", "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn                      ", 75);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("51.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("104100j/tmp/run_randoop.pl4/Users/sophie/Documents/defectsj/tmp/run", "pStoH avaJ", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "2.0", "44444444444444444444444444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("51B-08_0.7.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51B-08_0.7.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("51B-08_0.7.14444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO" + "'", str1.equals("CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("SUN.AWT.cgRAPHICSeNVIRONMENT");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("    /     ", '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.6", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.1", "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80-b15", strArray7, strArray12);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("4444                                                                       ", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 8 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "    /     " + "'", str9.equals("    /     "));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80-b15" + "'", str13.equals("1.7.0_80-b15"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                          Java HotSpM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                          Java HotSpM" + "'", str1.equals("                                                          Java HotSpM"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                               \nd1.3                                                ", (java.lang.CharSequence) "                                                         4#a################################     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("SUN.AWT.cgRAPHICSeNVIRONMENT", (long) 63);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 63L + "'", long2 == 63L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4#################################     /Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51031_1560278052", "                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("   ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                                           ", "e", 417);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.3", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "69", charArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', 2, 47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.AWT.cgRAPHICSeNVIRONMENT", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str2.equals("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "2a-1a2  ", (java.lang.CharSequence[]) strArray6);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("104100j/tmp/run_randoop.pl4/Users/sophie/Documents/defectsj/tmp/run", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 22 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str8.equals("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#42#-1#2#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        char[] charArray6 = new char[] { '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 100, 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 67, 22);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44a", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4#a" + "'", str8.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 69 + "'", int14 == 69);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 69 + "'", int15 == 69);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1 100 -1 0 100", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10a100", "\n", "######");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a100" + "'", str3.equals("10a100"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10#100", "24-142", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#00" + "'", str3.equals("0#00"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-14-1410410", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str5.equals("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.Class<?> wildcardClass14 = intArray1.getClass();
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 69 + "'", int15 == 69);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.341.741.641.741.341.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                            Mac OS X                                             ", "                                                                                              1.3", 38);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "     ", 22, 49);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("0#00");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "00#0" + "'", str1.equals("00#0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaavaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", "hiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("2a-1a2", "                                 100410041                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2" + "'", str2.equals("2a-1a2"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("51.0", "Oracle Corporation", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 46);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0" + "'", str4.equals("51.0"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\nd", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\nd" + "'", str2.equals("\nd"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "###################Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!" + "'", str5.equals("hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!#hi#!"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, (double) 408, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Oaaaaa Caapaaatiaa", (java.lang.CharSequence) "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str1.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        char[] charArray4 = new char[] { '4', 'a' };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     1a100a-1a0a100", charArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 4444, 35);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4#a" + "'", str6.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4#a" + "'", str9.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 22 + "'", int10 == 22);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15", "oRACLE cORPORATION", 4444);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                         4#a################################     ", "97.0a2.0a-1.0a10.0a97.044444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                         4#a################################     " + "'", str2.equals("                                                         4#a################################     "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1a", (double) 550);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 550.0d + "'", double2 == 550.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                         4#a################################     ", (java.lang.CharSequence) "             Oracle Corporation", 1560);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle", (java.lang.CharSequence) "1.31.71.61.71.31.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...", "\nd1.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 22.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 22.0f + "'", float3 == 22.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 10, 4);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0#00", "", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################Java HotSpot(TM) 64-Bit Server VM", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "a 4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a 4" + "'", str2.equals("a 4"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaa########################################################################################################################################################################################################", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("class[Ljava.lang.String;", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("...SOPHIE/dOCUMENTS/DEFECTS4J/TM...", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...SOPHIE/dOCUMENTS/DEFECTS4J/TM..." + "'", str2.equals("...SOPHIE/dOCUMENTS/DEFECTS4J/TM..."));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444...4# ", (java.lang.CharSequence) "    ################################a#4                                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("     pStoH avaJ                                  ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.1", "4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.1" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.1"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("     ", "aaaaaaaaa########################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API Specification", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str2.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...4# # #4# #444444444444444444444444444444...", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4159 + "'", int2 == 4159);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 10, 4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) '#', (int) '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10 100" + "'", str20.equals("10 100"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", "Aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim", "Sophiesophiesophiesophiesophiesophiesophiesophiesop");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "us", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        double[] doubleArray1 = new double[] { 2 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 69, (int) (short) 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2.0" + "'", str3.equals("2.0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        short[] shortArray3 = new short[] { (short) 100, (byte) 100, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100410041" + "'", str5.equals("100410041"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.4", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4#################################     /Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/0.0odnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/0.0odnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/0.0odnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("edom dexim", 9.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0.9                             ", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.6Sophiesophiesophiesophiesophiesophiesophiesophiesop", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6Sophiesophiesophiesophiesophiesophiesophiesophiesop" + "'", str2.equals("1.6Sophiesophiesophiesophiesophiesophiesophiesophiesop"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("       sophie", "#444a4a", 1100);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10a1a-1a10a0a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a1a-1a10a0a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                               ", 93);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("i!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("oracle Corporation", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Corporation" + "'", str2.equals("oracle Corporation"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.String[][] strArray1 = new java.lang.String[][] { strArray0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(strArray1);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.048.0410.04-1.0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class[Ljava.lang.String;", 137, "00#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "00#000#000#000#000#000#000#000#000#000#000#000#000#000#0class[Ljava.lang.String;00#000#000#000#000#000#000#000#000#000#000#000#000#000#00" + "'", str3.equals("00#000#000#000#000#000#000#000#000#000#000#000#000#000#0class[Ljava.lang.String;00#000#000#000#000#000#000#000#000#000#000#000#000#000#00"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("44444444444444444444444444444...4# ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 100, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4#a" + "'", str15.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "44a" + "'", str18.equals("44a"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4aa" + "'", str20.equals("4aa"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4aa");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                 100410041                                 ", "# 4 a a", "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/0.0odnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########" + "'", str1.equals("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str2.equals("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) 'a', (int) (short) 0);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 69 + "'", int13 == 69);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "69" + "'", str15.equals("69"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4#################################     /Users/sophie/Documents/defects4j/tmp/run_rndoop.pl_51031_1560278052", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 31.0f, (double) 48, (double) 93);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.0d + "'", double3 == 31.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2 -1 2", "\n", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                               100410041                               ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        char[] charArray7 = new char[] { '#', '4', 'a', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 10, 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpM", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.6", charArray7);
        java.lang.Class<?> wildcardClass15 = charArray7.getClass();
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 1560, 408);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 31 + "'", int8 == 31);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(63, (int) '#', 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 63, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 63");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4aa                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.Class<?> wildcardClass8 = longArray4.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 5, 1);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("97.0a2.0a-1.0a10.0a97.044444444444444444444444444", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0a2.0a-1.0a10.0a97.044444444444444444444444444" + "'", str2.equals("97.0a2.0a-1.0a10.0a97.044444444444444444444444444"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "\n", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 0, (int) (byte) 0);
        java.lang.Class<?> wildcardClass10 = longArray4.getClass();
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "1.344444444444444444444444444444JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15", (java.lang.CharSequence) "10 100aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.344444444444444444444444444444JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15" + "'", charSequence2.equals("1.344444444444444444444444444444JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.344444444444444444444444444444", (java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93 + "'", int2 == 93);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4#a################################44444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a################################4444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4#a################################4444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 0, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a-1a0a10" + "'", str7.equals("10a-1a0a10"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1#10#-1", (java.lang.CharSequence) "-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410U-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410L-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410J-14-1410410", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("44444444444444444444444444444...4# J44444444444444444444444444444...4# a44444444444444444444444444444...4# v44444444444444444444444444444...4# a44444444444444444444444444444...4#  44444444444444444444444444444...4# P44444444444444444444444444444...4# l44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# f44444444444444444444444444444...4# o44444444444444444444444444444...4# r44444444444444444444444444444...4# m44444444444444444444444444444...4#  44444444444444444444444444444...4# A44444444444444444444444444444...4# P44444444444444444444444444444...4# I44444444444444444444444444444...4#  44444444444444444444444444444...4# S44444444444444444444444444444...4# p44444444444444444444444444444...4# e44444444444444444444444444444...4# c44444444444444444444444444444...4# i44444444444444444444444444444...4# f44444444444444444444444444444...4# i44444444444444444444444444444...4# c44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# i44444444444444444444444444444...4# o44444444444444444444444444444...4# n44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# ", 27, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444...4# J44444444444444444444444444444...4# a44444444444444444444444444444...4# v44444444444444444444444444444...4# a44444444444444444444444444444...4#  44444444444444444444444444444...4# P44444444444444444444444444444...4# l44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# f44444444444444444444444444444...4# o44444444444444444444444444444...4# r44444444444444444444444444444...4# m44444444444444444444444444444...4#  44444444444444444444444444444...4# A44444444444444444444444444444...4# P44444444444444444444444444444...4# I44444444444444444444444444444...4#  44444444444444444444444444444...4# S44444444444444444444444444444...4# p44444444444444444444444444444...4# e44444444444444444444444444444...4# c44444444444444444444444444444...4# i44444444444444444444444444444...4# f44444444444444444444444444444...4# i44444444444444444444444444444...4# c44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# i44444444444444444444444444444...4# o44444444444444444444444444444...4# n44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# " + "'", str3.equals("44444444444444444444444444444...4# J44444444444444444444444444444...4# a44444444444444444444444444444...4# v44444444444444444444444444444...4# a44444444444444444444444444444...4#  44444444444444444444444444444...4# P44444444444444444444444444444...4# l44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# f44444444444444444444444444444...4# o44444444444444444444444444444...4# r44444444444444444444444444444...4# m44444444444444444444444444444...4#  44444444444444444444444444444...4# A44444444444444444444444444444...4# P44444444444444444444444444444...4# I44444444444444444444444444444...4#  44444444444444444444444444444...4# S44444444444444444444444444444...4# p44444444444444444444444444444...4# e44444444444444444444444444444...4# c44444444444444444444444444444...4# i44444444444444444444444444444...4# f44444444444444444444444444444...4# i44444444444444444444444444444...4# c44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# i44444444444444444444444444444...4# o44444444444444444444444444444...4# n44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        short[] shortArray1 = new short[] { (short) -1 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10#100", 1100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.341.741.641.741.341.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 49, (float) 49, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.8", (java.lang.CharSequence) "1.0 8.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("################################     a     4#", 1450);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("edom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10#100", 38, "1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.01.01.01.01.0110#1001.01.01.01.01.01" + "'", str3.equals("1.01.01.01.01.0110#1001.01.01.01.01.01"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("##############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##############################" + "'", str1.equals("##############################"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("    /     ", '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Corporation");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.341.741.641.741.341.6                                                                             ");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.81.81.81.81.81.81.81.81.8", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 78");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "    /     " + "'", str9.equals("    /     "));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("en", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("     pStoH avaJ                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "pStoH avaJ" + "'", str1.equals("pStoH avaJ"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "97.0a2.0a-1.0a10.0a97.044444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("5", 550, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1a100a-1a0a100", (java.lang.CharSequence) "p-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 97, 6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("4#a4#4#a4#");
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("4#a4#4#a4#");
        java.lang.Class<?> wildcardClass11 = strArray10.getClass();
        int[] intArray13 = new int[] { 69 };
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray13);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray13, '#', 31, 0);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray13);
        java.lang.Class<?> wildcardClass20 = intArray13.getClass();
        long[] longArray24 = new long[] { 2, (short) -1, 2 };
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join(longArray24, '4', 0, (-1));
        java.lang.Class<?> wildcardClass29 = longArray24.getClass();
        java.lang.Class<?> wildcardClass30 = longArray24.getClass();
        java.lang.Class[] classArray32 = new java.lang.Class[5];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray33 = (java.lang.Class<?>[]) classArray32;
        wildcardClassArray33[0] = wildcardClass5;
        wildcardClassArray33[1] = wildcardClass8;
        wildcardClassArray33[2] = wildcardClass11;
        wildcardClassArray33[3] = wildcardClass20;
        wildcardClassArray33[4] = wildcardClass30;
        java.lang.String str44 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray33);
        java.lang.String str45 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) wildcardClassArray33);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 69 + "'", int14 == 69);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 69 + "'", int19 == 69);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(classArray32);
        org.junit.Assert.assertNotNull(wildcardClassArray33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [J" + "'", str44.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [J"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [J" + "'", str45.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Iclass [J"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava" + "'", str2.equals("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "class[Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("2#-1#2", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2#-1#2" + "'", str2.equals("2#-1#2"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                             sophie                                             ", (java.lang.CharSequence) "                                   ###############################                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, 32, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 77, (int) (short) -1);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "104100" + "'", str8.equals("104100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java" + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java/users/sophie/library/java/extensions:/library/java/javavirtualmachines/jdk.jdk/contents/home/jre/lib/ext:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", "edom dexim");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        " + "'", str2.equals("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", "10 100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("    ", "                                                                                  Java HotSpM", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.6", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   1.6    " + "'", str2.equals("   1.6    "));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("tiklooTCWL.xsocam.twawl.nus", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             tiklooTCWL.xsocam.twawl.nus             " + "'", str2.equals("             tiklooTCWL.xsocam.twawl.nus             "));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oaaaaa Caapaaatiaa", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        short[] shortArray3 = new short[] { (short) -1, (byte) 10, (short) -1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 69, (int) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#10#-1" + "'", str7.equals("-1#10#-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "    ################################a#4                                                         ", (java.lang.CharSequence) "Sophiesophiesophiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                  Java HotSpM", "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpM" + "'", str2.equals("Java HotSpM"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.0a8.0a10.0a-1.0                                                                                ", 4159);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               1.0a8.0a10.0a-1.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               1.0a8.0a10.0a-1.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) '4', (int) '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 -1 10 10" + "'", str12.equals("-1 -1 10 10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("5", "             Oracle Corporation", "/Users/sophie/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5" + "'", str3.equals("5"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "4# # #4# #4", 71);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        float[] floatArray2 = new float[] { 0L, 32 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 32.0f + "'", float6 == 32.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn                      ", "             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn" + "'", str2.equals("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.4##############################################################################################");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', 408, 1450);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 408");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "UTF-8", charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 100, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4#a" + "'", str15.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", "-1#10#-1                                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4#a################################4444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a################################4444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4#a################################4444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("ttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ttp://java.oracle.com/" + "'", str1.equals("ttp://java.oracle.com/"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#-1#10#10", "1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                  ###############################                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("# 4 a a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# 4 a a" + "'", str2.equals("# 4 a a"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#a4#", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4#a4#a4#" + "'", str2.equals("#a4#a4#a4#"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-14-1410410/-14-1410410u-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410l-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410u-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410l-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410j-14-1410410", 801, "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b-14-1410410/-14-1410410u-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410l-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410u-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410l-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410j-14-1410410" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b-14-1410410/-14-1410410u-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410l-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-14104101-14-1410410.-14-14104107-14-1410410.-14-14104100-14-1410410_-14-14104108-14-1410410/-14-1410410u-14-1410410s-14-1410410e-14-1410410r-14-1410410s-14-1410410/-14-1410410s-14-1410410o-14-1410410p-14-1410410h-14-1410410i-14-1410410e-14-1410410/-14-1410410l-14-1410410i-14-1410410b-14-1410410r-14-1410410a-14-1410410r-14-1410410y-14-1410410/-14-1410410j-14-1410410"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("             ", "#a4aaaa");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "Java(TM) SE Runtime Environment", (int) 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn" + "'", str8.equals("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(52.0f, 0.0f, (float) 104100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 104100.0f + "'", float3 == 104100.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                   69", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   69" + "'", str2.equals("                                   69"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", "                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str2.equals("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use...", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use..." + "'", str3.equals("...ts4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Use..."));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "4#a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 1450, 0);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracle Corporation", charArray7);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...SOPHIE/dOCUMENTS/DEFECTS4J/TM...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", 1100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1100 + "'", int2 == 1100);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4444                                                                       ", 37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     " + "'", str2.equals("                                     "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_.../Users/sophie/Documents/             Oracle Corporation", 1450, "4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4/Users/sophie/Documents/defects4j/tmp/run_.../Users/sophie/Documents/             Oracle Corporation4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4" + "'", str3.equals("4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4/Users/sophie/Documents/defects4j/tmp/run_.../Users/sophie/Documents/             Oracle Corporation4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1#10#-1                                            ", "             Oracle Corporation", 63);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("2#-1#2", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2#-1#2" + "'", str2.equals("2#-1#2"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        double[][] doubleArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(doubleArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        char[] charArray6 = new char[] { '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "2.0", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM.0_8", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                             sophie                                             ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4#a" + "'", str8.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444", "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...a/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...c/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...O/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...S/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/... /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...X/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...", (java.lang.CharSequence) "                                                          Java HotSpM", 1450);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        float[] floatArray2 = new float[] { 0L, 32 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporatio", "10a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporatio" + "'", str2.equals("oracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporationoracle corporatio"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", "10#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aa" + "'", str11.equals("4aa"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("################################", 52, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 1450, "0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J" + "'", str3.equals("1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ", 75);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#444a4a", "                                                         4#a################################     ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.4                                                                                                 ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("pMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", "SUN.AWT.cgRAPHICSeNVIRONMENT                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSp" + "'", str2.equals("pMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSp"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolki", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolki" + "'", str2.equals("sun.lwawt.macosx.LWCToolki"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                              1.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              1.3" + "'", str2.equals("                                                                                              1.3"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("511.7.0_80-b15.1.7.0_80-b150");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "511.7.0_80-b15.1.7.0_80-b150" + "'", str1.equals("511.7.0_80-b15.1.7.0_80-b150"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        char[] charArray8 = new char[] { '4', ' ', ' ', '4', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 14, 10);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 49 + "'", int10 == 49);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4# # #4# #4" + "'", str12.equals("4# # #4# #4"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "d\n", "4#a################################44444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, (double) 47, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("d", 11, "hiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hiesophiesd" + "'", str3.equals("hiesophiesd"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, 22, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 29, (long) 144, (long) 14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 144L + "'", long3 == 144L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) 'a', (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 100, 100);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int22 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "69" + "'", str21.equals("69"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 69 + "'", int22 == 69);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "69" + "'", str24.equals("69"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.048.0410.04-1.0", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.048.0410.04-1.0" + "'", str3.equals("1.048.0410.04-1.0"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "104100" + "'", str10.equals("104100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/.../uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Java Platform API Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "ora", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                               ", "1.81.81.81.81.81.81.81.81.8");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("2.0", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.0" + "'", str2.equals("2.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.02.0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1560L, 0L, (long) 75);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("    ", "    ################################a#4                                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    ################################a#4                                                         " + "'", str2.equals("    ################################a#4                                                         "));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4#a################################44444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "                                   ###############################                                  ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 32, (int) ' ');
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "001a0a1-a001a1", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     " + "'", str1.equals("     "));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 38, 3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a100" + "'", str12.equals("10a100"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4aa                                   ", 52, 67);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4aa                                   " + "'", str3.equals("4aa                                   "));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) " ", (java.lang.CharSequence) "1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1a100a-1a0a100" + "'", charSequence2.equals("1a100a-1a0a100"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("140014001", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "140014001" + "'", str2.equals("140014001"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                               \nd1.3                                                ", "                                  ###############################                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               \nd1.3                                                " + "'", str2.equals("                                               \nd1.3                                                "));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                  ###############################                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                         ", "                                                                                                                           ", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                         " + "'", str4.equals("                                                                         "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU", "#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#42#-1#2#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU" + "'", str2.equals("508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) 'a', (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 100, 100);
        int int20 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int23 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 10, 0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 69 + "'", int20 == 69);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "69" + "'", str22.equals("69"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("class [Ljava.lang.String;", 53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            class [Ljava.lang.String;" + "'", str2.equals("                            class [Ljava.lang.String;"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("d\n");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 69 + "'", int8 == 69);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.9", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-b11", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444444444444444444444444444444444444444", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Oaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4/Users/sophie/Documents/defects4j/tmp/run_.../Users/sophie/Documents/             Oracle Corporation4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4#4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "          ", (java.lang.CharSequence) "                              4#a4#4#a4#                               ", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#42#-1#2#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                               ", charArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 0, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          ", "aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                                          Java HotSpM", (java.lang.CharSequence) "4 ", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.6", "Java HotSpM");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.6" + "'", str4.equals("1.6"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mac os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a100a-1a0a100" + "'", str9.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n" + "'", str1.equals("#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n#########C ####\n"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44 4 444 44", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("aaaaaaaaaa", "i!", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        java.lang.Class<?> wildcardClass6 = strArray4.getClass();
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "10#100");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "############     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                         4#a################################    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("hiesophiesophiesophiesophiesophiesoph", "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiesophiesophiesophiesophiesophiesoph" + "'", str2.equals("hiesophiesophiesophiesophiesophiesoph"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(6L, 1L, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11", (java.lang.CharSequence) "       sophie");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 5, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.0 8.0 10.0 -1.0" + "'", str16.equals("1.0 8.0 10.0 -1.0"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("2a-1a2  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2  " + "'", str2.equals("2a-1a2  "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a-1a10a10" + "'", str9.equals("-1a-1a10a10"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, (long) 4159, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("p-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"p-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "d1.3", (java.lang.CharSequence) "d\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#" + "'", str1.equals("4#"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "JMpStoH avaJMpStoH avaJMpStoH avaJMpStoH avaJ0.15", (java.lang.CharSequence) "97.042.04-1.0410.0497.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.344444444444444444444444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", charSequence2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(7L, 417L, 104100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########", "#4444", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "0.00.00.00.0", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                   69", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str1.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/mac os xmac os xERmac os x/mac os xOPHIE/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xIBRARY/jAmac os xA/jAmac os xAmac os xIRTUALmACHINEmac os x/mac os xDK1.7.0_80.mac os xDK/mac os xONTENTmac os x/mac os xOmac os xE/mac os xRE/LIB/EXT:/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/mac os xETWORK/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/sYmac os xTEmac os x/mac os xIBRARY/jAmac os xA/mac os xXTENmac os xIONmac os x:/Umac os xR/LIB/mac os xAmac os xA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("...otSpM", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...otSpM" + "'", str2.equals("...otSpM"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.3");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str6.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("    /     ", '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Oracle Corporation");
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#4444", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "    /     " + "'", str9.equals("    /     "));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "1.344444444444444444444444444444");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", (int) (short) 1, 550);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mixed mode", "http://java.oracle.com/", "1.0#8.0#10.0#-1.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 2, 2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0" + "'", str12.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("OaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaa", 48);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaa" + "'", str2.equals("OaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaa"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray7 = null;
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", strArray6, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str8.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2a-1a2  ", "noitaroproC elcarO");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "###########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSp", 'a');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", strArray5, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 104");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444", "Sophiesophiesophiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hiesophiesophiesophiesophiesophiesoph", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#100#-1#0#100" + "'", str10.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#100#-1#0#100" + "'", str12.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1 100 -1 0 100" + "'", str14.equals("1 100 -1 0 100"));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.01.01.01.01.0110#1001.01.01.01.01.01", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 4444);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "10a-1a0a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 417);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa c" + "'", str1.equals("oaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa caapaaatiaaoaaaaa c"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                                                      Java HotSp");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSp" + "'", str1.equals("Java HotSp"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", (java.lang.CharSequence) "010 10010 10010 10010 10010 10010 10010 10010 10010 10010 10010 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", (java.lang.CharSequence[]) strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray3, strArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str14.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaavaJ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.6Sophiesophiesophiesophiesophiesophiesophiesophiesop");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6Sophiesophiesophiesophiesophiesophiesophiesophiesop" + "'", str1.equals("1.6Sophiesophiesophiesophiesophiesophiesophiesophiesop"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                   ###############################                                  ", 801);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "dddddddddddddddddddddddddddddddddddddddddd     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, 0.0f, (float) 47);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "\nd", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "\nd" + "'", charSequence2.equals("\nd"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie", "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.4##############################################################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "#444a4a", (java.lang.CharSequence) "001a0a1-a001a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("4aa                                   ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4aa                                   " + "'", str2.equals("4aa                                   "));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10#100", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#100" + "'", str3.equals("10#100"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.048.0410.04-1.0" + "'", str11.equals("1.048.0410.04-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("    /     ", '#');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "Oracle Corporation");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie", "4#a################################");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80-b15", strArray8, strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "sophie" + "'", str13.equals("sophie"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7.0_80-b15" + "'", str14.equals("1.7.0_80-b15"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("             10 100             ", (long) 45);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray13 = new char[] { '4', ' ', ' ', '4', ' ', '4' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", charArray13);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", charArray13);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesoph", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4#a################################", charArray13);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "141004-1404100", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 49 + "'", int15 == 49);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", " ", 408);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("   ", "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.341.741.641.741.341.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) 14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.0d + "'", double2 == 14.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                 140014001                       ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        int[] intArray4 = new int[] { 97, (short) 0, 801, 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 1560, 49);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mac os x", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Loracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Li", "CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaOatiapa CaO");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80", (double) 144);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 144.0d + "'", double2 == 144.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("# 4 a a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# 4 a a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "OaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaaOaaaaaCaapaaatiaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C########..." + "'", str2.equals("#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C#########\n#### C########..."));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.awt.CGraphicsEnvironment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "             Oracle Corporation", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("2a-1a22a-1a22a-1a22a-1a22a-1a2", 5, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2a-1a22a-1a22a-1a22a-1a22a-1a2" + "'", str3.equals("2a-1a22a-1a22a-1a22a-1a22a-1a2"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar" + "'", str1.equals("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("######", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "######" + "'", str2.equals("######"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "                                   ###############################                                  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                    ###############################                                  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "104100" + "'", str8.equals("104100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10 100" + "'", str10.equals("10 100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (int) (short) -1, 1100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("42508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/eihpos/sresU/T/ng0000cf4n1x2n2qc13v_4nmz795v6/v_/sredlof/rav/2508720651_13015_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444...4# J44444444444444444444444444444...4# a44444444444444444444444444444...4# v44444444444444444444444444444...4# a44444444444444444444444444444...4#  44444444444444444444444444444...4# P44444444444444444444444444444...4# l44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# f44444444444444444444444444444...4# o44444444444444444444444444444...4# r44444444444444444444444444444...4# m44444444444444444444444444444...4#  44444444444444444444444444444...4# A44444444444444444444444444444...4# P44444444444444444444444444444...4# I44444444444444444444444444444...4#  44444444444444444444444444444...4# S44444444444444444444444444444...4# p44444444444444444444444444444...4# e44444444444444444444444444444...4# c44444444444444444444444444444...4# i44444444444444444444444444444...4# f44444444444444444444444444444...4# i44444444444444444444444444444...4# c44444444444444444444444444444...4# a44444444444444444444444444444...4# t44444444444444444444444444444...4# i44444444444444444444444444444...4# o44444444444444444444444444444...4# n44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# a44444444444444444444444444444...4# ", (java.lang.CharSequence) "10#-1#0#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 0, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "141004-1404100" + "'", str9.equals("141004-1404100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1a100a-1a0a100" + "'", str15.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1 100 -1 0 100" + "'", str17.equals("1 100 -1 0 100"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        long[] longArray4 = new long[] { (-1L), (-1L), (byte) 10, (byte) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) '4', (int) '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 558, 550);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("a4#a4#a4#a4#a", "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                                                                                                                                                                                                                                                                                 ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }
}

