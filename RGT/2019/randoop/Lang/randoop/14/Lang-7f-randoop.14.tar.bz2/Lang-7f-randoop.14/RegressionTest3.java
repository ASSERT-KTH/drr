import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                          Java HotSpM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("i!", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "i!" + "'", str2.equals("i!"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0.0", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1a100a-1a0a100", "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1i100i-1i0i100" + "'", str3.equals("1i100i-1i0i100"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MpStoH avaJ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "edom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                    ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0", 49, "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ" + "'", str3.equals("51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        char[] charArray6 = new char[] { '#', '4', 'a', 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) (byte) 10, 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", charArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#444a4a" + "'", str14.equals("#444a4a"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#a4aaaa" + "'", str16.equals("#a4aaaa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("     4#a################################     ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", 49, 73);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str4.equals("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("24.80-b11", 8, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11" + "'", str3.equals("24.80-b11"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#####################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "    /     ", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("  ", "", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                      " + "'", str3.equals("                                                                      "));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification", (int) (short) 1, "sUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("2a-1a2");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4aa", (java.lang.CharSequence) "0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                     1a100a-1a0a100", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("2a-1a2", "             Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a-1a2" + "'", str2.equals("2a-1a2"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen" + "'", str1.equals("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4#a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a" + "'", str1.equals("4#a"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "4444", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  #4444   ", ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "#4444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/", "4#a################################44444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "Java Platform API Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("sophiesophiesophiesophiesophiesophiesophiesophiesoph", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 5, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "  ", "                                  ###############################                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", (java.lang.CharSequence) "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("             Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("http://java.oracle.com/", "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ttp://java.oracle.com/" + "'", str2.equals("ttp://java.oracle.com/"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                            Mac OS X                                             ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 144, (float) 32L, (float) 73);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 144.0f + "'", float3 == 144.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                              1.3", (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim", "                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("2a-1a2  -8", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "2-12", (java.lang.CharSequence) "HI!", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(97.0d, (double) 96, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) ' ', 1560);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#####################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.81.81.81.81.81.81.81.81.8", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("\nd", "1.3", (int) (short) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\nd1.3" + "'", str4.equals("\nd1.3"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 28, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "edom dexim", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/", charSequence1, 69);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "x86_64", "1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("MpStoH avaJ", "Java HotSpM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10a1a-1a10a0a100", "UTF-8", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a-1a10a0a100" + "'", str3.equals("10a1a-1a10a0a100"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "   ", 10, 10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6, 1560);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10 100", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                 100410041                                 ", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("oracle Corporation", "i!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 75, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 75");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("pStoH avaJ                            ", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     pStoH avaJ                                  " + "'", str2.equals("     pStoH avaJ                                  "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\nd1.3", 49, 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern(" ", "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444", "97.042.04-1.0410.0497.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10 100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaavaJ", (java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oaaaaa Caapaaatiaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", (int) (byte) 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oaaaaa Caapaaatiaa" + "'", str5.equals("Oaaaaa Caapaaatiaa"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1 == 51.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "###################Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("##", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##" + "'", str2.equals("##"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("mixed mode", "4#a4#4#a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("edom dexim", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        char[] charArray6 = new char[] { '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     1a100a-1a0a100", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 97, 10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "d", charArray6);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "     4#a################################     ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4#a" + "'", str8.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4#a" + "'", str11.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("104100", "1.344444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104100" + "'", str2.equals("104100"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkit", (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "1.0a8.0a10.0a-1.0", "1#100#-1#0#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str3.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "141004-1404100", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str1.equals("4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4#a", "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 75);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4#a" + "'", str4.equals("4#a"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4#a" + "'", str5.equals("4#a"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn" + "'", str2.equals("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("511.7.0_80-b15.1.7.0_80-b150", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "511.7.0_80-b15.1.7.0_80-b150" + "'", str2.equals("511.7.0_80-b15.1.7.0_80-b150"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0" + "'", str1.equals("0.0"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  UTF-8   ", "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4#a################################", "#444a4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a################################" + "'", str2.equals("4#a################################"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                    " + "'", str1.equals("                                                    "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "2a-1a2  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15", (java.lang.CharSequence) "1.6", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_...", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("#a4aaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a4aaaa" + "'", str1.equals("#a4aaaa"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.3", "1i100i-1i0i100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#4444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 209 + "'", int1 == 209);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double[] doubleArray5 = new double[] { 97L, 2L, (short) -1, 10L, 'a' };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("  UTF-8   ", "4", 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str3.equals("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("JAVA HOTSPOT(TM) 64-BIT SERVER VM", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER V" + "'", str2.equals("JAVA HOTSPOT(TM) 64-BIT SERVER V"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 100, 4);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "                                                                                      Java HotSpM");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                       Java HotSpM");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        short[] shortArray5 = new short[] { (short) 1, (short) 100, (short) -1, (byte) 0, (byte) 100 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a-1a0a100" + "'", str7.equals("1a100a-1a0a100"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#100#-1#0#100" + "'", str10.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#100#-1#0#100" + "'", str12.equals("1#100#-1#0#100"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "10a1a-1a10a0a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1#100#-1#0#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray5);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#a" + "'", str10.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                  ###############################                                   ", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("http://java.oracle.com/", "10a1a-1a10a0a100", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "                                 100410041                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 71 + "'", int2 == 71);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("10a1a-1a10a0a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a1a-1a10a0a100" + "'", str1.equals("10a1a-1a10a0a100"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "10#100");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sophie" + "'", str4.equals("sophie"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052" + "'", str2.equals("     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("  ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("69", "1.81.81.81.81.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "69" + "'", str2.equals("69"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.awt.CGraphicsEnvironment", (float) 417);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 417.0f + "'", float2 == 417.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Oracle Corporation", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a100a-1a0a100" + "'", str1.equals("1a100a-1a0a100"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8", "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4#a", "2a-1a2  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#" + "'", str2.equals("4#"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10a1a-1a10a0a100", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-b15", 6);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "4#");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a4#a4#a4#a4#a" + "'", str5.equals("a4#a4#a4#a4#a"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 100);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("2-12", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2-12" + "'", str2.equals("2-12"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("  UTF-8   ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  UTF-8   " + "'", str2.equals("  UTF-8   "));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("mixed mode", "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("en", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "d", (java.lang.CharSequence) "pStoH avaJ", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4#", "4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi", 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "################################     a     4#", (java.lang.CharSequence) "Oaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("             Oracle Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("2-12");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "2", (java.lang.CharSequence) "1.341.741.641.741.341.6", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10a-1a0a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.81.81.81.81.81.81.81.81.8", 96);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#" + "'", str1.equals("4#"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.awt.CGraphicsEnvironment", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("4#a4#4#a4#", "#####################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a4#4#a4#" + "'", str2.equals("4#a4#4#a4#"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                      Java HotSpM", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "1.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.7.0_80-b15");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sUN.AWT.cgRAPHICSeNVIRONMENT", "4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str2.equals("sUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(6, 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "  ", (java.lang.CharSequence) "ttp://java.oracle.com/", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "##", (java.lang.CharSequence) "4 a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("    ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                      Java HotSpM", "Java Virtual Machine Specification");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("###################Java HotSpot(TM) 64-Bit Server VM", "sophie");
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.3", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                 100410041                                 ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray2 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray2);
        org.junit.Assert.assertNotNull(numberUtilsArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn", 144);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "001a01", (java.lang.CharSequence) "1.344444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0" + "'", str1.equals("1.0"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#4444", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "###############################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.1", (double) 1.4f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1d + "'", double2 == 1.1d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA", "Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 27, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("24.80-b11", "10#100", (int) (byte) 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 31, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 69 + "'", int12 == 69);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                            Mac OS X                                             ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sophie", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       sophie" + "'", str2.equals("       sophie"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("a.oracle.com/", "104100", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "51.0Java HotSpMJava HotSpMJava HotSpMJava HotSpMJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4aa", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "###################Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.7.0_80-B15"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("104100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 104100L + "'", long1.equals(104100L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 8, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                               ", (java.lang.CharSequence) "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 73, (-1L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                            Mac OS X                                             ", (java.lang.CharSequence) "\nd");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4#a", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                     1a100a-1a0a100", charArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 97, 10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#a" + "'", str10.equals("4#a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 22 + "'", int11 == 22);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "                                                                                              1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4", "", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.7.0_80", "1.0 8.0 10.0 -1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "noitaroproC elcarO", 144);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-14-1410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4#a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 100, 73);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10#100" + "'", str17.equals("10#100"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.341.741.641.741.341.6                                                                             ", 417, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("2#-1#2", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2#-1#2" + "'", str3.equals("2#-1#2"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 75, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "pStoH avaJ                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "1.4", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" ", "2-12");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52, (double) 22, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4#a4#4#a4#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444i!4444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4#", "                                                                         ", 28);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4#" + "'", str4.equals("4#"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Users/sophie", "                                                                                              1.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("  #4444   ", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  #4444   " + "'", str2.equals("  #4444   "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("4#a4#4#a4#", 71);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                              4#a4#4#a4#                               " + "'", str2.equals("                              4#a4#4#a4#                               "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4#a################################44444444444444444444444444444444444444444444444444444444444444444", (int) 'a', "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4#a################################44444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4#a################################44444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "################################", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", (java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1450 + "'", int2 == 1450);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, (-1.0d), (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("4#a################################", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a################################" + "'", str2.equals("4#a################################"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "noitaroproC elcarO", (java.lang.CharSequence) "                     1a100a-1a0a100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", "Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        char[] charArray5 = new char[] { '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10a1a-1a10a0a100", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4#a" + "'", str7.equals("4#a"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aa" + "'", str11.equals("4aa"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", "", (int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaa" + "'", str4.equals("aaaaaaaaaa"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("2-12", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2-12" + "'", str2.equals("2-12"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int[] intArray1 = new int[] { 69 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 69 + "'", int2 == 69);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "69" + "'", str4.equals("69"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "69" + "'", str6.equals("69"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Java HotSpM", (java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0.0", "pStoH avaJ", "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0" + "'", str3.equals("0.0"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2a-1a2" + "'", str9.equals("2a-1a2"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2#-1#2" + "'", str11.equals("2#-1#2"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "     4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "\nd");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("511.7.0_80-b15.1.7.0_80-b150", "2.0", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "511.7.0_80-b15.1.7.0_80-b150" + "'", str3.equals("511.7.0_80-b15.1.7.0_80-b150"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4', 75, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", 27, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str3.equals("Javaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaHotSpot(TM)aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa64-Bitaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaServeraaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corporation", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "a4#a4#a4#a4#a");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...M/Users/", (java.lang.CharSequence) "2a-1a2  ", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                         4#a################################     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                         4#a################################    " + "'", str1.equals("                                                         4#a################################    "));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("     pStoH avaJ                                  ", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     pStoH avaJ                                  " + "'", str2.equals("     pStoH avaJ                                  "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.Class<?> wildcardClass8 = longArray3.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2a-1a2" + "'", str10.equals("2a-1a2"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 1, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("     pStoH avaJ                                  ", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "2#-1#2", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.8", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 69, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 69");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '#', (float) (byte) -1, (float) 75);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 75.0f + "'", float3 == 75.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", 0);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "AVAJ/BIL/RSU/:SNOISNETXe/AVAj/YRARBIl/METSYs/:SNOISNETXe/AVAj/YRARBIl/KROWTEn/:SNOISNETXe/AVAj/YRARBIl/:TXE/BIL/ERJ/EMOh/STNETNOc/KDJ.08_0.7.1KDJ/SENIHCAmLAUTRIvAVAj/AVAj/YRARBIl/:SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu/", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "2a-1a2  ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444", "4#", 417);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "1.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11", 38);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str4.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) 73, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.3", "##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str2.equals("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String[] strArray3 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        try {
            float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100410041", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [Ljava.lang.String;", (java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", "4#a", (int) (short) 1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn", 97, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJob", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("################################     a     4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############################     a     4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("             Oracle Corporation", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                       100410041                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 140014001                       " + "'", str1.equals("                                 140014001                       "));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 67);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn", 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("fc0000gn/T/4_v31cq2n2x1n4/var/folders/_v/6v597zmn", "aaaaaaaaaa", 75);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("UTF-8", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean5 = javaVersion0.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion6.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean11 = javaVersion6.atLeast(javaVersion10);
        boolean boolean12 = javaVersion0.atLeast(javaVersion10);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("             Oracle Corporation", "", (int) (byte) 100);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-14-1410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.2999999523162842d, (double) (byte) -1, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2999999523162842d + "'", double3 == 1.2999999523162842d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.0 8.0 10.0 -1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0 8.0 10.0 -1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4#a################################", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "  UTF-8   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "###################Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "x86_64");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4 a", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str6.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("100410041", "################################");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, 51.0d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM" + "'", str2.equals("Java HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpMJava HotSpM"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("en", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("i!", "       sophie", "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "i!" + "'", str4.equals("i!"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#444a4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0a8.0a10.0a-1.0                                                                                ", "################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 100, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', (int) (byte) 1, 0);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("2a-1a2  ", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2a-1a2  " + "'", str3.equals("2a-1a2  "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.81.81.81.81.81.81.81.81.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en", 67);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                       100410041                                 ", (java.lang.CharSequence) "ttp://java.oracle.com/", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-14-1410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.9                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                               69", "\nd1.3", 209);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "             Oracle Corporation", "4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("     pStoH avaJ                                  ", "001a01", "1.1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     pStoH avaJ                                  " + "'", str3.equals("     pStoH avaJ                                  "));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 73, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10#100", (java.lang.CharSequence) "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "  #4444   ", 38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Sophiesophiesophiesophiesophiesophiesophiesophiesoph");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "   ", (java.lang.CharSequence) "4#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java HotSpM", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("4#", "                                                                         ", 28);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8" + "'", str6.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_8"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "2#-1#2", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) (short) 100, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str13.equals("1.0a8.0a10.0a-1.0"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "                              4#a4#4#a4#                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J/Users/sophie/Library/1.7.0_8/Users/sophie/Library/J", "#4444", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("################################     a     4#", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################     a     4#" + "'", str2.equals("################################     a     4#"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 100, 73);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java Platform API Specification");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        long[] longArray3 = new long[] { 2, (short) -1, 2 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 0, (-1));
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "97.042.04-1.0410.0497.0", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4#a4#4#a4#", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.0a8.0a10.0a-1.0                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0a8.0a10.0a-1.0                                                                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double[] doubleArray0 = new double[] {};
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "104100" + "'", str10.equals("104100"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaavaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava" + "'", str1.equals("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaarevreSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatiB-46aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)MT(topStoHaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaava"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Mac OS X is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10a100", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a100" + "'", str2.equals("10a100"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("###################Java HotSpot(TM) 64-Bit Server VM", 8, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("###################Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "     pStoH avaJ                                  ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa C", "-14-1410410");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###############################", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "###############################" + "'", str5.equals("###############################"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "###############################" + "'", str6.equals("###############################"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) -1, (byte) 0, (byte) 10 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "\nd");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: \nd");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "oRACLE cORPORATION", charSequence1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4#a################################     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        double[] doubleArray4 = new double[] { 1.0f, 8L, 10.0d, (-1.0f) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) (short) 100, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 10, 0);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#', 4, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0a8.0a10.0a-1.0" + "'", str6.equals("1.0a8.0a10.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "104100" + "'", str8.equals("104100"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.344444444444444444444444444444", "1#100#-1#0#100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a.oracle.com/" + "'", str1.equals("a.oracle.com/"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "                                 140014001                       ", 1450);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 63 + "'", int3 == 63);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "       sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 52, 31L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_80", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double[] doubleArray5 = new double[] { 97L, 2L, (short) -1, 10L, 'a' };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.341.741.641.741.341.6");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("HI!", 0, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!" + "'", str3.equals("HI!"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("             ", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("oRACLE cORPORATION", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0" + "'", str4.equals("1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0" + "'", str6.equals("1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("10a100", "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a100" + "'", str2.equals("10a100"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 209);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "2a-1a2  ", (java.lang.CharSequence) "-1a-1a10a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/", 96, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("     4#a################################     ", "                                                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4#a################################     " + "'", str2.equals("4#a################################     "));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, 27, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "1.31.71.61.71.31.6");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.31.71.61.71.31.6" + "'", charSequence2.equals("1.31.71.61.71.31.6"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen", 45, "Oaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa CaapaaatiaaOaaaaa Caapaaatiaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen" + "'", str3.equals("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaedom dexim");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10a100");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "#444a4a", 0, (-1));
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("JAVA HOTSPOT(TM) 64-BIT SERVER V", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("69", "1#100#-1#0#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "69" + "'", str2.equals("69"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "       sophie", (java.lang.CharSequence) "104100", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("4#a################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4#a################################" + "'", str1.equals("4#a################################"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("pStoH avaJ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "  ", "    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "                                                                      ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 10, 4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) '#', (int) '#');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 8, 5);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "hi!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi!");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4#a################################", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "i!", (java.lang.CharSequence) "4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "2a-1a2");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                 140014001                       ", "Oaaaaa Caapaaatiaa", "4#a################################     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                 140014001                       " + "'", str3.equals("                                 140014001                       "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaa", "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl", 'a');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM" + "'", str5.equals("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 0, (double) 'a', 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("x86_64", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("US", (float) 4L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "4aa", (java.lang.CharSequence) "2#-1#2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100410041aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JAVA HOTSPOT(TM) 64-BIT SERVER V", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("2#-1#2", 1450, "#4444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#42#-1#2#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4" + "'", str3.equals("#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#42#-1#2#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4444#4"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "   ", (java.lang.CharSequence) "1.341.741.641.741.341.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                      Java HotSpM", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("2-12", "                                                                                               69");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2-12" + "'", str2.equals("2-12"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                         4#a################################    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER V", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("    ", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                            " + "'", str2.equals("                                                                                                                            "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("raaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar" + "'", str1.equals("MVaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa11b-08.42aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaar"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!" };
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hi!");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Java HotSpot(TM) 64-Bit Server VM", (int) (short) 10, (int) (short) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("\n", strArray3, strArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', (int) (byte) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "\n" + "'", str6.equals("\n"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("US", "\nd1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\nd");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\nd\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mac OS X" + "'", str1.equals("mac OS X"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444441.341.741.641.741.341.6                                                                             444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "                                                                                      Java HotSpM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Users/sophie", "0.9", "4444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie" + "'", str3.equals("Users/sophie"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        float[] floatArray4 = new float[] { (short) -1, (byte) 1, 97L, 75.0f };
        float[][] floatArray5 = new float[][] { floatArray4 };
        float[] floatArray10 = new float[] { (short) -1, (byte) 1, 97L, 75.0f };
        float[][] floatArray11 = new float[][] { floatArray10 };
        float[] floatArray16 = new float[] { (short) -1, (byte) 1, 97L, 75.0f };
        float[][] floatArray17 = new float[][] { floatArray16 };
        float[] floatArray22 = new float[] { (short) -1, (byte) 1, 97L, 75.0f };
        float[][] floatArray23 = new float[][] { floatArray22 };
        float[][][] floatArray24 = new float[][][] { floatArray5, floatArray11, floatArray17, floatArray23 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(floatArray24);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 417, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 144, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################################################################################################################" + "'", str3.equals("################################################################################################################################################"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.341.741.641.741.341.6                                                                             ", (int) (byte) 100, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.8", "4#a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "97.042.04-1.0410.0497.0", (java.lang.CharSequence) "  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        float[] floatArray1 = new float[] { 1L };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 63, 1450);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 63");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(1L, (long) (byte) 0, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Corporatio CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Oracle", (java.lang.CharSequence) "MpStoH avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                       100410041                                 ", "1i100i-1i0i100");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   ", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   " + "'", str2.equals("UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   4  UTF-8   "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sophiesophiesophiesophiesophiesophiesophiesophiesoph", (java.lang.CharSequence) "4444", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        byte[] byteArray2 = new byte[] { (byte) 10, (byte) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) '#', 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 10, 4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) '#', (int) '#');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "###############################");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ###############################");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10a100" + "'", str8.equals("10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#100" + "'", str10.equals("10#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100410041", 71);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               100410041                               " + "'", str2.equals("                               100410041                               "));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                         4#a################################    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.31.71.61.71.31.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.31.71.61.71.31.6" + "'", str1.equals("1.31.71.61.71.31.6"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("69", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "69" + "'", str2.equals("69"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("2a-1a2  -8", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("141004-1404100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"141004-1404100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10a-1a0a10", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "1.7.0_8", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(51.0d, (double) 10.0f, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-1a-1a10a10", "4#a################################", "0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a-1a10a10" + "'", str3.equals("-1a-1a10a10"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", "1i100i-1i0i100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("2-12", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaa2-12aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100410041", "j/tmp/run_randoop.pl4/Users/sophie/Documents/defects");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-14-1410410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#####################################################################", (int) (byte) 1, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###########################" + "'", str3.equals("###########################"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                              1.3", "", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                              1.3" + "'", str3.equals("                                                                                              1.3"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "2.0", "Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51031_1560278052/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "100410041");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.4", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen" + "'", str1.equals("enOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationenOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporationen"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.3", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        float[] floatArray1 = new float[] { (byte) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', (int) ' ', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 2, 2);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', (int) (short) 10, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a', "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa24.80-b11aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4444", (java.lang.CharSequence) "################################################################################################################################################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "#444a4a", (java.lang.CharSequence) "                                                         4#a################################     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java Platform API Specification", "                                                                                               69", "#a4aaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }
}

