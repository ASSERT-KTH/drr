import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/users/sophie/documents/defects4j/tmp/run_rndoop...", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_rndoop..." + "'", str2.equals("/users/sophie/documents/defects4j/tmp/run_rndoop..."));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "32 52 52 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", charArray11);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray11, ' ');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a a       #" + "'", str18.equals("a a       #"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(" ", "100.0#0.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#0.0#10.0#100.0" + "'", str2.equals("100.0#0.0#10.0#100.0"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("...404-1", "ava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...404-1" + "'", str2.equals("...404-1"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("248-b", "b-", 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2b-" + "'", str4.equals("2b-"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "            TNEMNORIVNeSCIHPARgc.TWA.NUS            ", (java.lang.CharSequence) "44444444444411003514444444444444", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("44444444444411003514444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444411003514444444444444" + "'", str1.equals("44444444444411003514444444444444"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#######################", (java.lang.CharSequence) "Java Platform API Specificatio", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        char[] charArray5 = new char[] { '4', ' ', 'a', ' ', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4# #a# #a" + "'", str7.equals("4# #a# #a"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', 13, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", "1004974-1414-14-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.5");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "a a       #44444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("35", "Java HotSpot(TM) 64-Bit Server", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        char[] charArray8 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.Class<?> wildcardClass11 = charArray8.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#-1#100#100#35#0", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "32 52 52 1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a4a4#444 " + "'", str10.equals("#4a4a4#444 "));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#4a4a4#444 " + "'", str13.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        double[] doubleArray2 = new double[] { 1L, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) 'a', (int) (byte) -1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a1.0" + "'", str4.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                 ", 87, "...oolk");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 ...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk" + "'", str3.equals("                 ...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/so...", "MIXED MOD");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/so..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/so..."));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a a       #", "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a a       #" + "'", str2.equals("a a       #"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.041.041.0452.048.0", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a a       #" + "'", str14.equals("a a       #"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "O", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0 -1 100 100 35 0", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("jAVA pLATFORM api sPECIFICATIO", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATIO" + "'", str2.equals("jAVA pLATFORM api sPECIFICATIO"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541", "04-14-1414100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("3a53a1                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3a53a1                       " + "'", str1.equals("3a53a1                       "));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 52, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) '4', 27);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/Users/sop444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a100a100a35a0" + "'", str12.equals("0a-1a100a100a35a0"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 -1 100 100 35 0" + "'", str15.equals("0 -1 100 100 35 0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0#-1.0#100.0#10.0#100.0", 9, "-1.0 10.0 0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#-1.0#100.0#10.0#100.0" + "'", str3.equals("-1.0#-1.0#100.0#10.0#100.0"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("#a a a aaaa", "444444444444", 142);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) 'a', 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("J5055V...15l5M501..15S510.f.05....", 1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J5055V...15l5M501..15S510.f.05...." + "'", str3.equals("J5055V...15l5M501..15S510.f.05...."));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 179, (long) 46, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 179L + "'", long3 == 179L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1a100a35a1", "/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100a35a1" + "'", str2.equals("1a100a35a1"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1004-140  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####" + "'", str2.equals("                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporation", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (int) (byte) -1);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "100.0 0.0 10.0 100.0                                                                                ");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                       1.0a1.0a100.0", strArray5, strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.0");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, ' ');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("0a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a0", strArray12, strArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle#Corporation" + "'", str8.equals("Oracle#Corporation"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                       1.0a1.0a100.0" + "'", str13.equals("                                       1.0a1.0a100.0"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0 . 0" + "'", str17.equals("0 . 0"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97, (float) 35L, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) -1, (byte) -1, (byte) 1, (byte) 100 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 100, (int) (byte) 100);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a-1a1a100" + "'", str12.equals("0a-1a-1a1a100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/uoERo/ooPHIE", 95, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/uoERo/ooPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/uoERo/ooPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        float[] floatArray3 = new float[] { (short) -1, 10L, 0.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 97, 3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 5, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#-1#-1#0#-1" + "'", str12.equals("0#-1#-1#0#-1"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence) "...oolk");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray5, strArray9);
        java.lang.Class<?> wildcardClass11 = strArray9.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "            sun.awt.cgraphicsenvironment            mixed modemixed modemixed modemixed modemixed", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "US" + "'", str10.equals("US"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 45, (int) (short) -1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str15.equals("-1.04-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1.0a-1.0a100.0a10.0a100.0" + "'", str17.equals("-1.0a-1.0a100.0a10.0a100.0"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("TIKLOOtcwl.XSOCAM.TWAWL.NUS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("10.14.3", 23, 94);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean16 = javaVersion14.atLeast(javaVersion15);
        java.lang.String str17 = javaVersion14.toString();
        boolean boolean18 = javaVersion11.atLeast(javaVersion14);
        java.lang.String str19 = javaVersion11.toString();
        boolean boolean20 = javaVersion5.atLeast(javaVersion11);
        boolean boolean21 = javaVersion1.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.4" + "'", str17.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.1" + "'", str19.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 9, (short) 9, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 9 + "'", short3 == (short) 9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "####0.0#####", (java.lang.CharSequence) "                 1.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.0 1.0 100.0", (java.lang.CharSequence) "MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#-1#100#100#35#0" + "'", str9.equals("0#-1#100#100#35#0"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("          ", "100.0#0.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1a100a35a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("f455629");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/users/sophie/documents/defects4j/tmp/run_randoop...", "100a-1a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop..." + "'", str2.equals("/users/sophie/documents/defects4j/tmp/run_randoop..."));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0", 142);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean6 = javaVersion1.atLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "100.0#0.0#10.0#100.0");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/" + "'", str4.equals("/"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("           aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...            ", "3a53a1                       ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "ot(tm) 64-", 629);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "#######################", (java.lang.CharSequence) "HI!           F455629                #4A4A4#444 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64", "a", "-1.0#10.0#0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_64" + "'", str3.equals("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_64"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".7.0_80", "JAVA hOTsPOT(tm) 64-bIT sERVER vm", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("44444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444" + "'", str1.equals("44444"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.0 1.0 100.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 1.0 100." + "'", str1.equals("1.0 1.0 100."));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;", "                 1.0a1.0", 46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;" + "'", str3.equals("CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 3884, 3);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.0a1.0a a       #44444444444444444", "100#-1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a1.0a a       #44444444444444444" + "'", str2.equals("1.0a1.0a a       #44444444444444444"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        float[] floatArray3 = new float[] { (short) -1, 10L, 0.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 83, 30);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0a10.0a0.0" + "'", str6.equals("-1.0a10.0a0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "0a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "US", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "uS", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                            f455629", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 10, (byte) 10, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "4-140");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 4-140");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0-1100100350", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "-1.0410.040.0", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("a a       #", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             a a       #" + "'", str2.equals("             a a       #"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("tiklooTCWL.xsocam.twawl.nus", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    tiklooTCWL.xsocam.twawl.nus    " + "'", str3.equals("    tiklooTCWL.xsocam.twawl.nus    "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1410043541", "0#-1#-1", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.", "classa...", 45);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100." + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100."));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_64", 0, 83);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6" + "'", str3.equals("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 0, 406);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, (double) 94L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                  1.0a1.0", "100A-1Af455629                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  1.0a1.0" + "'", str2.equals("                  1.0a1.0"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("0 -1 -1 1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 -1 -1 1 100" + "'", str1.equals("0 -1 -1 1 100"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaa a a a#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa a a a#" + "'", str2.equals("aaaa a a a#"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100A-1A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100A-1A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.0a1.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a1.0" + "'", str2.equals("1.0a1.0"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("            TNEMNORIVNeSCIHPARgc.TWA.NUS            ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            " + "'", str2.equals("            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "#######################", (java.lang.CharSequence) "#-1#1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#######################" + "'", charSequence2.equals("#######################"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                 ", "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 " + "'", str3.equals("                 "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("248-b");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"248-b\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 13, (long) 27);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100a-1a0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("jAVA hOTsPOT(tm) 64-bIT sERVER v", "/Users/sop444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "-1.0#10.0#0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("     1004-140");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.01.0100.0" + "'", str2.equals("1.01.0100.0"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/USERS/SOPHIE/DOCUMENTS/DEFECTS4JAVA HOTSPOT(TM) 64-BIT SERVER VMN/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4JAVA HOTSPOT(TM) 64-BIT SERVER VMN/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4JAVA HOTSPOT(TM) 64-BIT SERVER VMN/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, '4', (int) (byte) 1, (-1));
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "04-14100410043540", charArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("x86_64", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", "1.7");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporation", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.041.04100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("            s", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                          Java(TM) SE Runtime Environment                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1410043541" + "'", str8.equals("1410043541"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0.0 0.01 0.1-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0 0.01 0.1-" + "'", str1.equals("0.0 0.01 0.1-"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus", (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle", (java.lang.CharSequence) "10#0#1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0", (java.lang.CharSequence) "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("JavaPlatformAPISpecificatio", "1.7.0_80-b151.7.0_80-b15", "            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ".7.0_80", (java.lang.CharSequence) "EnEnEnEnEnEnEnEnEnEnEnEn");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("MIXED MODEMIXED MODEMIXED MODEMIXED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODEMIXED MODEMIXED MODEMIXED" + "'", str1.equals("MIXED MODEMIXED MODEMIXED MODEMIXED"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Serve" + "'", str1.equals("java HotSpot(TM) 64-Bit Serve"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100.0#0.0#10.0#100.0", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0" + "'", str2.equals("100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 24, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.0#0.0#10.0#100.0", "1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        int[] intArray6 = new int[] { 100, 'a', (short) -1, (short) 1, (byte) -1, (short) -1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 1, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T//VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/Thi!", 46, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T//VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/Thi!" + "'", str3.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T//VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/Thi!"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a-1a100a100a35a0", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("TiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  " + "'", str2.equals("TiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                      http://java.oracle.com/                                       ", (int) (short) 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 44, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 44");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aaaa a a a#" + "'", str12.equals("aaaa a a a#"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.041.041.0452.048.0", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 95, 18);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "ndoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defects4j/fracl", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1.01.0100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64", "                  1.0a1.");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64" + "'", str5.equals("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "3245245241");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ot(TM) 64-", (java.lang.CharSequence) ":", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-1.0 -1.0 100.0 10.0 100.0", "jAVA hOTsPOT(tm) 64-bIT sERVER v");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 45);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 13, 5);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("32a52a52a1", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaPlatformAPISpecificatio" + "'", str1.equals("JavaPlatformAPISpecificatio"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "0#-1#-1", 95);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140" + "'", charSequence2.equals("     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#4a4a4#444 ", 893);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a4a4#444 " + "'", str2.equals("#4a4a4#444 "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) -1, 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', 64, 52);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(179.0f, (float) 7, 1.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 179.0f + "'", float3 == 179.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int[] intArray3 = new int[] { 97, (byte) -1, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 23, 2);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        int[] intArray3 = new int[] { (byte) 1, '#', 3 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 1039, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a35a3" + "'", str7.equals("1a35a3"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#aaaaa#a4a ", "java Platform API Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("tiklooTCWL4xsocam4twawl4nus");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tiklooTCWL4xsocam4twawl4nus\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  " + "'", str1.equals("TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  "));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/uoERo/ooPHIE", 2, 179);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oERo/ooPHIE" + "'", str3.equals("oERo/ooPHIE"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sop444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.0a1.0a100.0", "TIKLOOtcwl4XSOCAM4TWAWL4NUS", "1a100a35a1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray4 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray4);
        org.junit.Assert.assertNotNull(systemUtilsArray4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("51.0", 7, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44451.0" + "'", str3.equals("44451.0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Platform API Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                       1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a-1a-1a1a100", (java.lang.CharSequence) "tiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0.001A0.01A0.001A0.1-A0.1-", (java.lang.CharSequence) "0a-1a100a100a35a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", "hi!", 179);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("US", "                            f455629", "0.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("iklooTCWL4xsocam4twawl4nus", "Oracle Corporation", 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "iklooTCWL4xsocam4twawl4nus" + "'", str3.equals("iklooTCWL4xsocam4twawl4nus"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("           aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...            ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa..." + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a1000a-1a-1a1a100", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                4                                                ", (java.lang.CharSequence) "US", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("TIKLOOtcwl4XSOCAM4TWAWL4NUS", (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 30, (float) 5L, (float) 142L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 30, 179);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ".7.0_80", (java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop...", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 87, (double) (short) 1, (double) 64);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("       ", "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140", 87);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean7 = javaVersion1.atLeast(javaVersion6);
        java.lang.String str8 = javaVersion6.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        boolean boolean13 = javaVersion9.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean16 = javaVersion14.atLeast(javaVersion15);
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        java.lang.String str20 = javaVersion17.toString();
        boolean boolean21 = javaVersion14.atLeast(javaVersion17);
        java.lang.String str22 = javaVersion14.toString();
        boolean boolean23 = javaVersion10.atLeast(javaVersion14);
        boolean boolean24 = javaVersion6.atLeast(javaVersion10);
        boolean boolean25 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7" + "'", str8.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.4" + "'", str20.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.1" + "'", str22.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100a-1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a-1a0" + "'", str1.equals("100a-1a0"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100 97 -1 1 -1 -1", (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1a100a-1a0a100a1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100a-1a0a100a1" + "'", str2.equals("1a100a-1a0a100a1"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4", "#-1#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4" + "'", str2.equals("-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Java HotSpot(TM) 64-Bit Server VM", "classa[J#classa[Ljava.lang.String;#classa[Ljava.lang.String;#classa[J#classa[Ljava.lang.String;", "1.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("O");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O" + "'", str1.equals("O"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str11.equals("-1.0 -1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str13.equals("-1.04-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 35, 12);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("10.14.3", "aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0.0 0.01 0.1-", (java.lang.CharSequence) "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.0 0.01 0.1-" + "'", charSequence2.equals("0.0 0.01 0.1-"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray7 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray11 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[][] byteArray16 = new byte[][] { byteArray3, byteArray7, byteArray11, byteArray15 };
        byte[] byteArray20 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray24 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray28 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray32 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[][] byteArray33 = new byte[][] { byteArray20, byteArray24, byteArray28, byteArray32 };
        byte[] byteArray37 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray41 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray45 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray49 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[][] byteArray50 = new byte[][] { byteArray37, byteArray41, byteArray45, byteArray49 };
        byte[] byteArray54 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray58 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray62 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[] byteArray66 = new byte[] { (byte) 100, (byte) 1, (byte) -1 };
        byte[][] byteArray67 = new byte[][] { byteArray54, byteArray58, byteArray62, byteArray66 };
        byte[][][] byteArray68 = new byte[][][] { byteArray16, byteArray33, byteArray50, byteArray67 };
        java.lang.String str69 = org.apache.commons.lang3.StringUtils.join(byteArray68);
        java.lang.String str73 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) byteArray68, '4', 13, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "" + "'", str73.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "  sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.041.0", (java.lang.CharSequence) "                                      http://java.oracle.com/                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1a35a3", "0a-1a-1a1a100");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                 ...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100a-1a", "04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-141004100435", ".1.0000000");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a-1a" + "'", str3.equals("100a-1a"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.4");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140", 18, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140" + "'", str3.equals("     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0a1.0a a       #44444444444444444", "f455629                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a1.0a a       #44444444444444444" + "'", str2.equals("1.0a1.0a a       #44444444444444444"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.0a1.0a100.0", "100#-1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a1.0a100.0" + "'", str2.equals("1.0a1.0a100.0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100a-1a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', (double) 893, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 52, 29);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", 142);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/uoERo/ooPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "    tiklooTCWL.xsocam.twawl.nus    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n", "ndoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/fracl", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa CaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa \n" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa CaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa \n"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("E", 13.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.0d + "'", double2 == 13.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    tiklooTCWL.xsocam.twawl.nus    ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray13 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray13);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray13);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", charArray13);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray13);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", charArray13);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#################################################################################################", charArray13);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "             a a       #", charArray13);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6" + "'", str2.equals("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 893, 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "1.0a1.0");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', 100, 10);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "1.0a1.0");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '4', 100, 10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("51.0", strArray5, strArray12);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.stripAll(strArray19, "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100.0 0.0 10.0 100.0                                                                                ", strArray5, strArray21);
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!           f455629                #4a4a4#444 ", (java.lang.CharSequence[]) strArray21);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "51.0" + "'", str17.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100.0 0.0 10.0 100.0                                                                                " + "'", str22.equals("100.0 0.0 10.0 100.0                                                                                "));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), 35L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0a-1a-1a1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a-1a-1a1a100" + "'", str1.equals("0a-1a-1a1a100"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "#a a a aaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#-1#0" + "'", str10.equals("100#-1#0"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 12, 9);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("            SUN.AWT.cgRAPHICSeNVIRONMENT            ", "10 0 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            SUN.AWT.cgRAPHICSeNVIRONMENT            " + "'", str2.equals("            SUN.AWT.cgRAPHICSeNVIRONMENT            "));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        int[] intArray3 = new int[] { 97, (byte) -1, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 11, 406);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97a-1a-1" + "'", str6.equals("97a-1a-1"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a", (java.lang.CharSequence) "444444444444", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "# a a # 4  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "iklooTCWL4xsocam4twawl4nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                       1.0a1.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "             MIXED MOD             ", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "...oolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java Viren");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "neriV avaJ" + "'", str1.equals("neriV avaJ"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", ' ');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("EnEnEnEnEnEnEnEnEnEnEnEn");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        float[] floatArray3 = new float[] { (byte) 100, 12, 87L };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 12.0f + "'", float4 == 12.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0412.0487.0" + "'", str7.equals("100.0412.0487.0"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("9", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               9" + "'", str2.equals("                               9"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 9, 0.0f, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", (java.lang.CharSequence) "a a       #44444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 590 + "'", int2 == 590);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1.0 10.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x" + "'", str1.equals("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1.0 10.0 0.0", (java.lang.CharSequence) "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.0 1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "...404-1", "  sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "TIKLOOt...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        int[] intArray6 = new int[] { 100, 'a', (short) -1, (short) 1, (byte) -1, (short) -1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1004974-1414-14-1" + "'", str14.equals("1004974-1414-14-1"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 5, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) 'a', 0);
        short short15 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) -1 + "'", short15 == (short) -1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("       ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "100.0#0.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray11 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", charArray11);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray11, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a#a# # # ##" + "'", str18.equals("a#a# # # ##"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "a4a4 4 4 4#" + "'", str20.equals("a4a4 4 4 4#"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1100351", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1100351" + "'", str2.equals("1100351"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("# a a # 4  ", "0.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.11.71.61.71.4", "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", "0                                                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.util.regex.PatternSyntaxException; message: Unclosed character class near index 90\nclass [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;\n                                                                                          ^");
        } catch (java.util.regex.PatternSyntaxException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("E", "#######################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E" + "'", str2.equals("E"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "classa...", 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-b", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mode", (int) (short) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.15", "####################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.15" + "'", str2.equals("0.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.150.15"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10a0a1", "#-1#1", "0#53#001#001#1-#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "50a0a5" + "'", str3.equals("50a0a5"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 0, 3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 52, 13);
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-1404-1" + "'", str8.equals("04-14-1404-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#-1#-1" + "'", str12.equals("0#-1#-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 0 + "'", short17 == (short) 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("0#-1#-1#0#-1", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        0#-1#-1#0#-1" + "'", str2.equals("                                                                                        0#-1#-1#0#-1"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1 100 35 1" + "'", str8.equals("1 100 35 1"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("100#-1#0", 100, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/users/sophie", "1.0a1.0a a #44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 7, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", "MIXED MOD", 32);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("sophie##", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0a1.0a a       #44444444444444444", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 9, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0", (java.lang.CharSequence) "1.01.0100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.040.0412.040.0", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80-b151.7.0_80-b1", "                       ", (int) '#', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                       " + "'", str4.equals("                       "));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                                       1.0a1.0a100.0", (java.lang.CharSequence) "JAVA hOTsPOT(tm) 64-bIT sERVER");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("F455629", "-b", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64", "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed", "                                                               aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "0 -1 -1 1 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        java.lang.String str7 = javaVersion4.toString();
        boolean boolean8 = javaVersion1.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 179, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.0 1.0 100.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 1.0 100." + "'", str1.equals("1.0 1.0 100."));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#####", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0a1.0a a #44444444444444444", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        char[] charArray7 = new char[] {};
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "us", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                       ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("us/Users/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us/Users/" + "'", str1.equals("us/Users/"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                 " + "'", str1.equals("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                 "));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0#-1#-1#0#-1", (java.lang.CharSequence) "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("j5055V...15l5M501..15S510.f.05....", "#4a4a4#44", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 2, 64L, 45L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', 23, 95);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 23");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100 -1 0" + "'", str10.equals("100 -1 0"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 5, 0);
        java.lang.Class<?> wildcardClass20 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str15.equals("-1.0 -1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                       ", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                       " + "'", str2.equals("                                                                                       "));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100A-1A", "OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100A-1A" + "'", str2.equals("100A-1A"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0 0.0 10.0 100.0                                                                              US", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "4-140", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "1.3", "1a100a35a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#-1#100#100#35#0" + "'", str11.equals("0#-1#100#100#35#0"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "97a-1a-1", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Cor9aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 590, "            TNEMNORIVNeSCIHPARgc.TWA.NUS            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNO" + "'", str3.equals("            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNO"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sop", "##################################Java Platform API Specification###################################", "US");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("# a a # 4  ", 629);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "# a a # 4  " + "'", str2.equals("# a a # 4  "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a-1a100a100a35a0", (java.lang.CharSequence) "             a a       #", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("MIXED MODEMIXED MODEMIXED MODEMIXED", "-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXED MODEMIXED MODEMIXED MODEMIXED" + "'", str2.equals("MIXED MODEMIXED MODEMIXED MODEMIXED"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0#-1#100#100#35#0", charArray3);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "111oolkit", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80-b15", (int) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                 1.0a1.0", (java.lang.CharSequence) "1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-b", (java.lang.CharSequence) "3a53a1                       ", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.0A1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            ", "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            " + "'", str2.equals("            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS            "));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                 ", "                            f455629");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            f455629" + "'", str2.equals("                            f455629"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004-140");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "100.0a1.", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1004-140" + "'", str4.equals("1004-140"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.0 1.0 100.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 1.0 100.0" + "'", str2.equals("1.0 1.0 100.0"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ', (int) (byte) 0, 0);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#0#1" + "'", str10.equals("10#0#1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a0a1" + "'", str12.equals("10a0a1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10a0a1" + "'", str14.equals("10a0a1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        long[][][] longArray0 = new long[][][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(longArray0);
        org.junit.Assert.assertNotNull(longArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "#######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("100.0a1.100.0a1.100.0a1.100.0aen####################################################################", "ndoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/fracl");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a1.100.0a1.100.0a1.100.0aen####################################################################" + "'", str2.equals("100.0a1.100.0a1.100.0a1.100.0aen####################################################################"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNO", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNO" + "'", str2.equals("            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNO"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) -1, (byte) -1, (byte) 1, (byte) 100 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 100, (int) (byte) 100);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 13, (int) (short) 9);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 64, (int) (byte) 1);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a-1a1a100" + "'", str12.equals("0a-1a-1a1a100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80-b151.7.0_80-b15", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0", "                                                                                            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("TIKLOOtcwl4XSOCAM4TWAWL4NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklootcwl4xsocam4twawl4nus" + "'", str1.equals("tiklootcwl4xsocam4twawl4nus"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.0a1.0a a #44444444444444444", (java.lang.CharSequence) "             MIXED MOD             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        float[] floatArray3 = new float[] { 1L, 1.0f, (short) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.0a1.0a100.0" + "'", str5.equals("1.0a1.0a100.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80", "sun.awt.CGraphicsEnvironmentmixedmodemixedmodemixedmodemixedmodemixed");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        double[] doubleArray2 = new double[] { 1L, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) 'a', (int) (byte) -1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a1.0" + "'", str4.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.0#1.0" + "'", str12.equals("1.0#1.0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 95, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 35, (int) (byte) -1);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 44, (long) 87, (long) 3884);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3884L + "'", long3 == 3884L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oERo/ooPHIE", 64, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oERo/ooPHIE44444444444444444444444444444444444444444444444444444" + "'", str3.equals("oERo/ooPHIE44444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "100 97 -1 1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140" + "'", str2.equals("     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("            TNEMNORIVNeSCIHPARgc.TWA.NUS            ", "hi!           f455629                #4a4a4#444 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            TNEMNORIVNeSCIHPARgc.TWA.NUS            " + "'", str2.equals("            TNEMNORIVNeSCIHPARgc.TWA.NUS            "));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "     -");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/uoERo/ooPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/uoERo/ooPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/uoERo/ooPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaa a a a#", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "     1004-140");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", "0#-1#-1#0#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  " + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  "));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!", "oERo/ooPHIE44444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", "f455629                                     #4a4a4#444                                           ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1.04-1.04100.0410.04100.0", "illkl lkl ilkl illkl                                                                                ", 1039);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1004-140  ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.1", "0.", "444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                       " + "'", str1.equals("                                                                                       "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("b-", 1412, "100a-1a0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01b-100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01" + "'", str3.equals("100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01b-100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("0#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#-1#100#100#35#0" + "'", str1.equals("0#-1#100#100#35#0"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100.041.041.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        char[] charArray7 = new char[] {};
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "us", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx.LWCToolkit1410043541", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1.0A-1.0A100.0A10.0A100.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("111oolkit", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0" + "'", str1.equals("-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "1.0a1.0");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 100, 10);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "1.0a1.0");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, '4', 100, 10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("51.0", strArray3, strArray10);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "51.0" + "'", str15.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray16);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "# a a # 4", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Cor9aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444444444444444444444444444", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("100#-1#0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 3884);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_rndoop...", (java.lang.CharSequence) "a a       #44444444444444444444444444444444444444444", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "04-14-1404-1", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####", '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("                                                               aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", strArray4, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 784");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sun.lwawt.macosx.LWCToolkit", "tiklootcwl4xsocam4twawl4nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("java HotSpot(TM) 64-Bit Serve", "100 -1 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-Bit Serve" + "'", str2.equals("java HotSpot(TM) 64-Bit Serve"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0#-1#-1", 0, "100.0a1.100.0a1.100.0a1.100.0aen");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#-1#-1" + "'", str3.equals("0#-1#-1"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#####", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.0a1.0a a       #44444444444444444", charArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', 142, (int) (short) 1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1a100a35a1", "04-14-1404-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100a35a1" + "'", str2.equals("1a100a35a1"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 1412, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ", "1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100 -1 0", 893, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100 -1 0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("100 -1 0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "44451.0", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", 1412);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", str1.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(".7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0.", "            sun.awt.cgraphicsenvironment            mixed modemixed modemixed modemixed modemixed", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0." + "'", str3.equals("0."));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0", (int) '#', (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("       ", "100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...oolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ...oolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100 97 -1 1 -1 -1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sERVER vm", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', (int) '4', 23);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 95, 590);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 95");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3245245241" + "'", str8.equals("3245245241"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-1404-1" + "'", str8.equals("04-14-1404-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "04-14-1404-1" + "'", str10.equals("04-14-1404-1"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "04-14-1404-1", (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "E");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#################################################################################################" + "'", str7.equals("#################################################################################################"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#################################################################################################" + "'", str8.equals("#################################################################################################"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#################################################################################################" + "'", str9.equals("#################################################################################################"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MIXED MODEMIXED MODEMIXED MODEMIXED", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#4a4a4#44", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a4a4#44" + "'", str2.equals("#4a4a4#44"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0#53#001#001#1-#0", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("a");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "O", (java.lang.CharSequence) "100.0 0.0 10.0 100.0                                                                              US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4# #a# #a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ", "          ", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                                                                    #4a4a4#444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a4a4#444" + "'", str1.equals("#4a4a4#444"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophie", "", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "oERo/ooPHIE44444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", 3884);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("f455629                                                                                             ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("3a53a1                       ", (int) (short) -1, 27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3a53a1                  ..." + "'", str3.equals("3a53a1                  ..."));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        double[] doubleArray2 = new double[] { 1L, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a1.0" + "'", str4.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0 -1 -1 0 -1", "100A-1A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 -1 -1 0 -1" + "'", str2.equals("0 -1 -1 0 -1"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "10 0 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "04-14-1404-1", (java.lang.CharSequence[]) strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "E");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.CharSequence charSequence10 = null;
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporation", 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence10, (java.lang.CharSequence[]) strArray13);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                            hi", strArray4, strArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#################################################################################################" + "'", str8.equals("#################################################################################################"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#################################################################################################" + "'", str9.equals("#################################################################################################"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("#4a4a4#444 ", "1.0a1.0", 100);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "-b1", 893);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("...404-1", strArray4, strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "...404-1" + "'", str9.equals("...404-1"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", 1039);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(":", "1a35a3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("111oolkit", "/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "111oolkit" + "'", str2.equals("111oolkit"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.11.71.61.71.4", "aaaaaaaaaaaaaa1a100a35a1                                                                       ", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        char[] charArray8 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1.0 -1.0 100.0 10.0 100.0", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /uSERS/SOPHIE is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2L, 97.0f, (float) 46);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4", (int) (byte) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4" + "'", str3.equals("-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;", (java.lang.CharSequence) "4# #a# #a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi", (java.lang.CharSequence) "44444444444411003514444444444444", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                       1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###" + "'", str1.equals("TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        double[] doubleArray2 = new double[] { 1L, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) 'a', (int) (byte) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a1.0" + "'", str4.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.0a1.0" + "'", str10.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.041.0" + "'", str12.equals("1.041.0"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                           :", (java.lang.CharSequence) "100A-1A");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("SUN.LWAWT.MACOSX.LWCTOOLKIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.LWCTOOLKIT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100." + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.classa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100."));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) 5, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 29, (long) ' ', 30L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        char[] charArray7 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        java.lang.Class<?> wildcardClass10 = charArray7.getClass();
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.0A-1.0A100.0A10.0A100.0", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#4a4a4#444 " + "'", str9.equals("#4a4a4#444 "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10L, (float) 83, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0#10.0#0.0", "sophie##", 94);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("E", "                 ", (int) (byte) -1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray10, strArray14);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, ' ', 44, 5);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle#Corporation", strArray5, strArray14);
        int int21 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "US" + "'", str15.equals("US"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Oracle#Corporation" + "'", str20.equals("Oracle#Corporation"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = javaVersion4.atLeast(javaVersion5);
        boolean boolean9 = javaVersion0.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0#-1#-1#0#-1", 0, "a4a4 4 4 4#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#-1#-1#0#-1" + "'", str3.equals("0#-1#-1#0#-1"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.0a1.0a100.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", (java.lang.CharSequence) "#a a a aaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".7.0_80#################################################################################################", "0a-1a100a100a35a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("tiklooTCWL.xsocam.twawl.nus", "                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####", "#4a4a4#44");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.awt.CGraphicsEnvironment", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.040.0412.040.0", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("us/Users/", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "us/Users/" + "'", str3.equals("us/Users/"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0.9", 3884);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("v REVREs TIb-46 )mt(TOPsTOh AVAj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "V REVREs TIb-46 )mt(TOPsTOh AVAj" + "'", str1.equals("V REVREs TIb-46 )mt(TOPsTOh AVAj"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("    tiklooTCWL.xsocam.twawl.nus    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "3a53a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/uSERS/SOPHIE", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE" + "'", str3.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.0 1.0 100.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 1.0 100." + "'", str1.equals("1.0 1.0 100."));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, (long) 3884, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str13.equals("-1.04-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Viren");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1004-140", 44, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004-140aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("1004-140aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        short[] shortArray3 = new short[] { (byte) 10, (short) 10, (byte) 100 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10 10 100" + "'", str5.equals("10 10 100"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0#-1#-1#0#-1", "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#-1#-1#0#" + "'", str2.equals("#-1#-1#0#"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100 -1 0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 -1 0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("100 -1 0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }
}

