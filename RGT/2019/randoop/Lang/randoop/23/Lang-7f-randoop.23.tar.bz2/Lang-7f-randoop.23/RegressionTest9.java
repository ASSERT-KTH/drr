import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sop444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100.0 0.0 10.0 100.0                                                                                ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0 0.0 10.0 100.0                                                                                " + "'", str3.equals("100.0 0.0 10.0 100.0                                                                                "));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(".7.0_80#################################################################################################", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp" + "'", str1.equals("AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp"));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("-1.0#10.0#0.0", 590);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-14100410043540", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-14100410043540" + "'", str2.equals("04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-14100410043540"));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0 -1 -1 0 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0-1-10-1" + "'", str1.equals("0-1-10-1"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0", (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "###########", (java.lang.CharSequence) "100.0 0.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97a-1a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MACOSX.LWCTOOLKIT", "0a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a0", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "oERo/ooPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "O", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 45, 32);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 30, 22);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, 2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440"));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a0a1", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01b-100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "  sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", "hi!", 179);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) -1, (byte) -1, (byte) 1, (byte) 100 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 100, (int) (byte) 100);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "a a       #");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: a a       #");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a-1a1a100" + "'", str12.equals("0a-1a-1a1a100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0a-1a-1a1a100" + "'", str15.equals("0a-1a-1a1a100"));
    }
}

