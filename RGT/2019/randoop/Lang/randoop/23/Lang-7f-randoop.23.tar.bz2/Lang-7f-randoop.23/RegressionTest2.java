import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100.0 0.0 10.0 100.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 0.0 10.0 100.0" + "'", str2.equals("100.0 0.0 10.0 100.0"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (java.lang.CharSequence) "-1.0a-1.0a100.0a10.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 44 + "'", int2 == 44);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.041.041.0", (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", 0, "1.041.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0" + "'", str3.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 1, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", charSequence2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("a", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, 0L, (long) 95);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 95L + "'", long3 == 95L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int[] intArray6 = new int[] { 100, 'a', (short) -1, (short) 1, (byte) -1, (short) -1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 87, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 87");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("j5055V...15l5M501..15S510.f.05....", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_80-b15", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) ".1.0000000", (java.lang.CharSequence) "                                                                                                                                                                       ####0.0#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#4a4a4#444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a4a4#44" + "'", str1.equals("#4a4a4#44"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1.0A-1.0A100.0A10.0A100.0", "/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "\n", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", "32a52a52a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str2.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Oracle Corporation", 0, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "O" + "'", str3.equals("O"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("x86_64", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("jAVA hOTsPOT(tm) 64-bIT sERVER v", "1004974-1414-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER v" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER v"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100.0#0.0#10.0#100.0", (java.lang.CharSequence) "aaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) 'a', 1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "                            f455629                            f455629                #4a4a4#444 ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                             f455629                            f455629                #4a4a4#444 ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java(TM) SE Runtime Environment", "/Users/sophie", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-b11", "0.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.", "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "32a52a52a1", (java.lang.CharSequence) "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server V", (int) (short) 10, "100.0#0.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "f455629                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.0a1.0", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a1.0" + "'", str2.equals("1.0a1.0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0 0.0 10.0 100.0                                                                              US");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0#-1#-1#0#-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (java.lang.CharSequence) "en", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "100.0#0.0#10.0#100.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                      1.7.0_80                      ", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("j5055V...15l5M501..15S510.f.05....", "                            f455629");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j5055V...15l5M501..15S510.f.05...." + "'", str2.equals("j5055V...15l5M501..15S510.f.05...."));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sophie", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(".1.0000000", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "100.041.041.0", (java.lang.CharSequence) "1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100.041.041.0" + "'", charSequence2.equals("100.041.041.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Oracle#Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "-1.0A-1.0A100.0A10.0A100.0", "1.0a1.0a100.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7.0_80" + "'", str2.equals(".7.0_80"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("            sun.awt.CGraphicsEnvironment            ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("            sun.awt.CGraphicsEnvironment            ", "Oracle Corporation", "1.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            sun.awt.CGraphicsEnvironment            " + "'", str3.equals("            sun.awt.CGraphicsEnvironment            "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sop", (java.lang.CharSequence) "", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0" + "'", str3.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("04-14100410043540", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "04-14100410043540" + "'", str2.equals("04-14100410043540"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.0", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("f455629");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "f455629" + "'", str1.equals("f455629"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###", (java.lang.CharSequence) "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-b15", "f455629");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b1" + "'", str2.equals("-b1"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass9 = longArray6.getClass();
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray14, strArray18);
        java.lang.Class<?> wildcardClass20 = strArray18.getClass();
        java.lang.String[] strArray25 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray29 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray25, strArray29);
        java.lang.Class<?> wildcardClass31 = strArray29.getClass();
        long[] longArray38 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long39 = org.apache.commons.lang3.math.NumberUtils.max(longArray38);
        long long40 = org.apache.commons.lang3.math.NumberUtils.min(longArray38);
        java.lang.Class<?> wildcardClass41 = longArray38.getClass();
        java.lang.String[] strArray46 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray50 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str51 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray46, strArray50);
        java.lang.Class<?> wildcardClass52 = strArray50.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray53 = new java.lang.reflect.AnnotatedElement[] { wildcardClass9, wildcardClass20, wildcardClass31, wildcardClass41, wildcardClass52 };
        java.lang.String str54 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray53);
        java.lang.String str56 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) annotatedElementArray53, '#');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "US" + "'", str19.equals("US"));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "US" + "'", str30.equals("US"));
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(longArray38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "US" + "'", str51.equals("US"));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(annotatedElementArray53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str54.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;" + "'", str56.equals("class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(35.0d, (double) 10L, (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEach("#4a4a4#444", strArray4, strArray14);
        int int17 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0" + "'", str5.equals("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "US" + "'", str15.equals("US"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#4a4a4#444" + "'", str16.equals("#4a4a4#444"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0A-1.0A100.0A10.0A100.0" + "'", str1.equals("-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sophie", (int) (byte) 0, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.041.04100.0", (int) (short) 100, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("E");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-b1", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b1" + "'", str2.equals("-b1"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "E", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                       1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                       1.0a1.0a100.0" + "'", str1.equals("                                       1.0a1.0a100.0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ", (java.lang.CharSequence) "            SUN.AWT.cgRAPHICSeNVIRONMENT            ", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("#4a4a4#44", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100.0a1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0#-1#-1", (java.lang.CharSequence) "100.0a1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "-1.0410.040.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "f455629");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 5, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Platform API Specification", "O", "51.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "100.0a1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("04-14-1404-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04-14-1404-1" + "'", str1.equals("04-14-1404-1"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("-1.0a10.0a0.0", 179);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("J5055V...15l5M501..15S510.f.05....");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J5055V...15l5M501..15S510.f.05...." + "'", str1.equals("J5055V...15l5M501..15S510.f.05...."));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed", (java.lang.CharSequence) "mp/run_randoop.pl_51871_1560279118/target/classes:/U", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("100.0#0.0#10.0#100.0", 44);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#0.0#10.0#100.0" + "'", str2.equals("100.0#0.0#10.0#100.0"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Server" + "'", str1.equals("java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa" + "'", str1.equals("aaaaaaaaaa"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("f455629", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10#0#1", "/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                            f455629", charSequence1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray3, strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 2, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "en" + "'", str5.equals("en"));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1", "1.7");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "1.4", 0);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        long[] longArray6 = new long[] { (byte) -1, 12, 95L, 100, (byte) 10, (short) 10 };
        long[] longArray13 = new long[] { (byte) -1, 12, 95L, 100, (byte) 10, (short) 10 };
        long[] longArray20 = new long[] { (byte) -1, 12, 95L, 100, (byte) 10, (short) 10 };
        long[] longArray27 = new long[] { (byte) -1, 12, 95L, 100, (byte) 10, (short) 10 };
        long[] longArray34 = new long[] { (byte) -1, 12, 95L, 100, (byte) 10, (short) 10 };
        long[] longArray41 = new long[] { (byte) -1, 12, 95L, 100, (byte) 10, (short) 10 };
        long[][] longArray42 = new long[][] { longArray6, longArray13, longArray20, longArray27, longArray34, longArray41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(longArray42);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertNotNull(longArray13);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray27);
        org.junit.Assert.assertNotNull(longArray34);
        org.junit.Assert.assertNotNull(longArray41);
        org.junit.Assert.assertNotNull(longArray42);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1004974-1414-14-1", "1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004974-1414-14-1" + "'", str2.equals("1004974-1414-14-1"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0#-1#-1", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "                                                                                                                                                                       ####0.0#####");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle4Corporation" + "'", str6.equals("Oracle4Corporation"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n", (java.lang.CharSequence) "0.0aaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sop");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                         1.0a1.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ", (java.lang.CharSequence) "class [Cclass [Cclass [Ljava.lang.String;", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("mixed mode", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "97a-1a-1", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "0#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("TIKLOOtcwl.XSOCAM.TWAWL.NUS", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T" + "'", str2.equals("T"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("J5055V...15l5M501..15S510.f.05....", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                                       1.0a1.0a100.0", (java.lang.CharSequence) "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0.0aaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0aaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime Environment", "J5055V...15l5M501..15S510.f.05....", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("mp/run_randoop.pl_51871_1560279118/target/classes:/U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mp/run_randoop.pl_51871_1560279118/target/classes:/U" + "'", str1.equals("mp/run_randoop.pl_51871_1560279118/target/classes:/U"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1.0A-1.0A100.0A10.0A100.0", "1.0 1.0 100.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0" + "'", str3.equals("-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (-1), (int) (byte) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 100, 100);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0a1.0a1.0", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS X", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0410.040.0", "100.041.041.0", "Mac OS X");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0#-1#100#100#35#0", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', (int) '#', 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "9", (java.lang.CharSequence) "1.5", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java HotSpot(TM) 64-Bit Server", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("04-14100410043540", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####", (java.lang.CharSequence) "100.0a1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1039 + "'", int2 == 1039);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#################################################################################################", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                      1.7.0_80                      ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        float[] floatArray6 = new float[] { 3, 0.0f, 35L, 1, (byte) -1, (short) 1 };
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (byte) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 95, 51.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("            SUN.AWT.cgRAPHICSeNVIRONMENT            ", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                            f455629                            f455629                #4a4a4#444 ", "hi!", 52, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!           f455629                #4a4a4#444 " + "'", str4.equals("hi!           f455629                #4a4a4#444 "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJob", "100.0#0.0#10.0#100.0", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("            SUN.AWT.cgRAPHICSeNVIRONMENT            ", '#');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "-1.0410.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sop", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                                                                                                       ####0.0#####", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "            SUN.AWT.cgRAPHICSeNVIRONMENT            ", "100.0 0.0 10.0 100.0                                                                              US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("f455629                                                                                             ", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f455629                                                                                             " + "'", str3.equals("f455629                                                                                             "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0.0", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "http://java.oracle.com/", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "", "#4a4a4#444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.awt.CGraphicsEnvironment", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a', (int) '#', 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "100.0 0.0 10.0 100.0                                                                              US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100a-1a0", 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###" + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                      1.7.0_80                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 1039);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", (int) ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str3.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100.041.041.0452.048.0", "ot(TM) 64-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.041.041.0452.048.0" + "'", str2.equals("100.041.041.0452.048.0"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", "-1.0a-1.0a100.0a10.0a100.0", "sophie", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "04-14-1404-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b15", "", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", (java.lang.CharSequence) "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 142 + "'", int2 == 142);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1.equals(0L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "ot(TM) 64-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("O", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO" + "'", str2.equals("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "class [Cclass [Cclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        float[] floatArray5 = new float[] { 100.0f, 1L, 1L, '4', 8 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.041.041.0452.048.0" + "'", str7.equals("100.041.041.0452.048.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "TIKLOOtcwl.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str2.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.0a1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a1.0" + "'", str1.equals("1.0a1.0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mp/run_randoop.pl_51871_1560279118/target/classes:/U", (java.lang.CharSequence) "0#-1#-1#0#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   " + "'", str1.equals("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   "));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 23, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       " + "'", str3.equals("                       "));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0A-1.0A100.0A10.0A100.0", "1.5", "1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#################################################################################################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sophie", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", "Mac OS X");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("ot(TM) 64-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ot(tm) 64-" + "'", str1.equals("ot(tm) 64-"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 1.0 100.0" + "'", str1.equals("1.0 1.0 100.0"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#4a4a4#44", (java.lang.CharSequence) "                                       1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", 10, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Viren" + "'", str3.equals("Java Viren"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100.0f, (double) (-1), (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", "            sun.awt.CGraphicsEnvironment            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str2.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", (java.lang.CharSequence) "####0.0#####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#4a4a4#444", "-b1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0a-1.0a100.0a10.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                            f455629                            f455629                #4a4a4#444 ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("mp/run_randoop.pl_51871_1560279118/target/classes:/U", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.0a1.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-b1", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", "            sun.awt.CGraphicsEnvironment            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("X", "class [Cclass [Cclass [Ljava.lang.String;", "                                       1.0a1.0a100.0", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X" + "'", str4.equals("X"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1004974-1414-14-1", (java.lang.CharSequence) "-1.0a-1.0a100.0a10.0a100.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0aaaaaaa", 'a');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp", (java.lang.CharSequence) "46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x", 1039);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "sun.lwawt.macosx.CPrinterJob", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", 95);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java HotSpot(TM) 64-Bit Server VM", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "100.041.041.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.0a10.0a0.0", "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("ava Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("-1.0A-1.0A100.0A10.0A100.0", "Java Platform API Specification", "", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1.0A-1.0A100.0A10.0A100.0" + "'", str4.equals("-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1.0 -1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str1.equals("-1.0 -1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Oracle#Corporation", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0#-1#100#100#35#0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0" + "'", str2.equals("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("\n", (int) (byte) 0, 44);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0a1.0a100.0", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "J5055V...15l5M501..15S510.f.05....", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#-1#-1#0#-1", "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("04-14100410043540", (int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "04-14100410043540" + "'", str3.equals("04-14100410043540"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "sun.awt.CGraphicsEnvironment", 44);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str1.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.041.041.0452.048.0", (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim(".1.0000000");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".1.0000000" + "'", str1.equals(".1.0000000"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, 95L, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 95L + "'", long3 == 95L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                      1.7.0_80                      ", (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "a a       #", (java.lang.CharSequence) "Java Platform API Specification", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9" + "'", str1.equals("9"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 1, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "            SUN.AWT.cgRAPHICSeNVIRONMENT            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10 0 1", "100.041.041.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(12.0f, (float) (byte) 10, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("97a-1a-1", "                         1.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         1.0a1.0" + "'", str2.equals("                         1.0a1.0"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "04-14100410043540", (int) '#');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("tiklooTCWL.xsocam.twawl.nus", "http://java.oracle.com/", "24.80-b11");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server", "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0", 87);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("f455629                                                                                             ", "#4a4a4#444", 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "f455629                                     #4a4a4#444                                           " + "'", str3.equals("f455629                                     #4a4a4#444                                           "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#0#1" + "'", str10.equals("10#0#1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10#0#1" + "'", str13.equals("10#0#1"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "04-14100410043540");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER v");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1004974-1414-14-1", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1004974-1414-14-1" + "'", str3.equals("1004974-1414-14-1"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#4a4a4#444 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#4a4a4#444", (java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#4a4a4#444", 45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "j5055V...15l5M501..15S510.f.05....");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1a100a35a1", 24, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaa1a100a35a1" + "'", str3.equals("aaaaaaaaaaaaaa1a100a35a1"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("04-14-1404-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04-14-1404-1" + "'", str1.equals("04-14-1404-1"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                            f455629                            f455629                #4a4a4#444 ", (double) 44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.0d + "'", double2 == 44.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1004-140", charSequence1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("32a52a52a1", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32a52a52a1" + "'", str2.equals("32a52a52a1"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "j5055V...15l5M501..15S510.f.05....");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaa", "                                       1.0a1.0a100.0");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100.0 0.0 10.0 100.0", strArray5, strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "X", (java.lang.CharSequence[]) strArray5);
        java.lang.CharSequence charSequence12 = null;
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "hi!");
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence12, (java.lang.CharSequence[]) strArray15);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0.", strArray5, strArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0 0.0 10.0 100.0" + "'", str10.equals("100.0 0.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                         1.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "en", 5, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', 0L, 95L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0#-1#-1#0#-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.0a1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("X", "hi!           f455629                #4a4a4#444 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X" + "'", str2.equals("X"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (byte) 10, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1004-140", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("class [Cclass [Cclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [Cclass [Cclass [Ljava.lang.String;" + "'", str1.equals("class [Cclass [Cclass [Ljava.lang.String;"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("class [Cclass [Cclass [Ljava.lang.String;", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.0a1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0a1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed   ", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray4, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "sun.awt.CGraphicsEnvironment");
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "#4a4a4#44", (int) (short) 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "US" + "'", str9.equals("US"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("En", "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "En" + "'", str2.equals("En"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Virtual Machine Specification", "1.7", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, (int) (short) 0, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("248-b", 3, 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-b" + "'", str3.equals("-b"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "0.", (java.lang.CharSequence) "9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) (short) -1, (double) 179);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 179.0d + "'", double3 == 179.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed" + "'", str2.equals("            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1.0A-1.0A100.0A10.0A100.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0A-1.0A100.0A10.0A100.0" + "'", str2.equals("-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "class [Cclass [Cclass [Ljava.lang.String;", (java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str2.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "class [Cclass [Cclass [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.util.regex.PatternSyntaxException; message: Unclosed character class near index 40\nclass [Cclass [Cclass [Ljava.lang.String;\n                                        ^");
        } catch (java.util.regex.PatternSyntaxException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#4a4a4#444 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("en", (int) ' ', "100.0a1.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0a1.100.0a1.100.0a1.100.0aen" + "'", str3.equals("100.0a1.100.0a1.100.0a1.100.0aen"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "j5055V...15l5M501..15S510.f.05....", "04-14-1414100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("http://java.oracle.com/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                      http://java.oracle.com/                                       " + "'", str2.equals("                                      http://java.oracle.com/                                       "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-b15" + "'", str1.equals("-b15"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 12, 95L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 95L + "'", long3 == 95L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100." + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100."));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                            f455629", (java.lang.CharSequence) "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                                                                                       ####0.0#####", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####" + "'", str2.equals("                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE" + "'", str1.equals("MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###" + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "ot(tm) 64-", 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (-1), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "f455629                                     #4a4a4#444                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("jAVA hOTsPOT(tm) 64-bIT sERVER v", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100.0#0.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("mixed mode", "mp/run_randoop.pl_51871_1560279118/target/classes:/U", (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mp/run_randoop.pl_51871_1560279118/target/classes:/U" + "'", str4.equals("mp/run_randoop.pl_51871_1560279118/target/classes:/U"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str2.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 0, 3);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-1404-1" + "'", str8.equals("04-14-1404-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#-1#-1" + "'", str12.equals("0#-1#-1"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.0a1.0a100.0", (java.lang.CharSequence) "class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("32a52a52a1", (-1), "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32a52a52a1" + "'", str3.equals("32a52a52a1"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64", 10, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64" + "'", str3.equals("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        float[] floatArray4 = new float[] { 100.0f, 0, 10.0f, 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0 0.0 10.0 100.0" + "'", str6.equals("100.0 0.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.041.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.041.04100.0" + "'", str1.equals("1.041.04100.0"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                      http://java.oracle.com/                                       ", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "100.0a1.100.0a1.100.0a1.100.0aen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        float[] floatArray4 = new float[] { 32, 35, (short) 1, 12 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 35.0f + "'", float5 == 35.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n", (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        short[] shortArray5 = new short[] { (byte) 0, (short) 1, (short) 10, (byte) 100, (short) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "04-14-1404-1", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "0a-1a100a100a35a0", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 95, 0);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 2, 142);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.", "04-14100410043540");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaa", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0#-1#-1", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100.0a1.100.0a1.100.0a1.100.0aen", (java.lang.CharSequence) "MIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sun.lwawt.macosx.CPrinterJob", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("#################################################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server", (java.lang.CharSequence) "J5055V...15l5M501..15S510.f.05....");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(".7.0_80", "#################################################################################################", (int) 'a', 1039);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".7.0_80#################################################################################################" + "'", str4.equals(".7.0_80#################################################################################################"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0a-1a100a100a35a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.0a10.0a0.0", "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64", (int) ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "-1.0a-1.0a100.0a10.0a100.0", (int) (short) 100, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.3", "tiklooTCWL.xsocam.twawl.nus");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100.0 0.0 10.0 100.0                                                                                ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0 0.0 10.0 100.0                                                                                " + "'", str6.equals("100.0 0.0 10.0 100.0                                                                                "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        char[] charArray8 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0 0.0 10.0 100.0                                                                                ", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "J5055V...15l5M501..15S510.f.05....", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a4a4#444 " + "'", str10.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("T", "#4a4a4#44", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("248-b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "248-b" + "'", str1.equals("248-b"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", (java.lang.CharSequence) ".7.0_80#################################################################################################", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####", "-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####" + "'", str2.equals("####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.7.0_80-b151.7.0_80-b15", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100.0 0.0 10.0 100.0                                                                                ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0 0.0 10.0 100.0                                                                                " + "'", str4.equals("100.0 0.0 10.0 100.0                                                                                "));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporation", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (int) (byte) -1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "100.0 0.0 10.0 100.0                                                                                ");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Oracle#Corporation" + "'", str6.equals("Oracle#Corporation"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#4a4a4#444", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a4a4#444" + "'", str2.equals("#4a4a4#444"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#4a4a4#44", "", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#4a4a4#44" + "'", str3.equals("#4a4a4#44"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0                                                                                                   ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ":", (int) 'a', (int) 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.3", 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.3f + "'", float2 == 1.3f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0, (double) 100L, (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.0a1.0a100.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ".1.0000000");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0#-1#-1", (java.lang.CharSequence) "Oracle Corporation", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.041.04100.0", "", (int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3245245241" + "'", str10.equals("3245245241"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "E", "-b");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10.14.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "100.041.041.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0", (int) (short) 1, 24);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 24, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 24");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sop");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 7, 0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Platform API Specification", "0.", "-1.0410.040.0", 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100.0a1.", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaa", "                                       1.0a1.0a100.0");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 3, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("java HotSpot(TM) 64-Bit Server", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-Bit Server" + "'", str2.equals("java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("jAVA hOTsPOT(tm) 64-bIT sERVER vm", "####0.0#####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA hOTsPOT(tm) 64-bIT sERVER vm" + "'", str2.equals("jAVA hOTsPOT(tm) 64-bIT sERVER vm"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("US", "100.0a1.100.0a1.100.0a1.100.0aen");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, 1039, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1039 + "'", int3 == 1039);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("            SUN.AWT.cgRAPHICSeNVIRONMENT            ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            SUN.AWT.cgRAPHICSeNVIRONMENT            " + "'", str2.equals("            SUN.AWT.cgRAPHICSeNVIRONMENT            "));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleCorporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100, 95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("#4a4a4#44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a4a4#44" + "'", str1.equals("#4a4a4#44"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0#-1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0#-1#-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "jAVA hOTsPOT(tm) 64-bIT sERVER vm", (java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#-1#100#100#35#0" + "'", str1.equals("0#-1#100#100#35#0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("MIXED MODE", ".7.0_80#################################################################################################", "04-14-1404-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MODE" + "'", str3.equals("MIXED MODE"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.", 97, 1039);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0410.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#');
        try {
            float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100.0a1.", "-b");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a1." + "'", str2.equals("100.0a1."));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sophie", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100.0 0.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#####", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ', 10, 2);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 0.0 10.0 100.0", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10#0#1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#0#1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("9", (int) (byte) 100, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Cor9aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Cor9aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "04-14-1404-1", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA hOTsPOT(tm) 64-bIT sERVER" + "'", str1.equals("JAVA hOTsPOT(tm) 64-bIT sERVER"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "class [Cclass [Cclass [Ljava.lang.String;", (java.lang.CharSequence[]) strArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "-b15", 0, 45);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.CharSequence charSequence0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.length(charSequence0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) 7, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("hi!           f455629                #4a4a4#444 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!           f455629                #4a4a4#444" + "'", str1.equals("hi!           f455629                #4a4a4#444"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mixed mode", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS X", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "f455629");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray5, strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "sun.awt.CGraphicsEnvironment");
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0                                                                                                   ", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "US" + "'", str10.equals("US"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1.04-1.04100.0410.04100.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str2.equals("-1.04-1.04100.0410.04100.0"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("En", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "En" + "'", str2.equals("En"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("f455629");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "97a-1a-1", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32 52 52 1" + "'", str10.equals("32 52 52 1"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp", "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 179, (long) (byte) 0, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 179L + "'", long3 == 179L);
    }
}

