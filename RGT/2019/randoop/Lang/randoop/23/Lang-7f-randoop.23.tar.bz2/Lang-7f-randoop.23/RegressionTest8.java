import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 590, 9.0d, (double) 1412);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1412.0d + "'", double3 == 1412.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "# a a # 4  ", "            sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "            sun.awt.cgraphicsenvironment            mixed modemixed modemixed modemixed modemixed", (java.lang.CharSequence) "100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01b-100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a0100a-1a01", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.0a1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a a       #44444444444444444444444444444444444444444", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# a a # 4  ", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", charArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', (int) (byte) 1, (-1));
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "04-14100410043540", charArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "35");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', 1, (int) (short) 1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(13, (int) '4', 24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "en", 3884);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                            f455629                            f455629                #4a4a4#444 ", "                 ...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            f455629                            f455629                #4a4a4#444 " + "'", str2.equals("                            f455629                            f455629                #4a4a4#444 "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0 -1 100 100 35 0", (int) (byte) 1, "35");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 -1 100 100 35 0" + "'", str3.equals("0 -1 100 100 35 0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("classa...", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "classa..." + "'", str3.equals("classa..."));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("           aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.3", 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Java HotSpot(TM) 64-Bit Server" + "'", str9.equals("Java HotSpot(TM) 64-Bit Server"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 45, 0.0d, (double) 95);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("a100a1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64", 3884, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("TIKLOOtcwl4XSOCAM4TWAWL4NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOtcwl4XSOCAM4TWAWL4NUS" + "'", str1.equals("TIKLOOtcwl4XSOCAM4TWAWL4NUS"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "MIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODEMIXED MODE", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-1.0A-1.0A100.0A10.0A100.0", (int) (byte) 100, 87);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie##", "           aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...            ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', (int) (short) 100, (int) (short) 100);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("O", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("44451.0", "1.0a1.0a a #44444444444444444", " ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44451.0" + "'", str3.equals("44451.0"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("HI!           F455629                #4A4A4#444 ", "  sun.awt.CGraphicsEnvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!           F455629                #4A4A4#444 " + "'", str2.equals("HI!           F455629                #4A4A4#444 "));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1004-140");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "            TNEMNORIVNeSCIHPARgc.TWA.NUS            ");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10#0#1");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("MIXED MODEMIXED MODEMIXED MODEMIXED", strArray2, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1004-140" + "'", str4.equals("1004-140"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004-140" + "'", str5.equals("1004-140"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;", "1004974-1414-14-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;" + "'", str2.equals("CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("a100a1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray3 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2 };
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils5 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils6 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray7 = new org.apache.commons.lang3.SystemUtils[] { systemUtils4, systemUtils5, systemUtils6 };
        org.apache.commons.lang3.SystemUtils systemUtils8 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils9 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils10 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray11 = new org.apache.commons.lang3.SystemUtils[] { systemUtils8, systemUtils9, systemUtils10 };
        org.apache.commons.lang3.SystemUtils systemUtils12 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils13 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils14 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray15 = new org.apache.commons.lang3.SystemUtils[] { systemUtils12, systemUtils13, systemUtils14 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray16 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray3, systemUtilsArray7, systemUtilsArray11, systemUtilsArray15 };
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray16);
        org.junit.Assert.assertNotNull(systemUtilsArray3);
        org.junit.Assert.assertNotNull(systemUtilsArray7);
        org.junit.Assert.assertNotNull(systemUtilsArray11);
        org.junit.Assert.assertNotNull(systemUtilsArray15);
        org.junit.Assert.assertNotNull(systemUtilsArray16);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "T", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaa", "java Platform API Specificatio", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray3);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, '#', (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java Platform API Specificatio", 5, 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/LibrJava Platform API Specificatiova/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("/LibrJava Platform API Specificatiova/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        float[] floatArray3 = new float[] { (short) -1, 10L, 0.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#', 9, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0a10.0a0.0" + "'", str6.equals("-1.0a10.0a0.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0410.040.0" + "'", str8.equals("-1.0410.040.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0410.040.0" + "'", str11.equals("-1.0410.040.0"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("          ", "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "111oolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("-1.0 -1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str1.equals("-1.0 -1.0 100.0 10.0 100.0"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        double[] doubleArray2 = new double[] { 1L, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a1.0" + "'", str4.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("             a a       #", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             a a       #" + "'", str3.equals("             a a       #"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "Java Platform API Specificatio", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100L, (float) 64L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/", "            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] {};
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.0aaaaaaa", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100a-1a0", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.041.041.0452.048.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#-1#1", (java.lang.CharSequence) "#################################################################################################", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification" + "'", str3.equals("Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/", "1.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0.0", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str6 = javaVersion0.toString();
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.1" + "'", str6.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str11.equals("-1.0 -1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str13.equals("-1.04-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "9" + "'", str1.equals("9"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "sophie", 590);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("f455629");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"f455629\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_64", "                                                                   0#-1#-1                                                                    ", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444440                                                                                                   ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("TIKLOOtcwl.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TIKLOOtcwl.XSOCAM.TWAWL.NUS" + "'", str1.equals("TIKLOOtcwl.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10.14.3", 83, "                            f455629");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3                            f455629                            f455629      " + "'", str3.equals("10.14.3                            f455629                            f455629      "));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("###########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###########" + "'", str1.equals("###########"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporation", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (int) (byte) -1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-b15", (java.lang.CharSequence[]) strArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "tiklooTCWL.xsocam.twawl.nu", 97, 9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51871_1560279118/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51871_1560279118/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "java Platform API Specificatio", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VMJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "j5055V...15l5M501..15S510.f.05....", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0a-1a100a100a35a0", 142, "3a53a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a0a-1a100a100a35a0" + "'", str3.equals("3a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a13a53a0a-1a100a100a35a0"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tiklootcwl4xsocam4twawl4nus", 29, "0a-1a-1a1a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tiklootcwl4xsocam4twawl4nus0a" + "'", str3.equals("tiklootcwl4xsocam4twawl4nus0a"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " sERVER vm", "100.0a1.100.0a1.100.0a1.100.0aen####################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("#4a4a4#444");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0", 179, "java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0" + "'", str3.equals("-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        char[] charArray8 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        java.lang.Class<?> wildcardClass11 = charArray8.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                 ", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0a-1a-1a0a-1", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#4a4a4#444 " + "'", str10.equals("#4a4a4#444 "));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#4a4a4#444 " + "'", str13.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "##a#a###4# " + "'", str17.equals("##a#a###4# "));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "                                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) '4', 23);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0 . 0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("tiklootcwl4xsocam4twawl4nus", "                                      http://java.oracle.com/                                       ", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                      http://java.oracle.com/                                       ", 100, "4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      http://java.oracle.com/                                       " + "'", str3.equals("                                      http://java.oracle.com/                                       "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                            f455629                            f455629                #4a4a4#444 ", "-1.TIKLOOtcwl4XSOCAM4TWAWL4NUS0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            f455629                            f455629                #4a4a4#444 " + "'", str3.equals("                            f455629                            f455629                #4a4a4#444 "));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 32, 30L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "####0.0#####", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ot(tm) 64-", (java.lang.CharSequence) "f455629");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#a a a aaa", (long) 95);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 95L + "'", long2 == 95L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("J5055V...15l5M501..15S510.f.05....", "04-14-1404-1", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J5055V...15l5M501..15S510.f.05...." + "'", str3.equals("J5055V...15l5M501..15S510.f.05...."));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#####", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "####0.0#####", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.0", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004-140" + "'", str10.equals("1004-140"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100a-1a0" + "'", str12.equals("100a-1a0"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-b1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporation", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean4 = javaVersion1.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.8" + "'", str5.equals("1.8"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "T", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                               9", "100a-1a0", "-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               9" + "'", str3.equals("                               9"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 5, 0L, (long) 179);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 179L + "'", long3 == 179L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0#53#001#001#1-#0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("24.80-b11", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str2.equals("24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                    ####0.0#####                    ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                    ####0.0#####                    " + "'", str2.equals("                    ####0.0#####                    "));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean6 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        boolean boolean12 = javaVersion8.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean15 = javaVersion13.atLeast(javaVersion14);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean18 = javaVersion16.atLeast(javaVersion17);
        java.lang.String str19 = javaVersion16.toString();
        boolean boolean20 = javaVersion13.atLeast(javaVersion16);
        java.lang.String str21 = javaVersion13.toString();
        boolean boolean22 = javaVersion9.atLeast(javaVersion13);
        boolean boolean23 = javaVersion5.atLeast(javaVersion9);
        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7" + "'", str7.equals("1.7"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.4" + "'", str19.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.1" + "'", str21.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                4                                                ", "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###", "#-1#-1#0#");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4", 95, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaa-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4a" + "'", str4.equals("aaaaaaaaaa-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4a"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "v REVREs TIb-46 )mt(TOPsTOh AVAj", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "2b-");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        char[] charArray6 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        java.lang.Class<?> wildcardClass9 = charArray6.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#4a4a4#444 " + "'", str8.equals("#4a4a4#444 "));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#4a4a4#444 " + "'", str11.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "# a a # 4  " + "'", str13.equals("# a a # 4  "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        float[] floatArray3 = new float[] { (byte) 100, 12, 87L };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) (short) -1, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 12.0f + "'", float4 == 12.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 100.0f + "'", float5 == 100.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/LibrJava Platform API Specificatiova/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 11, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-1.0#-1.0#100.0#10.0#100.0", (int) (byte) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("            sun.awt.CGraphicsEnvironment            ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a", "-b15", "aaaaaaaaaaaaaa1a100a35a1                                                                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a" + "'", str3.equals("aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("SUN.LWAWT.MACOSX.LWCTOOLKIT", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "##################################Java Platform API Specification###################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "Java Virtual Machine Specification", 100, 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine Specification" + "'", str4.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", charArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray3, ' ');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray3, 'a', 893, (int) (byte) 1);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".051.051.0" + "'", str2.equals(".051.051.0"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("#######", "/users/sophie/documents/defects4j/tmp/run_rndoop...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######" + "'", str2.equals("#######"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "b-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-b", 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("F455629", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140     1004-140", "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6", "-b1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100 97 -1 1 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 97 -1 1 -1 -1" + "'", str1.equals("100 97 -1 1 -1 -1"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0                                                                                                   ", "0 -1 -1 0 -1", (int) (byte) 1, (int) (short) 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "00 -1 -1 0 -1                                                                                           " + "'", str4.equals("00 -1 -1 0 -1                                                                                           "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1", "4# #a# #a", "/USERS/SOPHIE/DOCUMENTS/DEFECTS4JAVA HOTSPOT(TM) 64-BIT SERVER VMN/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java HotSpot(TM) 64-Bit Server", 95, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                       ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "E", (int) (byte) 100, 142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str16.equals("-1.04-1.04100.0410.04100.0"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0 -1 100 100 35 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("tiklooTCWL4xsocam4twawl4nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL4xsocam4twawl4nu" + "'", str1.equals("tiklooTCWL4xsocam4twawl4nu"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", "44444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("java HotSpot(TM) 64-Bit Serve", "/users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java HotSpot(TM) 64-Bit Serve" + "'", str2.equals("java HotSpot(TM) 64-Bit Serve"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1410043541");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.410043541E9d + "'", double1 == 1.410043541E9d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-1.0 -1.0 100.0 10.0 100.0", (java.lang.CharSequence) "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x" + "'", str2.equals("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                       1.0a1.0a100.0", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("illkl lkl ilkl illkl                                                                                ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "illkl lkl ilkl illkl                                                                                " + "'", str2.equals("illkl lkl ilkl illkl                                                                                "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("tiklootcwl4xsocam4twawl4nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklootcwl4xsocam4twawl4nus" + "'", str1.equals("tiklootcwl4xsocam4twawl4nus"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.LWAWT.MACOSX.lwctOOLKIT", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("a100a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a100a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        double[] doubleArray4 = new double[] { (short) 100, 0.0f, 12, 0.0d };
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 27, 10);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.040.0412.040.0" + "'", str8.equals("100.040.0412.040.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "J5055V...15l5M501..15S510.f.05....");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sop");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str5 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7" + "'", str5.equals("1.7"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        float[] floatArray3 = new float[] { (short) -1, 10L, 0.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0410.040.0" + "'", str7.equals("-1.0410.040.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0a10.0a0.0" + "'", str10.equals("-1.0a10.0a0.0"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...404-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "f455629                                                                                             ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', (long) 5, 29L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1004-140  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004-140" + "'", str1.equals("1004-140"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#0#1" + "'", str10.equals("10#0#1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10 0 1" + "'", str14.equals("10 0 1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10a0a1" + "'", str16.equals("10a0a1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10 0 1" + "'", str18.equals("10 0 1"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 1.0 100.0" + "'", str1.equals("1.0 1.0 100.0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 590, (float) 1039, (float) 142L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 142.0f + "'", float3 == 142.0f);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 10, (byte) 10, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 27, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 27");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 10, 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100a35a1" + "'", str7.equals("1a100a35a1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("oERo/ooPHIE", "111oolkit", "CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oERo/ooPHIE" + "'", str3.equals("oERo/ooPHIE"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10#0#1");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#######################", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 22 + "'", int3 == 22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("...404-1", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("f455629                                     #4a4a4#444                                           ", "tiklooTCWL4xsocam4twawl4nus", 0, 11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "tiklooTCWL4xsocam4twawl4nus                                 #4a4a4#444                                           " + "'", str4.equals("tiklooTCWL4xsocam4twawl4nus                                 #4a4a4#444                                           "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa" + "'", str2.equals("aaa"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("04-14-1414100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##################################Java Platform API Specification###################################", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "JAVA hOTsPOT(tm) 64-bIT sERVER");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "            tnemnorivnescihpargc.twa.nus            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("     1004-140", "####0.0#####");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" sERVER vm", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "0 -1 100 100 35 0", 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, 0L, (long) 95);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.04-1.04100.0410.041");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("classa[J#classa[Ljava.lang.String;#classa[Ljava.lang.String;#classa[J#classa[Ljava.lang.String;", "", 590);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "classa[J#classa[Ljava.lang.String;#classa[Ljava.lang.String;#classa[J#classa[Ljava.lang.String;" + "'", str3.equals("classa[J#classa[Ljava.lang.String;#classa[Ljava.lang.String;#classa[J#classa[Ljava.lang.String;"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tikloo\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#a a a aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aaaaaa" + "'", str1.equals("#aaaaaa"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("java HotSpot(TM) 64-Bit Serve");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"java HotSpot(TM) 64-Bit Serve\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi" + "'", str1.equals("/Users/sophi"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                           :", "Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification", "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                           :" + "'", str3.equals("                                           :"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification", "/users/sophie/documents/defects4j/tmp/run_rndoop...", 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification" + "'", str3.equals("Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification/users/sophie/documents/defects4j/tmp/run_rndoop...Javasun.lwawt.macosx.LWCToolkitPlatformsun.lwawt.macosx.LWCToolkitAPIsun.lwawt.macosx.LWCToolkitSpecification"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaa1a100a35a1                                                                       ", (java.lang.CharSequence) "-1.0 -1.0 100.0 10.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a" + "'", str2.equals("aaaaaaaaa            SUN.AWT.cgRAPHICSeNVIRONMENT            a"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) 1039);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1039.0f + "'", float3 == 1039.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "F455629", (java.lang.CharSequence) "10.14.3                            f455629                            f455629      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', (int) (short) 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "04-14100410043540" + "'", str9.equals("04-14100410043540"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#-1#100#100#35#0" + "'", str12.equals("0#-1#100#100#35#0"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("TIKLOOt...", (float) 29L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 29.0f + "'", float2 == 29.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "                    ####0.0#####                    ", 9, 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                    ####0.0#####                    " + "'", str4.equals("                    ####0.0#####                    "));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa CaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa \n", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####0.0#####", "                  1.0a1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####", "MIXED MODE");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str1.equals("classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "tiklootcwl4xsocam4twawl4nus0a", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "tiklooTCWL.xsocam.twawl.nus");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1.0#-1.0#100.0#10.0#100.0", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("E", "                 ", (int) (byte) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x" + "'", str10.equals("46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "b-", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1", 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  " + "'", str2.equals("TCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  "));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Oracle#Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                            hi", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("    tiklooTCWL.xsocam.twawl.nus    ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wl.nus    am.twa    tiklooTCWL.xsoc" + "'", str2.equals("wl.nus    am.twa    tiklooTCWL.xsoc"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6" + "'", str2.equals("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        char[] charArray7 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        java.lang.Class<?> wildcardClass10 = charArray7.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 1, 0);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#######################", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#4a4a4#444 " + "'", str9.equals("#4a4a4#444 "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#4a4a4#444 " + "'", str12.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0 1.0 100.0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "us/Users/");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "uS", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "1.0a1.0");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51871_1560279118/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", strArray5, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-141004100435", "0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("f455629                                     #4a4a4#444                                           ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MIXED MODE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /Users/sophie", "10 10 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-1.04-1.04100.0410.041", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0" + "'", str2.equals("-1.0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_6");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Oracle Corporation", "hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("##################################Java Platform API Specification###################################", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##################################Java Platform API Specification###################################" + "'", str3.equals("##################################Java Platform API Specification###################################"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi", (float) 64L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 64.0f + "'", float2 == 64.0f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "97a-1a-1", (java.lang.CharSequence) "class [Cclass [Cclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1.0a-1.0a100.0a10.0a100.0", "java HotSpot(TM) 64-Bit Server");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 29, 3884L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3884L + "'", long3 == 3884L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("jAVA pLATFORM api sPECIFICATIO", "tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATIO" + "'", str2.equals("jAVA pLATFORM api sPECIFICATIO"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7", "tiklooTCWL.xsocam.twawl.nu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1#100#35#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#100#35#" + "'", str2.equals("#100#35#"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("MIXED MODEMIXED MODEMIXED MODEMIXED", "a a       #");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXED MODEMIXED MODEMIXED MODEMIXED" + "'", str2.equals("MIXED MODEMIXED MODEMIXED MODEMIXED"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "1004-140  ", (java.lang.CharSequence) "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.041.0", 893);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      1.041.0" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      1.041.0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        float[] floatArray3 = new float[] { (short) -1, 10L, 0.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0410.040.0" + "'", str7.equals("-1.0410.040.0"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray9, strArray13);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, ' ', 44, 5);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray13, "0                                                                                                   ");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0", strArray4, strArray13);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, ":");
        boolean boolean24 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "US" + "'", str14.equals("US"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0" + "'", str21.equals("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("J5055V...15l5M501..15S510.f.05....", 9, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J5055V...15l5M501..15S510.f.05...." + "'", str3.equals("J5055V...15l5M501..15S510.f.05...."));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaa", "                                       1.0a1.0a100.0");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, " ");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a100a1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "aaaaaaaaaa" + "'", str5.equals("aaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#aaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull(".1.0000000");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".1.0000000" + "'", str1.equals(".1.0000000"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        double[] doubleArray2 = new double[] { 1L, (byte) 1 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) 'a', (int) (byte) -1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.0a1.0" + "'", str4.equals("1.0a1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) 'a', 1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "                  1.0a1.");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                   1.0a1.");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1.0#-1.0#100.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0#-1.0#100.0#10.0#100.0" + "'", str1.equals("-1.0#-1.0#100.0#10.0#100.0"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "aaaaaaaaaa");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 35, (-1));
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO", (java.lang.CharSequence) "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("...oolk", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                               aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", "100.0a1.0a1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                               aaaaaaaaaaaaaaaaaaaaaaaaaaaaa..." + "'", str2.equals("                                                               aaaaaaaaaaaaaaaaaaaaaaaaaaaaa..."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("tiklootcwl4xsocam4twawl4nus", "             MIXED MOD             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklootcwl4xsocam4twawl4nus" + "'", str2.equals("tiklootcwl4xsocam4twawl4nus"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("     1004-140");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        char[] charArray5 = new char[] {};
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "97a-1a-1", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA hOTsPOT(tm) 64-bIT sERVER", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "TIKLOOtcwl4XSOCAM4TWAWL4NUS", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0", 1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0" + "'", str3.equals("-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.01.0 1.0 100.0-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("TIKLOOtcwl4XSOCAM4TWAWL4NUS", "fc0000gn/T /Users/sophie4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IKLOOtcwl4XSOCAM4TWAWL4NUS" + "'", str2.equals("IKLOOtcwl4XSOCAM4TWAWL4NUS"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100#-1#0", "44444", 30);
        long[] longArray10 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray10);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray10);
        java.lang.Object[] objArray14 = new java.lang.Object[] { "100#-1#0", longArray10 };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(objArray14, "aaaaaaaaaa-1.0a10.0a0.0hi!           f455629                #4a4a4#444 hi!           f455629                #4a");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 406, (long) (short) 1, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 406L + "'", long3 == 406L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 0);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ', 9, 0);
        double double20 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str15.equals("-1.0 -1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "#-1#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle4Corporation" + "'", str1.equals("Oracle4Corporation"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 590);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("0a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a0" + "'", str1.equals("0a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a00a-1a100a100a35a0"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.5", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "tiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) 30, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracleaCorp", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0a1.100.0a1.100.0a1.100.0aen", "       ");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("#######", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "#######" + "'", str7.equals("#######"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51871_1560279118/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("    tiklooTCWL.xsocam.twawl.nus    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tiklooTCWL.xsocam.twawl.nus" + "'", str1.equals("tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(".051.051.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(52.0f, (float) 12, (float) 8L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0." + "'", str2.equals("0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0."));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java Virtual Machine Specification is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("tiklootcwl4xsocam4twawl4nus", "JAVA hOTsPOT(tm) 64-bIT sERVER vm");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#############################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####", (int) 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####" + "'", str3.equals("                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####                                                                                                                                                                       ####0.0#####"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HI!           F455629                #4A4A4#444 ", "#4a4a4#44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!           F455629                #4A4A4#444 " + "'", str2.equals("HI!           F455629                #4A4A4#444 "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sop", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3884, (long) 32, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3884L + "'", long3 == 3884L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 0, (int) (short) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0#-1.0#100.0#10.0#100.0" + "'", str13.equals("-1.0#-1.0#100.0#10.0#100.0"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("3245245241", "aaa", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus", "                                                4                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus" + "'", str2.equals("tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus       tiklooTCWL.xsocam.twawl.nus"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("tiklootcwl4xsocam4twawl4nus", "1004-140  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0#-1.0#100.0#10.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("            s", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            s" + "'", str3.equals("            s"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("oERo/ooPHIE", 30, "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle4CorporationOoERo/ooPHIE" + "'", str3.equals("Oracle4CorporationOoERo/ooPHIE"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 29.0f, (double) 7, (double) 29.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.0d + "'", double3 == 29.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        char[] charArray4 = new char[] {};
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a", charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n", charArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ', (int) '#', 7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JAVA hOTsPOT(tm) 64-bIT sERVER vm", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", 893);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java HotSpot(TM) 64-Bit Server", "-1.04-1.04100.0410.04100.0", "1.0A1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10a0a1" + "'", str13.equals("10a0a1"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("US", (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar", "", "TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4Java HotSpot(TM) 64-Bit Server VMn/generation/randoop-current.jar"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3, (float) 590, (float) 11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0.001A0.01A0.001A0.1-A0.1-", "4444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.001A0.01A0.001A0.1-A0.1-" + "'", str2.equals("0.001A0.01A0.001A0.1-A0.1-"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "100.0a1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("100 -1 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 -1 " + "'", str1.equals("100 -1 "));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie", 1412, "#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#######/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie" + "'", str3.equals("#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#################aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#######/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/Users/sophie"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.00a-1a-1a0a-1                 1.0a1.0", "#a a a aaaa", (int) '#');
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                            f455629                            f455629                #4a4a4#444 ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "9");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                            ", 29, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1004974-1414-14-1", "                 ...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "AaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Cor9aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3245245241" + "'", str8.equals("3245245241"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32 52 52 1" + "'", str10.equals("32 52 52 1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/VAR\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b151.7.0_80-b1", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("fc0000gn/T /Users/sophie4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4/var/folders/_v/6v597zmn", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100.0a1.", "TIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0A1.100.0A1.100.0A1.100.0AENTIKLOOTCWL.XSOCAM.TWAWL.NUS####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0a1." + "'", str2.equals("100.0a1."));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "            sun.awt.cgraphicsenvironment            mixed modemixed modemixed modemixed modemixed", (java.lang.CharSequence) "-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T//VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/Thi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T//VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/Thi!" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T//VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/Thi!"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0 1.0 100.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "f455629                                     #4a4a4#444                                           ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa CaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOaaaaa \n", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "            TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNORIVNeSCIHPARgc.TWA.NUS                        TNEMNO", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.0a1.0a100.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a1.0a100.0" + "'", str2.equals("1.0a1.0a100.0"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(179L, (long) 9, (long) 893);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1100351", (java.lang.CharSequence) "...404-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("MIXED MOD");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MOD" + "'", str1.equals("MIXED MOD"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "Oracle Corporation");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str1.equals("classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-b", (java.lang.CharSequence) "100.0a1.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("classa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1a100a-1a0a100a1", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a1" + "'", str2.equals("1a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a11a100a-1a0a100a1"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("0 . 0", 406, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        double[] doubleArray6 = new double[] { 142.0f, 45, (short) 0, 142.0f, 179, 64L };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 179.0d + "'", double8 == 179.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "142.0#45.0#0.0#142.0#179.0#64.0" + "'", str10.equals("142.0#45.0#0.0#142.0#179.0#64.0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("##################################Java Platform API Specification###################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##################################Java Platform API Specification###################################" + "'", str1.equals("##################################Java Platform API Specification###################################"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "hi!");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100.0 0.0 10.0 100.0                                                                                ", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "/Users/sop", (int) (byte) 10);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "                                            hi");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("En", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "En" + "'", str12.equals("En"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corp"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("-1.0410.040.0", (int) (short) 100, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ndoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/fracl");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ndoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/fracl" + "'", str1.equals("ndoop-current.jation/ration/generamework/lib/test_generasses:/Users/sophie/Documents/defectsj/fracl"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray4, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/users/sophie/documents/defects4j/tmp/run_randoop.pl_51871_1560279118");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "US" + "'", str9.equals("US"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1004-140", (java.lang.CharSequence) "0#-1#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444", 7, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.8", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" sERVER vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " sERVER vm" + "'", str1.equals(" sERVER vm"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaa", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaa1a100a35a1                                                                       ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa1a100a35a1                                                                       " + "'", str2.equals("aaaaaaa1a100a35a1                                                                       "));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;", 4, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;" + "'", str3.equals("class [Jclass [Ljava.lang.String;class [Ljava.lang.String;class [Jclass [Ljava.lang.String;"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java HotSpot(TM) 64-Bit Server VM", "             MIXED MOD             ", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-141004100435");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("v REVREs TIb-46 )mt(TOPsTOh AVAj", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118", "####################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "v REVREs TIb-46 )mt(TOPsTOh AVAj" + "'", str3.equals("v REVREs TIb-46 )mt(TOPsTOh AVAj"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/", "neriV avaJ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100 -1 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 -1" + "'", str1.equals("100 -1"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hi!           f455629                #4a4a4#444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!           f455629                #4a4a4#444" + "'", str1.equals("hi!           f455629                #4a4a4#444"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("41sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"41sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("44451.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                      http://java.oracle.com/                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                      http://java.oracle.com/                                       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####" + "'", str1.equals("####0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#########0.0#####"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "            tnemnorivnescihpargc.twa.nus            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "##a#a###4# ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", "MIXED MOD", 32);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http://java.oracle.com/" + "'", str4.equals("http://java.oracle.com/"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1.0A-1.0A100.0A10.0A100.0", "/users/sophie", "                                       1.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0A-1.0A100.0A10.0A100.0" + "'", str3.equals("-1.0A-1.0A100.0A10.0A100.0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" ", "tiklootcwl.xsocam.twawl.nus");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (long) 3884);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3884L + "'", long2 == 3884L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.", "a a       #", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "###########", (java.lang.CharSequence) "-1.0A-1.0A100.0A10.0A100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("IKLOOtcwl4XSOCAM4TWAWL4NUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "IKLOOtcwl4XSOCAM4TWAWL4NUS" + "'", str1.equals("IKLOOtcwl4XSOCAM4TWAWL4NUS"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("3245245241", "CLASS [CCLASS [CCLASS [LJAVA.LANG.STRING;", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("0-1100100350", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0-110010035" + "'", str2.equals("0-110010035"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        java.lang.Class<?> wildcardClass12 = byteArray3.getClass();
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "f455629                                     #4a4a4#444                                           ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: f455629                                     #4a4a4#444                                           ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10 0 1" + "'", str11.equals("10 0 1"));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "#############################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1#100#35#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#100#35#1" + "'", str1.equals("1#100#35#1"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1...404-1", "                 ...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk...oolk");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("E", "                 ", (int) (byte) -1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("j5055V...15l5M501..15S510.f.05....", "class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;", "46_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x0.1a0.146_68x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "j5055V...15l5M501..15S510.f.05...." + "'", str3.equals("j5055V...15l5M501..15S510.f.05...."));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "444444444444", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#a a a aaa", "", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle4Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        char[] charArray9 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle Corporationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#4a4a4#444 " + "'", str11.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 87 + "'", int12 == 87);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 39 + "'", int14 == 39);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("32 52 52 1", "1#100#35#1", 95, 45);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32 52 52 11#100#35#1" + "'", str4.equals("32 52 52 11#100#35#1"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.CPrinterJob", "100.0 0.0 10.0 100.0                                                                              US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.01.0100.0", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                         1.01.0100.0" + "'", str2.equals("                                         1.01.0100.0"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("ot(tm) 64-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ot(tm) 64- is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.0 0.0 10.0 100.0", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        char[] charArray7 = new char[] { '#', 'a', 'a', '#', '4', ' ' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#100#35#", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#4a4a4#444 " + "'", str9.equals("#4a4a4#444 "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                                                                                       ", "a100a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                       " + "'", str2.equals("                                                                                       "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1004-140aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) ".7.0_80#################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("En", "100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0100.0#0.0#10.0#100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4', (int) (short) 100, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray3, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 0 + "'", byte8 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10#0#1" + "'", str10.equals("10#0#1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 0 + "'", byte12 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10 0 1" + "'", str14.equals("10 0 1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10#0#1" + "'", str16.equals("10#0#1"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#4a4a4#44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#4a4a4#44" + "'", str1.equals("#4a4a4#44"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "TIKLOOt...", "00 -1 -1 0 -1                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0#-1#-1", charSequence1, 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "35353535353                            f455629");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 64, 0L, (long) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 64L + "'", long3 == 64L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray10 = new char[] { 'a', 'a', ' ', ' ', ' ', '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("http://java.oracle.com/", "            sun.awt.cgraphicsenvironment            mixed modemixed modemixed modemixed modemixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 100, 24);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "04-14-1404-1" + "'", str8.equals("04-14-1404-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "            tnemnorivnescihpargc.twa.nus            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("100.0a1.100.0a1.100.0a1.100.0aen", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("f455629");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"f455629\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.041.04100.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/so...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "classa[J#classa[Ljava.lang.String;#classa[Ljava.lang.String;#classa[J#classa[Ljava.lang.String;", (java.lang.CharSequence) ".7.0_80#################################################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", "35353535353                            f455629");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("32 52 52 11#100#35#1", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32 52 52 11#100#35#1" + "'", str2.equals("32 52 52 11#100#35#1"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", "                                           :");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 45, 32);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0 -1 -1 1 100", "tiklootcwl4xsocam4twawl4nus0a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 -1 -1 1 100" + "'", str2.equals("0 -1 -1 1 100"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        double[] doubleArray5 = new double[] { (short) -1, (-1L), 100, (short) 10, 100 };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray5, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0 -1.0 100.0 10.0 100.0" + "'", str11.equals("-1.0 -1.0 100.0 10.0 100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str13.equals("-1.04-1.04100.0410.04100.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.04-1.04100.0410.04100.0" + "'", str16.equals("-1.04-1.04100.0410.04100.0"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("IKLOOtcwl4XSOCAM4TWAWL4NUS", "JavaPlatformAPISpecificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "KLOOtcwl4XSOCAM4TWAWL4NU" + "'", str2.equals("KLOOtcwl4XSOCAM4TWAWL4NU"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("111oolkit", 893, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7f + "'", float1 == 1.7f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("#4a4a4#44", "50a0a5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a4a4#44" + "'", str2.equals("#4a4a4#44"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.0a1.0a100.0", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/LibrJava Platform API Specificatiova/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 5, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) 'a', 0);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short19 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0a-1a-1a0a-1" + "'", str17.equals("0a-1a-1a0a-1"));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) -1 + "'", short19 == (short) -1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle#Corporation", "TiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ", 64);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#4a4a4#444", 18, 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0" + "'", str1.equals("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("32 52 52 1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#100#35#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("100#97#-1#1#-1#-1", "fc0000gn/T /Users/sophie4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        int[] intArray6 = new int[] { 100, 'a', (short) -1, (short) 1, (byte) -1, (short) -1 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100#97#-1#1#-1#-1" + "'", str9.equals("100#97#-1#1#-1#-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("fc0000gn/T /Users/sophie4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4/var/folders/_v/6v597zmn", 179, 629);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "fc0000gn/T /Users/sophie4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4/var/folders/_v/6v597zmn" + "'", str3.equals("fc0000gn/T /Users/sophie4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T /var/folders/_v/6v597zmn4_v31cq2n2x1n4/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("# a a # 4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 893, (double) 406, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Orcle Corportion");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100.0 0.0 10.0 100.0                                                                                ", "UTF-8", 32);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", " ", 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("US", strArray13, strArray17);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, ' ', 44, 5);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "0                                                                                                   ");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0", strArray8, strArray17);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray17);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.", strArray3, strArray17);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "US" + "'", str18.equals("US"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0" + "'", str25.equals("0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:." + "'", str27.equals("/users/sophie/library/java/extensions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:."));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                 1.0a1.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 179, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 35, 12);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 590, 30);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_641.0a1.0x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "#######################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoRACLE cORPORATIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("41sun.lwawt.macosx.LWCToolkit1410043541sun.lwawt.macosx", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("#############################################", "us/Users/", "1.041.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0 0.0 10.0 100.0                                                                              US");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "tiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nustiklooTCWL.xsocam.twawl.nus", (java.lang.CharSequence) "#4a4a4#444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0-1100100350", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        short[] shortArray3 = new short[] { (short) 100, (byte) -1, (short) 0 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 32, 32);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        byte[] byteArray1 = new byte[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("class [J#class [Ljava.lang.String;#class [Ljava.lang.String;#class [J#class [Ljava.lang.String;", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle CorpaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaOracle \n", 39);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        long[] longArray6 = new long[] { 0, (short) -1, (byte) 100, (short) 100, '#', 0L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long15 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long16 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0a-1a100a100a35a0" + "'", str12.equals("0a-1a100a100a35a0"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 100L + "'", long15 == 100L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO", "                    ####0.0#####                    ", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("tiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "###########", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100A-1A");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-B15", '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.041.0", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.041.0" + "'", str7.equals("1.041.0"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("a4a4 4 4 4#", "0#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#00#-1#100#100#35#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4a4 4 4 4#" + "'", str2.equals("a4a4 4 4 4#"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("32a52a52a1", "0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Oracle Corporation", "...404-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        int[] intArray3 = new int[] { 97, (byte) -1, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97#-1#-1" + "'", str8.equals("97#-1#-1"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Viren", "1 100 35 1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 27, (-1));
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1 100 35 1" + "'", str13.equals("1 100 35 1"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                 1.0a1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0a1.0" + "'", str1.equals("1.0a1.0"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "class [Cclass [Cclass [Ljava.lang.String;", (java.lang.CharSequence) "100.0a1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("T", "0 -1 100 100 35 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "T" + "'", str2.equals("T"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        int[] intArray1 = new int[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (byte) 100, (int) ' ');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 52, 590);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "04-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-1410041004354004-14100410043540");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "1.0a1.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 100, 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "tiklooTCWL.xsocam.twawl.nus");
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java HotSpot(TM) 64-Bit Server VM", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Ho" + "'", str2.equals("Java Ho"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str1.equals("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-b1", (java.lang.CharSequence) "                            f455629", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...aaaaaaaaaaaaaaaaaaaaaaaaaaaaa...", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        int[] intArray4 = new int[] { 1, (byte) 100, '#', (byte) 1 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a100a35a1" + "'", str9.equals("1a100a35a1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 100 35 1" + "'", str11.equals("1 100 35 1"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        long[] longArray4 = new long[] { ' ', 52, '4', 1L };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32a52a52a1" + "'", str6.equals("32a52a52a1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "3245245241" + "'", str8.equals("3245245241"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "b-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("MIXED MODEMIXED MODEMIXED MODEMIXED", "Orcle Corportion", 179);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(8.0f, 1.7f, 29.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 29.0f + "'", float3 == 29.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MIXED MOD", (java.lang.CharSequence) "                  1.0a1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        short[] shortArray5 = new short[] { (byte) 0, (short) -1, (short) -1, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 5, 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', (int) 'a', 0);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short18 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', (int) (short) 0, 39);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0a-1a-1a0a-1" + "'", str17.equals("0a-1a-1a0a-1"));
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) -1 + "'", short18 == (short) -1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("100.0 0.0 10.0 100.0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "TCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  100.0a1.100.0a1.100.0a1.100.0aentiklooTCWL.xsocam.twawl.nus####0.0#########0.0#########0.0#########0.0#########0.0#########0.0###                                                                                  ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("a a       #44444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a a       #44444444444444444444444444444444444444444" + "'", str1.equals("a a       #44444444444444444444444444444444444444444"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sop", "-1.04-1.04100.0410.04100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaa1a100a35a1                                                                       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "51.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.051.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("            sun.awt.CGraphicsEnvironment            aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "#a a a aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51871_1560279118/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_641.0-1.0x86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/uoERo/ooPHIE");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode", "sun.lwawt.macosx.LWCToolkit");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("E", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 7 vs 126");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
    }
}

