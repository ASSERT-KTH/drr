import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

//    @Test
//    public void test01() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test01");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long11 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test02");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.split();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.resume();
        stopWatch0.suspend();
        long long11 = stopWatch0.getSplitTime();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test03");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        long long5 = stopWatch0.getSplitTime();
//        stopWatch0.stop();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.reset();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test04");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.String str4 = stopWatch0.toString();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        long long7 = stopWatch0.getSplitTime();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

//    @Test
//    public void test05() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test05");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getTime();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test06");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getSplitTime();
//        stopWatch0.stop();
//        java.lang.String str12 = stopWatch0.toString();
//        java.lang.String str13 = stopWatch0.toSplitString();
//        java.lang.String str14 = stopWatch0.toSplitString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.002" + "'", str13.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0:00:00.002" + "'", str14.equals("0:00:00.002"));
//    }

//    @Test
//    public void test07() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test07");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12L + "'", long11 == 12L);
//    }

//    @Test
//    public void test08() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test08");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.start();
//        long long14 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test09");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        stopWatch0.stop();
//        long long16 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
//    }

//    @Test
//    public void test10() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test10");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        long long12 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test11");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        long long3 = stopWatch0.getTime();
        java.lang.String str4 = stopWatch0.toString();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.suspend();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        try {
            long long11 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test12() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test12");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test13");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test14");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test15");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.String str4 = stopWatch0.toString();
//        stopWatch0.stop();
//        java.lang.String str6 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//    }

//    @Test
//    public void test16() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test16");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        stopWatch0.reset();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        long long11 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test17() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test17");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.reset();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

//    @Test
//    public void test18() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test18");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.split();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test19");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.split();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test20() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test20");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.reset();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toString();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.007" + "'", str2.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
//    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test21");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.reset();
//        java.lang.String str7 = stopWatch0.toString();
//        long long8 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        java.lang.String str10 = stopWatch0.toString();
//        java.lang.String str11 = stopWatch0.toString();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test22");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.002" + "'", str10.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test23");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.split();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.resume();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test24");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.stop();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        java.lang.String str12 = stopWatch0.toString();
//        java.lang.String str13 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass15 = stopWatch0.getClass();
//        long long16 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.001" + "'", str13.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test25");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        java.lang.String str14 = stopWatch0.toSplitString();
//        java.lang.String str15 = stopWatch0.toSplitString();
//        stopWatch0.unsplit();
//        java.lang.String str17 = stopWatch0.toString();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0:00:00.002" + "'", str14.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0:00:00.002" + "'", str15.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-433407:00:-46.73" + "'", str17.equals("-433407:00:-46.73"));
//    }

//    @Test
//    public void test26() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test26");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        long long15 = stopWatch0.getTime();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        long long18 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test27");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:01.632" + "'", str5.equals("0:00:01.632"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1633L + "'", long8 == 1633L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:01.633" + "'", str9.equals("0:00:01.633"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:01.633" + "'", str10.equals("0:00:01.633"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1633L + "'", long11 == 1633L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1633L + "'", long12 == 1633L);
//    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test28");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.split();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.suspend();
        stopWatch0.unsplit();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test29");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getSplitTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        java.lang.String str16 = stopWatch0.toString();
//        java.lang.String str17 = stopWatch0.toString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0:00:00.000" + "'", str16.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0:00:00.000" + "'", str17.equals("0:00:00.000"));
//    }

//    @Test
//    public void test30() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test30");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test31");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.stop();
        stopWatch0.reset();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test32() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test32");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test33");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.002" + "'", str10.equals("0:00:00.002"));
//    }

//    @Test
//    public void test34() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test34");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getSplitTime();
//        stopWatch0.reset();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.002" + "'", str8.equals("0:00:00.002"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test35");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        stopWatch0.stop();
//        try {
//            long long13 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test36");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        java.lang.String str11 = stopWatch0.toString();
//        java.lang.String str12 = stopWatch0.toSplitString();
//        long long13 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass17 = stopWatch0.getClass();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.002" + "'", str8.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-433407:00:-48.98" + "'", str12.equals("-433407:00:-48.98"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test37");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.split();
        long long4 = stopWatch0.getSplitTime();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        long long8 = stopWatch0.getTime();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test38");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

//    @Test
//    public void test39() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test39");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.reset();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.reset();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:01.234" + "'", str5.equals("0:00:01.234"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1234L + "'", long6 == 1234L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:01.235" + "'", str10.equals("0:00:01.235"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//    }

//    @Test
//    public void test40() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test40");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.reset();
//        java.lang.String str10 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.reset();
//        try {
//            java.lang.String str14 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test41");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        long long13 = stopWatch0.getTime();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test42");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test43");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        long long12 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        long long17 = stopWatch0.getSplitTime();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1560265250669L) + "'", long17 == (-1560265250669L));
//    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test44");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        long long3 = stopWatch0.getTime();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.String str9 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test45");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        try {
//            java.lang.String str6 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//    }

//    @Test
//    public void test46() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test46");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.reset();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//    }

//    @Test
//    public void test47() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test47");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.936" + "'", str2.equals("0:00:00.936"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 937L + "'", long3 == 937L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.937" + "'", str4.equals("0:00:00.937"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.937" + "'", str5.equals("0:00:00.937"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 937L + "'", long6 == 937L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.937" + "'", str8.equals("0:00:00.937"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test48");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.split();
        long long4 = stopWatch0.getSplitTime();
        stopWatch0.unsplit();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test49");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.stop();
//        long long12 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        try {
//            java.lang.String str14 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//    }

//    @Test
//    public void test50() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test50");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        try {
//            long long12 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test51");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.suspend();
        try {
            java.lang.String str4 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test52");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        long long10 = stopWatch0.getSplitTime();
//        long long11 = stopWatch0.getSplitTime();
//        java.lang.String str12 = stopWatch0.toString();
//        long long13 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
//    }

//    @Test
//    public void test53() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test53");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.reset();
//        java.lang.String str12 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test54");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.suspend();
//        stopWatch0.unsplit();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.reset();
//        java.lang.String str11 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-433407:00:-52.15" + "'", str9.equals("-433407:00:-52.15"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test55");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.002" + "'", str10.equals("0:00:00.002"));
//    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test56");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.split();
//        long long4 = stopWatch0.getSplitTime();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1197L + "'", long4 == 1197L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:01.198" + "'", str5.equals("0:00:01.198"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1197L + "'", long6 == 1197L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:01.200" + "'", str9.equals("0:00:01.200"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1200L + "'", long10 == 1200L);
//    }

//    @Test
//    public void test57() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test57");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        long long12 = stopWatch0.getTime();
//        long long13 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        long long15 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass16 = stopWatch0.getClass();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test58");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        long long10 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        java.lang.String str12 = stopWatch0.toString();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.001" + "'", str2.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.002" + "'", str8.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest5.test59");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.start();
//        java.lang.String str2 = stopWatch0.toString();
//        long long3 = stopWatch0.getTime();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        long long12 = stopWatch0.getSplitTime();
//        long long13 = stopWatch0.getSplitTime();
//        java.lang.String str14 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass15 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.001" + "'", str4.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0:00:01.036" + "'", str14.equals("0:00:01.036"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }
//}

