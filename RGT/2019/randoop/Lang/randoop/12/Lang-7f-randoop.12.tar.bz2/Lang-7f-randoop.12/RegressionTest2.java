import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "100a10a0a100a0a1", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray1 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0 };
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray3 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils2 };
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils4 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray6 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray1, numberUtilsArray3, numberUtilsArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray6);
        org.junit.Assert.assertNotNull(numberUtilsArray1);
        org.junit.Assert.assertNotNull(numberUtilsArray3);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java(TM) SE Runtime Envi...", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "         :");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("mixed mode", "33 97 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("100a-1a0", 9, "01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0100a-1a0" + "'", str3.equals("0100a-1a0"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "33 97 -1 -1 -1", (java.lang.CharSequence) "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("M OS X", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M OS X" + "'", str2.equals("M OS X"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(10.0f, 0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, (float) (byte) -1, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1.0a28.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                  100a10a0a100a0a1                  ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("a");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "4444444444444444444444444444444");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 177 + "'", int5 == 177);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Java HotSpot(TM) 64-Bit Server VM", "18.0a97.0a100.0a0.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "M44 OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        long[] longArray3 = new long[] { 100, (-1), (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 33, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 10, (int) (byte) 10);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', (int) (byte) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15                                                                                        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime Envi...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "a", (java.lang.CharSequence) "33 97 -1 -1 -1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J100 10 0 100 0 ", (java.lang.CharSequence) "////////////////////////////////");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("100#-1#0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#-1#0  " + "'", str2.equals("100#-1#0  "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.", "ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444", "M44 OS X", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("U", 0, "h");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "U" + "'", str3.equals("U"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("a", "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "", 97);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "0.9", (-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("x", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x" + "'", str2.equals("x"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("#################################################################################################hi ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#################################################################################################hi" + "'", str1.equals("#################################################################################################hi"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "18.0a97.0a100.0a0.0a-1.0a0.0", charSequence1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "0 33 10 -1 100 -1", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("HI!", "35.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                  100a10a0a100a0a1                  ", "284177410043410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  100a10a0a100a0a1                  " + "'", str2.equals("                  100a10a0a100a0a1                  "));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                   100#10#0#100#0#1", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "#################################################################################################hi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("01 001 0", "0a10a1a1a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 001 " + "'", str2.equals(" 001 "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("h", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0 33 10 -1 100 -1", "sun.lwawt.macosx.LWCToolkit", "35.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 33 10 -1 100 -1" + "'", str3.equals("0 33 10 -1 100 -1"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long[] longArray1 = new long[] { 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 97, (int) 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', (int) (short) 1, (int) (short) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10" + "'", str17.equals("10"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", "sun.lwawt.macosx.CPrinterJob", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/", "52a3a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/" + "'", str2.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, (long) 10, (long) 33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10", 9, "x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xxxxxxx10" + "'", str3.equals("xxxxxxx10"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("e", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 e                                                  " + "'", str2.equals("                                                 e                                                  "));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("X86_64HI!", "33 97 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64HI!" + "'", str2.equals("X86_64HI!"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("IBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "100#-1#0  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("18.0a97.0a100.0a0.0a-1.0a0.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a-1.0a0.0a100.0a97.0a18.0" + "'", str2.equals("0.0a-1.0a0.0a100.0a97.0a18.0"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444" + "'", str1.equals("444"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", ".0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "284177410043410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J100 10 0 100 0 ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "                                                 e                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "97.0", (java.lang.CharSequence) "4444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444444", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.9", (java.lang.CharSequence) "                  100a10a0a100a0a1                  ", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", 0, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str3.equals("ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(35.0f, (float) 28L, (float) 166);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 166.0f + "'", float3 == 166.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, (long) (short) 1, (long) 27);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, (long) 166, (long) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 166L + "'", long3 == 166L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "0", (java.lang.CharSequence) "4444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10  10 hi! hi! 10", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10  10 hi! hi! 10" + "'", str3.equals("10  10 hi! hi! 10"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100a-1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100A-1A0" + "'", str1.equals("100A-1A0"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.6", "/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("M OS X", "U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M OS X" + "'", str2.equals("M OS X"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "0a10a1a1a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_GRAPHICSENV;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str0.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0.0a-1.0a0.0a100.0a97.0a18.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444", 3, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444" + "'", str3.equals("444"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, 9, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "-1.0a28.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("10", strArray7, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("JAVA HOTSPOT(TM) 64-BIT SERVER VM", strArray3, strArray11);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "01 001 0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str13.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("MV revreS tiB-46 )MT(topStoH avaJ", "10  10 hi! hi! 10", "100a10a0a100a0a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV revreS tiB-46 )MT(topStoH avaJ" + "'", str3.equals("MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java(TM) SE Runtime Envi...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Envi..." + "'", str1.equals("Java(TM) SE Runtime Envi..."));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100a10a0a100a0a1", "0 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a10a0a100a0a1" + "'", str2.equals("100a10a0a100a0a1"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("HI!", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        char[] charArray5 = new char[] { 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 10, (int) (short) 0);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray5);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray5);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 33, 3);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double[] doubleArray1 = new double[] { (short) 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', (int) (byte) 10, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0" + "'", str3.equals("10.0"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        char[] charArray6 = new char[] { 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 10, (int) (short) 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray6);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444", charArray6);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                 e                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        long[] longArray2 = new long[] { 18, 52 };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', 97, 166);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 166 + "'", int3 == 166);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("us");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"us\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0a-1.0a0.0a100.0a97.0a18.0", (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("M OS X", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X OS M" + "'", str2.equals("X OS M"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80", "USUSUSUSUSUSUSUSUSUSUSUSUSUSU...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                  100a10a0a100a0a1                  ", (java.lang.CharSequence[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (-1), 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Users/s...le.com/", (java.lang.CharSequence) "               10                ", 166);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "100#10#0#100#0#1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0100a-1a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "100 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/" + "'", str1.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0a33a10a-1a100a-1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a33a10a-1a100a-1" + "'", str2.equals("0a33a10a-1a100a-1"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100 10 0 100 0 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 10 0 100 0 1" + "'", str1.equals("100 10 0 100 0 1"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "################h################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0", (java.lang.CharSequence) "X OS M");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Envi...", "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "100 1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "100 1" + "'", charSequence2.equals("100 1"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "X86_64HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("          M44 OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          M44 OS X" + "'", str1.equals("          M44 OS X"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "", (int) (short) 1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str1.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.07.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0" + "'", str4.equals("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.07.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("97.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "", "################h################");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0 100 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 100 10" + "'", str1.equals("0 100 10"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "100#-1#0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 77 + "'", int2 == 77);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("MV revreS tiB-46 )MT(topStoH avaJ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   MV revreS tiB-46 )MT(topStoH avaJ" + "'", str2.equals("                   MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10" + "'", str3.equals("10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 1", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("HI!", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("334974-14-14-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "334974-14-14-1" + "'", str1.equals("334974-14-14-1"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                  100a10a0a100a0a1                  ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  100a10a0a100a0a1                  " + "'", str2.equals("                  100a10a0a100a0a1                  "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "                                                 e                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0 33 10 -1 100 -1", ' ');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J100 10 0 100 0 ", "                                                                                            0 100 10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "100#-1#0  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace(":", "", "http://java.oracle.com/", 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("a");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1.0a28.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (int) '4', "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        long[] longArray5 = new long[] { (short) 0, 10L, (byte) 1, 1, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray5, '#');
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a10a1a1a1" + "'", str7.equals("0a10a1a1a1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#10#1#1#1" + "'", str9.equals("0#10#1#1#1"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                          10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                          10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100a10a0a100a0a1", 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "US                              ", 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray3, strArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 6 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100#10#0#100#0#1" + "'", str5.equals("100#10#0#100#0#1"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                            0 100 10", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("################h################", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.9", "010010");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("0a10a1a1a1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 18, (double) (short) 10, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                   100#10#0#100#0#1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("h", "                                                \n                                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) " \n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100 1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 1" + "'", str2.equals("100 1"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "0 33 10 -1 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray6 = new double[] { 'a', 3, 1.0d, 100, (short) 0, (byte) 0 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', (int) ' ', 177);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "284177410043410", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "x", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "X OS Mac");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#################################################################################################", (java.lang.CharSequence) " ", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "US                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.0", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "52a3a100a-1", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', (int) '4', 9);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "Java HotSpot(TM) 64-Bit Server VM", "0.0a-1.0a0.0a100.0a97.0a18.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "          M44 OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50837_1560277813" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50837_1560277813"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (-1), (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("X OS M");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X OS M" + "'", str1.equals("X OS M"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10" + "'", charSequence2.equals("10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32L, 0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                   MV revreS tiB-46 )MT(topStoH avaJ", (java.lang.CharSequence) "                   MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("xxxxxxx10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(":", 10, 99);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "100a10a0a100a0a1", (java.lang.CharSequence) "x86_64hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 166, (long) (short) 100, 33L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("X86_64HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64HI!" + "'", str1.equals("X86_64HI!"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("97.0#3.0#1.0#100.0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0#3.0#1.0#100.0#0.0#0.0" + "'", str1.equals("97.0#3.0#1.0#100.0#0.0#0.0"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "tnemnorivnE emitnuR ES )MT(avaJ", "334974-14-14-1", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0" + "'", str4.equals("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("U", "                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', (int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("http://java.oracle.com/", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "#################################################################################################hi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("xxxxxxx10", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813", "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.07.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "0#33#10#-1#100#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("100a10a0a100a0a1", ".0_80-b15", 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a10a0a100a0a1" + "'", str3.equals("100a10a0a100a0a1"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "X86_64", "/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Mac OS X", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X               " + "'", str2.equals("Mac OS X               "));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("h", "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaah" + "'", str4.equals("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaah"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie", "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X               ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS ..." + "'", str2.equals("Mac OS ..."));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(28.0f, (float) 'a', (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", ' ');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("U", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "U" + "'", str5.equals("U"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("-1.0a28.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0a28.0" + "'", str1.equals("-1.0a28.0"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444" + "'", str1.equals("4444444444444"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("284177410043410", "                   MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100A-1A0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaah", (java.lang.CharSequence) "4444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("mixed mode", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("33 97 -1 -1 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"33 97 -1 -1 -1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.awt.CGraphicsEnvironment", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0#33#10#-1#100#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0#33#10#-1#100#-1" + "'", str1.equals("0#33#10#-1#100#-1"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10.14.3");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10010.01010.0010.010010.0010.01", "1.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        char[] charArray7 = new char[] { 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 10, (int) (short) 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", charArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444", charArray7);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', (int) ' ', (int) ' ');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0 33 10 -1 100 -1", charArray7);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "a" + "'", str22.equals("a"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0" + "'", str2.equals("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10  10 hi! hi! 10");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "                  100a10a0a100a0a1                  ", (int) '4', 50);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence[] charSequenceArray8 = new java.lang.CharSequence[] { "10", "", "10", "hi!", "hi!", "10" };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charSequenceArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS ...", charSequenceArray8);
        org.junit.Assert.assertNotNull(charSequenceArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSU...", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10, (double) 166L, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "M44 OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("us");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int[] intArray5 = new int[] { 33, 'a', (byte) -1, (byte) -1, (short) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', (int) (byte) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "334974-14-14-1" + "'", str7.equals("334974-14-14-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA", "U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".0_80-b15", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100#10#0#100#0#1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("JAVA HOTSPOT(TM) 64-BIT SERVER VM", "tnemnorivnE emitnuR ES )MT(avaJ", (int) '4');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "                                                \n                                                ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) ".0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 213 + "'", int2 == 213);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "0100a-1a0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "0 100 10", 99, 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 100 10" + "'", str4.equals("0 100 10"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("100a10a0a100a0a1", "   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a10a0a100a0a1" + "'", str2.equals("100a10a0a100a0a1"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "h", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("X86_64HI!", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "0 100 10", 28);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("   ", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "010010");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                   100#10#0#100#0#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", 100, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80" + "'", str3.equals("0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "HI!", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0a33a10a-1a100a-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/s...le.com/", "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/s...le.com/" + "'", str2.equals("/Users/s...le.com/"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(32L, (-1L), (long) 27);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "334974-14-14-1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/moc.el...s/sresU/", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, (-1), 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#################################################################################################hi ", (java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("################h################", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J100 10 0 100 0 1", "X86_64");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("http://java.oracle.com/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("          M44 OS X", 213, 166);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "X86_64HI!", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("mixed mode", "IBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813", (int) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "X86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ", "  X86_64  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0", "10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("10");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("10", strArray7, strArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("JAVA HOTSPOT(TM) 64-BIT SERVER VM", strArray3, strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSU...", (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str13.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J100 10 0 100 0 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mac OS X               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "1.7.0_8");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.7.0_8");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 10 0 100 0 1" + "'", str12.equals("100 10 0 100 0 1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a10a0a100a0a1" + "'", str14.equals("100a10a0a100a0a1"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("#################################################################################################hi", (double) 18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.0a-1.0a0.0a100.0a97.0a18.0", (java.lang.CharSequence) "0100a-1a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4');
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10", (java.lang.CharSequence[]) strArray5);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/", (java.lang.CharSequence[]) strArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "M44 OS X" + "'", str7.equals("M44 OS X"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 18 + "'", int8 == 18);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "M OS X" + "'", str11.equals("M OS X"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        char[] charArray7 = new char[] { 'a' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 10, (int) (short) 0);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", charArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444", charArray7);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', (int) ' ', (int) ' ');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        java.lang.Class<?> wildcardClass21 = charArray7.getClass();
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80-b11", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                          10", (java.lang.CharSequence) "284177410043410", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU", "444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444" + "'", str2.equals("444"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', (int) (short) -1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0a28.0" + "'", str6.equals("-1.0a28.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0a28.0" + "'", str8.equals("-1.0a28.0"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "334974-14-14-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444", "35.0", (int) (short) 100, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444444444444435.0" + "'", str4.equals("444444444444435.0"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("100a-1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a-1a0" + "'", str1.equals("100a-1a0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                   100#10#0#100#0#1", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                   100#10#0#100#0#1" + "'", str2.equals("                   100#10#0#100#0#1"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"M\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("...le.com/", "18.0a97.0a100.0a0.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...le.com/" + "'", str2.equals("...le.com/"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (byte) 0, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int[] intArray5 = new int[] { 33, 'a', (byte) -1, (byte) -1, (short) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', (int) (short) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "334974-14-14-1" + "'", str7.equals("334974-14-14-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "100A-1A0", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" \n", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("28a177a100a3a10", "X OS M", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "28a177a100a3a10" + "'", str3.equals("28a177a100a3a10"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "tnemnorivnE emitnuR ES )MT(avaJ", 32);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("X86_64HI!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaah");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                   MV revreS tiB-46 )MT(topStoH avaJ", (int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  MV revreS tiB-46 " + "'", str3.equals("                  MV revreS tiB-46 "));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444", (java.lang.CharSequence) "         :", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(32L, (long) 7, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.7d, 0.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("h", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h" + "'", str3.equals("h"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("100a-1a0", "24.80-b11", "x86_64hi");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("a", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk", (int) (byte) 1, 50);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/JavaVirtualMachines/jdk" + "'", str3.equals("Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("X86_64", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "10  10 hi! hi! 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "#################################################################################################", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaah", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Lib\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("  X86_64  ", "0.9", 50);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  X86_64  " + "'", str3.equals("  X86_64  "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                  MV revreS tiB-46 ", 177);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  MV revreS tiB-46 " + "'", str2.equals("                  MV revreS tiB-46 "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100 1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#################################################################################################", 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################################################################" + "'", str3.equals("#################################################################################################"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence[] charSequenceArray8 = new java.lang.CharSequence[] { "10", "", "10", "hi!", "hi!", "10" };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charSequenceArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01", charSequenceArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray8, '#', (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(charSequenceArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 213, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specificatio", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '#', 9, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("h", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0a10a1a1a1", "97.0", (int) ' ', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "097.0" + "'", str4.equals("097.0"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("\n", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "01 001 0", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("X OS M", "Library/Java/JavaVirtualMachines/jdk", "x86_64hi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("100#-1#0", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("US", "100#-1#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("a", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 28.0f + "'", float5 == 28.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 28.0f + "'", float7 == 28.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0a28.0" + "'", str9.equals("-1.0a28.0"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                  MV revreS tiB-46 ", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  MV revreS tiB-46 " + "'", str2.equals("                  MV revreS tiB-46 "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                           hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                           HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("                           HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("################h################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################h################" + "'", str1.equals("################h################"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X86_64", 1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64" + "'", str3.equals("X86_64"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("28a177a100a3a10", "", "http://java.oracle.com/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1a1a1a01a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a1a1a01a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("444444444444435.0", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444435.0" + "'", str3.equals("444444444444435.0"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("          M44 OS X", (-1), 213);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          M44 OS X" + "'", str3.equals("          M44 OS X"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                 e                                                  ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                 e                                                  " + "'", str2.equals("                                                 e                                                  "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        java.lang.String str8 = javaVersion5.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str10 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.4" + "'", str10.equals("1.4"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) " \n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 67 + "'", int2 == 67);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, charSequence1, 67);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("284177410043410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "284177410043410" + "'", str1.equals("284177410043410"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("X86_64HI!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                                \n                                                ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.7", "", "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/", "HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 100, 77);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "...le.com/", (java.lang.CharSequence) "100#10#0#100#0#1", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "################h################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 166.0f, (double) (short) 100, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444444444444444444444444444", "sun.awt.CGraphicsEnvironment", ".0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100a10a0a100a0a1", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Mac OS ...", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS " + "'", str2.equals("Mac OS "));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("100#-1#0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Oracle Corporation", "#################################################################################################hi", "Mac OS X               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporaton" + "'", str3.equals("Oracle Corporaton"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("01 001 0", '#');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2, 1.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.3", (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/", (java.lang.CharSequence) "0a10a1a1a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100 10 0 100 0 1", "01 001 0", "U");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Mac OS X               ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Mac OS X               ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("US");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 23, "HI!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI" + "'", str3.equals("HI!HI!HI!HI!HI!HI!HI!HI"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "#################################################################################################hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', (int) (byte) 1, 3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("noitacificepS enihcaM lautriV avaJ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  noitacificepS enihcaM lautriV avaJ" + "'", str2.equals("                                                                  noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Mac OS ...", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS ..." + "'", str2.equals("Mac OS ..."));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "  X86_64  ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.0a-1.0a0.0a100.0a97.0a18.0", (java.lang.CharSequence) "Oracle Corporaton");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("18.0a97.0a100.0a0.0a-1.0a0.0", "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "18.0a97.0a100.0a0.0a-1.0a0.0" + "'", str2.equals("18.0a97.0a100.0a0.0a-1.0a0.0"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "", (int) (short) 1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#10#0#100#0#1", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10  10 hi! hi! 10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10  10 HI! HI! 10" + "'", str1.equals("10  10 HI! HI! 10"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        long[] longArray3 = new long[] { 100, (-1), (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 33, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 10, (int) (byte) 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100#-1#0" + "'", str14.equals("100#-1#0"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (-1L), (long) 213);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 213L + "'", long3 == 213L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a33a10a-1a100a-1" + "'", str13.equals("0a33a10a-1a100a-1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("0 100 10", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 100 10" + "'", str2.equals("0 100 10"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100 10 0 100 0 1", "0100a-1a0", "X86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8XX 8X X 8XX X 8" + "'", str3.equals("8XX 8X X 8XX X 8"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Oracle Corporaton");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporaton" + "'", str1.equals("Oracle Corporaton"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.3", "0 33 10 -1 100 -1", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.7", "#################################################################################################hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "         :");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Oracle Corporaton", "", "x86_64hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                   100#10#0#100#0#1", 213);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("h", 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         h" + "'", str3.equals("         h"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " 001 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(":", "en", 166);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:" + "'", str3.equals(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Envi...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("USUSUSUSUSUSUSUSUSUSUSUSUSUSU...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSU..." + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSU..."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "100.0", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double[] doubleArray1 = new double[] { (short) 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 52, 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0" + "'", str3.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ".0_80-b15", (java.lang.CharSequence) "hi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_8", (java.lang.CharSequence) "0#33#10#-1#100#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "US", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.0", "33 97 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0" + "'", str2.equals("0.0"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X OS M", (int) (byte) 100, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaX OS M" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaX OS M"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0100a-1a0", (java.lang.CharSequence) "0 33 10 -1 100 -1", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "         h", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:" + "'", str2.equals(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("noitacificepS enihcaM lautriV avaJ", 2, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str3.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 10 0 100 0 1" + "'", str12.equals("100 10 0 100 0 1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a10a0a100a0a1" + "'", str14.equals("100a10a0a100a0a1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100 10 0 100 0 1" + "'", str16.equals("100 10 0 100 0 1"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 0 + "'", byte17 == (byte) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        short[] shortArray3 = new short[] { (short) 0, (short) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 100, (int) (short) 0);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0 100 10" + "'", str5.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.3", "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4');
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10", (java.lang.CharSequence[]) strArray6);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", 0);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("          M44 OS X", strArray15, strArray19);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("18.0a97.0a100.0a0.0a-1.0a0.0", strArray6, strArray19);
        int int23 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray19);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "M44 OS X" + "'", str8.equals("M44 OS X"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 18 + "'", int9 == 18);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "          M44 OS X" + "'", str21.equals("          M44 OS X"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "18.0a97.0a100.0a0.0a-1.0a0.0" + "'", str22.equals("18.0a97.0a100.0a0.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }
}

