import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:" + "'", str2.equals(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk...", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x86_64hi!", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "#################################################################################################", (int) (short) 1, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0100a-1a0", (java.lang.CharSequence) "x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01", "/moc.el...s/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01" + "'", str2.equals("01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "#############################################################################################Mc OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64HI", "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (int) (short) 444);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("X86_64HI", "10  10 HI! HI! 10");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 67, (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, (float) 3L, (float) 27);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 27.0f + "'", float3 == 27.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("h", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("#################################################################################################hi ", 77);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################hi " + "'", str2.equals("####################hi "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.", "44444441.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1." + "'", str2.equals("1."));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("    1.3hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    1.3hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) (byte) 10, (int) (byte) 1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b15", "", 33);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444", ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray4, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str10.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, 28.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("  X86_64  ", 177);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                         X86_64  " + "'", str2.equals("                                                                                                                                                                         X86_64  "));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 10, (int) (short) 0);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a" + "'", str14.equals("a"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) 10L, 213.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Documents/defects4j/tmp/run_randoop" + "'", str2.equals("/Documents/defects4j/tmp/run_randoop"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("          M44 OS X");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("44444444444444444444444444444444444444444444444444", "", "mixed mode");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("M44 OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10010.01010.0010.010010.0010.01", "100a-1a0", (int) (short) 1, 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1100a-1a010010.0010.01" + "'", str4.equals("1100a-1a010010.0010.01"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("333333333333333333333333333333333333333333333X OS Mac33333333333333333333333333333333333333333333");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "333333333333333333333333333333333333333333333X OS Mac33333333333333333333333333333333333333333333" + "'", str1.equals("333333333333333333333333333333333333333333333X OS Mac33333333333333333333333333333333333333333333"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                  MV revreS tiB-46 ", 213, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0.0", ".0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80-b15" + "'", str2.equals(".0_80-b15"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "  X86_64  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "-1.0#28.0", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10  10 hi! hi! 10", 67, "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Envir10  10 hi! hi! 10Java(TM) SE Runtime Envir" + "'", str3.equals("Java(TM) SE Runtime Envir10  10 hi! hi! 10Java(TM) SE Runtime Envir"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "0#10#1#1#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmode" + "'", str1.equals("mixedmode"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(177, 36, 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 177 + "'", int3 == 177);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/...", 36, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, (double) 166L, (double) 13);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "100 1", "100a10a0a100a0a1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                            0 100 10", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "0#100#10", "01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("noitacificepS enihcaM lautriV avaJ", (int) (short) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str3.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwawt", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt" + "'", str2.equals("sun.lwawt"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', 99, 27);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#10#0#100#0#1" + "'", str12.equals("100#10#0#100#0#1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 0 + "'", byte18 == (byte) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("100 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100" + "'", str1.equals("100"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("86_64hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "86_64hi" + "'", str1.equals("86_64hi"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("              X86_64               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              X86_64               " + "'", str1.equals("              X86_64               "));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 799);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                   ", (java.lang.CharSequence) "                           HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 166, (int) (short) 1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/", "#############################################################################################Mac OS ", "01                  ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/" + "'", str3.equals("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("33.0a52.0a-1.0a-1.0", "097.0", (int) '#');
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0.0a-1.0a0.0a100.0a97.0a18.0", (java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSU...", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "mixedmode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("44444441.4", "333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333", "0a33a10a-1a100a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444441.4" + "'", str3.equals("44444441.4"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "284177410043410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre10.0/Library/J100 10 0 100 0 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("44444444444444444444444444444444", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444444445E31d + "'", double2 == 4.444444444444445E31d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b114", (int) (short) 100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10  10 hi! hi! 10", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10  10 hi! hi! 10" + "'", str2.equals("10  10 hi! hi! 10"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 213, (int) (short) 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#10#0#100#0#1" + "'", str12.equals("100#10#0#100#0#1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0a33a10a-1a100a-1", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a33a10a-1a100a-1" + "'", str2.equals("0a33a10a-1a100a-1"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        float[][] floatArray0 = new float[][] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(floatArray0);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("X OS Mac", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X OS Mac" + "'", str3.equals("X OS Mac"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) (byte) 10, (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a33a10a-1a100a-1" + "'", str14.equals("0a33a10a-1a100a-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0a33a10a-1a100a-1" + "'", str16.equals("0a33a10a-1a100a-1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0#33#10#-1#100#-1" + "'", str18.equals("0#33#10#-1#100#-1"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("10", strArray4, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int11 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence[]) strArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 23 + "'", int11 == 23);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Maa OS X" + "'", str13.equals("Maa OS X"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "#######################", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("X86_64", "01X SO 44M!ihX SO 44M!ihX SO 44M01X SO 44MX SO 44M01", (int) (byte) 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "35.0", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("3397-1-1-1", "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "-1.0#28.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3397-1-1-1" + "'", str3.equals("3397-1-1-1"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("\n", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("              x86_64hi!", "10mixed modemixed mode10mixed modehi!mixed modehi!mixed mode10", 166);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                                                  noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS enihcaM lautriV avaJ" + "'", str1.equals("noitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime Envi...", (java.lang.CharSequence) "/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "U" + "'", str2.equals("U"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "              x86_64hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444444", "24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        double[] doubleArray6 = new double[] { 18, 97.0f, (short) 100, 0L, (short) -1, 0.0f };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "18.0a97.0a100.0a0.0a-1.0a0.0" + "'", str8.equals("18.0a97.0a100.0a0.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "18.0a97.0a100.0a0.0a-1.0a0.0" + "'", str10.equals("18.0a97.0a100.0a0.0a-1.0a0.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4');
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 28.0f + "'", float5 == 28.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 28.0f + "'", float7 == 28.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1.0428.0" + "'", str11.equals("-1.0428.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0 28.0" + "'", str14.equals("-1.0 28.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0 28.0" + "'", str16.equals("-1.0 28.0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/s...le.com/", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#############################################################################################Mac OS ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', (int) (byte) 1, (int) (short) 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 10, (int) (byte) 0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0a28.0" + "'", str6.equals("-1.0a28.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 28.0f + "'", float11 == 28.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                         /var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "x86_6", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', 100, (int) 'a');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("52a3a100a-1", "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52a3a100a-1" + "'", str2.equals("52a3a100a-1"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52a3a100a-1", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(33L, (long) 77, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 77L + "'", long3 == 77L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("-1.0a28.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0a28." + "'", str1.equals("-1.0a28."));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "-1.0#28.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("US                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US                              \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "X86_64HI!", (java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "              X86_64               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Mac OS ", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS " + "'", str2.equals("Mac OS "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("8XX 8X X 8XX X 8", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8 X 8XX X 8X 8XX" + "'", str2.equals("8 X 8XX X 8X 8XX"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "  X86_6   ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0 1.0", 0, "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0 1.0" + "'", str3.equals("-1.0 1.0"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "24.80-b114");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1.0#28.0", (java.lang.CharSequence) "                  100a10a0a100a0a1                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        double[] doubleArray1 = new double[] { (short) 100 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) (byte) 1, 177);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0 100 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA", ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-11");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 156 + "'", int1 == 156);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("04100410");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "04100410" + "'", str1.equals("04100410"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1.0#28.0", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "#################################################################################################hi", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "#################################################################################################hi" + "'", charSequence2.equals("#################################################################################################hi"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0#100#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        char[] charArray6 = new char[] { 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#10#1#1#1", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################" + "'", str2.equals("#################################################################################################"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("444444444444435.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444435.0" + "'", str1.equals("444444444444435.0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) -1, (byte) 100, (byte) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 0, (int) (short) 0);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 100, (int) (byte) 0);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte16 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte16 + "' != '" + (byte) 100 + "'", byte16 == (byte) 100);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0#28.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "##", (java.lang.CharSequence) "0a10a1a1a1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Virtual Machine Specificatio", (java.lang.CharSequence) "####################hi ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50837_1560277813");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50837_1560277813" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50837_1560277813"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("###############################################################################################################################################", (double) 166);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 166.0d + "'", double2 == 166.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10033!97!-1!-1!-1#33!97!-1!-1!-11033!97!-1!-1!-0.9", "JAVA VIRTUAL MACHINE SPECIFICATION", "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10033!97!-1!-1!-1#33!97!-1!-1!-11033!97!-1!-1!-0.9" + "'", str3.equals("10033!97!-1!-1!-1#33!97!-1!-1!-11033!97!-1!-1!-0.9"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#################################################################################################hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#################################################################################################hi!" + "'", str2.equals("#################################################################################################hi!"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("mixedmode", "#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixedmode" + "'", str2.equals("mixedmode"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporaton", 99, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporatonaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Oracle Corporatonaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/s...le.com/", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/s...le.com/" + "'", str2.equals("/Users/s...le.com/"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10033!97!-1!-1!-1#33!97!-1!-1!-11033!97!-1!-1!-0.9", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.awt.CGraphicsEnvironment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0a28.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                            H                                                                                    ", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80" + "'", str1.equals("0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                  100a10a0a100a0a1                  ", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                  100a10a0a10..." + "'", str2.equals("                  100a10a0a10..."));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("01                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "-1.0 28.0", "          M44 OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100A-1A0", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0    1.3hi!/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "M44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS X", (java.lang.CharSequence) "Mac OS ", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 0, 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 63 + "'", int3 == 63);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100#-1#0  ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(".0_80-b15", (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        long[] longArray3 = new long[] { 100, (-1), (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 33, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 10, (int) (byte) 10);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/...", "0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 1, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#33#10#-1#100#-1" + "'", str12.equals("0#33#10#-1#100#-1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "                                                \n                                                ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("01                  ...", "10033!97!-1!-1!-1#33!97!-1!-1!-11033!97!-1!-1!-0.9", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#33#10#-1#100#-1" + "'", str10.equals("0#33#10#-1#100#-1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("    1.3hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "              x86_64hi!", (java.lang.CharSequence) "97.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                   100#10#0#100#0#1", 27, "100a10a0a100a0a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                   100#10#0#100#0#1" + "'", str3.equals("                   100#10#0#100#0#1"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "usJava HotSpot(TM) 64-Bit Server VM", 177);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("3.41.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                                \n                                                ", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                \n                                                " + "'", str2.equals("                                                \n                                                "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmen" + "'", str1.equals("sun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "Java(TM) SE Runtime Environment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0", "28a177a100a3a10");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-11", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 48 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                                                            0 100 10", "", "1.041.04100.04100.040.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.001.041.04100.04100.040.0 1.041.04100.04100.040.011.041.04100.04100.040.001.041.04100.04100.040.001.041.04100.04100.040.0 1.041.04100.04100.040.011.041.04100.04100.040.001.041.04100.04100.040.0" + "'", str3.equals("1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.0 1.041.04100.04100.040.001.041.04100.04100.040.0 1.041.04100.04100.040.011.041.04100.04100.040.001.041.04100.04100.040.001.041.04100.04100.040.0 1.041.04100.04100.040.011.041.04100.04100.040.001.041.04100.04100.040.0"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a33a10a-1a100a-1" + "'", str11.equals("0a33a10a-1a100a-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a33a10a-1a100a-1" + "'", str13.equals("0a33a10a-1a100a-1"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10  10 hi! hi! 10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "100.0", (java.lang.CharSequence) "#################################################################################################hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("              x86_64hi!", "51.                                                                  noitacificepS enihcaM lautriV avaJ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "             x86_64hi!              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10  10 hi! hi! 10", (int) (byte) 10, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10  10 hi! hi! 10" + "'", str3.equals("10  10 hi! hi! 10"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("284177410043410", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104341004177428" + "'", str2.equals("104341004177428"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("x86_64", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x" + "'", str2.equals("x"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                   100#10#0#100#0#1", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        char[] charArray2 = new char[] { 'a' };
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a', 10, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ');
        java.lang.Class<?> wildcardClass10 = charArray2.getClass();
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("33.0a52.0a-1.0a-1.0", "097.0", (int) '#');
        java.lang.Class<?> wildcardClass15 = strArray14.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str17 = javaVersion16.toString();
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str19 = javaVersion18.toString();
        boolean boolean20 = javaVersion16.atLeast(javaVersion18);
        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion18);
        java.lang.Class<?> wildcardClass22 = javaVersion18.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        java.lang.Class<?> wildcardClass25 = javaVersion23.getClass();
        char[] charArray28 = new char[] { 'a' };
        boolean boolean29 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray28);
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join(charArray28, 'a', 10, (int) (short) 0);
        java.lang.String str35 = org.apache.commons.lang3.StringUtils.join(charArray28, ' ');
        java.lang.Class<?> wildcardClass36 = charArray28.getClass();
        java.lang.Class[] classArray38 = new java.lang.Class[5];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray39 = (java.lang.Class<?>[]) classArray38;
        wildcardClassArray39[0] = wildcardClass10;
        wildcardClassArray39[1] = wildcardClass15;
        wildcardClassArray39[2] = wildcardClass22;
        wildcardClassArray39[3] = wildcardClass25;
        wildcardClassArray39[4] = wildcardClass36;
        java.lang.String str50 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray39);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a" + "'", str9.equals("a"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.3" + "'", str17.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.3" + "'", str19.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(charArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "a" + "'", str35.equals("a"));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(classArray38);
        org.junit.Assert.assertNotNull(wildcardClassArray39);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "class [Cclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [C" + "'", str50.equals("class [Cclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [C"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaX OS M");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaX OS M\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1.0 1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 1.0" + "'", str1.equals("-1.0 1.0"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk18.0a97.0a100.0a0.0a-1.0a0.0", "97.0", (int) (byte) -1, 156);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97.0" + "'", str4.equals("97.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("ava HotSpot(TM) 64-Bit Server VM", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "####################hi ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-11", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "51.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0#10#1#1#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "Java HotSpot(TM) 64-Bit Server VM");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "####################hi ", 799);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 97, 9);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                \n                                                ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10  10 hi! hi! 10", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("         :");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"         :\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0#33#10#-1#100#-1", "       10  10 HI! HI! 10        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF-8", 36, "284177410043410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-82841774100434102841774100434102" + "'", str3.equals("UTF-82841774100434102841774100434102"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        float[] floatArray6 = new float[] { (-1.0f), (short) 0, 1.0f, 97L, (byte) 10, (byte) 0 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 9, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("////////////////////////////////", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "////////////////////////////////" + "'", str3.equals("////////////////////////////////"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "1.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "0a33a10a-1a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" 001 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("mv revres tib-46 )mt(topstoh avaj", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 27, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) (short) 100, (int) '#');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("100 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 1" + "'", str1.equals("100 1"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-82841774100434102841774100434102");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.2");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "33.0a52.0a-1.0a-1.0", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80-b15aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "97.0#3.0#1.0#100.0#0.0#0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("######################################################################################################################################################################", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "######################################################################################################################################################################" + "'", str3.equals("######################################################################################################################################################################"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, (float) 0L, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        float[] floatArray2 = new float[] { (short) -1, 28 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) (short) 100, 28);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 28.0f + "'", float4 == 28.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 28.0f + "'", float5 == 28.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 28.0f + "'", float7 == 28.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1.0 28.0" + "'", str13.equals("-1.0 28.0"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "us", (java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) -1, (byte) 100, (byte) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 0, (int) (short) 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "0 33 10 -1 100 -1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0 33 10 -1 100 -1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0.0a-1.0a0.0a100.0a97.0a18.0", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0a-1.0a0.0a100.0a97.0a18.0" + "'", str2.equals(".0a-1.0a0.0a100.0a97.0a18.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "    1.3hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        long[] longArray1 = new long[] { 10 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 97, (int) 'a');
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 4, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "////////////////////////////////", 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("0100a-1a0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("51.                                                                  noitacificepS enihcaM lautriV avaJ", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " avaJ" + "'", str2.equals(" avaJ"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', (int) '4', 18);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#################################################################################################hi ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "x86_64hi!", (java.lang.CharSequence) "                   100#10#0#100#0#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "X OS Mac");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "               10                ", charSequence1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0", "28a177a100a3a10");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " \n", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "US");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " \n" + "'", str5.equals(" \n"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a10" + "'", str7.equals("0a10"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "    1.3hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0#-1#100#0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, 799.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 799.0d + "'", double3 == 799.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-", "#################################################################################################hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) 50, 799.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 799.0d + "'", double3 == 799.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                           HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "S/JDK1.7.0_80.JDK18.0A97.0A100.0A0.0A-1.0A0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("                           HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                \n                                                ", "44444441.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                \n                                                " + "'", str2.equals("                                                \n                                                "));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                   MV revreS tiB-46 )MT(topStoH avaJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                   MV revreS tiB-46 )MT(topStoH avaJ\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0a10a1a1a1", "X86_64HI!");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "284177410043410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0100a-1a0", "x86_6", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "sun.lwawt.macosx.CPrinterJo");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.lwawt.macosx.CPrinterJo");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 10 0 100 0 1" + "'", str12.equals("100 10 0 100 0 1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mac OS ...", (java.lang.CharSequence) "              X86_64               ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0 28.0", "100 10 0 100 0 1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "334974-14-14-1", (java.lang.CharSequence) "51.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(28.0f, (float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str7 = javaVersion6.toString();
        java.lang.String str8 = javaVersion6.toString();
        boolean boolean9 = javaVersion3.atLeast(javaVersion6);
        boolean boolean10 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { 'a', ' ', ' ' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ', 100, (int) (byte) 100);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "              X86_64               ", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "aa a " + "'", str17.equals("aa a "));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                  MV revreS tiB-46 1010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                  mv revres tib-46 1010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010" + "'", str1.equals("                  mv revres tib-46 1010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("xxxxxxx10", 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(" 001 ", "-1.0428.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 001 " + "'", str2.equals(" 001 "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("01 001 0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_8");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_8" + "'", str3.equals("1.7.0_8"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", (java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                  MV revreS tiB-46 1010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 5, "100A-1A0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10100" + "'", str3.equals("10100"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "01                  ...", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "////////////////////////////////", (java.lang.CharSequence) "                                                                                                 ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Virtual Machine Specificatio", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-1.0a28.", "                   100#10#0#100#0#1", 63, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                   100#10#0#100#0#1" + "'", str4.equals("                   100#10#0#100#0#1"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("             x86_64hi!              ", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             x86_64hi!              " + "'", str2.equals("             x86_64hi!              "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 593 + "'", int1 == 593);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-11", (-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100a10a0a100a0a1", "xxxxxxx10", "M44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1.0#28.0", (int) (short) 0, "                                                                                                                                                                         X86_64  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#28.0" + "'", str3.equals("-1.0#28.0"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#################################################################################################hi", (java.lang.CharSequence) "                          10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                          u l   ch n     c f c    n                                ", "                                          u l   ch n     c f c    n                                ", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "UTF-82841774100434102841774100434102", (java.lang.CharSequence) "X OS M", 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Oracle Corporatonaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "M44 OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporatonaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("Oracle Corporatonaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "###############################################################################################################################################", (java.lang.CharSequence) "0 -1 100 0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "###############################################################################################################################################" + "'", charSequence2.equals("###############################################################################################################################################"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US                              ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 284177410043410L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.84177417E14f + "'", float2 == 2.84177417E14f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 32, (long) 4, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "                                   ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("UTF-8", "51.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4444444444435.0", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) '4', 0.0d, (double) 166.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 166.0d + "'", double3 == 166.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64hi!", "0.9", 213);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "x86_64hi!" + "'", str5.equals("x86_64hi!"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10033!97!-1!-1!-1#33!97!-1!-1!-11033!97!-1!-1!-1#33!97!-1!-1!-1033!97!-1!-1!-1#33!97!-1!-1!-110033!97!-1!-1!-1#33!97!-1!-1!-1033!97!-1!-1!-1#33!97!-1!-1!-11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "18.0a97.0a100.0a0.0a-1.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        char[] charArray5 = new char[] { 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 10, (int) (short) 0);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray5);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a" + "'", str14.equals("a"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "a" + "'", str16.equals("a"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n  \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", (java.lang.CharSequence) ".0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("ava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VM", "01                          ", "444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444", 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("ava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VMxava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444", (float) 63);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4444.0f + "'", float2 == 4444.0f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0100a-1a0", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0100a-1a0" + "'", str2.equals("0100a-1a0"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                   MV revreS tiB-46 )MT(topStoH avaJ", "0", 0, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0                 MV revreS tiB-46 )MT(topStoH avaJ" + "'", str4.equals("0                 MV revreS tiB-46 )MT(topStoH avaJ"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str4 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion3.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean10 = javaVersion1.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str13 = javaVersion12.toString();
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str15 = javaVersion14.toString();
        boolean boolean16 = javaVersion12.atLeast(javaVersion14);
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean18 = javaVersion11.atLeast(javaVersion14);
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion19);
        java.lang.String str21 = javaVersion19.toString();
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str23 = javaVersion22.toString();
        java.lang.String str24 = javaVersion22.toString();
        boolean boolean25 = javaVersion19.atLeast(javaVersion22);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        boolean boolean27 = javaVersion11.atLeast(javaVersion22);
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean29 = javaVersion11.atLeast(javaVersion28);
        boolean boolean30 = javaVersion1.atLeast(javaVersion28);
        java.lang.String str31 = javaVersion28.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.3" + "'", str13.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.3" + "'", str15.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.4" + "'", str21.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.4" + "'", str23.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.4" + "'", str24.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.8" + "'", str31.equals("1.8"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "         :", (java.lang.CharSequence) "sun.lwawt");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1.0 28.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0#33#10#-1#100#-1" + "'", str10.equals("0#33#10#-1#100#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0 33 10 -1 100 -1" + "'", str12.equals("0 33 10 -1 100 -1"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.8", "97.0a3.0a1.0a100.0a0.0a0.0334974-14-14-197.0a3.0a1.0a100.0a0.0a0.0", 177);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("          M44 OS X", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3397-1-1-1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "100 ", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        short[] shortArray3 = new short[] { (short) 0, (short) 100, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 0, (int) (byte) 1);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0 100 10" + "'", str5.equals("0 100 10"));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("\n", 0, "100#-1#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" 001 ", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001 " + "'", str2.equals(" 001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001  001 "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("noitacificepS enihcaM lautriV avaJ", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("33.0a52.0a-1.0a-1.0", "sun.awt.CGraphicsEnvironment", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                \n                                                ", "aaa", " 001 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                \n                                                " + "'", str3.equals("                                                \n                                                "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444444445E62d + "'", double2 == 4.444444444444445E62d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#10#1#1#1");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0#10#1#1#1" + "'", str4.equals("0#10#1#1#1"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11", "097.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.3", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt", "a# # ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", 166);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt" + "'", str4.equals("sun.lwawt"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk18.0a97.0a100.0a0.0a-1.0a0.0", (java.lang.CharSequence) "0                 MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "US                              ", (java.lang.CharSequence) "444444444444444444444444444444414444444444444444444444444444444.444444444444444444444444444444474444444444444444444444444444444", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a# # ", (java.lang.CharSequence) "86_64hi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                          u l   ch n     c f c    n                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', 63, 36);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0a10a1a1a1", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10a1a1a1        " + "'", str2.equals("0a10a1a1a1        "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 27, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("3.41.01", "0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80", (int) 'a', 593);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3.41.010_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80" + "'", str4.equals("3.41.010_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "mixed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_6", (java.lang.CharSequence) " \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n  \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) ' ', (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7000000476837158d + "'", double3 == 1.7000000476837158d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/moc.el...s/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/moc.el...s/sresU/" + "'", str2.equals("/moc.el...s/sresU/"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#################################################################################################", "");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 100, (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        long[] longArray3 = new long[] { 100, (-1), (byte) 0 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7", "97.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        short[] shortArray0 = new short[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 5, 4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 99, 13);
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        short[] shortArray1 = new short[] { (byte) 10 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (-1), 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str7 = javaVersion6.toString();
        java.lang.String str8 = javaVersion6.toString();
        boolean boolean9 = javaVersion3.atLeast(javaVersion6);
        boolean boolean10 = javaVersion1.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean13 = javaVersion11.atLeast(javaVersion12);
        boolean boolean14 = javaVersion6.atLeast(javaVersion11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.4" + "'", str5.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.4" + "'", str8.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_8", 97, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, 28.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("01                          ", (int) '4', "3397-1-1-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3397-1-1-13301                          3397-1-1-133" + "'", str3.equals("3397-1-1-13301                          3397-1-1-133"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("33 97 -1 -1 -1");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", '4');
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', 36, 33);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 63, (double) 166.0f, (double) 77);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 63.0d + "'", double3 == 63.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 10, (byte) 0, (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 100, (int) (byte) 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "Maa OS X");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Maa OS X");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100 10 0 100 0 1" + "'", str12.equals("100 10 0 100 0 1"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 0 + "'", byte13 == (byte) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444444444444444444444444444", "                                                \n                                                ", 36, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4                                                \n                                                " + "'", str4.equals("4                                                \n                                                "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "usJava HotSpot(TM) 64-Bit Server VM", "100 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "33 97 -1 -1 -1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "8XX 8X X 8XX X 8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaJava Virtual Machine Specificationaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Maa OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Maa OS X" + "'", str1.equals("Maa OS X"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "xxxxxxx10", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("097.0SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97.0SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#10#0#100#0#1", (java.lang.CharSequence) "usJava HotSpot(TM) 64-Bit Server VM", 156);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.awt.CGraphicsEnvironment", (int) '#', "X86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86sun.awt.CGraphicsEnvironmentX86_" + "'", str3.equals("X86sun.awt.CGraphicsEnvironmentX86_"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("X86_64", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X86_64" + "'", str2.equals("X86_64"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4                                                \n                                                ", (java.lang.CharSequence) "                                          u l   ch n     c f c    n                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("33 97 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Java(TM) SE Runtime Environment", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("US                              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("               10                ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               10                " + "'", str2.equals("               10                "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "                                                                                            h                                                                                    ", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("33 97 -1 -1 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "33 97 -1 -1 -1" + "'", str1.equals("33 97 -1 -1 -1"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) " \n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        double[] doubleArray4 = new double[] { 33L, '4', (-1), (-1L) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", "sun.lwawt.macosx.LWCToolkit", (int) '#');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10M44 OS XM44 OS X10M44 OS Xhi!M44 OS Xhi!M44 OS X10", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 799, (long) 67, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 799L + "'", long3 == 799L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("097.0", "M44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS XM44 OS ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "097.0" + "'", str2.equals("097.0"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 0, (int) (short) 0);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "X86_64HI!", (java.lang.CharSequence) "444444444444435.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("0#100#10", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#10" + "'", str2.equals("0#100#10"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("U", 2, "3397-1-1-13301                          3397-1-1-133");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "U3" + "'", str3.equals("U3"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str3.equals("ibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "sun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                   ", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(52.0f, (float) 213, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-11", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("#", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 77, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "         :");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("24.80-b114", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b114" + "'", str2.equals("24.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b114"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100A-1A0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "#################################################################################################", "-1.0 1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                  MV revreS tiB-46 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        int[] intArray5 = new int[] { 33, 'a', (byte) -1, (byte) -1, (short) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', 100, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "334974-14-14-1" + "'", str7.equals("334974-14-14-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                                                                  noitacificepS enihcaM lautriV avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.07.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0428.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                         X86_64  ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("100334974-14-14-1#334974-14-14-110334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-1100334974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-", "0.9", (int) 'a', 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.934974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-" + "'", str4.equals("10.934974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "097.0SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        char[] charArray6 = new char[] { 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 10, (int) (short) 0);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.3", charArray6);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/", charArray6);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 33, 3);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.8", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOPHIE/LIBRARY/JAx86_6XTENSIONS:/USR/LIB/JAVA", "0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11sun.lwawt.macosx.CPrinterJobsun.lwawt.macosx.CPrinterJob24.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b1124.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("tnemnorivnE emitnuR ES )MT(avaJ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str2.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(".0_80-b15", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15" + "'", str2.equals(".0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15.0_80-b15"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.", "97.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(77L, (long) 18, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(":en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:en:", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        int[] intArray3 = new int[] { 97, 0, 28 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 166, (int) (byte) -1);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 97 + "'", int8 == 97);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("a", "4444444444444444444444444444", "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Documents/defects4j/tmp/run_randoop.pl_50837_1560277813/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        char[] charArray3 = new char[] {};
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64hi", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "97.0", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1100a-1a010010.0010.01", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#-1#100#0", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                  100a10a0a100a0a1                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.934974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-", 5, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.934974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-" + "'", str3.equals("10.934974-14-14-1#334974-14-14-10334974-14-14-1#334974-14-14-"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        int[] intArray6 = new int[] { (byte) 0, 33, (short) 10, (short) -1, (byte) 100, (-1) };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) (byte) 10, (int) (byte) 1);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) 'a', 28);
        int int19 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 33 10 -1 100 -1" + "'", str8.equals("0 33 10 -1 100 -1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 17, 77);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        char[] charArray5 = new char[] { 'a', ' ', ' ' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', (int) 'a', 10);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "a# # " + "'", str9.equals("a# # "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("35.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35.0" + "'", str1.equals("35.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "24.80-b114", (java.lang.CharSequence) "                   MV revreS tiB-46 )MT(topStoH avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("097.0SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/", "class [Cclass [Ljava.lang.String;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "097.0SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/" + "'", str2.equals("097.0SUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSU/"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("    1.3hi!", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!" + "'", str2.equals("    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!    1.3hi!"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("97.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.097.0", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#######################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 63);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############################################################" + "'", str2.equals("###############################################################"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 100, (byte) -1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', (int) (byte) 0, 3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a100a-1" + "'", str9.equals("1a100a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1a100a-1" + "'", str11.equals("1a100a-1"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                  MV revreS tiB-46 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                  MV revreS tiB-46 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b11424.80-b114", "sun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#######################", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("104341004177428", 1, "mv revres tib-46 )mt(topstoh avaj");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "104341004177428" + "'", str3.equals("104341004177428"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Library/Java/JavaVirtualMachines/jdk" + "'", str1.equals("Library/Java/JavaVirtualMachines/jdk"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(4.444444444444445E62d, (double) 7.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "1100a-1a010010.0010.01", "Maa OS X");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "3397-1-1-13301                          3397-1-1-133", charSequence1, 177);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 444 + "'", int2 == 444);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("097.0", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "097.0" + "'", str2.equals("097.0"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "U", (java.lang.CharSequence) "0a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "4444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                            H                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

