import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test001");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        java.lang.String str14 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0:00:00.000" + "'", str14.equals("0:00:00.000"));
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        stopWatch0.split();
        long long9 = stopWatch0.getSplitTime();
        java.lang.String str10 = stopWatch0.toString();
        stopWatch0.split();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test003");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.reset();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.reset();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.reset();
//        try {
//            java.lang.String str14 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        long long2 = stopWatch0.getTime();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        stopWatch0.stop();
        stopWatch0.reset();
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toSplitString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test010");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        long long11 = stopWatch0.getSplitTime();
//        long long12 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.reset();
        long long3 = stopWatch0.getTime();
        try {
            java.lang.String str4 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        long long2 = stopWatch0.getTime();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.reset();
        try {
            long long8 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.reset();
        long long7 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.unsplit();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test018");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        long long12 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.unsplit();
        java.lang.String str10 = stopWatch0.toString();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.split();
        stopWatch0.split();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test020");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.004" + "'", str9.equals("0:00:00.004"));
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test021");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long11 = stopWatch0.getSplitTime();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        try {
//            java.lang.String str14 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test022");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass15 = stopWatch0.getClass();
//        java.lang.String str16 = stopWatch0.toString();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.001" + "'", str13.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0:00:00.002" + "'", str16.equals("0:00:00.002"));
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test023");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        stopWatch0.split();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test024");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.reset();
//        java.lang.String str10 = stopWatch0.toString();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test025");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        java.lang.String str6 = stopWatch0.toString();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        stopWatch0.reset();
        long long5 = stopWatch0.getTime();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test027");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.005" + "'", str7.equals("0:00:00.005"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            java.lang.String str10 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test029");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.stop();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        long long6 = stopWatch0.getTime();
        try {
            java.lang.String str7 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test031");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        long long8 = stopWatch0.getTime();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        long long8 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        java.lang.String str10 = stopWatch0.toString();
        stopWatch0.stop();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.split();
        java.lang.String str4 = stopWatch0.toSplitString();
        long long5 = stopWatch0.getTime();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test035");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test036");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        java.lang.String str12 = stopWatch0.toSplitString();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test037");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        long long12 = stopWatch0.getTime();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.stop();
        stopWatch0.reset();
        try {
            long long6 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test041");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        long long4 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        stopWatch0.stop();
//        java.lang.String str9 = stopWatch0.toString();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test042");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test043");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.suspend();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        long long9 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        java.lang.String str11 = stopWatch0.toSplitString();
        java.lang.String str12 = stopWatch0.toSplitString();
        long long13 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        long long5 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        long long10 = stopWatch0.getTime();
        long long11 = stopWatch0.getTime();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test049");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.002" + "'", str10.equals("0:00:00.002"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test050");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.reset();
//        long long9 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test051");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test052");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        stopWatch0.unsplit();
//        long long12 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.008" + "'", str7.equals("0:00:00.008"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.009" + "'", str9.equals("0:00:00.009"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.009" + "'", str10.equals("0:00:00.009"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1560263895568L) + "'", long12 == (-1560263895568L));
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test053");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getSplitTime();
//        long long8 = stopWatch0.getSplitTime();
//        long long9 = stopWatch0.getSplitTime();
//        java.lang.String str10 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.stop();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.unsplit();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test056");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            long long13 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        long long2 = stopWatch0.getTime();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.stop();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test061");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        try {
//            java.lang.String str13 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.suspend();
        stopWatch0.stop();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test064");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.stop();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.unsplit();
        stopWatch0.suspend();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            long long12 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test066");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        long long6 = stopWatch0.getTime();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.reset();
        long long9 = stopWatch0.getTime();
        stopWatch0.reset();
        long long11 = stopWatch0.getTime();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        try {
            java.lang.String str5 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        long long3 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test075");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        long long15 = stopWatch0.getTime();
//        long long16 = stopWatch0.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.002" + "'", str13.equals("0:00:00.002"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 3L + "'", long15 == 3L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3L + "'", long16 == 3L);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test076");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        stopWatch0.reset();
//        java.lang.String str16 = stopWatch0.toString();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.001" + "'", str13.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0:00:00.000" + "'", str16.equals("0:00:00.000"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        try {
            long long7 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        long long6 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        try {
            java.lang.String str8 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test079");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        java.lang.String str12 = stopWatch0.toString();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.002" + "'", str8.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.003" + "'", str10.equals("0:00:00.003"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.003" + "'", str12.equals("0:00:00.003"));
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test080");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test081");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.resume();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        long long10 = stopWatch0.getSplitTime();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.stop();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.014" + "'", str8.equals("0:00:00.014"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 15L + "'", long11 == 15L);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test083");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.suspend();
        java.lang.String str7 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test085");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        java.lang.String str5 = stopWatch0.toString();
        long long6 = stopWatch0.getTime();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test087");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.start();
        try {
            java.lang.String str9 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test089");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        long long11 = stopWatch0.getTime();
//        java.lang.String str12 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        long long14 = stopWatch0.getTime();
//        long long15 = stopWatch0.getTime();
//        stopWatch0.stop();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2L + "'", long15 == 2L);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test090");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.stop();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.String str8 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        try {
            long long5 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.suspend();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        try {
            long long7 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.unsplit();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.String str16 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0:00:00.000" + "'", str16.equals("0:00:00.000"));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test096");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test098");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        long long7 = stopWatch0.getSplitTime();
        stopWatch0.unsplit();
        stopWatch0.split();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test102");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test106");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        try {
            long long10 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.reset();
        long long9 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.String str11 = stopWatch0.toString();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test112");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.suspend();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        java.lang.String str10 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.reset();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test116");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        java.lang.String str12 = stopWatch0.toString();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test117");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.String str12 = stopWatch0.toString();
//        java.lang.String str13 = stopWatch0.toString();
//        long long14 = stopWatch0.getSplitTime();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.002" + "'", str13.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test118");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test120");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        stopWatch0.split();
//        long long9 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.stop();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        java.lang.String str10 = stopWatch0.toString();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test122");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        java.lang.String str8 = stopWatch0.toString();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-433406:-38:-17.03" + "'", str8.equals("-433406:-38:-17.03"));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.reset();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test125");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long14 = stopWatch0.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.unsplit();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test127");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        java.lang.String str9 = stopWatch0.toString();
        long long10 = stopWatch0.getSplitTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.suspend();
        java.lang.String str7 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        try {
            java.lang.String str9 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test131");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        long long9 = stopWatch0.getTime();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        long long2 = stopWatch0.getTime();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        stopWatch0.start();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.split();
        stopWatch0.unsplit();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test134");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.resume();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        long long5 = stopWatch0.getSplitTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test139");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        long long9 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test140");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass14 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test141");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12L + "'", long8 == 12L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.012" + "'", str9.equals("0:00:00.012"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.012" + "'", str10.equals("0:00:00.012"));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.stop();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        try {
            java.lang.String str8 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        try {
            long long8 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        stopWatch0.split();
        long long9 = stopWatch0.getSplitTime();
        java.lang.String str10 = stopWatch0.toString();
        stopWatch0.unsplit();
        long long12 = stopWatch0.getTime();
        stopWatch0.reset();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test146");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.String str7 = stopWatch0.toString();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.008" + "'", str7.equals("0:00:00.008"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 8L + "'", long8 == 8L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        long long9 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        java.lang.String str12 = stopWatch0.toSplitString();
        java.lang.String str13 = stopWatch0.toString();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.000" + "'", str13.equals("0:00:00.000"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test149");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.String str5 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test150");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        java.lang.String str10 = stopWatch0.toString();
        stopWatch0.start();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.split();
        stopWatch0.stop();
        long long10 = stopWatch0.getSplitTime();
        stopWatch0.unsplit();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test153");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.reset();
//        try {
//            java.lang.String str11 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test154");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        stopWatch0.start();
//        stopWatch0.split();
//        java.lang.String str4 = stopWatch0.toSplitString();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test155");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        long long4 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test156");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        stopWatch0.start();
//        java.lang.String str3 = stopWatch0.toString();
//        long long4 = stopWatch0.getTime();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        long long8 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        long long8 = stopWatch0.getTime();
        stopWatch0.stop();
        long long10 = stopWatch0.getTime();
        long long11 = stopWatch0.getSplitTime();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        stopWatch0.unsplit();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test158");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.reset();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test159");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long4 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        java.lang.String str7 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        long long8 = stopWatch0.getTime();
        long long9 = stopWatch0.getTime();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        stopWatch0.stop();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        try {
            java.lang.String str5 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.suspend();
        long long5 = stopWatch0.getTime();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        try {
            java.lang.String str8 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.reset();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test168");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.String str3 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        long long9 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test169");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.split();
//        java.lang.String str13 = stopWatch0.toSplitString();
//        stopWatch0.stop();
//        java.lang.String str15 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.007" + "'", str9.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7L + "'", long10 == 7L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.008" + "'", str13.equals("0:00:00.008"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0:00:00.008" + "'", str15.equals("0:00:00.008"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        java.lang.String str5 = stopWatch0.toString();
        long long6 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            java.lang.String str9 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        long long9 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        java.lang.String str12 = stopWatch0.toSplitString();
        java.lang.String str13 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.000" + "'", str13.equals("0:00:00.000"));
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test173");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.stop();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.split();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getTime();
        long long8 = stopWatch0.getTime();
        long long9 = stopWatch0.getSplitTime();
        java.lang.String str10 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test176");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.stop();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.unsplit();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        long long11 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test180");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.stop();
//        long long13 = stopWatch0.getSplitTime();
//        long long14 = stopWatch0.getTime();
//        java.lang.String str15 = stopWatch0.toString();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 6L + "'", long11 == 6L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 7L + "'", long14 == 7L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0:00:00.007" + "'", str15.equals("0:00:00.007"));
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test181");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test182");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test183");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.stop();
//        long long13 = stopWatch0.getSplitTime();
//        long long14 = stopWatch0.getSplitTime();
//        long long15 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10L + "'", long15 == 10L);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test184");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        long long12 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        long long6 = stopWatch0.getTime();
        long long7 = stopWatch0.getTime();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        java.lang.String str7 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        long long8 = stopWatch0.getTime();
        stopWatch0.reset();
        try {
            long long10 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        long long9 = stopWatch0.getTime();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test190");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.resume();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        long long9 = stopWatch0.getSplitTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.reset();
        java.lang.String str12 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.resume();
        long long9 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.unsplit();
        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getSplitTime();
        long long8 = stopWatch0.getSplitTime();
        long long9 = stopWatch0.getSplitTime();
        java.lang.String str10 = stopWatch0.toSplitString();
        java.lang.String str11 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        long long4 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            java.lang.String str7 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test198");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.reset();
//        long long12 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getTime();
        long long8 = stopWatch0.getTime();
        java.lang.String str9 = stopWatch0.toSplitString();
        long long10 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        long long6 = stopWatch0.getTime();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test201");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test202");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.split();
//        long long6 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9L + "'", long6 == 9L);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test203");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        long long14 = stopWatch0.getTime();
//        try {
//            long long15 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.002" + "'", str10.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.002" + "'", str13.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getTime();
        long long8 = stopWatch0.getTime();
        long long9 = stopWatch0.getSplitTime();
        stopWatch0.unsplit();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test205");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        java.lang.String str5 = stopWatch0.toString();
//        java.lang.String str6 = stopWatch0.toString();
//        long long7 = stopWatch0.getTime();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test206");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.reset();
//        try {
//            java.lang.String str13 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.suspend();
        java.lang.String str8 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.String str10 = stopWatch0.toString();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.suspend();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        long long8 = stopWatch0.getTime();
        java.lang.String str9 = stopWatch0.toString();
        stopWatch0.split();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.reset();
        long long9 = stopWatch0.getTime();
        java.lang.String str10 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test210");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.stop();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.009" + "'", str9.equals("0:00:00.009"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.010" + "'", str12.equals("0:00:00.010"));
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test212");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.stop();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            long long8 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        java.lang.String str6 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        long long8 = stopWatch0.getSplitTime();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test217");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toString();
//        java.lang.String str11 = stopWatch0.toString();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test218");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        long long7 = stopWatch0.getSplitTime();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        long long5 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test221");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        long long11 = stopWatch0.getTime();
//        java.lang.String str12 = stopWatch0.toString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            java.lang.String str8 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        stopWatch0.stop();
        stopWatch0.reset();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test224");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        long long4 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        java.lang.String str5 = stopWatch0.toString();
        long long6 = stopWatch0.getTime();
        try {
            long long7 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        java.lang.String str7 = stopWatch0.toString();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test227");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long9 = stopWatch0.getSplitTime();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toString();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test228");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.resume();
//        long long13 = stopWatch0.getSplitTime();
//        java.lang.String str14 = stopWatch0.toSplitString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1560263899081L) + "'", long13 == (-1560263899081L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-433406:-38:-19.19" + "'", str14.equals("-433406:-38:-19.19"));
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test229");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long10 = stopWatch0.getTime();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test230");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.reset();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 11L + "'", long9 == 11L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test231");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        java.lang.String str14 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0:00:00.003" + "'", str14.equals("0:00:00.003"));
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test232");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.stop();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test234");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        try {
            long long2 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test236");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.suspend();
        long long6 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test239");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        long long4 = stopWatch0.getTime();
//        stopWatch0.reset();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test240");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.stop();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.007" + "'", str7.equals("0:00:00.007"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.007" + "'", str11.equals("0:00:00.007"));
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.reset();
        long long9 = stopWatch0.getTime();
        stopWatch0.reset();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        java.lang.String str9 = stopWatch0.toString();
        stopWatch0.stop();
        try {
            long long11 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test246");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        java.lang.String str11 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            long long13 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test247");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.String str3 = stopWatch0.toString();
//        stopWatch0.split();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test249");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        long long11 = stopWatch0.getSplitTime();
//        long long12 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long15 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2L + "'", long15 == 2L);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test250");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        long long11 = stopWatch0.getSplitTime();
//        long long12 = stopWatch0.getSplitTime();
//        stopWatch0.split();
//        stopWatch0.split();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test252");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        long long10 = stopWatch0.getSplitTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test253");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        stopWatch0.resume();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        try {
//            java.lang.String str13 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.String str7 = stopWatch0.toString();
        java.lang.String str8 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        java.lang.String str13 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.000" + "'", str13.equals("0:00:00.000"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.stop();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test257");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.reset();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.String str8 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test259");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.String str3 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test260");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.reset();
//        try {
//            java.lang.String str13 = stopWatch0.toSplitString();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test261");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.stop();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test262");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test264");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        java.lang.String str6 = stopWatch0.toString();
//        java.lang.String str7 = stopWatch0.toString();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.suspend();
        long long9 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        long long9 = stopWatch0.getTime();
        long long10 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test268");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9L + "'", long7 == 9L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.000" + "'", str13.equals("0:00:00.000"));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test269");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        long long14 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        java.lang.String str16 = stopWatch0.toString();
//        java.lang.String str17 = stopWatch0.toString();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.003" + "'", str10.equals("0:00:00.003"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 8L + "'", long11 == 8L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.010" + "'", str13.equals("0:00:00.010"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 11L + "'", long14 == 11L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0:00:00.011" + "'", str16.equals("0:00:00.011"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0:00:00.011" + "'", str17.equals("0:00:00.011"));
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test270");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        java.lang.String str12 = stopWatch0.toString();
//        java.lang.String str13 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.002" + "'", str13.equals("0:00:00.002"));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test272");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.002" + "'", str9.equals("0:00:00.002"));
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getTime();
        long long8 = stopWatch0.getTime();
        java.lang.String str9 = stopWatch0.toSplitString();
        java.lang.String str10 = stopWatch0.toSplitString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        long long3 = stopWatch0.getTime();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        try {
            long long7 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test275");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long13 = stopWatch0.getTime();
//        stopWatch0.split();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.reset();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test277");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        java.lang.String str7 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.suspend();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.split();
        long long13 = stopWatch0.getSplitTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        try {
            long long8 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.String str9 = stopWatch0.toString();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        java.lang.String str8 = stopWatch0.toString();
        stopWatch0.unsplit();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.reset();
        long long3 = stopWatch0.getTime();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        java.lang.String str7 = stopWatch0.toString();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.stop();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test289");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test290");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        long long8 = stopWatch0.getTime();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test291");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.stop();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test293");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        stopWatch0.reset();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.unsplit();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test296");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.008" + "'", str10.equals("0:00:00.008"));
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test297");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        long long14 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        java.lang.String str16 = stopWatch0.toString();
//        long long17 = stopWatch0.getTime();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.003" + "'", str13.equals("0:00:00.003"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3L + "'", long14 == 3L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0:00:00.004" + "'", str16.equals("0:00:00.004"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4L + "'", long17 == 4L);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test298");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long11 = stopWatch0.getSplitTime();
//        stopWatch0.stop();
//        long long13 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        stopWatch0.unsplit();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test300");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.split();
        long long11 = stopWatch0.getTime();
        stopWatch0.stop();
        long long13 = stopWatch0.getSplitTime();
        long long14 = stopWatch0.getTime();
        java.lang.String str15 = stopWatch0.toString();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0:00:00.000" + "'", str15.equals("0:00:00.000"));
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test303");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        java.lang.String str8 = stopWatch0.toSplitString();
//        stopWatch0.split();
//        java.lang.String str10 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.007" + "'", str7.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.007" + "'", str8.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.008" + "'", str10.equals("0:00:00.008"));
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test305");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test307");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        stopWatch0.resume();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.reset();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test308");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.unsplit();
//        java.lang.String str11 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test309");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.reset();
//        long long13 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.002" + "'", str9.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2L + "'", long10 == 2L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test310");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.String str12 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.unsplit();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
        long long14 = stopWatch0.getTime();
        try {
            long long15 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.start();
        long long8 = stopWatch0.getTime();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            long long6 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test315");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.stop();
//        java.lang.String str10 = stopWatch0.toString();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.002" + "'", str10.equals("0:00:00.002"));
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test316");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        java.lang.String str5 = stopWatch0.toString();
//        java.lang.String str6 = stopWatch0.toString();
//        long long7 = stopWatch0.getTime();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.011" + "'", str5.equals("0:00:00.011"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.011" + "'", str6.equals("0:00:00.011"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 11L + "'", long7 == 11L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.011" + "'", str8.equals("0:00:00.011"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.011" + "'", str9.equals("0:00:00.011"));
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test317");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        long long10 = stopWatch0.getSplitTime();
//        java.lang.String str11 = stopWatch0.toString();
//        java.lang.String str12 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test319");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        long long9 = stopWatch0.getTime();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        long long4 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        stopWatch0.resume();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getSplitTime();
        stopWatch0.unsplit();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        long long8 = stopWatch0.getTime();
        java.lang.String str9 = stopWatch0.toString();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        long long2 = stopWatch0.getTime();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test325");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test327");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toString();
//        java.lang.String str12 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        try {
//            long long14 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.002" + "'", str12.equals("0:00:00.002"));
//    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test328");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long6 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        stopWatch0.suspend();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.unsplit();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        java.lang.String str7 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test333");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        java.lang.String str6 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        long long8 = stopWatch0.getSplitTime();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.unsplit();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        stopWatch0.suspend();
        stopWatch0.stop();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.stop();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        long long11 = stopWatch0.getTime();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test337");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.stop();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.reset();
//        long long13 = stopWatch0.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        long long8 = stopWatch0.getTime();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test339");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6L + "'", long6 == 6L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test340");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.reset();
//        java.lang.String str10 = stopWatch0.toString();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        long long4 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        java.lang.String str7 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.String str9 = stopWatch0.toString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.stop();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test345");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        java.lang.String str8 = stopWatch0.toString();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test347");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        java.lang.String str7 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test348");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        java.lang.String str9 = stopWatch0.toString();
        stopWatch0.resume();
        long long11 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.stop();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test352");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.reset();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.start();
//        try {
//            long long8 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        long long8 = stopWatch0.getTime();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        long long7 = stopWatch0.getSplitTime();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.suspend();
        stopWatch0.resume();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        long long2 = stopWatch0.getTime();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.start();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test358");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.reset();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test359");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
//        java.lang.String str3 = stopWatch0.toString();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6L + "'", long5 == 6L);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test360");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 26L + "'", long5 == 26L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 27L + "'", long6 == 27L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test361");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        long long4 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.split();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test363");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.suspend();
//        long long12 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass15 = stopWatch0.getClass();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.002" + "'", str9.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.004" + "'", str10.equals("0:00:00.004"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.split();
        stopWatch0.unsplit();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test366");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.split();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.unsplit();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test369");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.stop();
//        long long6 = stopWatch0.getTime();
//        long long7 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        java.lang.String str9 = stopWatch0.toString();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test371");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        long long8 = stopWatch0.getTime();
//        try {
//            long long9 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test373");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.resume();
//        stopWatch0.suspend();
//        java.lang.String str13 = stopWatch0.toString();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.001" + "'", str13.equals("0:00:00.001"));
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.suspend();
        long long6 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        long long9 = stopWatch0.getTime();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        stopWatch0.reset();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        try {
            java.lang.String str4 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test377");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.start();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.String str8 = stopWatch0.toString();
        stopWatch0.reset();
        java.lang.String str10 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        java.lang.String str12 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        long long5 = stopWatch0.getTime();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        long long8 = stopWatch0.getTime();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test382");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.stop();
//        long long10 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        long long5 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        long long8 = stopWatch0.getTime();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.suspend();
        java.lang.String str8 = stopWatch0.toString();
        stopWatch0.resume();
        java.lang.String str10 = stopWatch0.toString();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        long long6 = stopWatch0.getTime();
        java.lang.String str7 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.split();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test386");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.split();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        stopWatch0.suspend();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        java.lang.String str7 = stopWatch0.toString();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.suspend();
        stopWatch0.reset();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test389");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test390");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        stopWatch0.start();
//        java.lang.String str3 = stopWatch0.toString();
//        long long4 = stopWatch0.getTime();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.split();
//        long long7 = stopWatch0.getSplitTime();
//        long long8 = stopWatch0.getSplitTime();
//        long long9 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        stopWatch0.start();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.resume();
        stopWatch0.split();
        stopWatch0.unsplit();
        java.lang.String str10 = stopWatch0.toString();
        java.lang.String str11 = stopWatch0.toString();
        stopWatch0.split();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        long long5 = stopWatch0.getSplitTime();
        long long6 = stopWatch0.getSplitTime();
        long long7 = stopWatch0.getTime();
        stopWatch0.unsplit();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        long long7 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        stopWatch0.reset();
        long long13 = stopWatch0.getTime();
        java.lang.String str14 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0:00:00.000" + "'", str14.equals("0:00:00.000"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        long long10 = stopWatch0.getSplitTime();
        stopWatch0.resume();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test396");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        try {
//            long long14 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test397");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.005" + "'", str7.equals("0:00:00.005"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test398");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.split();
//        long long13 = stopWatch0.getSplitTime();
//        long long14 = stopWatch0.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test399");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test400");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.resume();
//        long long13 = stopWatch0.getSplitTime();
//        java.lang.String str14 = stopWatch0.toSplitString();
//        java.lang.Class<?> wildcardClass15 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1560263903836L) + "'", long13 == (-1560263903836L));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-433406:-38:-23.64" + "'", str14.equals("-433406:-38:-23.64"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.start();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test403");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        java.lang.String str10 = stopWatch0.toString();
//        long long11 = stopWatch0.getTime();
//        long long12 = stopWatch0.getTime();
//        java.lang.String str13 = stopWatch0.toString();
//        long long14 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        java.lang.String str17 = stopWatch0.toString();
//        java.lang.String str18 = stopWatch0.toSplitString();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0:00:00.001" + "'", str13.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0:00:00.001" + "'", str17.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0:00:00.001" + "'", str18.equals("0:00:00.001"));
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        stopWatch0.reset();
        long long4 = stopWatch0.getTime();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.suspend();
        try {
            java.lang.String str7 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test406");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        long long8 = stopWatch0.getTime();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test407");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test408");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.reset();
//        long long13 = stopWatch0.getTime();
//        long long14 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        long long6 = stopWatch0.getTime();
        java.lang.String str7 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        java.lang.String str9 = stopWatch0.toString();
        long long10 = stopWatch0.getSplitTime();
        stopWatch0.split();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test410");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getSplitTime();
//        long long11 = stopWatch0.getSplitTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.resume();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        long long9 = stopWatch0.getSplitTime();
        stopWatch0.stop();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test413");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        long long7 = stopWatch0.getTime();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        try {
            stopWatch0.stop();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test416");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        stopWatch0.stop();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be reset before being restarted. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.split();
        java.lang.String str6 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        long long8 = stopWatch0.getSplitTime();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str10 = stopWatch0.toString();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.split();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        long long7 = stopWatch0.getSplitTime();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        long long7 = stopWatch0.getTime();
        stopWatch0.stop();
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test422");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        long long10 = stopWatch0.getTime();
//        java.lang.String str11 = stopWatch0.toString();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.007" + "'", str6.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.007" + "'", str8.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.007" + "'", str9.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7L + "'", long10 == 7L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.007" + "'", str11.equals("0:00:00.007"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        long long10 = stopWatch0.getTime();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test424");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.reset();
//        java.lang.String str11 = stopWatch0.toString();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.suspend();
        long long9 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test426");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.stop();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        long long11 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 7L + "'", long11 == 7L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test427");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        long long11 = stopWatch0.getTime();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test428");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.stop();
//        stopWatch0.reset();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test429");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        stopWatch0.suspend();
//        long long13 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.006" + "'", str8.equals("0:00:00.006"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.007" + "'", str10.equals("0:00:00.007"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test430");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.String str10 = stopWatch0.toSplitString();
//        stopWatch0.unsplit();
//        stopWatch0.stop();
//        try {
//            long long13 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test432");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toString();
//        long long12 = stopWatch0.getSplitTime();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.start();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.split();
        stopWatch0.split();
        long long9 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        java.lang.String str5 = stopWatch0.toString();
        java.lang.String str6 = stopWatch0.toString();
        long long7 = stopWatch0.getTime();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.String str9 = stopWatch0.toString();
        stopWatch0.unsplit();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.000" + "'", str9.equals("0:00:00.000"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str5 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            stopWatch0.split();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        long long4 = stopWatch0.getTime();
        stopWatch0.start();
        stopWatch0.suspend();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test438");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        long long3 = stopWatch0.getTime();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.reset();
//        try {
//            stopWatch0.unsplit();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        long long7 = stopWatch0.getSplitTime();
        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.split();
        long long11 = stopWatch0.getSplitTime();
        java.lang.String str12 = stopWatch0.toSplitString();
        long long13 = stopWatch0.getSplitTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.000" + "'", str12.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.unsplit();
        stopWatch0.suspend();
        stopWatch0.reset();
        stopWatch0.start();
        stopWatch0.reset();
        long long13 = stopWatch0.getTime();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test441");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        long long6 = stopWatch0.getSplitTime();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        java.lang.String str9 = stopWatch0.toSplitString();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test442");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.split();
//        stopWatch0.stop();
//        stopWatch0.unsplit();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        long long3 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str4 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test445");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test446");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long8 = stopWatch0.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test447");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        java.lang.String str8 = stopWatch0.toString();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.unsplit();
//        long long11 = stopWatch0.getTime();
//        stopWatch0.reset();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test448");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.reset();
//        long long11 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test450");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        java.lang.String str4 = stopWatch0.toString();
//        java.lang.String str5 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.String str7 = stopWatch0.toString();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.stop();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.suspend();
        stopWatch0.stop();
        long long10 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test452");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        long long11 = stopWatch0.getTime();
//        try {
//            stopWatch0.start();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 7L + "'", long11 == 7L);
//    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test453");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.String str6 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        stopWatch0.suspend();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.suspend();
        java.lang.String str7 = stopWatch0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str7 = stopWatch0.toString();
        long long8 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.start();
        long long7 = stopWatch0.getTime();
        long long8 = stopWatch0.getTime();
        stopWatch0.split();
        stopWatch0.unsplit();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        long long8 = stopWatch0.getTime();
        stopWatch0.start();
        long long10 = stopWatch0.getTime();
        stopWatch0.reset();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        stopWatch0.stop();
        stopWatch0.reset();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        long long4 = stopWatch0.getTime();
        long long5 = stopWatch0.getTime();
        stopWatch0.start();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.suspend();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.reset();
        java.lang.String str6 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test462");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        java.lang.String str5 = stopWatch0.toString();
//        long long6 = stopWatch0.getSplitTime();
//        stopWatch0.unsplit();
//        try {
//            stopWatch0.split();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test463");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.String str11 = stopWatch0.toString();
//        long long12 = stopWatch0.getSplitTime();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.002" + "'", str11.equals("0:00:00.002"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test464");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        long long6 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        stopWatch0.resume();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        long long13 = stopWatch0.getTime();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.000" + "'", str11.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test465");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        long long9 = stopWatch0.getTime();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.resume();
//        java.lang.String str12 = stopWatch0.toSplitString();
//        stopWatch0.reset();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.009" + "'", str7.equals("0:00:00.009"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-433406:-38:-24.04" + "'", str12.equals("-433406:-38:-24.04"));
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test466");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        long long4 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long7 = stopWatch0.getTime();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.unsplit();
//        long long11 = stopWatch0.getTime();
//        java.lang.String str12 = stopWatch0.toString();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test467");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        try {
//            stopWatch0.suspend();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test468");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        long long8 = stopWatch0.getSplitTime();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.String str10 = stopWatch0.toString();
//        stopWatch0.suspend();
//        long long12 = stopWatch0.getTime();
//        stopWatch0.reset();
//        long long14 = stopWatch0.getTime();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toString();
        stopWatch0.suspend();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        java.lang.String str10 = stopWatch0.toString();
        try {
            stopWatch0.suspend();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be running to suspend. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.000" + "'", str10.equals("0:00:00.000"));
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test470");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        long long4 = stopWatch0.getTime();
//        java.lang.String str5 = stopWatch0.toString();
//        try {
//            long long6 = stopWatch0.getSplitTime();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.stop();
        java.lang.String str5 = stopWatch0.toString();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test472");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        java.lang.String str10 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0:00:00.001" + "'", str10.equals("0:00:00.001"));
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test473");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long6 = stopWatch0.getTime();
//        java.lang.String str7 = stopWatch0.toString();
//        java.lang.String str8 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        try {
//            stopWatch0.resume();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.String str4 = stopWatch0.toString();
        stopWatch0.start();
        long long6 = stopWatch0.getTime();
        stopWatch0.reset();
        java.lang.String str8 = stopWatch0.toString();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0:00:00.000" + "'", str4.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.stop();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.reset();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test476");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.split();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toSplitString();
//        java.lang.String str7 = stopWatch0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test477");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        java.lang.String str12 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.String str2 = stopWatch0.toString();
        stopWatch0.start();
        stopWatch0.reset();
        stopWatch0.start();
        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
        stopWatch0.suspend();
        java.lang.String str8 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
        stopWatch0.resume();
        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
        stopWatch0.reset();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.000" + "'", str8.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        stopWatch0.start();
        long long5 = stopWatch0.getTime();
        stopWatch0.split();
        java.lang.String str7 = stopWatch0.toSplitString();
        stopWatch0.split();
        stopWatch0.stop();
        stopWatch0.unsplit();
        try {
            java.lang.String str11 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test480");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        stopWatch0.start();
//        stopWatch0.split();
//        long long4 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        stopWatch0.start();
        stopWatch0.reset();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        stopWatch0.start();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.reset();
        try {
            java.lang.String str6 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.split();
        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
        stopWatch0.unsplit();
        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        java.lang.String str3 = stopWatch0.toString();
        stopWatch0.reset();
        try {
            java.lang.String str5 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test485");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        java.lang.String str9 = stopWatch0.toString();
//        stopWatch0.split();
//        java.lang.String str11 = stopWatch0.toSplitString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0:00:00.001" + "'", str11.equals("0:00:00.001"));
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test486");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        java.lang.String str5 = stopWatch0.toString();
//        java.lang.String str6 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass7 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.001" + "'", str5.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        java.lang.String str2 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        long long6 = stopWatch0.getTime();
        long long7 = stopWatch0.getTime();
        try {
            stopWatch0.unsplit();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch has not been split. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        long long5 = stopWatch0.getTime();
        stopWatch0.start();
        try {
            stopWatch0.start();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch already started. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test489");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        long long6 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.String str8 = stopWatch0.toString();
//        java.lang.String str9 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass10 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0:00:00.001" + "'", str8.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0:00:00.001" + "'", str9.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        stopWatch0.reset();
        stopWatch0.reset();
        stopWatch0.start();
        long long4 = stopWatch0.getTime();
        stopWatch0.suspend();
        java.lang.String str6 = stopWatch0.toString();
        try {
            long long7 = stopWatch0.getSplitTime();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        java.lang.String str1 = stopWatch0.toString();
        stopWatch0.start();
        long long3 = stopWatch0.getTime();
        stopWatch0.stop();
        java.lang.String str5 = stopWatch0.toString();
        long long6 = stopWatch0.getTime();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0:00:00.000" + "'", str5.equals("0:00:00.000"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test492");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toString();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass9 = stopWatch0.getClass();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.stop();
//        java.lang.String str12 = stopWatch0.toSplitString();
//        java.lang.Class<?> wildcardClass13 = stopWatch0.getClass();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.001" + "'", str7.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        stopWatch0.reset();
        stopWatch0.start();
        try {
            java.lang.String str4 = stopWatch0.toSplitString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be split to get the split time. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test494");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        long long1 = stopWatch0.getTime();
//        java.lang.String str2 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.start();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        long long7 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        java.lang.Class<?> wildcardClass12 = stopWatch0.getClass();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
        long long1 = stopWatch0.getTime();
        java.lang.Class<?> wildcardClass2 = stopWatch0.getClass();
        java.lang.String str3 = stopWatch0.toString();
        java.lang.Class<?> wildcardClass4 = stopWatch0.getClass();
        try {
            stopWatch0.resume();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch must be suspended to resume. ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.000" + "'", str3.equals("0:00:00.000"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test496");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        stopWatch0.split();
//        java.lang.String str7 = stopWatch0.toSplitString();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        long long10 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass11 = stopWatch0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0:00:00.000" + "'", str7.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test497");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        stopWatch0.start();
//        stopWatch0.suspend();
//        java.lang.Class<?> wildcardClass5 = stopWatch0.getClass();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.resume();
//        java.lang.Class<?> wildcardClass8 = stopWatch0.getClass();
//        long long9 = stopWatch0.getTime();
//        stopWatch0.split();
//        stopWatch0.stop();
//        java.lang.String str12 = stopWatch0.toSplitString();
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.000" + "'", str6.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0:00:00.001" + "'", str12.equals("0:00:00.001"));
//    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test498");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        java.lang.String str3 = stopWatch0.toString();
//        stopWatch0.split();
//        stopWatch0.reset();
//        try {
//            stopWatch0.stop();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Stopwatch is not running. ");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0:00:00.001" + "'", str3.equals("0:00:00.001"));
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test499");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        stopWatch0.start();
//        stopWatch0.split();
//        stopWatch0.stop();
//        long long5 = stopWatch0.getSplitTime();
//        java.lang.String str6 = stopWatch0.toString();
//        stopWatch0.unsplit();
//        long long8 = stopWatch0.getTime();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0:00:00.001" + "'", str6.equals("0:00:00.001"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1560263905411L) + "'", long8 == (-1560263905411L));
//    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test500");
//        org.apache.commons.lang.time.StopWatch stopWatch0 = new org.apache.commons.lang.time.StopWatch();
//        java.lang.String str1 = stopWatch0.toString();
//        java.lang.String str2 = stopWatch0.toString();
//        java.lang.Class<?> wildcardClass3 = stopWatch0.getClass();
//        stopWatch0.start();
//        long long5 = stopWatch0.getTime();
//        java.lang.Class<?> wildcardClass6 = stopWatch0.getClass();
//        stopWatch0.split();
//        stopWatch0.suspend();
//        stopWatch0.resume();
//        long long10 = stopWatch0.getTime();
//        stopWatch0.reset();
//        stopWatch0.reset();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0:00:00.000" + "'", str1.equals("0:00:00.000"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0:00:00.000" + "'", str2.equals("0:00:00.000"));
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }
//}

