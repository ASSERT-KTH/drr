import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test01");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteFirst("hi!");
        int int7 = strBuilder6.size();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.append((long) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder9.appendNewLine();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj14 = strTokenizer13.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.appendWithSeparators((java.util.Iterator) strTokenizer16, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer16.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder21 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder21.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder21.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append((float) ' ');
        char[] charArray39 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray39);
        char[] charArray41 = strBuilder32.getChars(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = new org.apache.commons.lang.text.StrTokenizer(charArray39, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder21.append(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer46 = strTokenizer16.reset(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray39);
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray39);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(strTokenizer46);
        org.junit.Assert.assertNotNull(strTokenizer47);
        org.junit.Assert.assertNotNull(strTokenizer48);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test02");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadRight(0, (int) '#', '4');
        java.io.Reader reader8 = strBuilder7.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.replaceFirst('4', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder7.reverse();
        java.lang.StringBuffer stringBuffer13 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.append(stringBuffer13);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder20.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder21.replaceAll(strMatcher22, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder24.append(false);
        int int29 = strBuilder26.indexOf("hi!", 100);
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder26.append(1.0d);
        boolean boolean32 = strBuilder12.equals((java.lang.Object) strBuilder26);
        java.lang.String str33 = strBuilder26.getNullText();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test03");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst(strMatcher6);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.insert(0, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append((long) 10);
        boolean boolean17 = strBuilder16.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder10.append(strBuilder16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj22 = strTokenizer21.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer21.getQuoteMatcher();
        int int26 = strBuilder10.indexOf(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strBuilder30.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.appendPadding(1, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj38 = strTokenizer37.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer37.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoredChar('#');
        java.lang.String str46 = strTokenizer43.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer43.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer43.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer40.setDelimiterMatcher(strMatcher49);
        int int52 = strBuilder34.lastIndexOf(strMatcher49, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder10.deleteAll(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.delete(5, 17);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder53.deleteFirst('3');
        org.apache.commons.lang.text.StrMatcher strMatcher59 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder58.replaceAll(strMatcher59, "0.0");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "hi!" + "'", obj22.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strBuilder61);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test04");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder6.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher11 = null;
        int int13 = strBuilder6.indexOf(strMatcher11, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder16.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher21 = null;
        int int23 = strBuilder16.indexOf(strMatcher21, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj31 = strTokenizer30.next();
        java.lang.Object obj32 = strTokenizer30.clone();
        java.lang.Object[] objArray33 = new java.lang.Object[] { 100.0f, int23, strBuilder25, obj32 };
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder6.appendWithSeparators(objArray33, "");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder6, (int) (byte) 100, 'a');
        char[] charArray39 = strBuilder3.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder3.setLength(0);
        java.lang.String str43 = strBuilder3.leftString(0);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + obj31 + "' != '" + "hi!" + "'", obj31.equals("hi!"));
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(charArray39);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test05");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder4.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append((float) (-1));
        char[] charArray12 = strBuilder9.toCharArray();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder9.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder9.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder9.insert(4, (float) (byte) 1);
        int int19 = strBuilder17.indexOf("false###########################40.0#######################101.0");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test06");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setIgnoredChar('#');
        java.lang.String str5 = strTokenizer4.nextToken();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer4.setQuoteChar('4');
        java.lang.Object obj8 = strTokenizer7.previous();
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + "hi!" + "'", obj8.equals("hi!"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test07");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer3.setIgnoredChar('#');
        java.lang.String str6 = strTokenizer3.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer3.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher9 = strTokenizer3.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]", strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = strTokenizer10.setDelimiterChar('3');
        java.util.List list13 = strTokenizer12.getTokenList();
        boolean boolean14 = strTokenizer12.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strMatcher9);
        org.junit.Assert.assertNotNull(strTokenizer12);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test08");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.append("StrTokenizer[]");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test09");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        int int10 = strBuilder8.indexOf(strMatcher9);
        int int12 = strBuilder8.lastIndexOf("");
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher14);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.setNewLineText("hi!");
        java.lang.String str22 = strBuilder19.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder19.insert(0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder19.insert((int) (short) 1, "");
        java.util.Collection collection29 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.appendWithSeparators(collection29, "hi!");
        int int33 = strBuilder31.lastIndexOf("");
        java.lang.Object obj34 = new java.lang.Object();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        int int43 = strBuilder36.indexOf(strMatcher41, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder45.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder47.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.replaceAll(strMatcher49, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder48.append(10.0f);
        java.lang.Object[] objArray54 = new java.lang.Object[] { "", int33, obj34, int43, 10.0f };
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder8.appendWithSeparators(objArray54, "");
        org.apache.commons.lang.text.StrBuilder strBuilder58 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder58.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder61 = strBuilder60.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder63 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder63.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder65.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder60.appendFixedWidthPadLeft((java.lang.Object) strBuilder65, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder69.deleteAll("");
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder8.append(strBuilder71);
        org.apache.commons.lang.text.StrBuilder strBuilder74 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder74.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strBuilder76.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder78 = strBuilder76.minimizeCapacity();
        boolean boolean79 = strBuilder72.equals((java.lang.Object) strBuilder76);
        org.apache.commons.lang.text.StrBuilder strBuilder81 = strBuilder76.setLength((int) (byte) 1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder61);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertNotNull(strBuilder78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strBuilder81);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test10");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder2 = strBuilder1.minimizeCapacity();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj6 = strTokenizer5.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer5.setIgnoreEmptyTokens(false);
        java.lang.String str9 = strTokenizer8.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.append((java.lang.Object) str9);
        int int11 = strBuilder1.length();
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.replaceAll(strMatcher17, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteAll("");
        int int25 = strBuilder21.lastIndexOf("4a4 4a");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder21.deleteFirst('a');
        boolean boolean28 = strBuilder1.equals(strBuilder21);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder1.appendFixedWidthPadLeft(7, (int) (byte) 1, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder32.deleteCharAt(0);
        org.junit.Assert.assertNotNull(strBuilder2);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + "hi!" + "'", obj6.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "StrTokenizer[hi!]" + "'", str9.equals("StrTokenizer[hi!]"));
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 17 + "'", int11 == 17);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder34);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test11");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strBuilder3.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder3.append(10);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder3.append((double) 1);
        int int11 = strBuilder3.lastIndexOf('4', 10);
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder3.replace(34, 1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: end < start");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test12");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadRight(0, (int) '#', '4');
        int int8 = strBuilder1.size();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder1.appendNewLine();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder18.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder13.appendFixedWidthPadLeft((java.lang.Object) strBuilder18, 0, ' ');
        java.io.Writer writer23 = strBuilder13.asWriter();
        int int26 = strBuilder13.indexOf("", (int) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder1.append(strBuilder13);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.setNewLineText("hi!");
        java.lang.String str34 = strBuilder31.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder31.insert(0, '4');
        java.lang.Class<?> wildcardClass38 = strBuilder31.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder31.clear();
        int int42 = strBuilder39.lastIndexOf("4", (int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder46.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder49 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder49.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder51.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder46.appendFixedWidthPadLeft((java.lang.Object) strBuilder51, 0, ' ');
        int int56 = strBuilder46.size();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder46.trim();
        char[] charArray64 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = new org.apache.commons.lang.text.StrTokenizer(charArray64);
        org.apache.commons.lang.text.StrBuilder strBuilder66 = strBuilder57.append(charArray64);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder68.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder71 = strBuilder70.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher72 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder74 = strBuilder71.replaceAll(strMatcher72, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder76 = strBuilder71.deleteFirst("hi!");
        boolean boolean77 = strBuilder57.equalsIgnoreCase(strBuilder71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = strTokenizer80.setIgnoredChar('#');
        java.lang.String str83 = strTokenizer82.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher84 = strTokenizer82.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer82.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrMatcher strMatcher87 = strTokenizer82.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder88 = strBuilder71.deleteFirst(strMatcher87);
        int int90 = strBuilder39.indexOf(strMatcher87, 0);
        int int91 = strBuilder1.indexOf(strMatcher87);
        org.apache.commons.lang.text.StrBuilder strBuilder95 = strBuilder1.appendFixedWidthPadLeft(47, 0, '5');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(writer23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(charArray64);
        org.junit.Assert.assertNotNull(strBuilder66);
        org.junit.Assert.assertNotNull(strBuilder70);
        org.junit.Assert.assertNotNull(strBuilder71);
        org.junit.Assert.assertNotNull(strBuilder74);
        org.junit.Assert.assertNotNull(strBuilder76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(strTokenizer82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "hi!" + "'", str83.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher84);
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertNotNull(strMatcher87);
        org.junit.Assert.assertNotNull(strBuilder88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
        org.junit.Assert.assertNotNull(strBuilder95);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test13");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder4.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append((float) (-1));
        char[] charArray12 = strBuilder9.toCharArray();
        int int15 = strBuilder9.lastIndexOf("100.0", (int) ' ');
        java.io.Writer writer16 = strBuilder9.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.ensureCapacity((int) (short) 1);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(writer16);
        org.junit.Assert.assertNotNull(strBuilder18);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test14");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.replaceFirst('#', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder12.minimizeCapacity();
        char[] charArray21 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray21, 'a');
        try {
            org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder12.insert((int) '4', charArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 52");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strTokenizer23);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test15");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, 0, ' ');
        int int13 = strBuilder3.size();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder3.trim();
        char[] charArray21 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray21);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder14.append(charArray21);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray21, 'f', '4');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(strBuilder23);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test16");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        int int10 = strBuilder8.indexOf(strMatcher9);
        int int12 = strBuilder8.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder8.setNewLineText("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder14.append("4a4", (int) (byte) 1, 2);
        boolean boolean20 = strBuilder14.contains('3');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test17");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("4");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setDelimiterString("0.0");
        java.lang.String str4 = strTokenizer3.getContent();
        boolean boolean5 = strTokenizer3.hasPrevious();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4" + "'", str4.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test18");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((float) ' ');
        char[] charArray10 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        char[] charArray12 = strBuilder3.getChars(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer(charArray10, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        int int16 = strTokenizer15.previousIndex();
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = strTokenizer15.setDelimiterString("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder22.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder25.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher30 = null;
        int int32 = strBuilder25.indexOf(strMatcher30, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher40 = null;
        int int42 = strBuilder35.indexOf(strMatcher40, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer49 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj50 = strTokenizer49.next();
        java.lang.Object obj51 = strTokenizer49.clone();
        java.lang.Object[] objArray52 = new java.lang.Object[] { 100.0f, int42, strBuilder44, obj51 };
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder25.appendWithSeparators(objArray52, "");
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder22.appendFixedWidthPadLeft((java.lang.Object) strBuilder25, (int) (byte) 100, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder25.setCharAt(5, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = strTokenizer63.setIgnoredChar('#');
        java.lang.String str66 = strTokenizer63.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer68 = strTokenizer63.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher69 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strTokenizer63.setTrimmerMatcher(strMatcher69);
        org.apache.commons.lang.text.StrMatcher strMatcher71 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = strTokenizer70.setIgnoredMatcher(strMatcher71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer77 = strTokenizer75.setIgnoredChar('#');
        java.lang.String str78 = strTokenizer77.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher79 = strTokenizer77.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer70.setDelimiterMatcher(strMatcher79);
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer70.getTrimmerMatcher();
        int int82 = strBuilder60.indexOf(strMatcher81);
        org.apache.commons.lang.text.StrTokenizer strTokenizer83 = strTokenizer18.setIgnoredMatcher(strMatcher81);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + obj50 + "' != '" + "hi!" + "'", obj50.equals("hi!"));
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer68);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strTokenizer72);
        org.junit.Assert.assertNotNull(strTokenizer77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher79);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strMatcher81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer83);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test19");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder8.appendFixedWidthPadRight((java.lang.Object) 10.0d, 34, '4');
        int int13 = strBuilder8.length();
        boolean boolean14 = strBuilder8.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder8.minimizeCapacity();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 34 + "'", int13 == 34);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test20");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteFirst("hi!");
        int int7 = strBuilder6.size();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.append((long) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder9.appendNewLine();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj14 = strTokenizer13.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.appendWithSeparators((java.util.Iterator) strTokenizer16, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer16.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer16.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = strTokenizer16.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer16.setIgnoredChar('f');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strMatcher22);
        org.junit.Assert.assertNotNull(strTokenizer24);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test21");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance("055555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555555");
        org.junit.Assert.assertNotNull(strTokenizer1);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test22");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer2.setIgnoredChar('#');
        java.lang.String str5 = strTokenizer2.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer2.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher8 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strTokenizer2.setTrimmerMatcher(strMatcher8);
        org.apache.commons.lang.text.StrMatcher strMatcher10 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer9.setIgnoredMatcher(strMatcher10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer14.setIgnoredChar('#');
        java.lang.String str17 = strTokenizer16.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = strTokenizer16.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer9.setDelimiterMatcher(strMatcher18);
        java.util.List list20 = strTokenizer19.getTokenList();
        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder24.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher26 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder25.replaceAll(strMatcher26, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder25.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.append(' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer35.setIgnoredChar('#');
        java.lang.String str38 = strTokenizer35.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer35.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer35.getQuoteMatcher();
        int int43 = strBuilder30.indexOf(strMatcher41, 1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        org.apache.commons.lang.text.StrBuilder strBuilder47 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder47.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder47.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strBuilder47.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher55 = strTokenizer54.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder57 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder57.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder59.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder62 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder62.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder64.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder59.appendFixedWidthPadLeft((java.lang.Object) strBuilder64, 0, ' ');
        java.io.Writer writer69 = strBuilder59.asWriter();
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = strBuilder59.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher71 = strTokenizer70.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer72 = new org.apache.commons.lang.text.StrTokenizer("10", strMatcher55, strMatcher71);
        org.apache.commons.lang.text.StrTokenizer strTokenizer73 = strTokenizer44.setIgnoredMatcher(strMatcher71);
        int int75 = strBuilder30.lastIndexOf(strMatcher71, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer19.setTrimmerMatcher(strMatcher71);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strMatcher55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder64);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(writer69);
        org.junit.Assert.assertNotNull(strTokenizer70);
        org.junit.Assert.assertNotNull(strMatcher71);
        org.junit.Assert.assertNotNull(strTokenizer73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer76);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test23");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrMatcher strMatcher9 = null;
        int int10 = strBuilder8.indexOf(strMatcher9);
        int int12 = strBuilder8.lastIndexOf("");
        org.apache.commons.lang.text.StrMatcher strMatcher14 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher14);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.setNewLineText("hi!");
        java.lang.String str22 = strBuilder19.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder19.insert(0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder19.insert((int) (short) 1, "");
        java.util.Collection collection29 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder19.appendWithSeparators(collection29, "hi!");
        int int33 = strBuilder31.lastIndexOf("");
        java.lang.Object obj34 = new java.lang.Object();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder36.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder36.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher41 = null;
        int int43 = strBuilder36.indexOf(strMatcher41, 0);
        org.apache.commons.lang.text.StrBuilder strBuilder45 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder45.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder47.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher49 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder48.replaceAll(strMatcher49, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder48.append(10.0f);
        java.lang.Object[] objArray54 = new java.lang.Object[] { "", int33, obj34, int43, 10.0f };
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder8.appendWithSeparators(objArray54, "");
        org.apache.commons.lang.text.StrBuilder strBuilder57 = strBuilder8.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder8.append("10hi!");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder51);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder57);
        org.junit.Assert.assertNotNull(strBuilder59);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test24");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, 0, ' ');
        java.io.Writer writer13 = strBuilder3.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder3.insert(0, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder3.replaceFirst("hi!", "hi!");
        boolean boolean21 = strBuilder3.contains("32.04a");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder3.setNewLineText("1");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder26.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder32.replaceFirst('#', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.append((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder43.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder44.deleteFirst("hi!");
        int int47 = strBuilder46.size();
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder46.append((long) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder49.appendNewLine();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj54 = strTokenizer53.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = strTokenizer53.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder49.appendWithSeparators((java.util.Iterator) strTokenizer56, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer59 = strTokenizer56.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder61 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder61.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder61.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder61.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder70 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder72 = strBuilder70.append((float) ' ');
        char[] charArray79 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = new org.apache.commons.lang.text.StrTokenizer(charArray79);
        char[] charArray81 = strBuilder72.getChars(charArray79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer84 = new org.apache.commons.lang.text.StrTokenizer(charArray79, '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder85 = strBuilder61.append(charArray79);
        org.apache.commons.lang.text.StrTokenizer strTokenizer86 = strTokenizer56.reset(charArray79);
        java.lang.String[] strArray87 = strTokenizer86.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder89 = strBuilder39.appendWithSeparators((java.lang.Object[]) strArray87, "10 6.0");
        org.apache.commons.lang.text.StrBuilder strBuilder91 = strBuilder24.appendWithSeparators((java.lang.Object[]) strArray87, "17 ");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(writer13);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertTrue("'" + obj54 + "' != '" + "hi!" + "'", obj54.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(strTokenizer59);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(strBuilder72);
        org.junit.Assert.assertNotNull(charArray79);
        org.junit.Assert.assertNotNull(charArray81);
        org.junit.Assert.assertNotNull(strBuilder85);
        org.junit.Assert.assertNotNull(strTokenizer86);
        org.junit.Assert.assertNotNull(strArray87);
        org.junit.Assert.assertNotNull(strBuilder89);
        org.junit.Assert.assertNotNull(strBuilder91);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test25");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("0.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('#');
        java.lang.String str8 = strTokenizer5.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = strTokenizer5.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher11 = strTokenizer5.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer("4", strMatcher11);
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strTokenizer1.setDelimiterMatcher(strMatcher11);
        boolean boolean14 = strTokenizer13.isIgnoreEmptyTokens();
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer10);
        org.junit.Assert.assertNotNull(strMatcher11);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test26");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append(false);
        int int12 = strBuilder9.indexOf("hi!", 100);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder9.setNewLineText("10");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder18.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher20 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder19.replaceAll(strMatcher20, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.setNewLineText("hi!");
        boolean boolean29 = strBuilder28.isEmpty();
        char[] charArray36 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        char[] charArray38 = strBuilder28.getChars(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder22.append(charArray36);
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
        char[] charArray41 = strBuilder14.getChars(charArray36);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder14.appendNewLine();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(charArray36);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(charArray41);
        org.junit.Assert.assertNotNull(strBuilder42);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test27");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((float) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append("");
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder3.replaceFirst(strMatcher6, "StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer9 = strBuilder8.asTokenizer();
        try {
            strTokenizer9.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: remove() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strTokenizer9);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test28");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance();
        boolean boolean1 = strTokenizer0.isIgnoreEmptyTokens();
        boolean boolean2 = strTokenizer0.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strTokenizer0.setQuoteChar('4');
        boolean boolean5 = strTokenizer4.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer4.reset("");
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strTokenizer7);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test29");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder4.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder9.insert(0, 100L);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteFirst("100.0");
        boolean boolean18 = strBuilder16.contains("04444444444444444444444444444444444110.0");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test30");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.setNewLineText("hi!");
        boolean boolean14 = strBuilder13.isEmpty();
        char[] charArray21 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer22 = new org.apache.commons.lang.text.StrTokenizer(charArray21);
        char[] charArray23 = strBuilder13.getChars(charArray21);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder7.append(charArray21);
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.insert(2, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder29 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder29.append((float) ' ');
        char[] charArray38 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = new org.apache.commons.lang.text.StrTokenizer(charArray38);
        char[] charArray40 = strBuilder31.getChars(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder27.append(charArray38);
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder41.appendNewLine();
        int int44 = strBuilder42.indexOf("");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(charArray38);
        org.junit.Assert.assertNotNull(charArray40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test31");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.setNewLineText("hi!");
        boolean boolean17 = strBuilder16.isEmpty();
        char[] charArray24 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer(charArray24);
        char[] charArray26 = strBuilder16.getChars(charArray24);
        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder8.append(charArray24, 0, 0);
        java.lang.Class<?> wildcardClass30 = strBuilder8.getClass();
        boolean boolean32 = strBuilder8.contains("          ");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertNotNull(charArray26);
        org.junit.Assert.assertNotNull(strBuilder29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test32");
        char[] charArray0 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer(charArray0, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher3 = strTokenizer2.getQuoteMatcher();
        org.apache.commons.lang.text.StrMatcher strMatcher4 = strTokenizer2.getIgnoredMatcher();
        org.junit.Assert.assertNotNull(strMatcher3);
        org.junit.Assert.assertNotNull(strMatcher4);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test33");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.setNewLineText("hi!");
        boolean boolean6 = strBuilder5.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) ' ');
        char[] charArray17 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray17);
        char[] charArray19 = strBuilder10.getChars(charArray17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder5.append((java.lang.Object) charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray17, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder1.append(charArray17);
        char[] charArray25 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = new org.apache.commons.lang.text.StrTokenizer(charArray25, 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher28 = strTokenizer27.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer(charArray17, strMatcher28);
        java.lang.String str30 = strTokenizer29.toString();
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strMatcher28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str30.equals("StrTokenizer[not tokenized yet]"));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test34");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        boolean boolean4 = strBuilder3.isEmpty();
        char[] charArray11 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer12 = new org.apache.commons.lang.text.StrTokenizer(charArray11);
        char[] charArray13 = strBuilder3.getChars(charArray11);
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder3.append((float) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.minimizeCapacity();
        int int18 = strBuilder16.lastIndexOf('5');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test35");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst(strMatcher6);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.insert(0, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append((long) 10);
        boolean boolean17 = strBuilder16.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder10.append(strBuilder16);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.append(0L);
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append('5');
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder22.setCharAt(0, 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test36");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.deleteAll('4');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder14.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder19.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder14.appendFixedWidthPadLeft((java.lang.Object) strBuilder19, 0, ' ');
        java.io.Writer writer24 = strBuilder14.asWriter();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strBuilder14.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder10.deleteAll(strMatcher26);
        java.lang.Object obj28 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder10.appendFixedWidthPadLeft(obj28, (int) (byte) -1, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder33 = strBuilder31.setNullText("971010");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = strBuilder37.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder37.minimizeCapacity();
        int int41 = strBuilder39.lastIndexOf("");
        org.apache.commons.lang.text.StrBuilder strBuilder42 = strBuilder31.append((java.lang.Object) strBuilder39);
        org.apache.commons.lang.text.StrMatcher strMatcher43 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder31.deleteAll(strMatcher43);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(writer24);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
        org.junit.Assert.assertNotNull(strBuilder33);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strTokenizer38);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(strBuilder42);
        org.junit.Assert.assertNotNull(strBuilder44);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test37");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, 0, ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder16.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.deleteFirst("hi!");
        int int21 = strBuilder17.lastIndexOf("hi!");
        int int23 = strBuilder17.lastIndexOf(' ');
        boolean boolean24 = strBuilder8.equalsIgnoreCase(strBuilder17);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder26.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder26.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher31 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder30.deleteFirst(strMatcher31);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder17.appendFixedWidthPadRight((java.lang.Object) strBuilder32, (int) '#', ' ');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertNotNull(strBuilder35);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test38");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((float) ' ');
        char[] charArray10 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = new org.apache.commons.lang.text.StrTokenizer(charArray10);
        char[] charArray12 = strBuilder3.getChars(charArray10);
        org.apache.commons.lang.text.StrTokenizer strTokenizer15 = new org.apache.commons.lang.text.StrTokenizer(charArray10, '#', '4');
        java.lang.String str16 = strTokenizer15.nextToken();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.setNewLineText("hi!");
        java.lang.String str23 = strBuilder20.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder20.insert(0, '4');
        java.lang.Class<?> wildcardClass27 = strBuilder20.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder20.clear();
        int int31 = strBuilder28.lastIndexOf("4", (int) (byte) -1);
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder35.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder40.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder35.appendFixedWidthPadLeft((java.lang.Object) strBuilder40, 0, ' ');
        int int45 = strBuilder35.size();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder35.trim();
        char[] charArray53 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = new org.apache.commons.lang.text.StrTokenizer(charArray53);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder46.append(charArray53);
        org.apache.commons.lang.text.StrBuilder strBuilder57 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder59 = strBuilder57.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder60 = strBuilder59.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher61 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder60.replaceAll(strMatcher61, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder65 = strBuilder60.deleteFirst("hi!");
        boolean boolean66 = strBuilder46.equalsIgnoreCase(strBuilder60);
        org.apache.commons.lang.text.StrTokenizer strTokenizer69 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer71 = strTokenizer69.setIgnoredChar('#');
        java.lang.String str72 = strTokenizer71.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher73 = strTokenizer71.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer75 = strTokenizer71.setEmptyTokenAsNull(true);
        org.apache.commons.lang.text.StrMatcher strMatcher76 = strTokenizer71.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder77 = strBuilder60.deleteFirst(strMatcher76);
        int int79 = strBuilder28.indexOf(strMatcher76, 0);
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer15.setTrimmerMatcher(strMatcher76);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32.04a" + "'", str16.equals("32.04a"));
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(charArray53);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder59);
        org.junit.Assert.assertNotNull(strBuilder60);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strBuilder65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(strTokenizer71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "hi!" + "'", str72.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher73);
        org.junit.Assert.assertNotNull(strTokenizer75);
        org.junit.Assert.assertNotNull(strMatcher76);
        org.junit.Assert.assertNotNull(strBuilder77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer80);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test39");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('#');
        java.lang.String str8 = strTokenizer7.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = strTokenizer7.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer1.setIgnoredMatcher(strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = new org.apache.commons.lang.text.StrTokenizer("hi!", 'a');
        org.apache.commons.lang.text.StrMatcher strMatcher15 = strTokenizer14.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer11.setDelimiterMatcher(strMatcher15);
        java.lang.Object obj17 = null;
        try {
            strTokenizer16.add(obj17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: add() is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strMatcher15);
        org.junit.Assert.assertNotNull(strTokenizer16);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test40");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer4 = strBuilder3.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder6.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder12.replaceFirst('#', 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.deleteAll("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder15.append((int) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder15.append(10.0f);
        boolean boolean22 = strBuilder3.equalsIgnoreCase(strBuilder15);
        java.lang.String str24 = strBuilder3.substring(0);
        int int26 = strBuilder3.indexOf("StrTokenizer[]");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strTokenizer4);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test41");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.setNewLineText("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder20.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) strBuilder20, 0, ' ');
        int int25 = strBuilder15.size();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder15.trim();
        char[] charArray33 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray33);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder26.append(charArray33);
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder35.ensureCapacity((int) (byte) 0);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder35.deleteFirst("");
        boolean boolean40 = strBuilder9.equalsIgnoreCase(strBuilder39);
        int int43 = strBuilder9.lastIndexOf("10.0", 40);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test42");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst(strMatcher6);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.insert(0, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.append((long) 10);
        boolean boolean17 = strBuilder16.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder10.append(strBuilder16);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj22 = strTokenizer21.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer21.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrMatcher strMatcher25 = strTokenizer21.getQuoteMatcher();
        int int26 = strBuilder10.indexOf(strMatcher25);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strBuilder30.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder30.appendPadding(1, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj38 = strTokenizer37.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer37.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer45 = strTokenizer43.setIgnoredChar('#');
        java.lang.String str46 = strTokenizer43.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = strTokenizer43.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher49 = strTokenizer43.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = strTokenizer40.setDelimiterMatcher(strMatcher49);
        int int52 = strBuilder34.lastIndexOf(strMatcher49, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder53 = strBuilder10.deleteAll(strMatcher49);
        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder53.delete(5, 17);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder53.deleteFirst('3');
        int int59 = strBuilder53.length();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + "hi!" + "'", obj22.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strMatcher25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertTrue("'" + obj38 + "' != '" + "hi!" + "'", obj38.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertNotNull(strTokenizer45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer48);
        org.junit.Assert.assertNotNull(strMatcher49);
        org.junit.Assert.assertNotNull(strTokenizer50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(strBuilder53);
        org.junit.Assert.assertNotNull(strBuilder56);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 5 + "'", int59 == 5);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test43");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("hi!-1.0");
        org.apache.commons.lang.text.StrMatcher strMatcher2 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer1.setIgnoredMatcher(strMatcher2);
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strTokenizer3);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test44");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("false###########################40.0#######################101.0");
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test45");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder7.append(false);
        int int12 = strBuilder9.indexOf("hi!", 100);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder9.setNewLineText("10");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder9.append(2);
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer19.setIgnoredChar('#');
        java.lang.String str22 = strTokenizer19.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = strTokenizer19.setQuoteChar('a');
        java.lang.String[] strArray25 = strTokenizer19.getTokenArray();
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder9.appendFixedWidthPadRight((java.lang.Object) strTokenizer19, (int) 'f', 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer24);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(strBuilder28);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test46");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("afalseaaa", "          ");
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test47");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj3 = strTokenizer2.next();
        java.lang.Object obj4 = strTokenizer2.clone();
        java.util.List list5 = strTokenizer2.getTokenList();
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer2.setQuoteChar('#');
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = strTokenizer7.reset();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strBuilder12.asTokenizer();
        java.lang.String str14 = strBuilder12.toString();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder16.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder16.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder16.clear();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = strTokenizer26.setIgnoredChar('#');
        java.lang.String str29 = strTokenizer26.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer26.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher32 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = strTokenizer26.setTrimmerMatcher(strMatcher32);
        org.apache.commons.lang.text.StrMatcher strMatcher34 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoredMatcher(strMatcher34);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = strTokenizer38.setIgnoredChar('#');
        java.lang.String str41 = strTokenizer40.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer40.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = strTokenizer33.setDelimiterMatcher(strMatcher42);
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder16.deleteAll(strMatcher42);
        org.apache.commons.lang.text.StrBuilder strBuilder46 = strBuilder12.replaceFirst(strMatcher42, "4");
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = strTokenizer7.setTrimmerMatcher(strMatcher42);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + "hi!" + "'", obj3.equals("hi!"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strTokenizer28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strTokenizer33);
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertNotNull(strTokenizer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strTokenizer43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder46);
        org.junit.Assert.assertNotNull(strTokenizer47);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test48");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        java.lang.String str6 = strBuilder3.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder3.insert(0, '4');
        java.lang.Class<?> wildcardClass10 = strBuilder3.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.setLength(10);
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder3.append((double) (byte) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) "StrTokenizer[not tokenized yet]", 100, 'a');
        boolean boolean20 = strBuilder18.startsWith("32.04a");
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder18.appendFixedWidthPadRight((int) (byte) 0, (-1), '5');
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder24.insert(45, "10");
        org.apache.commons.lang.text.StrBuilder strBuilder31 = strBuilder27.appendFixedWidthPadRight(9, (int) (byte) 0, 'a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertNotNull(strBuilder31);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test49");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.append((float) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder3.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder7.appendPadding(4, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder10.reverse();
        int int13 = strBuilder10.indexOf('5');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test50");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder(0);
        boolean boolean3 = strBuilder1.contains('f');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test51");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = strTokenizer5.setIgnoredChar('#');
        java.lang.String str8 = strTokenizer7.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher9 = strTokenizer7.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer10 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher9);
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = strTokenizer1.setIgnoredMatcher(strMatcher9);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder18 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder18.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder20.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder15.appendFixedWidthPadLeft((java.lang.Object) strBuilder20, 0, ' ');
        int int25 = strBuilder15.size();
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder15.trim();
        char[] charArray33 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray33);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder26.append(charArray33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = strTokenizer11.reset(charArray33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray33);
        org.junit.Assert.assertNotNull(strTokenizer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(strTokenizer36);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test52");
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj4 = strTokenizer3.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer6 = strTokenizer3.setIgnoreEmptyTokens(false);
        java.lang.String str7 = strTokenizer6.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher8 = strTokenizer6.getDelimiterMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder10 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder10.append((float) ' ');
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder12.deleteFirst(' ');
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder12.clear();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.append("");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder17.appendPadding(35, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = strTokenizer25.setIgnoredChar('#');
        java.lang.String str28 = strTokenizer25.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer30 = strTokenizer25.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher31 = strTokenizer25.getQuoteMatcher();
        int int32 = strBuilder17.lastIndexOf(strMatcher31);
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("", strMatcher8, strMatcher31);
        boolean boolean34 = strTokenizer33.hasPrevious();
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + "hi!" + "'", obj4.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "StrTokenizer[hi!]" + "'", str7.equals("StrTokenizer[hi!]"));
        org.junit.Assert.assertNotNull(strMatcher8);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strTokenizer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer30);
        org.junit.Assert.assertNotNull(strMatcher31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 34 + "'", int32 == 34);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test53");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteFirst("hi!");
        int int7 = strBuilder6.size();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.append((long) (byte) 10);
        java.lang.String str11 = strBuilder9.substring((int) (short) 1);
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder9.trim();
        org.apache.commons.lang.text.StrBuilder strBuilder14 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder16.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher18 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder17.replaceAll(strMatcher18, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder20.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.deleteAll("");
        int int26 = strBuilder22.indexOf('4');
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("StrTokenizer[not tokenized yet]");
        org.apache.commons.lang.text.StrTokenizer strTokenizer33 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer35 = strTokenizer33.setIgnoredChar('#');
        java.lang.String str36 = strTokenizer35.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher37 = strTokenizer35.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher37);
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer29.setIgnoredMatcher(strMatcher37);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder43.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder46 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder46.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder48.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder52 = strBuilder43.appendFixedWidthPadLeft((java.lang.Object) strBuilder48, 0, ' ');
        int int53 = strBuilder43.size();
        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder43.trim();
        char[] charArray61 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer62 = new org.apache.commons.lang.text.StrTokenizer(charArray61);
        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder54.append(charArray61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer64 = strTokenizer39.reset(charArray61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer65 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance(charArray61);
        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder22.insert(4, charArray61, 0, 2);
        char[] charArray69 = strBuilder9.getChars(charArray61);
        org.apache.commons.lang.text.StrTokenizer strTokenizer70 = new org.apache.commons.lang.text.StrTokenizer(charArray69);
        org.apache.commons.lang.text.StrMatcher strMatcher71 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer74 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer76 = strTokenizer74.setIgnoredChar('#');
        java.lang.String str77 = strTokenizer76.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher78 = strTokenizer76.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer80 = strTokenizer76.setDelimiterString("4a4 4a");
        org.apache.commons.lang.text.StrMatcher strMatcher81 = strTokenizer80.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer82 = new org.apache.commons.lang.text.StrTokenizer(charArray69, strMatcher71, strMatcher81);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher37);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNotNull(strBuilder49);
        org.junit.Assert.assertNotNull(strBuilder52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(strBuilder54);
        org.junit.Assert.assertNotNull(charArray61);
        org.junit.Assert.assertNotNull(strBuilder63);
        org.junit.Assert.assertNotNull(strTokenizer64);
        org.junit.Assert.assertNotNull(strTokenizer65);
        org.junit.Assert.assertNotNull(strBuilder68);
        org.junit.Assert.assertNotNull(charArray69);
        org.junit.Assert.assertNotNull(strTokenizer76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher78);
        org.junit.Assert.assertNotNull(strTokenizer80);
        org.junit.Assert.assertNotNull(strMatcher81);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test54");
        char[] charArray6 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer7 = new org.apache.commons.lang.text.StrTokenizer(charArray6);
        org.apache.commons.lang.text.StrTokenizer strTokenizer8 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray6);
        java.lang.Class<?> wildcardClass9 = strTokenizer8.getClass();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder13.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder14.deleteFirst("hi!");
        int int17 = strBuilder16.size();
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.append((long) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder19.appendNewLine();
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj24 = strTokenizer23.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = strTokenizer23.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = strBuilder19.appendWithSeparators((java.util.Iterator) strTokenizer26, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer26.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = strTokenizer26.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrBuilder strBuilder33 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder33.setNewLineText("hi!");
        boolean boolean36 = strBuilder35.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder38 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder38.append((float) ' ');
        char[] charArray47 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer48 = new org.apache.commons.lang.text.StrTokenizer(charArray47);
        char[] charArray49 = strBuilder40.getChars(charArray47);
        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder35.append((java.lang.Object) charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer51 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer52 = strTokenizer31.reset(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer54 = strTokenizer8.reset(charArray47);
        org.apache.commons.lang.text.StrTokenizer strTokenizer55 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray47);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertNotNull(strTokenizer8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertTrue("'" + obj24 + "' != '" + "hi!" + "'", obj24.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer26);
        org.junit.Assert.assertNotNull(strBuilder28);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer31);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(strBuilder40);
        org.junit.Assert.assertNotNull(charArray47);
        org.junit.Assert.assertNotNull(charArray49);
        org.junit.Assert.assertNotNull(strBuilder50);
        org.junit.Assert.assertNotNull(strTokenizer51);
        org.junit.Assert.assertNotNull(strTokenizer52);
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer54);
        org.junit.Assert.assertNotNull(strTokenizer55);
    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test55");
//        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
//        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
//        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
//        org.apache.commons.lang.text.StrBuilder strBuilder6 = new org.apache.commons.lang.text.StrBuilder("");
//        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder6.setNewLineText("hi!");
//        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder8.minimizeCapacity();
//        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.appendFixedWidthPadLeft((java.lang.Object) strBuilder8, 0, ' ');
//        java.io.Writer writer13 = strBuilder3.asWriter();
//        org.apache.commons.lang.text.StrTokenizer strTokenizer14 = strBuilder3.asTokenizer();
//        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder3.setNullText("StrTokenizer[hi!]");
//        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.delete((int) (short) 0, 0);
//        java.io.Writer writer20 = strBuilder16.asWriter();
//        org.apache.commons.lang.text.StrBuilder strBuilder22 = new org.apache.commons.lang.text.StrBuilder("");
//        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder22.setNewLineText("hi!");
//        boolean boolean25 = strBuilder24.isEmpty();
//        org.apache.commons.lang.text.StrBuilder strBuilder27 = new org.apache.commons.lang.text.StrBuilder("");
//        org.apache.commons.lang.text.StrBuilder strBuilder29 = strBuilder27.append((float) ' ');
//        char[] charArray36 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
//        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = new org.apache.commons.lang.text.StrTokenizer(charArray36);
//        char[] charArray38 = strBuilder29.getChars(charArray36);
//        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder24.append((java.lang.Object) charArray36);
//        org.apache.commons.lang.text.StrBuilder strBuilder40 = strBuilder39.appendNull();
//        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder40.appendPadding(1, '#');
//        java.lang.String str44 = strBuilder43.toString();
//        int int46 = strBuilder43.lastIndexOf('a');
//        org.apache.commons.lang.text.StrBuilder strBuilder48 = new org.apache.commons.lang.text.StrBuilder("");
//        org.apache.commons.lang.text.StrBuilder strBuilder50 = strBuilder48.setNewLineText("hi!");
//        org.apache.commons.lang.text.StrBuilder strBuilder51 = strBuilder50.minimizeCapacity();
//        org.apache.commons.lang.text.StrMatcher strMatcher52 = null;
//        org.apache.commons.lang.text.StrBuilder strBuilder54 = strBuilder51.replaceAll(strMatcher52, "hi!");
//        org.apache.commons.lang.text.StrBuilder strBuilder56 = strBuilder54.append(false);
//        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder56.deleteAll("");
//        int int60 = strBuilder56.lastIndexOf("4a4 4a");
//        org.apache.commons.lang.text.StrBuilder strBuilder63 = strBuilder43.appendFixedWidthPadRight((java.lang.Object) "4a4 4a", 32, '4');
//        boolean boolean65 = strBuilder63.contains(' ');
//        org.apache.commons.lang.text.StrBuilder strBuilder68 = strBuilder63.insert(34, ' ');
//        java.lang.String str69 = strBuilder63.getNewLineText();
//        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder16.append(strBuilder63);
//        org.junit.Assert.assertNotNull(strBuilder3);
//        org.junit.Assert.assertNotNull(strBuilder4);
//        org.junit.Assert.assertNotNull(strBuilder8);
//        org.junit.Assert.assertNotNull(strBuilder9);
//        org.junit.Assert.assertNotNull(strBuilder12);
//        org.junit.Assert.assertNotNull(writer13);
//        org.junit.Assert.assertNotNull(strTokenizer14);
//        org.junit.Assert.assertNotNull(strBuilder16);
//        org.junit.Assert.assertNotNull(strBuilder19);
//        org.junit.Assert.assertNotNull(writer20);
//        org.junit.Assert.assertNotNull(strBuilder24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(strBuilder29);
//        org.junit.Assert.assertNotNull(charArray36);
//        org.junit.Assert.assertNotNull(charArray38);
//        org.junit.Assert.assertNotNull(strBuilder39);
//        org.junit.Assert.assertNotNull(strBuilder40);
//        org.junit.Assert.assertNotNull(strBuilder43);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
//        org.junit.Assert.assertNotNull(strBuilder50);
//        org.junit.Assert.assertNotNull(strBuilder51);
//        org.junit.Assert.assertNotNull(strBuilder54);
//        org.junit.Assert.assertNotNull(strBuilder56);
//        org.junit.Assert.assertNotNull(strBuilder58);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
//        org.junit.Assert.assertNotNull(strBuilder63);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertNotNull(strBuilder68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
//        org.junit.Assert.assertNotNull(strBuilder70);
//    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test56");
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj3 = strTokenizer2.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer5 = strTokenizer2.setIgnoreEmptyTokens(false);
        java.util.List list6 = strTokenizer5.getTokenList();
        boolean boolean7 = strTokenizer5.isIgnoreEmptyTokens();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + "hi!" + "'", obj3.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test57");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder1.appendFixedWidthPadRight(0, (int) '#', '4');
        java.io.Reader reader8 = strBuilder7.asReader();
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder7.replaceFirst('4', 'a');
        boolean boolean12 = strBuilder7.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder7.insert((int) (byte) 10, true);
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder17.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher22 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.deleteFirst(strMatcher22);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder23.insert(0, (int) 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder28.append((long) 10);
        boolean boolean33 = strBuilder32.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder26.append(strBuilder32);
        org.apache.commons.lang.text.StrBuilder strBuilder35 = strBuilder7.append(strBuilder32);
        java.io.Writer writer36 = strBuilder35.asWriter();
        int int38 = strBuilder35.lastIndexOf("0.0");
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strTokenizer42.setIgnoredChar('#');
        java.lang.String str45 = strTokenizer44.nextToken();
        org.apache.commons.lang.text.StrMatcher strMatcher46 = strTokenizer44.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer47 = new org.apache.commons.lang.text.StrTokenizer("hi!", strMatcher46);
        org.apache.commons.lang.text.StrBuilder strBuilder49 = strBuilder35.replaceFirst(strMatcher46, "1");
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder35);
        org.junit.Assert.assertNotNull(writer36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertNotNull(strMatcher46);
        org.junit.Assert.assertNotNull(strBuilder49);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test58");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder((int) (byte) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.setNewLineText("hi!");
        boolean boolean6 = strBuilder5.isEmpty();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder8.append((float) ' ');
        char[] charArray17 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer18 = new org.apache.commons.lang.text.StrTokenizer(charArray17);
        char[] charArray19 = strBuilder10.getChars(charArray17);
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder5.append((java.lang.Object) charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = new org.apache.commons.lang.text.StrTokenizer(charArray17, 'a');
        org.apache.commons.lang.text.StrBuilder strBuilder24 = strBuilder1.append(charArray17);
        org.apache.commons.lang.text.StrTokenizer strTokenizer26 = new org.apache.commons.lang.text.StrTokenizer(charArray17, '3');
        org.apache.commons.lang.text.StrTokenizer strTokenizer27 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray17);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strBuilder24);
        org.junit.Assert.assertNotNull(strTokenizer27);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test59");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder4.deleteFirst("hi!");
        int int7 = strBuilder6.size();
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.append((long) (byte) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder9.appendNewLine();
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj14 = strTokenizer13.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer16 = strTokenizer13.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder9.appendWithSeparators((java.util.Iterator) strTokenizer16, "hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer19 = strTokenizer16.reset();
        org.apache.commons.lang.text.StrTokenizer strTokenizer21 = strTokenizer16.setIgnoreEmptyTokens(true);
        org.apache.commons.lang.text.StrTokenizer strTokenizer23 = strTokenizer16.setEmptyTokenAsNull(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strTokenizer23.setDelimiterChar('f');
        java.lang.Object obj26 = strTokenizer25.clone();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + "hi!" + "'", obj14.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer16);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strTokenizer19);
        org.junit.Assert.assertNotNull(strTokenizer21);
        org.junit.Assert.assertNotNull(strTokenizer23);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test60");
        org.apache.commons.lang.text.StrTokenizer strTokenizer0 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance();
        org.apache.commons.lang.text.StrMatcher strMatcher1 = null;
        org.apache.commons.lang.text.StrTokenizer strTokenizer2 = strTokenizer0.setDelimiterMatcher(strMatcher1);
        org.apache.commons.lang.text.StrTokenizer strTokenizer3 = strTokenizer0.reset();
        boolean boolean4 = strTokenizer0.hasNext();
        org.junit.Assert.assertNotNull(strTokenizer0);
        org.junit.Assert.assertNotNull(strTokenizer2);
        org.junit.Assert.assertNotNull(strTokenizer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test61");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        boolean boolean6 = strBuilder5.isEmpty();
        java.lang.StringBuffer stringBuffer7 = strBuilder5.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder5.minimizeCapacity();
        java.io.Reader reader9 = strBuilder5.asReader();
        org.apache.commons.lang.text.StrTokenizer strTokenizer11 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("971010");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder16 = strBuilder15.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher17 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder16.replaceAll(strMatcher17, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder19.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder23 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder23.setNewLineText("hi!");
        boolean boolean26 = strBuilder25.isEmpty();
        char[] charArray33 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = new org.apache.commons.lang.text.StrTokenizer(charArray33);
        char[] charArray35 = strBuilder25.getChars(charArray33);
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder19.append(charArray33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer38 = new org.apache.commons.lang.text.StrTokenizer(charArray33, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer11.reset(charArray33);
        char[] charArray40 = strBuilder5.getChars(charArray33);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = new org.apache.commons.lang.text.StrTokenizer(charArray40, '3', '5');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stringBuffer7);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(reader9);
        org.junit.Assert.assertNotNull(strTokenizer11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder16);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(charArray33);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertNotNull(charArray40);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test62");
        org.apache.commons.lang.text.StrTokenizer strTokenizer1 = org.apache.commons.lang.text.StrTokenizer.getCSVInstance("971010");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder3.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder6 = strBuilder5.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher7 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder6.replaceAll(strMatcher7, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = strBuilder9.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        boolean boolean16 = strBuilder15.isEmpty();
        char[] charArray23 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray23);
        char[] charArray25 = strBuilder15.getChars(charArray23);
        org.apache.commons.lang.text.StrBuilder strBuilder26 = strBuilder9.append(charArray23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer28 = new org.apache.commons.lang.text.StrTokenizer(charArray23, ' ');
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = strTokenizer1.reset(charArray23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer32 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer34 = strTokenizer32.setIgnoredChar('#');
        java.lang.String str35 = strTokenizer32.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer37 = strTokenizer32.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher38 = strTokenizer32.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer39 = strTokenizer32.reset();
        boolean boolean40 = strTokenizer32.isEmptyTokenAsNull();
        org.apache.commons.lang.text.StrMatcher strMatcher41 = strTokenizer32.getDelimiterMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer42 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher41);
        org.apache.commons.lang.text.StrTokenizer strTokenizer43 = org.apache.commons.lang.text.StrTokenizer.getTSVInstance(charArray23);
        org.junit.Assert.assertNotNull(strTokenizer1);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder6);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder11);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strBuilder26);
        org.junit.Assert.assertNotNull(strTokenizer29);
        org.junit.Assert.assertNotNull(strTokenizer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer37);
        org.junit.Assert.assertNotNull(strMatcher38);
        org.junit.Assert.assertNotNull(strTokenizer39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(strMatcher41);
        org.junit.Assert.assertNotNull(strTokenizer43);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test63");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrMatcher strMatcher6 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder5.deleteFirst(strMatcher6);
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder5.append(4);
        org.apache.commons.lang.text.StrBuilder strBuilder13 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder13.setNewLineText("hi!");
        boolean boolean16 = strBuilder15.isEmpty();
        char[] charArray23 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer24 = new org.apache.commons.lang.text.StrTokenizer(charArray23);
        char[] charArray25 = strBuilder15.getChars(charArray23);
        org.apache.commons.lang.text.StrTokenizer strTokenizer29 = new org.apache.commons.lang.text.StrTokenizer("971010", '4', '#');
        org.apache.commons.lang.text.StrMatcher strMatcher30 = strTokenizer29.getIgnoredMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer31 = new org.apache.commons.lang.text.StrTokenizer(charArray23, strMatcher30);
        strBuilder9.getChars(1, 3, charArray23, (int) (short) 0);
        char[] charArray34 = strBuilder9.toCharArray();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertNotNull(strMatcher30);
        org.junit.Assert.assertNotNull(charArray34);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test64");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        java.lang.String str6 = strBuilder3.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder3.insert(0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = strBuilder3.insert((int) (short) 1, "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer13 = strBuilder12.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder15 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder17 = strBuilder15.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder18 = strBuilder17.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher19 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder21 = strBuilder18.replaceAll(strMatcher19, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder21.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder25 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder25.setNewLineText("hi!");
        boolean boolean28 = strBuilder27.isEmpty();
        char[] charArray35 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer36 = new org.apache.commons.lang.text.StrTokenizer(charArray35);
        char[] charArray37 = strBuilder27.getChars(charArray35);
        org.apache.commons.lang.text.StrBuilder strBuilder38 = strBuilder21.append(charArray35);
        org.apache.commons.lang.text.StrBuilder strBuilder41 = strBuilder38.insert(2, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder43 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder45 = strBuilder43.append((float) ' ');
        char[] charArray52 = new char[] { '4', 'a', '4', ' ', '4', 'a' };
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = new org.apache.commons.lang.text.StrTokenizer(charArray52);
        char[] charArray54 = strBuilder45.getChars(charArray52);
        org.apache.commons.lang.text.StrBuilder strBuilder55 = strBuilder41.append(charArray52);
        org.apache.commons.lang.text.StrBuilder strBuilder58 = strBuilder55.setCharAt((int) (byte) 1, '4');
        java.io.Writer writer59 = strBuilder55.asWriter();
        org.apache.commons.lang.text.StrBuilder strBuilder62 = strBuilder12.appendFixedWidthPadRight((java.lang.Object) strBuilder55, 4, '3');
        org.apache.commons.lang.text.StrBuilder strBuilder64 = strBuilder55.deleteAll('a');
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder12);
        org.junit.Assert.assertNotNull(strTokenizer13);
        org.junit.Assert.assertNotNull(strBuilder17);
        org.junit.Assert.assertNotNull(strBuilder18);
        org.junit.Assert.assertNotNull(strBuilder21);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(charArray35);
        org.junit.Assert.assertNotNull(charArray37);
        org.junit.Assert.assertNotNull(strBuilder38);
        org.junit.Assert.assertNotNull(strBuilder41);
        org.junit.Assert.assertNotNull(strBuilder45);
        org.junit.Assert.assertNotNull(charArray52);
        org.junit.Assert.assertNotNull(charArray54);
        org.junit.Assert.assertNotNull(strBuilder55);
        org.junit.Assert.assertNotNull(strBuilder58);
        org.junit.Assert.assertNotNull(writer59);
        org.junit.Assert.assertNotNull(strBuilder62);
        org.junit.Assert.assertNotNull(strBuilder64);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test65");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder4 = strBuilder3.minimizeCapacity();
        org.apache.commons.lang.text.StrMatcher strMatcher5 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder7 = strBuilder4.replaceAll(strMatcher5, "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder9 = strBuilder4.deleteFirst("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder11 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder13 = strBuilder11.setNewLineText("hi!");
        java.lang.String str16 = strBuilder13.substring((int) (short) 0, (int) '4');
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder13.insert(0, '4');
        org.apache.commons.lang.text.StrBuilder strBuilder22 = strBuilder13.insert((int) (short) 1, "");
        java.util.Collection collection23 = null;
        org.apache.commons.lang.text.StrBuilder strBuilder25 = strBuilder13.appendWithSeparators(collection23, "hi!");
        boolean boolean26 = strBuilder9.equals((java.lang.Object) strBuilder13);
        org.apache.commons.lang.text.StrBuilder strBuilder28 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder30 = strBuilder28.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder34 = strBuilder28.appendFixedWidthPadRight(0, (int) '#', '4');
        org.apache.commons.lang.text.StrBuilder strBuilder37 = strBuilder34.replaceFirst('#', 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer40 = new org.apache.commons.lang.text.StrTokenizer("", '#');
        java.lang.String str41 = strTokenizer40.toString();
        org.apache.commons.lang.text.StrMatcher strMatcher42 = strTokenizer40.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder44 = strBuilder34.replaceAll(strMatcher42, "StrTokenizer[not tokenized yet]");
        java.lang.StringBuffer stringBuffer45 = strBuilder44.toStringBuffer();
        org.apache.commons.lang.text.StrBuilder strBuilder48 = strBuilder13.append(stringBuffer45, (int) (short) 1, (int) (short) 10);
        java.lang.String str49 = strBuilder48.getNullText();
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder4);
        org.junit.Assert.assertNotNull(strBuilder7);
        org.junit.Assert.assertNotNull(strBuilder9);
        org.junit.Assert.assertNotNull(strBuilder13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder22);
        org.junit.Assert.assertNotNull(strBuilder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(strBuilder30);
        org.junit.Assert.assertNotNull(strBuilder34);
        org.junit.Assert.assertNotNull(strBuilder37);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "StrTokenizer[not tokenized yet]" + "'", str41.equals("StrTokenizer[not tokenized yet]"));
        org.junit.Assert.assertNotNull(strMatcher42);
        org.junit.Assert.assertNotNull(strBuilder44);
        org.junit.Assert.assertNotNull(stringBuffer45);
        org.junit.Assert.assertNotNull(strBuilder48);
        org.junit.Assert.assertNull(str49);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test66");
        org.apache.commons.lang.text.StrBuilder strBuilder1 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder3 = strBuilder1.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder5 = strBuilder1.append((long) 10);
        org.apache.commons.lang.text.StrBuilder strBuilder8 = strBuilder1.replaceFirst("hi!", "hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder10 = strBuilder1.deleteAll('4');
        org.apache.commons.lang.text.StrBuilder strBuilder12 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder14 = strBuilder12.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder15 = strBuilder14.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder17 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder19 = strBuilder17.setNewLineText("hi!");
        org.apache.commons.lang.text.StrBuilder strBuilder20 = strBuilder19.minimizeCapacity();
        org.apache.commons.lang.text.StrBuilder strBuilder23 = strBuilder14.appendFixedWidthPadLeft((java.lang.Object) strBuilder19, 0, ' ');
        java.io.Writer writer24 = strBuilder14.asWriter();
        org.apache.commons.lang.text.StrTokenizer strTokenizer25 = strBuilder14.asTokenizer();
        org.apache.commons.lang.text.StrMatcher strMatcher26 = strTokenizer25.getQuoteMatcher();
        org.apache.commons.lang.text.StrBuilder strBuilder27 = strBuilder10.deleteAll(strMatcher26);
        int int30 = strBuilder10.lastIndexOf('4', 35);
        org.apache.commons.lang.text.StrBuilder strBuilder32 = strBuilder10.setNullText("");
        java.lang.String str33 = strBuilder10.getNewLineText();
        org.apache.commons.lang.text.StrBuilder strBuilder36 = strBuilder10.insert(0, (double) 100);
        org.apache.commons.lang.text.StrBuilder strBuilder39 = strBuilder10.replaceFirst("32.04a", "");
        org.apache.commons.lang.text.StrBuilder strBuilder41 = new org.apache.commons.lang.text.StrBuilder("");
        org.apache.commons.lang.text.StrBuilder strBuilder43 = strBuilder41.setNewLineText("hi!");
        org.apache.commons.lang.text.StrTokenizer strTokenizer44 = strBuilder43.asTokenizer();
        org.apache.commons.lang.text.StrBuilder strBuilder47 = strBuilder43.appendPadding(1, 'a');
        org.apache.commons.lang.text.StrTokenizer strTokenizer50 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        java.lang.Object obj51 = strTokenizer50.next();
        org.apache.commons.lang.text.StrTokenizer strTokenizer53 = strTokenizer50.setIgnoreEmptyTokens(false);
        org.apache.commons.lang.text.StrTokenizer strTokenizer56 = new org.apache.commons.lang.text.StrTokenizer("hi!", "");
        org.apache.commons.lang.text.StrTokenizer strTokenizer58 = strTokenizer56.setIgnoredChar('#');
        java.lang.String str59 = strTokenizer56.getContent();
        org.apache.commons.lang.text.StrTokenizer strTokenizer61 = strTokenizer56.setQuoteChar('a');
        org.apache.commons.lang.text.StrMatcher strMatcher62 = strTokenizer56.getQuoteMatcher();
        org.apache.commons.lang.text.StrTokenizer strTokenizer63 = strTokenizer53.setDelimiterMatcher(strMatcher62);
        int int65 = strBuilder47.lastIndexOf(strMatcher62, 10);
        org.apache.commons.lang.text.StrBuilder strBuilder67 = strBuilder47.append((float) '#');
        org.apache.commons.lang.text.StrBuilder strBuilder69 = strBuilder67.append(false);
        org.apache.commons.lang.text.StrBuilder strBuilder70 = strBuilder39.append(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder3);
        org.junit.Assert.assertNotNull(strBuilder5);
        org.junit.Assert.assertNotNull(strBuilder8);
        org.junit.Assert.assertNotNull(strBuilder10);
        org.junit.Assert.assertNotNull(strBuilder14);
        org.junit.Assert.assertNotNull(strBuilder15);
        org.junit.Assert.assertNotNull(strBuilder19);
        org.junit.Assert.assertNotNull(strBuilder20);
        org.junit.Assert.assertNotNull(strBuilder23);
        org.junit.Assert.assertNotNull(writer24);
        org.junit.Assert.assertNotNull(strTokenizer25);
        org.junit.Assert.assertNotNull(strMatcher26);
        org.junit.Assert.assertNotNull(strBuilder27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(strBuilder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(strBuilder36);
        org.junit.Assert.assertNotNull(strBuilder39);
        org.junit.Assert.assertNotNull(strBuilder43);
        org.junit.Assert.assertNotNull(strTokenizer44);
        org.junit.Assert.assertNotNull(strBuilder47);
        org.junit.Assert.assertTrue("'" + obj51 + "' != '" + "hi!" + "'", obj51.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer53);
        org.junit.Assert.assertNotNull(strTokenizer58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertNotNull(strTokenizer61);
        org.junit.Assert.assertNotNull(strMatcher62);
        org.junit.Assert.assertNotNull(strTokenizer63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(strBuilder67);
        org.junit.Assert.assertNotNull(strBuilder69);
        org.junit.Assert.assertNotNull(strBuilder70);
    }
}

