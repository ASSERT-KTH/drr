import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                         ", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("############################################################# sun.awt.CGraphicsEnvironment      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment     " + "'", str1.equals("############################################################# sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 34, 80);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 34");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', 32, (int) (byte) -1);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("0.0 0.0 1.0 100.0", "/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("############################################################# sun.awt.CGraphicsEnvironment      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment      " + "'", str1.equals("############################################################# sun.awt.CGraphicsEnvironment      "));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.3       ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (short) 100, (long) 71);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("############################################################# sun.awt.CGraphicsEnvironment     ", "##########/ Library / Java / Java Virtual Machines / jdk 1 . 7 . 0 _ 80 . jdk / Contents / Home / jre / lib / endorsed ##########", "Jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment     " + "'", str3.equals("############################################################# sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", "aaaaaaaaaa...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        java.lang.CharSequence[] charSequenceArray1 = new java.lang.CharSequence[] {};
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.24444444", charSequenceArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray1, "aaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("ORACLEJava Platform API SpecificationCORPORATION", "sun.lwawt.macosx.LWCToolkit", "44444444444444444ORACLE CORPORATION44444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLEJava Platform API SpecificationCORPORATION" + "'", str3.equals("ORACLEJava Platform API SpecificationCORPORATION"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", 3, "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle" + "'", str3.equals("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 9, 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0.0#0.0#1.0#100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0#0.0#1.0#100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa", "                         X OS Mc                         X OS Mc                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857", "MacOSX", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########", "l ss org. ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "44444444444444444444444444444444444444444444444444444444444444444", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1" + "'", str3.equals("0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "RACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("96.0#32.0#35.0#12.0#1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "96.0#32.0#35.0#12.0#1.7" + "'", str1.equals("96.0#32.0#35.0#12.0#1.7"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80", "##########/ Library / Java / Java Virtual Machines / jdk 1 . 7 . 0 _ 80 . jdk / Contents / Home / jre / lib / endorsed ##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("############################################################# sun.awt.CGraphicsEnvironment      ", 3, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment      " + "'", str3.equals("############################################################# sun.awt.CGraphicsEnvironment      "));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.4", "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        int[] intArray6 = new int[] { 0, 9, (-1), (byte) 0, 9, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 26, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 26");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 9 -1 0 9 1" + "'", str8.equals("0 9 -1 0 9 1"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10.14.3", "1.7", 19, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7" + "'", str4.equals("1.7"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.CPrinterJob", "0a9a-1a0a9a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1 0 -1 -1 100", "                                                              ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", 65, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1" + "'", str3.equals("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaa44a4 ", "#####################", "", 26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaa44a4 " + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaa44a4 "));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hie/Library/", "# a   4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 4336);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence) "X86_", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("#aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#a" + "'", str1.equals("#a"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1#0#-1#-1#100", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "Jv Pltform API Specifiction#########################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(94, 8, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10a10a-1", "                                                                                        ", "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a10a-1" + "'", str3.equals("10a10a-1"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/uSERS/SOPHIE", "44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("     ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Platform API Specification", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oRACLE CORPORATIONa10aa10aa1", (int) '#', "US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUoRACLE CORPORATIONa10aa10aa1USUS" + "'", str3.equals("USUoRACLE CORPORATIONa10aa10aa1USUS"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle" + "'", str1.equals("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "1.7.0_80-b151.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "# a   4", (java.lang.CharSequence) "MacOSX                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("uS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Su" + "'", str1.equals("Su"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("ORACLEJava Platform API SpecificationCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEJava Platform API SpecificationCORPORATIO" + "'", str1.equals("ORACLEJava Platform API SpecificationCORPORATIO"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0" + "'", str1.equals("0"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "S", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Mac OS", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("en", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("###4aaa ####", "http://java.oracle.com/", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####" + "'", str3.equals("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction" + "'", str1.equals("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/", "##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("-1 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 " + "'", str1.equals("-1 "));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/", "sophie", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "E", "10.0");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444", "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_80-b151.7.0_80-b151.7.0_80-b15", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version", "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", 3, (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version" + "'", str4.equals("cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(96.0f, 137.0f, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 137.0f + "'", float3 == 137.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("44A4 ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1#0#-1#-1#100", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#100" + "'", str2.equals("1#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#100"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        float[] floatArray5 = new float[] { 96, 32, 35L, 12, 1.7f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.7f + "'", float6 == 1.7f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 96.0f + "'", float7 == 96.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 96.0f + "'", float8 == 96.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 96.0f + "'", float9 == 96.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.7f + "'", float10 == 1.7f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_80", 26, 19);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...14.31.7.0_801..." + "'", str3.equals("...14.31.7.0_801..."));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ines/jdk1.7.0_80.jdk/Cont", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(":                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#-1#0#0#100#0" + "'", str11.equals("1#-1#0#0#100#0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "32a-1a10a12a10a1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0a9a-1a0a9a1", "##########/-Library-/-Java-/-Java-Virtual-Machines-/-jdk--.-7-.-0-_-0-.-jdk-/-Contents-/-Home-/-jre-/-lib-/-endorsed-##########", "4.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "9191" + "'", str3.equals("9191"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4aaa ", 1456);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4aaa " + "'", str2.equals("4aaa "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(23, 10, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        int[] intArray4 = new int[] { 2, (short) 100, 3, 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2a100a3a1" + "'", str6.equals("2a100a3a1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2#100#3#1" + "'", str8.equals("2#100#3#1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11", (java.lang.CharSequence) "104104-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1 -1 0 0 100 0");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("############################################################# sun.awt.CGraphicsEnvironment     ", 0, 96);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment     " + "'", str3.equals("############################################################# sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 6, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44a4 ", (java.lang.CharSequence) "X86_");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4.3", (java.lang.CharSequence) "Oaraclea aCaorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(9L, (long) 137, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 137L + "'", long3 == 137L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Su", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 4336);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        float[] floatArray6 = new float[] { 52L, 2, 25, (-1L), 3L, 2L };
        float[] floatArray13 = new float[] { 52L, 2, 25, (-1L), 3L, 2L };
        float[][] floatArray14 = new float[][] { floatArray6, floatArray13 };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray14);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) 'a', 12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 65, (int) (byte) 10);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (short) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaa44a4 ", (java.lang.CharSequence) "TNEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(21, 65, 84);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 84 + "'", int3 == 84);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.LWCToolkit", "l ss org. ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("7.0_80-b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.0_80-b" + "'", str1.equals("7.0_80-b"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "MacOSX                                                           ", (int) (byte) 10, 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "444444MacOSX                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("444444MacOSX                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) (short) 10, (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) (byte) 10, (-1));
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "              -1                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        char[] charArray5 = new char[] { '4', 'a', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray5);
        java.lang.Class<?> wildcardClass7 = charArray5.getClass();
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4#a# " + "'", str10.equals("4#a# "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray3, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) 'a', (int) (short) 0);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, "1#-1#0#0#100#0", 80, 4336);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 80");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.0" + "'", str7.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 71);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.3       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3       " + "'", str1.equals("1.3       "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                           3.1                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.1" + "'", str1.equals("3.1"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE" + "'", str1.equals("-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 4336, 34);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "9191");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jAVApLATFORMapisPECIFICATION" + "'", str1.equals("jAVApLATFORMapisPECIFICATION"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 92, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 92");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str10.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#aa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 170L + "'", long1.equals(170L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#" + "'", str2.equals("#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("USUSUSUSUSUSUSUSUSUS", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUS" + "'", str2.equals("USUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "h00p://jv7!0i.i7i!b/", (java.lang.CharSequence) "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-B15", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "...14.31.7.0_801...", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444# a   4", "                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "U", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444# a   4" + "'", str4.equals("4444444444444444444# a   4"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44444444", "hie/Librry/", "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444" + "'", str3.equals("44444444"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("J");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                       ", "XOSMcXOSMc", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       " + "'", str3.equals("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10 10 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  # a   4", (java.lang.CharSequence) "1a-1a0a0a100a0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0" + "'", str13.equals("10.0"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4444444444444444444# a   4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444# a   4" + "'", str1.equals("4444444444444444444# a   4"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", "############");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT" + "'", str2.equals("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "UTF-8-UTF-81UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 28, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str12.equals("0.0 0.0 1.0 100.0"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("UTF-8UTF-8UTF-8UTF-8U/Users/sophie", "###", 92);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "9191");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        int[] intArray6 = new int[] { 0, 9, (-1), (byte) 0, 9, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 97, 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 9 -1 0 9 1" + "'", str8.equals("0 9 -1 0 9 1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a9a-1a0a9a1" + "'", str10.equals("0a9a-1a0a9a1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 96, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.7.0_80-b151.7.0_80-b151.7.0_80-b15", "HTTP://JV.ORCLE.COM/", "hi!7.0_80-bhi!7.0_80-bhi!");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;", "                                                              ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 35, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("en");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"en\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10#10#-1", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(" sun.awt.CGraphicsEnvironment      ", "44a4 ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " sun.awt.CGraphicsEnvironment      " + "'", str3.equals(" sun.awt.CGraphicsEnvironment      "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Oaraclea aCaorporation", 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.3       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.CharSequence[] charSequenceArray1 = new java.lang.CharSequence[] {};
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.24444444", charSequenceArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray1, '4', 4336, 96);
        org.junit.Assert.assertNotNull(charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATION", (java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("en", 96, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("2a100a3a1", "1.4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("a10a", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a10a" + "'", str2.equals("a10a"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hie/Library/", "                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("S", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S" + "'", str2.equals("S"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("2.80-b11", "444444444444", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "10.04444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                        ", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', 88, (-1));
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 1.7d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                           3.1                                          ", "0.0a0.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str2.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "         1          4          0          4          -          1          4          -          1  ", (java.lang.CharSequence) "                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        double[] doubleArray5 = new double[] { '#', (byte) 1, 0.0d, (short) -1, 1L };
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4', 35, 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("USUSUSUSUSUSUSUSUSU", 23, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##USUSUSUSUSUSUSUSUSU##" + "'", str3.equals("##USUSUSUSUSUSUSUSUSU##"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 3, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1404-14-14100", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "S");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", (java.lang.CharSequence) "444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1010-1", (java.lang.CharSequence) "###4aaa ####");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1010-1" + "'", charSequence2.equals("1010-1"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("4444444444444", "jAVA pLATFORM api sPECIFICATION", "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444" + "'", str3.equals("4444444444444"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0.9", "OrHcle CorporHtion", "1#0#-1#-1#100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty(" # a   4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# a   4" + "'", str1.equals("# a   4"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE", 23, "l ss org. ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE" + "'", str3.equals("-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("##USUSUSUSUSUSUSUSUSU##");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0" + "'", str8.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("444444444...", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaa..." + "'", str3.equals("aaaaaaaaa..."));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "eihpos");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1Java HotSpo");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("ORACLEJava Platform API SpecificationCORPORATION", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLEJava Platform API SpecificationCORPORATION" + "'", str2.equals("ORACLEJava Platform API SpecificationCORPORATION"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray3, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.0" + "'", str7.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/uSERS/SOPHIE", 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/..." + "'", str3.equals("/uSERS/..."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ORACLEJava Platform API SpecificationCORPORATIO", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLEJv Pltform API SpecifictionCORPORATIO" + "'", str2.equals("ORACLEJv Pltform API SpecifictionCORPORATIO"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 1, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 80, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("10#10#-110#10#-110#10#-110#10#-110#1CORPORATIONAPHICSENVIRONMENT10#10#-110#10#-110#10#-110#10#-110#1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ORACLE CORPORATION", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("   -1     ", "0.0a0.0a1.0a100.0", 9);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.LWCToolkit", "4aaa ", "MacOSX                                                           ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str4.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "24.80-b11", "-14");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str3.equals("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT" + "'", str8.equals("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ORACLE CORPORATION", "Oaraclea aCaorporation", "444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4RA4LE444RP4RATI4N" + "'", str3.equals("4RA4LE444RP4RATI4N"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 35, "OrHcle CorporHtion");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OrHcle CorporHtioOrHcle CorporHtion" + "'", str3.equals("OrHcle CorporHtioOrHcle CorporHtion"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "              -1                ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class [C", (java.lang.CharSequence) "7.0_80-b");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "ORACLE#CORPORATION", (java.lang.CharSequence) "51.0", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("us");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7" + "'", str1.equals("/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str6 = javaVersion5.toString();
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        java.lang.String str12 = javaVersion10.toString();
        boolean boolean13 = javaVersion5.atLeast(javaVersion10);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.3" + "'", str12.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "444444MacOSX                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0 9 -1 0 9 1", "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 2, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1" + "'", str4.equals("0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("X OS Mc", "2#100#3#1", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X OS Mc" + "'", str3.equals("X OS Mc"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("##########/444444444444444444444444", 4336, 93);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########/444444444444444444444444" + "'", str3.equals("##########/444444444444444444444444"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0.9", "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0" + "'", str2.equals("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            " + "'", str2.equals("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            "));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("class [C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class [C" + "'", str1.equals("class [C"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44a4 ", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1 0 -1 -1 100", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "1 0 -1 -1 100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hie/Librry/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("         1          4          0          4          -          1          4          -          1  ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         1          4          0          4          -          1          4          -          1  " + "'", str2.equals("         1          4          0          4          -          1          4          -          1  "));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        char[] charArray5 = new char[] { '4', 'a', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray5);
        java.lang.Class<?> wildcardClass7 = charArray5.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "   -1     ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4aaa " + "'", str9.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1", "cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("324-141041241041", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "324-141041241041" + "'", str2.equals("324-141041241041"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.3", "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE" + "'", str1.equals("SOPHIE"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUS", (java.lang.CharSequence) "                                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#-1#0#0#100#0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8-UTF-81UTF-8", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0", 92, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                           0" + "'", str3.equals("                                                                                           0"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("SUN.AWT.cgRAPHICSeNVIRONMENT", 0, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AW..." + "'", str3.equals("SUN.AW..."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("2#100#3#1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUS", charSequence1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#aa", 93, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(94, (int) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "         ", (java.lang.CharSequence) "0.040.041.04100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("2#100#3#1", (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "ORACLEJava Platform API SpecificationCORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("44A4 ", "         1          4          0          4          -          1          4          -          1  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A4 " + "'", str2.equals("A4 "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("2a100a3a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2a100a3a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("###4aaa ####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###4aaa ####" + "'", str1.equals("###4aaa ####"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sers/so", "oRACLE#CORPORATION");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80", "-1 ", "10.04444444444444444444444444444");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/4444444444444444444444444444444444", "JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("3.1", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.1" + "'", str2.equals("3.1"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("MIXED MODE", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MIXED" + "'", str2.equals("MIXED"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!7.0_80-bhi!7.0_80-bhi!", 31, "                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   hi!7.0_80-bhi!7.0_80-bhi!   " + "'", str3.equals("   hi!7.0_80-bhi!7.0_80-bhi!   "));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "M", 12, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', (int) (short) 100, 0);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str9.equals("0.0a0.0a1.0a100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 100.0f + "'", float14 == 100.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1404-14-14100" + "'", str10.equals("1404-14-14100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      ", 1, "9191");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      " + "'", str3.equals("s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaa...", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaa...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa..." + "'", str2.equals("aaaaaaaaa..."));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80-b15", "oRACLE CORPORATIONa10aa10aa1JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "h00p://jv7!0i.i7i!b/", (java.lang.CharSequence) "444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28, (double) 0, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "", "444444444444444444444444-1 4444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10 10 -1", "4.3", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("32a-1a10a12a10a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32a-1a10a12a10a1" + "'", str1.equals("32a-1a10a12a10a1"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                               UTF-8-UTF-81UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########", "1.2", 80);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########" + "'", str3.equals("########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oracle corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "S EEEEEEEEEEEEEEEEEEEEEEE...", (java.lang.CharSequence) "Java Virtual Machine Specification                                                                  ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10#10#-110#10#-110#10#-110#10#-110#1CORPORATIONAPHICSENVIRONMENT10#10#-110#10#-110#10#-110#10#-110#1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1", 71);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "###");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1a-1a0a0a100a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT    ", (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "01EEEEEEEEEEEEEEEERACLE CORPORATIONAPHIC0ENVIRONMENT", (java.lang.CharSequence) "                                              Mc OS X                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("              -1                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "              -1                " + "'", str1.equals("              -1                "));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 34, 0L, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Jv Pltform API Specifiction", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv Plt" + "'", str2.equals("Jv Plt"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 65, 1.0f, (float) 9L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) (short) 0, (int) (short) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', 9, 1);
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 100 + "'", short17 == (short) 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("n.lwawt.macosx.CPrinterJosun.l", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) '4', (int) (byte) 10);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "ORACLEJava Platform API SpecificationCORPORATION", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("0#1.0#0.0#-1.0#1.0", 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0#1.0#0.0#-1.0#1.0" + "'", str3.equals("0#1.0#0.0#-1.0#1.0"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "us", (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("UTF-8-UTF-81UTF-8", "uS", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTF-8-UTF-81UTF-8" + "'", str4.equals("UTF-8-UTF-81UTF-8"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "4aaa ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "SUN.AW...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0a9a-1a0a9a1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", (java.lang.CharSequence) "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(charArray2, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "     ", charArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a');
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("############################################################# sun.awt.CGraphicsEnvironment      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(13, 93, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 93 + "'", int3 == 93);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("S");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S" + "'", str1.equals("S"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 61 + "'", int3 == 61);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1#0#-1#-1#100", (java.lang.CharSequence) "/uSERS/...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10.04444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("eeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("############################################################# sun.awt.CGraphicsEnvironment     ", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment     " + "'", str2.equals("############################################################# sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "USUoRACLE CORPORATIONa10aa10aa1USUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.lwawt.macosx.CPrinterJosun.l");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                2.80-b11", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 1456);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", 0, "2#100#3#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            " + "'", str3.equals("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                            ", 34);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("##########/ Library / Java / Java Virtual Machines / jdk 1 . 7 . 0 _ 80 . jdk / Contents / Home / jre / lib / endorsed ##########", "1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("jAVA pLATFORM api sPECIFICATION", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.7", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("44444444444444444ORACLE CORPORATION44444444444444444", "2a100a3a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0.0a0.0a1.0a100.0", (java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaa...", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("OrHcle CorporHtion", "Mac OS X", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1010-1", 3, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "rH le CorporHtion" + "'", str5.equals("rH le CorporHtion"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT", 137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1#0#-1#-1#100", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", "-1-1-1", 28);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT" + "'", str3.equals("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            " + "'", str2.equals("                            "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", (java.lang.CharSequence) "Mc OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "1.7.0_80-b15", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("    :    ", '#');
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_64", "                         ", (int) '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("TNEMNORIVNeSCIHPARgc.TWA.NUS", strArray5, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str6.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TNEMNORIVNeSCIHPARgc.TWA.NUS" + "'", str16.equals("TNEMNORIVNeSCIHPARgc.TWA.NUS"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "USUSUSUSUSUSUSUSUSU", 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 52, 92);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4aaa ", "hie/Library/", 137, 93);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4aaa hie/Library/" + "'", str4.equals("4aaa hie/Library/"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0 9 -1 0 9 1", "OrHcle CorporHtion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 9 -1 0 9 1" + "'", str2.equals("0 9 -1 0 9 1"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "44444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("MacOSX                                                           ", "x86_64", 25);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Jv Pltform API Specifiction", "-1");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "##USUSUSUSUSUSUSUSUSU##", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N4FC0000GN/T/" + "'", str1.equals("N4FC0000GN/T/"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "m");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", "cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("4444444444444444444# a   4", 21, "1 100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444# a   4" + "'", str3.equals("4444444444444444444# a   4"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJo", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java Virtual Machine Specification");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("SUN.AWT.cgRAPHICSeNVIRONMENT", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "IRONMENT" + "'", str2.equals("IRONMENT"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Jv Plt", "Java Platform API Specification", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "S EEEEEEEEEEEEEEEEEEEEEEE...", (java.lang.CharSequence) "1010-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...14.31.7.0_801...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("51.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1 == 51.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":                         ", (java.lang.CharSequence) "444444444...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        char[] charArray4 = new char[] { '#', '4', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10a10a-1", charArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ', 20, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1a10a1", "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "0.0 0.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...0.." + "'", str3.equals("...0.."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                       ", "", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!7.0_80-bhi!7.0_80-bhi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "4aaa ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        char[] charArray6 = new char[] { '4', 'a', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        java.lang.Class<?> wildcardClass8 = charArray6.getClass();
        java.lang.Class<?> wildcardClass9 = charArray6.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0 9 -1 0 9 1", "TNEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        float[] floatArray6 = new float[] { 96.0f, (byte) 1, 1.7f, 32L, 170L, (short) -1 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("oRACLE CORPORATION", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("U", "Java(TM) SE Runtime Environment", "n.lwawt.macosx.CPrinterJosun.l");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "U" + "'", str3.equals("U"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa", "1.3");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "oRACLE#CORPORATION");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("   hi!7.0_80-bhi!7.0_80-bhi!   ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        char[] charArray5 = new char[] { '4', 'a', ' ' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1#-1#0#0#100#0", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', 92, 92);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1a10a1", (java.lang.CharSequence) "2.80-b11                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                       ", "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT", (java.lang.CharSequence) "S EEEEEEEEEEEEEEEEEEEEEEE...", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("N", (int) '#', 4336);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#-1#0#0#100#0" + "'", str10.equals("1#-1#0#0#100#0"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####", "   hi!7.0_80-bhi!7.0_80-bhi!   ", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("EDOM DEXIM", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M" + "'", str2.equals("M"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa" + "'", str1.equals("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        char[] charArray7 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 0, (int) (byte) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) 'a', (int) '4');
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8-UTF-81UTF-8", charArray7);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', 0, 5);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "  # a   4" + "'", str21.equals("  # a   4"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/4444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444444444...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "7.0_80-b", 32, 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "                                           3.1                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15", (java.lang.CharSequence) "SUN.AW...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4", (java.lang.CharSequence) "104104-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.5");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444444444", (float) 21);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.44444448E8f + "'", float2 == 4.44444448E8f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10#10#-1", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10#10#-1" + "'", str3.equals("10#10#-1"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray4, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, 'a', 5, 1);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "51.0" + "'", str8.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        float[] floatArray5 = new float[] { 96, 32, 35L, 12, 1.7f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.7f + "'", float6 == 1.7f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.7f + "'", float7 == 1.7f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "96.0432.0435.0412.041.7" + "'", str9.equals("96.0432.0435.0412.041.7"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE", (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("sophie", strArray1, strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "N", (int) (byte) 10, 92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sophie" + "'", str5.equals("sophie"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("OrHcle CorporHtioOrHcle CorporHtion", "          ", 71, (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OrHcle CorporHtioOrHcle CorporHtion          " + "'", str4.equals("OrHcle CorporHtioOrHcle CorporHtion          "));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1a-1a0a0a100a0" + "'", str11.equals("1a-1a0a0a100a0"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        char[] charArray8 = new char[] { '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "          ", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 18 + "'", int15 == 18);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass7 = intArray3.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 31, (-1));
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int16 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a10a-1" + "'", str9.equals("10a10a-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Oaraclea aCaorporation", "#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0 9 -1 0 9 1", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "USUoRACLE CORPORATIONa10aa10aa1USUS", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("#####################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#####################" + "'", str1.equals("#####################"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { '4', 'a', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        java.lang.Class<?> wildcardClass8 = charArray6.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 0, (int) (byte) -1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4RA4LE444RP4RATI4N", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4aaa " + "'", str10.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                  sun.lwawt.macosx.CPrinterJob                                   ", "############################################################# sun.awt.CGraphicsEnvironment     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  sun.lwawt.macosx.CPrinterJob                                   " + "'", str2.equals("                                  sun.lwawt.macosx.CPrinterJob                                   "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("RACLE CORPORATION", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "44444444444444444ORACLE CORPORATION44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1Java HotSpo", "# 4  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1Java HotSpo" + "'", str2.equals("1Java HotSpo"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4#a# ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USUSUSUSUSUSUSUSUSUS");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version", (java.lang.CharSequence) "S", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VM", "...0..", 19);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                ", (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a10a", "# a   4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a10a" + "'", str2.equals("a10a"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###" + "'", str1.equals("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("RACLE CORPORATION", (int) (short) 0, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RACLE CORPORATION" + "'", str3.equals("RACLE CORPORATION"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "/", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("44444444444444444ORACLE CORPORATION44444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#a01a#a-a1a#a0a#a0a#a100a#aOaracle" + "'", str2.equals("a#a01a#a-a1a#a0a#a0a#a100a#aOaracle"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444" + "'", str1.equals("444444444444"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm" + "'", str3.equals("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "S", "1Java HotSpo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "104104-1" + "'", str9.equals("104104-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10a10a-1" + "'", str11.equals("10a10a-1"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("X OS Mc");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("JavaPlatformAPISpecification", "  # a   4", "0.040.041.04100.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaPlatformAPISpecification" + "'", str3.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", "                           ", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4aaa hie/Library/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", "Mac OS X");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "         ", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                  sun.lwawt.macosx.CPrinterJob                                   " + "'", str1.equals("                                  sun.lwawt.macosx.CPrinterJob                                   "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.3       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("RACLE CORPORATION", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "    :    ", (java.lang.CharSequence) "###");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str6 = javaVersion5.toString();
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str9 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", (java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}

