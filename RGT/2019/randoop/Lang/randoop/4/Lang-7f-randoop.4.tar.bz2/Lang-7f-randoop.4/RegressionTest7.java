import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ines/jdk1.7.0_80.jdk/Cont", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#####################", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.CharSequence[] charSequenceArray3 = new java.lang.CharSequence[] { "http://jv.orcle.com/", "Mc OS X" };
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.7.0_80-b15", charSequenceArray3);
        java.lang.Class<?> wildcardClass5 = charSequenceArray3.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) charSequenceArray3, '#');
        org.junit.Assert.assertNotNull(charSequenceArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "http://jv.orcle.com/#Mc OS X" + "'", str7.equals("http://jv.orcle.com/#Mc OS X"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", "ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0" + "'", str2.equals("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt", "44444444444444444444444444444444444444h   ://java.  ac  .c m/444444444444444444444444444444444444444", "hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt" + "'", str4.equals("sun.lwawt"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Jv Pltform AP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0" + "'", str11.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "rH le CorporHtion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sophie", 4336, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("e", "Jv Plt");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hie/Librry/", (java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("   -1     ", (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("44A4 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1", "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM", 65);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "oRACLE CORPORATIONa10aa10aa1JavaPlatformAPISpecification", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 56 + "'", int5 == 56);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 100, 12);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str19.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80-b15", "N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.24444444", 88);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.24444444" + "'", str2.equals("1.24444444"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  # a   4", "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                  1.7.0_80-b151.3", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, 0.0f, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10a10a-1", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("X86_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_" + "'", str1.equals("X86_"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", "Java Virtual Machine Specification                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("US", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "http://jv.orcle.com/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US" + "'", str4.equals("US"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("############################################################# sun.awt.CGraphicsEnvironment     ", "a10a", "444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment     " + "'", str3.equals("############################################################# sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1", (int) (byte) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1" + "'", str3.equals("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sers/so", 32, "  # a   4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  # a   4  # a   4  # a  sers/so" + "'", str3.equals("  # a   4  # a   4  # a  sers/so"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "Java Virtual Machine Specification                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str2.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray3, '4', (int) (short) 1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 32, (-1));
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("44A4 ", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44A4 " + "'", str3.equals("44A4 "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 96 + "'", int1 == 96);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) (short) 1, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specification", "0#1.0#0.0#-1.0#1.0", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b151.3", 13, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("n.lwawt.macosx.CPrinterJosun.l");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixJd modJ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray3, strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.0" + "'", str7.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("MacOSX                                                           ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        char[] charArray8 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', 0, (int) (byte) 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray8);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (byte) 100, (int) '4');
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10.14.3", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b11", 25, "1.2");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b111.21.21.21.21.21" + "'", str3.equals("24.80-b111.21.21.21.21.21"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "##USUSUSUSUSUSUSUSUSU##");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.CharSequence[] charSequenceArray0 = new java.lang.CharSequence[] {};
        java.lang.CharSequence[][] charSequenceArray1 = new java.lang.CharSequence[][] { charSequenceArray0 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charSequenceArray1);
        org.junit.Assert.assertNotNull(charSequenceArray0);
        org.junit.Assert.assertNotNull(charSequenceArray1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("oRACLE CORPORATIONa10aa10aa1JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a", (java.lang.CharSequence) "4aaa hie/Library/", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "sun.lwawt.macosx.CPrinterJosun.l", (int) (short) 100);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJosun.l", (java.lang.CharSequence[]) strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.24444444", strArray2, strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.24444444" + "'", str9.equals("1.24444444"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EIHPOS/SRESu/" + "'", str1.equals("EIHPOS/SRESu/"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 52, (int) (short) 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/uSERS/...", (java.lang.CharSequence) "9191");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                         X OS Mc                         X OS Mc                         ", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 1456);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#" + "'", str3.equals("#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str5.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) 'a', 12);
        float float18 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float19 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 2, 4336);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0" + "'", str11.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str11.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.040.041.04100.0" + "'", str13.equals("0.040.041.04100.0"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0.040.041.04100.0", "104104-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.040.041.04100.0" + "'", str2.equals("0.040.041.04100.0"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("oRACLE#CORPORATION", "...14.31.7.0_801...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE#CORPORATION" + "'", str2.equals("oRACLE#CORPORATION"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("##########/ Library / Java / Java Virtual Machines / jdk 1 . 7 . 0 _ 80 . jdk / Contents / Home / jre / lib / endorsed ##########");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########" + "'", str3.equals("##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("http://jv.orcle.com/", "oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://jv.orcle.com/" + "'", str2.equals("http://jv.orcle.com/"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1Java HotSpo", "oracle corporatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                       ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(19, (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########", (java.lang.CharSequence) "Jv Pltform API Specifiction#########################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                2.80-b11", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11" + "'", str2.equals("                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                             10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ", (java.lang.CharSequence) "444444MacOSX                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u" + "'", str1.equals("u"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1-1-1", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1-1-1" + "'", str2.equals("-1-1-1"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444444444444442a100a3a1444http://java.oracle.com/444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", (java.lang.CharSequence) "sophie", 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..." + "'", str2.equals("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..."));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass7 = intArray3.getClass();
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0.0 0.0 1.0 100.0", "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str3.equals("0.0 0.0 1.0 100.0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java Platform API Specification", (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("l ss org. ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ":", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "9191", (java.lang.CharSequence) "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1 ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 " + "'", str2.equals("-1 "));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      ", "    :    ", 31);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", "#", 6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 26L, (float) 34, (float) 88);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 26.0f + "'", float3 == 26.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) 'a', 12);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 2, 2);
        float float22 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0.040.041.04100.0" + "'", str24.equals("0.040.041.04100.0"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("US", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                              Mc OS X                                               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE", "jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE" + "'", str2.equals("-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "HTTP://JV.ORCLE.COM/");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", "0 9 -1 0 9 1", 94);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "IRONMENT", 0, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857", (java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", "Su", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44444444", 34, "          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                          44444444" + "'", str3.equals("                          44444444"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4aaa " + "'", str1.equals("4aaa "));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(65L, (long) 35, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("U", "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        int[] intArray3 = new int[] { (byte) 0, 28, (short) 1 };
        int[] intArray7 = new int[] { (byte) 0, 28, (short) 1 };
        int[] intArray11 = new int[] { (byte) 0, 28, (short) 1 };
        int[][] intArray12 = new int[][] { intArray3, intArray7, intArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray12, "          ");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray12, "Mac OS X");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray12);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray12);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass7 = intArray3.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a10a-1" + "'", str9.equals("10a10a-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("e", "1.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "2a100a3a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "   -1     ", (java.lang.CharSequence) "2a100a3a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("              -1                ", 65, "oracle corporatio");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle corporatiooracle corporati              -1                " + "'", str3.equals("oracle corporatiooracle corporati              -1                "));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://jv.orcle.com/", (float) 92);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 92.0f + "'", float2 == 92.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", (java.lang.CharSequence) ":                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass10 = javaVersion9.getClass();
        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass12 = javaVersion9.getClass();
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean14 = javaVersion4.atLeast(javaVersion9);
        java.lang.String str15 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass18 = javaVersion17.getClass();
        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass22 = javaVersion21.getClass();
        boolean boolean23 = javaVersion20.atLeast(javaVersion21);
        java.lang.Class<?> wildcardClass24 = javaVersion21.getClass();
        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        boolean boolean26 = javaVersion16.atLeast(javaVersion21);
        boolean boolean27 = javaVersion9.atLeast(javaVersion16);
        boolean boolean28 = javaVersion0.atLeast(javaVersion16);
        java.lang.String str29 = javaVersion16.toString();
        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.4" + "'", str15.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1.3" + "'", str29.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                       ", 56, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 1, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) (short) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444442a100a3a1444http://java.oracle.com/444444444444444444444444444444444444444", "#####################");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 21, 8);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-14", "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..." + "'", str2.equals("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..."));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.0", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0" + "'", str3.equals("10.0"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass7 = intArray3.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', (int) (byte) 100, 35);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 96, (int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10#10#-1" + "'", str14.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        int[] intArray4 = new int[] { 2, (short) 100, 3, 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.Class<?> wildcardClass8 = intArray4.getClass();
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2a100a3a1" + "'", str6.equals("2a100a3a1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "4aaa ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("         1          4          0          4          -          1          4          -          1  ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         1          4          0          4          -          1          4          -          1  " + "'", str2.equals("         1          4          0          4          -          1          4          -          1  "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "#", (java.lang.CharSequence) "44444444444444444ORACLE CORPORATION44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1a-1a0a0a100a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15", (java.lang.CharSequence) "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("324-141041241041", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 26);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, (long) 4336, (long) 23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4336L + "'", long3 == 4336L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSU", "1 0 -1 -1 100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.2f, (float) 8, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.2f + "'", float3 == 1.2f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "############", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 1L, 96.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("OrHcle CorporHtioOrHcle CorporHtion          ", "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment", "M");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                          44444444", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7", "104104-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "  # a   4", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "EIHPOS/SRESu/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaaaa44a4 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaa44a4 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "###4aaa ####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str6 = javaVersion2.toString();
        java.lang.String str7 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("51.0", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 27, 9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0" + "'", str4.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Mc OS X", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M" + "'", str2.equals("M"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        java.lang.Class<?> wildcardClass9 = charArray7.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray7);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 0, (int) (byte) -1);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                             10.14.3", charArray7);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "   -1     ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4aaa " + "'", str13.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###", 92, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###" + "'", str3.equals("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("0.15", "Jv Pltform API Specifiction#########################Mc OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.15" + "'", str2.equals("0.15"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########" + "'", str1.equals("########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version", (java.lang.CharSequence) "1.3       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("###");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "35.0#1.0#0.0#-1.0#1.0", (java.lang.CharSequence) "mixJd modJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X" + "'", str1.equals("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION", "Mac OS X");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oracle corporation", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("01EEEEEEEEEEEEEEEERACLE CORPORATIONAPHIC0ENVIRONMENT", (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "u", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("us", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.2", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "oRACLE CORPORATION", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("n.lwawt.macosx.CPrinterJosun.l");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n.lwawt.macosx.CPrinterJosun.l\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("MIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        int[] intArray2 = new int[] { (byte) 1, (short) 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', 1, 0);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_80", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444", 84);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("RACLE CORPORATION", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "32a-1a10a12a10a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1#0#-1#-1#100", "US");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1#0#-1#-1#100" + "'", str4.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.J" + "'", str1.equals("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.J"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("  # a   4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  # a   4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "-14", 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION" + "'", str1.equals("ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '#');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("   -1     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.2", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "S EEEEEEEEEEEEEEEEEEEEEEE...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "OrHcle CorporHtion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa", 28, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a10a-1" + "'", str9.equals("10a10a-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10a10a-1" + "'", str12.equals("10a10a-1"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "sun.awt.cgraphicsenvironment", 94);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 32, "                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", (-1), '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            " + "'", str3.equals("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 1, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("MacOSX                                                           ", "##########/444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) "4444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass10 = javaVersion9.getClass();
        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass12 = javaVersion9.getClass();
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean14 = javaVersion4.atLeast(javaVersion9);
        java.lang.String str15 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass18 = javaVersion17.getClass();
        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass22 = javaVersion21.getClass();
        boolean boolean23 = javaVersion20.atLeast(javaVersion21);
        java.lang.Class<?> wildcardClass24 = javaVersion21.getClass();
        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        boolean boolean26 = javaVersion16.atLeast(javaVersion21);
        boolean boolean27 = javaVersion9.atLeast(javaVersion16);
        boolean boolean28 = javaVersion2.atLeast(javaVersion9);
        java.lang.String str29 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion30 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str31 = javaVersion30.toString();
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean33 = javaVersion30.atLeast(javaVersion32);
        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass36 = javaVersion35.getClass();
        boolean boolean37 = javaVersion34.atLeast(javaVersion35);
        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion39 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass40 = javaVersion39.getClass();
        boolean boolean41 = javaVersion38.atLeast(javaVersion39);
        java.lang.Class<?> wildcardClass42 = javaVersion39.getClass();
        boolean boolean43 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion39);
        boolean boolean44 = javaVersion34.atLeast(javaVersion39);
        java.lang.String str45 = javaVersion39.toString();
        org.apache.commons.lang3.JavaVersion javaVersion46 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion47 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass48 = javaVersion47.getClass();
        boolean boolean49 = javaVersion46.atLeast(javaVersion47);
        org.apache.commons.lang3.JavaVersion javaVersion50 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion51 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass52 = javaVersion51.getClass();
        boolean boolean53 = javaVersion50.atLeast(javaVersion51);
        java.lang.Class<?> wildcardClass54 = javaVersion51.getClass();
        boolean boolean55 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion51);
        boolean boolean56 = javaVersion46.atLeast(javaVersion51);
        boolean boolean57 = javaVersion39.atLeast(javaVersion46);
        boolean boolean58 = javaVersion30.atLeast(javaVersion46);
        java.lang.String str59 = javaVersion46.toString();
        boolean boolean60 = javaVersion2.atLeast(javaVersion46);
        org.apache.commons.lang3.JavaVersion javaVersion61 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str62 = javaVersion61.toString();
        boolean boolean63 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion61);
        boolean boolean64 = javaVersion2.atLeast(javaVersion61);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.4" + "'", str15.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1.5" + "'", str29.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion30 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion30.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.2" + "'", str31.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion39 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion39.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1.4" + "'", str45.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion46 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion46.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion47 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion47.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + javaVersion50 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion50.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion51 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion51.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1.3" + "'", str59.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + javaVersion61 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion61.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1.3" + "'", str62.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "X86_", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaa...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaa...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.3       ", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3       " + "'", str3.equals("1.3       "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#100", (java.lang.CharSequence) "cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0a9a-1a0a9a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1a10a1", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("U");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0, (float) 26, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 26.0f + "'", float3 == 26.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT    ", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 4336);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("e", "", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "e" + "'", str5.equals("e"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Jv Pltform AP", (java.lang.CharSequence) "0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophie", "                         X OS Mc                         X OS Mc                         ", "l ss org. ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("444444444444444444444444444442a100a3a1444http://java.oracle.com/444444444444444444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("X86_", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("N");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"N\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 97, 3);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) 'a', 6);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "############################################################# sun.awt.CGraphicsEnvironment     ", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("JavaPlatformAPISpecification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "9191", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                             10.14.3", "OrHcle CorporHtioOrHcle CorporHtion          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa                       " + "'", str2.equals("                       aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa                       "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 1, 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("9191", "444447.0_80-b");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("############", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############" + "'", str2.equals("############"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hie/Library/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a10a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.24444444", charSequenceArray2);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa", charSequenceArray2);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray2);
        org.junit.Assert.assertNotNull(charSequenceArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 3, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) 'a', 12);
        float float18 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', 19, 1);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', 93, 0);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str20.equals("0.0a0.0a1.0a100.0"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0" + "'", str13.equals("10.0"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "oRACLE#CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("HTTP://JV.ORCLE.COM/", "44444444444444444444444444444444444444444444444444444444444444444", 93, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HTTP://JV.ORCLE.COM/44444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("HTTP://JV.ORCLE.COM/44444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                              ", "-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Orcle", "oRACLE CORPORATION");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0.040.041.04100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.040.041.04100.0" + "'", str1.equals("0.040.041.04100.0"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("44444444444444444ORACLE CORPORATION44444444444444444", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION44444444444444444" + "'", str2.equals("44444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION4444444444444444444444444444444444ORACLE CORPORATION44444444444444444"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("SUN.AW...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sUN.AW..." + "'", str1.equals("sUN.AW..."));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', (int) (byte) 100, 35);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', (int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1404-14-14100" + "'", str13.equals("1404-14-14100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4aaa ", "1a0a-1a-1a100");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########", 29, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "35.0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 35, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1.equals((-1.0f)));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("4444444444444444444# a   4", "/uSERS/...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444# a   4" + "'", str2.equals("4444444444444444444# a   4"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 93, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str3.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "              -1                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaa", (java.lang.CharSequence) "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SUN.AWT.cgRAPHICSeNVIRONMENT", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("u");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "MacOSX                                                           ", (java.lang.CharSequence) "1.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_80", 71);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.7.0_80", "");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("S", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "S" + "'", str7.equals("S"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.2f, (float) 61, (float) 96);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.2f + "'", float3 == 1.2f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..." + "'", str1.equals("XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "u");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "MacOSX                                                           ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#-1#0#0#100#0" + "'", str11.equals("1#-1#0#0#100#0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1 -1 0 0 100 0" + "'", str13.equals("1 -1 0 0 100 0"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "n.lwawt.macosx.CPrinterJosun.l", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/uSERS/SOPHIE" + "'", charSequence2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("SOPHIE", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " # a   4", "   -1     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 96, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################################################################" + "'", str3.equals("################################################################################################"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(26, 65, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 170L, (double) 10, (double) 88L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jre/lib/endorsed", "IRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#1001#0#-1#-1#100", (double) 23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.0d + "'", double2 == 23.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                        ", "J", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                        " + "'", str3.equals("                                                                                        "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("32a-1a10a12a10a1", (long) 29);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 29L + "'", long2 == 29L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0a9a-1a0a9a1", "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a9a-1a0a9a1" + "'", str2.equals("0a9a-1a0a9a1"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        double[] doubleArray6 = new double[] { 92, 0.0f, 'a', 21, '#', 88L };
        double[] doubleArray13 = new double[] { 92, 0.0f, 'a', 21, '#', 88L };
        double[][] doubleArray14 = new double[][] { doubleArray6, doubleArray13 };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "hie/Library/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "                        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("X86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Jv Pltform AP");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0", "aaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "###4aaa ####");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", charSequence2.equals("                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 100L, 4336L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4336L + "'", long3 == 4336L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MIXED MODE", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MODE" + "'", str3.equals("MIXED MODE"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1a0a-1a-1a100" + "'", str12.equals("1a0a-1a-1a100"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1a10a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a10a1" + "'", str1.equals("1a10a1"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    :    ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle corporationA10AA10AA1Oracle corporationA10AA10AA1Oracle corporationA10AA10AA" + "'", str1.equals("Oracle corporationA10AA10AA1Oracle corporationA10AA10AA1Oracle corporationA10AA10AA"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "01EEEEEEEEEEEEEEEERACLE CORPORATIONAPHIC0ENVIRONMENT");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("  # a   4  # a   4  # a  sers/so", "e", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  # a   4  # a   4  # a  srs/so" + "'", str3.equals("  # a   4  # a   4  # a  srs/so"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', (int) (byte) 0, (int) (byte) 1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (-1), 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "14-14040410040" + "'", str14.equals("14-14040410040"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1a-1a0a0a100a0" + "'", str16.equals("1a-1a0a0a100a0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9L, (float) 2, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 34, 29L, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 34L + "'", long3 == 34L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaa44a4 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("USUoRACLE CORPORATIONa10aa10aa1USUS", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaa44a4 ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", (java.lang.CharSequence) "                            ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("96.0#32.0#35.0#12.0#1.7", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", "OrHcle CorporHtioOrHcle CorporHtion", "eeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, 32, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "##########/ Library / Java / Java Virtual Machines / jdk 1 . 7 . 0 _ 80 . jdk / Contents / Home / jre / lib / endorsed ##########", (java.lang.CharSequence) "0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment    ", 4336, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str3.equals("sun.awt.CGraphicsEnvironment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("us");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0a0.0a1.0a100.0", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.040.041.04100.0" + "'", str3.equals("0.040.041.04100.0"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "1#0#-1#-1#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 27, 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1" + "'", str1.equals("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444...", "http://jv.orcle.com/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaa", "44444444444444444444444444444444444444h   ://java.  ac  .c m/444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#-1#0#0#100#0" + "'", str1.equals("#-1#0#0#100#0"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sUN.AW...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sUN.AW...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;", "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HTTP://JV.ORCLE.COM/", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                               UTF-8-UTF-81UTF-8", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        char[] charArray6 = new char[] { '4', 'a', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        java.lang.Class<?> wildcardClass8 = charArray6.getClass();
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "444444444444444444444444-1 4444444444444444444444444", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "44444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("...14.31.7.0_801...", "hi!7.0_80-bhi!7.0_80-bhi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...14.31.7.0_801..." + "'", str2.equals("...14.31.7.0_801..."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X", (java.lang.CharSequence) "http://java.oracle.com/", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#", (java.lang.CharSequence) "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass10 = javaVersion9.getClass();
        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass12 = javaVersion9.getClass();
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean14 = javaVersion4.atLeast(javaVersion9);
        java.lang.String str15 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass18 = javaVersion17.getClass();
        boolean boolean19 = javaVersion16.atLeast(javaVersion17);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass22 = javaVersion21.getClass();
        boolean boolean23 = javaVersion20.atLeast(javaVersion21);
        java.lang.Class<?> wildcardClass24 = javaVersion21.getClass();
        boolean boolean25 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion21);
        boolean boolean26 = javaVersion16.atLeast(javaVersion21);
        boolean boolean27 = javaVersion9.atLeast(javaVersion16);
        boolean boolean28 = javaVersion2.atLeast(javaVersion9);
        java.lang.String str29 = javaVersion2.toString();
        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.4" + "'", str15.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1.5" + "'", str29.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "http://jv.orcle.com/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Jv Pltform API Specifiction", "   -1     ", "     ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) " sun.awt.CGraphicsEnvironment      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("4RA4LE444RP4RATI4N");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4RA4LE444RP4RATI4N" + "'", str1.equals("4RA4LE444RP4RATI4N"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Oracle corporationA10AA10AA1Oracle corporationA10AA10AA1Oracle corporationA10AA10AA", "1a0a-1a-1a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle corporationA10AA10AA1Oracle corporationA10AA10AA1Oracle corporationA10AA10AA" + "'", str2.equals("Oracle corporationA10AA10AA1Oracle corporationA10AA10AA1Oracle corporationA10AA10AA"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        char[] charArray9 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, (int) (byte) 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + " ###a# #4" + "'", str19.equals(" ###a# #4"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaaaaaaaaa...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) (short) 10, (int) (byte) -1);
        java.lang.Class<?> wildcardClass9 = longArray1.getClass();
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 0, 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "oRACLE CORPORATION", (java.lang.CharSequence) "S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "-1 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("jAVA pLATFORM api sPECIFICATION", "http://java.oracle.com/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str3.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#####################", "##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####################" + "'", str3.equals("#####################"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1", 61, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 1" + "'", str3.equals(" 1"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 -1 0 0 100 0" + "'", str10.equals("1 -1 0 0 100 0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1a-1a0a0a100a0" + "'", str12.equals("1a-1a0a0a100a0"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!7.0_80-bhi!7.0_80-bhi!", "class [C", "                         X OS Mc                         X OS Mc                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!7.0_80-bhi!7.0_80-bhi!" + "'", str3.equals("hi!7.0_80-bhi!7.0_80-bhi!"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("US", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "US" + "'", str5.equals("US"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("7.0_80-b", "uS", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "7.0_80-b" + "'", str3.equals("7.0_80-b"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "M", (java.lang.CharSequence) "aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oaraclea aCaorporation", "0", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass7 = intArray3.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 31, (-1));
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a10a-1" + "'", str9.equals("10a10a-1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray3, '4');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "     ", charArray3);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "444444444", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 2, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str12.equals("0.0 0.0 1.0 100.0"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USUSUSUSUSUSUSUSUSUS");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Virtual Machine Specification");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("              -1                ", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 11");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("96.0432.0435.0412.041.7");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("2a100a3a1", "#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2a100a3a1" + "'", str2.equals("2a100a3a1"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("  # a   4  # a   4  # a  srs/so", (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/uSERS/...", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.4");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "MIXED MODE");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 32, (-1));
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 10, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str1.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("24.80-B11");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEE...", (java.lang.CharSequence) "4aaa hie/Library/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "S1EEEEEEEEEEEEEEEEEEEEEEE..." + "'", charSequence2.equals("S1EEEEEEEEEEEEEEEEEEEEEEE..."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0#0.0#1.0#100.0" + "'", str12.equals("0.0#0.0#1.0#100.0"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.lwawt.macosx.CPrinterJob", "104104-1", 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0L, (float) 3L, (float) 88L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "cl S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "444444444444444444444444444442a100a3a1444http://java.oracle.com/444444444444444444444444444444444444444", (java.lang.CharSequence) "   hi!7.0_80-bhi!7.0_80-bhi!   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("############################################################# sun.awt.CGraphicsEnvironment     ", (int) (short) 0, "us");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################# sun.awt.CGraphicsEnvironment     " + "'", str3.equals("############################################################# sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                          44444444", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1430 + "'", int2 == 1430);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray5, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ORACLE CORPORATION", "Oracle Corporation");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray6, strArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1 -1 0 0 100 0", (java.lang.CharSequence[]) strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "2.80-b11                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str11.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2.80-b11                                                                                  1.7.0_80-b151.3RA2.80-b11                                                                                  1.7.0_80-b151.3LE2.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.3RP2.80-b11                                                                                  1.7.0_80-b151.3RATI2.80-b11                                                                                  1.7.0_80-b151.3N" + "'", str14.equals("2.80-b11                                                                                  1.7.0_80-b151.3RA2.80-b11                                                                                  1.7.0_80-b151.3LE2.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.3RP2.80-b11                                                                                  1.7.0_80-b151.3RATI2.80-b11                                                                                  1.7.0_80-b151.3N"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "9191");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 80, 89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 80");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("ORACLEJava Platform API SpecificationCORPORATIO", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str2.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("444444MacOSX                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444mACosx                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444mACosx                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mc OS X");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4', (int) (short) 100, 52);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "McaOSaX" + "'", str8.equals("McaOSaX"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "2.80-b11", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Virtual Machine Specification", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("us", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!7.0_80-bhi!7.0_80-bhi!", (java.lang.CharSequence) "1 0 -1 -1 100", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("McaOSaX", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc#OS#X" + "'", str3.equals("Mc#OS#X"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0" + "'", str11.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0" + "'", str13.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-b11", "1.6", "0a9a-1a0a9a1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("TNEMNORIVNeSCIHPARgc.TWA.NUS", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("eihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Eihpos" + "'", str1.equals("Eihpos"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        char[] charArray9 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) 'a', (int) '4');
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray9);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("eeeeeeeeeeeeeeeeeee", "ibrary/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eeeeeeeeeeeeeeeeeee" + "'", str2.equals("eeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', (int) (short) 10, (int) (short) 1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("4RA4LE444RP4RATI4N", "MIXED", 1456);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", (int) '4', "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit 1.7Java HotSpot(TM) 64-Bit S" + "'", str3.equals("Java HotSpot(TM) 64-Bit 1.7Java HotSpot(TM) 64-Bit S"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("##########/444444444444444444444444", "oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str11.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "2.80-b11                                                                                  1.7.0_80-b151.3RA2.80-b11                                                                                  1.7.0_80-b151.3LE2.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.3RP2.80-b11                                                                                  1.7.0_80-b151.3RATI2.80-b11                                                                                  1.7.0_80-b151.3N", (java.lang.CharSequence) "##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "2.80-b11                                                                                  1.7.0_80-b151.3RA2.80-b11                                                                                  1.7.0_80-b151.3LE2.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.3RP2.80-b11                                                                                  1.7.0_80-b151.3RATI2.80-b11                                                                                  1.7.0_80-b151.3N" + "'", charSequence2.equals("2.80-b11                                                                                  1.7.0_80-b151.3RA2.80-b11                                                                                  1.7.0_80-b151.3LE2.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.32.80-b11                                                                                  1.7.0_80-b151.3RP2.80-b11                                                                                  1.7.0_80-b151.3RATI2.80-b11                                                                                  1.7.0_80-b151.3N"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixJd modJ");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/4444444444444444444444444444444444", "                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), (long) (short) 100, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1010-1", (java.lang.CharSequence) "u");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("UTF-8-UTF-81UTF-8", "14-14040410040", "                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8-UTF-81UTF-8" + "'", str3.equals("UTF-8-UTF-81UTF-8"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.5");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.5\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("mixed mode", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 80, 18);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "EIHPOS/SRESu/", 88);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) (byte) -1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", (java.lang.CharSequence) "     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("rH le CorporHtion", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "rH le CorporHtion" + "'", str2.equals("rH le CorporHtion"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "1 100", 21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("eihpos", "4RA4LE444RP4RATI4N");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos" + "'", str2.equals("eihpos"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("#####################", ":", 84);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################" + "'", str3.equals("#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaa..." + "'", str1.equals("aaaaaaaaa..."));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444...", "0.0 0.0 1.0 100.0", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "ORACLEJv Pltform API SpecifictionCORPORATIO", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ORACLEJv Pltform API SpecifictionCORPORATIO" + "'", charSequence2.equals("ORACLEJv Pltform API SpecifictionCORPORATIO"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  # a   4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  # a   4" + "'", str2.equals("  # a   4"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.lwawt");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("EDOM DEXIM");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("eeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eeeeeeeeeeeeeeeeeeeeeraphicsEnvironment" + "'", str1.equals("eeeeeeeeeeeeeeeeeeeeeraphicsEnvironment"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "96.0#32.0#35.0#12.0#1.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "35.0#1.0#0.0#-1.0#1.0", (java.lang.CharSequence[]) strArray7);
        java.lang.Class<?> wildcardClass9 = strArray7.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("OrHcle CorporHtion", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "OrHcle CorporHtion" + "'", str10.equals("OrHcle CorporHtion"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("SUN.AWT.cgRAPHICSeNVIRONMENT    ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2367 + "'", int2 == 2367);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        char[] charArray7 = new char[] {};
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1#0#-1#-1#100", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(" ", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', 18, 92);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " " + "'", str4.equals(" "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " " + "'", str5.equals(" "));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mac OS", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        char[] charArray4 = new char[] {};
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray4);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.0", charArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("SUN.AWT.cgRAPHICSeNVIRONMENT    ", "                         X OS Mc                         X OS Mc                         ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJob", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", "N");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "class [C", 97);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################", "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################" + "'", str2.equals("#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10#10#-1", 4336, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    10#10#-1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + "'", str3.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    10#10#-1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.Class<?> wildcardClass13 = strArray12.getClass();
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.Class<?> wildcardClass18 = strArray17.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray19 = new java.lang.reflect.AnnotatedElement[] { wildcardClass3, wildcardClass8, wildcardClass13, wildcardClass18 };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray19);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(annotatedElementArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str20.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Eihpos", (java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8U/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("UTF-8-UTF-81UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 -1 0 0 100 0" + "'", str10.equals("1 -1 0 0 100 0"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("104104-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("x86_64");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "http://java.oracle.com/", 3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) 100, 18);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 89, 56);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#-1#0#0#100#0" + "'", str11.equals("1#-1#0#0#100#0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#-1#0#0#100#0" + "'", str13.equals("1#-1#0#0#100#0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", "#####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#####################" + "'", str2.equals("#####################"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.7", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 36, 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("2.80-b11", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.80-b11                           " + "'", str2.equals("2.80-b11                           "));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '#', 8, 29);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT", ' ');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "51.0", (int) ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857"));
    }
}

