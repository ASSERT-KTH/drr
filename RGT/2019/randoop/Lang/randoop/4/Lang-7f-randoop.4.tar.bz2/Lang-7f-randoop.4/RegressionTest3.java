import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1404-14-14100" + "'", str10.equals("1404-14-14100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#0#-1#-1#100" + "'", str12.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("USUSUSUSUSUSUSUSUSUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "USUSUSUSUSUSUSUSUSUS" + "'", str1.equals("USUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("51.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1.equals(51.0d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", "1#0#-1#-1#100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.CPrinterJosun.l");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', (int) (short) 10, (int) (byte) -1);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0 9 -1 0 9 1", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 9 -1 0 9 1" + "'", str3.equals("0 9 -1 0 9 1"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                              Mc OS X                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1" + "'", str1.equals("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                                        ", "", "1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("oRACLE CORPORATIONa10aa10aa1", "JavaPlatformAPISpecification", (int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oRACLE CORPORATIONa10aa10aa1JavaPlatformAPISpecification" + "'", str4.equals("oRACLE CORPORATIONa10aa10aa1JavaPlatformAPISpecification"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1), 10.0f, (float) 96);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 96.0f + "'", float3 == 96.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        char[] charArray7 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 0, (int) (byte) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) 'a', (int) '4');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray7);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 1, 3);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#aa" + "'", str21.equals("#aa"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("EDOM DEXIM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: EDOM DEXIM is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("UTF-8", "", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", (java.lang.CharSequence) "104104-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 32, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1", "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1", (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11" + "'", str3.equals("1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("\n", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "e");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray3, strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Mc OS X", 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.0" + "'", str7.equals("51.0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/4444444444444444444444444444444444" + "'", str9.equals("/4444444444444444444444444444444444"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str2.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "0", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", "44a4 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("mixed mode", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "4aaa ", (java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("JavaPlatformAPISpecification", 93, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2L, 0.0d, 1.7000000476837158d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 6, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", "RACLE CORPORATION", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT" + "'", str3.equals("S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("7.0_80-b", "          ", "/");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                         X OS Mc                         X OS Mc                         ", 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1a-1a0a0a100a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Jv Pltform API Specifiction", (java.lang.CharSequence) "              -1                ", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("14-14040410040");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "RACLE CORPORATION", (java.lang.CharSequence) "2.80-b11", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-1-1-1", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, (int) (byte) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 -1 0 0 100 0" + "'", str10.equals("1 -1 0 0 100 0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "14-14040410040" + "'", str12.equals("14-14040410040"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("OrHcle CorporHtion", 9, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OrHcle CorporHtion" + "'", str3.equals("OrHcle CorporHtion"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0.0#0.0#1.0#100.0" + "'", str11.equals("0.0#0.0#1.0#100.0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment", 93, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      " + "'", str3.equals("s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", "sophie", "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion" + "'", str3.equals("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', (int) '4', 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1 -1 0 0 100 0", (float) 88L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 88.0f + "'", float2 == 88.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 52L, (double) 35, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                  1.7.0_80-b151.3", (java.lang.CharSequence) "oRACLE CORPORATIONa10aa10aa1", 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("USUSUSUSUSUSUSUSUSU", 2, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4aaa ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "X OS Mc", (java.lang.CharSequence) "a10a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1#-1#0#0#100#0", (int) (short) 1, 31);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#-1#0#0#100#0" + "'", str3.equals("#-1#0#0#100#0"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.3", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3       " + "'", str2.equals("1.3       "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444", "                                              Mc OS X                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1404-14-14100", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1404-14-14100" + "'", str2.equals("1404-14-14100"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4aaa ", "1 -1 0 0 100 0", "hi!7.0_80-bhi!7.0_80-bhi!", 96);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4aaa " + "'", str4.equals("4aaa "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a10a-1", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1Java HotSpo", (java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "   -1     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0 9 -1 0 9 1", charSequence1, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sophie", "J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J" + "'", str2.equals("J"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4aaa ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", "JavaPlatformAPISpecification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("m", "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "m" + "'", str2.equals("m"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                   ", "1.3       ", "          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "n.lwawt.macosx.CPrinterJosun.l");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "2.80-b11", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("sophie", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "OrHcle CorporHtion", (java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "104104-1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (int) ' ', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("MIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "4", (java.lang.CharSequence) "OrHcle CorporHtion", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a-1a0a0a100a0", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "                                              Mc OS X                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://jv.orcle.com/", (java.lang.CharSequence) "                                ", 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("0.0a0.0a1.0a100.0", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str2.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 94, (float) 52L, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0 9 -1 0 9 1", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 9 -1 0 9 1" + "'", str2.equals("0 9 -1 0 9 1"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_80", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "35.0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("e", "96.0432.0435.0412.041.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "e" + "'", str2.equals("e"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "en", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1Java HotSpo");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44a4 ", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie", 34, "UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8UTF-8UTF-8UTF-8U/Users/sophie" + "'", str3.equals("UTF-8UTF-8UTF-8UTF-8U/Users/sophie"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "J");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("MIXED MODE", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MIXED MODE" + "'", str3.equals("MIXED MODE"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "4", "# a   4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str3.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("jAVA pLATFORM api sPECIFICATION", "                       ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie", "", "1Java HotSpo", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie" + "'", str4.equals("/Users/sophie"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "    :    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                          1.3                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("    :    ", "oRACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    :    " + "'", str2.equals("    :    "));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 9, (long) 31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("oRACLE CORPORATIONa10aa10aa1JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, (int) (byte) 1, 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 93, (double) (byte) 0, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 93.0d + "'", double3 == 93.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("10.0", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0" + "'", str2.equals("10.0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("a10a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: a10a is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#", (java.lang.CharSequence) "                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) (short) 100, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("1.3", strArray4, strArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.3" + "'", str8.equals("1.3"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 65);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("0 9 -1 0 9 1", "M");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 9 -1 0 9 1" + "'", str2.equals("0 9 -1 0 9 1"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "X86_64", (int) (short) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("         ", 28, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         " + "'", str3.equals("         "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("#", "Java HotSpot(TM) 64-Bit Server VM", "                                              Mc OS X                                               ", 96);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#" + "'", str4.equals("#"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "96.0432.0435.0412.041.7", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a10a-1" + "'", str9.equals("10a10a-1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10a10a-1" + "'", str11.equals("10a10a-1"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", 97, "                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                  sun.lwawt.macosx.CPrinterJob                                   " + "'", str3.equals("                                  sun.lwawt.macosx.CPrinterJob                                   "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ORACLEJava Platform API SpecificationCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION" + "'", str1.equals("ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("          1          4          0          4          -          1          4          -          1          4          1          0          0          ", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80", (float) 65);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 65.0f + "'", float2 == 65.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int[] intArray3 = new int[] { (byte) 0, 28, (short) 1 };
        int[] intArray7 = new int[] { (byte) 0, 28, (short) 1 };
        int[] intArray11 = new int[] { (byte) 0, 28, (short) 1 };
        int[][] intArray12 = new int[][] { intArray3, intArray7, intArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray12, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray12);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("96.0432.0435.0412.041.7");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"96.0432.0435.0412.041.7\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.lwawt.macosx.CPrinterJosun.l", "1.24444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sophie");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "1.7.0_80-B15", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15" + "'", str3.equals("1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10.14.3", "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14.3" + "'", str2.equals("10.14.3"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "-1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS X", "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("444444444444", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444" + "'", str2.equals("444444444444"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double[] doubleArray6 = new double[] { 97.0f, 0, 31.0d, 0, 5, 0.0f };
        double[] doubleArray13 = new double[] { 97.0f, 0, 31.0d, 0, 5, 0.0f };
        double[] doubleArray20 = new double[] { 97.0f, 0, 31.0d, 0, 5, 0.0f };
        double[] doubleArray27 = new double[] { 97.0f, 0, 31.0d, 0, 5, 0.0f };
        double[][] doubleArray28 = new double[][] { doubleArray6, doubleArray13, doubleArray20, doubleArray27 };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(doubleArray28);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) doubleArray28, "                         X OS Mc                         X OS Mc                         ");
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 96, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, (int) (byte) 1, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 10, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 96, (-1));
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a10a1" + "'", str9.equals("1a10a1"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        char[] charArray4 = new char[] { '4', 'a', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray4);
        java.lang.Class<?> wildcardClass6 = charArray4.getClass();
        java.lang.Class[] classArray8 = new java.lang.Class[1];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray9 = (java.lang.Class<?>[]) classArray8;
        wildcardClassArray9[0] = wildcardClass6;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray9);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(classArray8);
        org.junit.Assert.assertNotNull(wildcardClassArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "class [C" + "'", str12.equals("class [C"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "a10a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode", (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("104104-1", "J", "-1 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "104104-1" + "'", str3.equals("104104-1"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1), 10.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "7.0_80-b", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                          1.3                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "#", (java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "35.0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment                      ", (java.lang.CharSequence) "1.7.0_80-b151.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Jv Pltform API Specifiction");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("24.80-b11");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "X86_6", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("us");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" sun.awt.CGraphicsEnvironment      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" sun.awt.CGraphicsEnvironment      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1-1-1", 26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10a10a-1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4aaa ", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "0 9 -1 0 9 1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0 9 -1 0 9 1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                  sun.lwawt.macosx.CPrinterJob                                   ", "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  sun.lwawt.macosx.CPrinterJob                                   " + "'", str2.equals("                                  sun.lwawt.macosx.CPrinterJob                                   "));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7", "sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("UTF-8-UTF-81UTF-8", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            " + "'", str2.equals("                            "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", (java.lang.CharSequence) "1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ORACLEJava Platform API SpecificationCORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLEJava Platform API SpecificationCORPORATION" + "'", str1.equals("ORACLEJava Platform API SpecificationCORPORATION"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b15" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b15"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b151.3", "hie/Library/", "44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.3" + "'", str3.equals("1.7.0_80-b151.3"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b151.3", 10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10a10a-1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a10a-1" + "'", str2.equals("10a10a-1"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJo", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str4.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.CPrinterJosun.l", "-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJosun.l" + "'", str2.equals("sun.lwawt.macosx.CPrinterJosun.l"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b15", (java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("104104-1", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1a0a-1a-1a100" + "'", str14.equals("1a0a-1a-1a100"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1.equals(10.0d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("              -1                ", "1a-1a0a0a100a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              -1                " + "'", str2.equals("              -1                "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, '4', 10, 35);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.3       ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3       " + "'", str2.equals("1.3       "));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10 10 -1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                                          1.3                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 1, 0.0d, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        char[] charArray6 = new char[] {};
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 28, 28);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.0 0.0 1.0 100.0", charArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "oRACLE CORPORATIONa10aa10aa1", charArray6);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1), 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1#0#-1#-1#100", "US");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        int int14 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray12);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '#', 12, (int) (byte) 1);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.CPrinterJo", strArray5, strArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 5 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1#0#-1#-1#100" + "'", str13.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                             10.14.3" + "'", str3.equals("                                             10.14.3"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ":", (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("UTF-8-UTF-81UTF-8", (int) (short) 10, "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8-UTF-81UTF-8" + "'", str3.equals("UTF-8-UTF-81UTF-8"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "HTTP://JV.ORCLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("sun.lwawt.macosx.LWCToolkit", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "104104-1", (java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("2.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0#1.0#0.0#-1.0#1.0", (java.lang.CharSequence) "10a10a-1", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        char[] charArray7 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 0, (int) (byte) 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', (int) 'a', (int) '4');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray7);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 1, 3);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', (int) (short) 0, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#aa" + "'", str21.equals("#aa"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.lwawt.macosx.LWCToolkit", "Java HotSpot(TM) 64-Bit Server VM", 96, 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM" + "'", str4.equals("sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        char[] charArray9 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) 'a', (int) '4');
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "          ", charArray9);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray9);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1#0#-1#-1#100", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', (int) (byte) 0, (int) (byte) 1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short17 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "14-14040410040" + "'", str14.equals("14-14040410040"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1a-1a0a0a100a0" + "'", str16.equals("1a-1a0a0a100a0"));
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 100 + "'", short17 == (short) 100);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJo");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Mac OS", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("us");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7", (java.lang.CharSequence) "n.lwawt.macosx.CPrinterJosun.l");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("104104-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "104104-1" + "'", str1.equals("104104-1"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 34, (float) 2L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("x86_64", "en", "-1 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0.0a0.0a1.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0a0.0a1.0a100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1 ", 52, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444-1 4444444444444444444444444" + "'", str3.equals("444444444444444444444444-1 4444444444444444444444444"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) 'a', 88L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 88L + "'", long3 == 88L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("ORACLEJava Platform API SpecificationCORPORATION", "    :    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORACLEJava Platform API SpecificationCORPORATION" + "'", str2.equals("ORACLEJava Platform API SpecificationCORPORATION"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8U/Users/sophie", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_80");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("USUSUSUSUSUSUSUSUSUS", "-1-1-1", "35.0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUSUSUSUSUSUSUSUSUS" + "'", str3.equals("USUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "EDOM DEXIM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1Java HotSpo");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-B15", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4aaa " + "'", str15.equals("4aaa "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("    :    ", "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/", 96);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("UTF-8", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", (int) 'a', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSERS/SOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "          1          4          0          4          -          1          4          -          1          4          1          0          0          ", (int) (byte) 0, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), (long) (short) 10, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("JavaPlatformAPISpecification", "", 94, 65);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaPlatformAPISpecification" + "'", str4.equals("JavaPlatformAPISpecification"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1", "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sun.awt.CGraphicsEnvironment", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa", 96);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("J", "", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J" + "'", str3.equals("J"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray3, strArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '4', (int) 'a', (int) (short) 0);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray15);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.0" + "'", str7.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "/4444444444444444444444444444444444" + "'", str14.equals("/4444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/4444444444444444444444444444444444" + "'", str16.equals("/4444444444444444444444444444444444"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa", 100);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;class [Ljava.lang.CharSequence;class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass [Ljava.lang.String;", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mc OS X", "-1-1-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mc OS X" + "'", str2.equals("Mc OS X"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "0.0a0.0a1.0a100.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "JavaPlatformAPISpecification", (java.lang.CharSequence) "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "#");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.Class<?> wildcardClass3 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray5);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44a4 ", charArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', (int) (short) 1, 0);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("2a100a3a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uS" + "'", str1.equals("uS"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                            ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                            " + "'", str3.equals("                            "));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("              -1                ", "sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("ORACLE CORPORATION", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATION" + "'", str3.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.CPrinterJob", "96.0432.0435.0412.041.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/" + "'", str1.equals("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0.0#0.0#1.0#100.0", (java.lang.CharSequence) ":", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1#0#-1#-1#100", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 65, 9L, 88L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', (int) (byte) 100, 35);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Mac OS X");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("0.0a0.0a1.0a100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str1.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444", (java.lang.CharSequence) "                         X OS Mc                         X OS Mc                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.4", "ORACLE CORPORATION", "44a4 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-B15", "mixed mode", "#aa", 28);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-B15" + "'", str4.equals("1.7.0_80-B15"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("http://java.oracle.com/", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "10 10 -1");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80-b151.3", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-1 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80-B15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7", charSequence1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version" + "'", str3.equals("cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 34, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                         ", (java.lang.CharSequence) "              -1                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("e", "10.14.3");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "e" + "'", str4.equals("e"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.0a0.0a1.0a100.0", "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str2.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 26, 2L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1a0a-1a-1a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "10#10#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " ", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1" + "'", str2.equals("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oRACLE CORPORATION", ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE#CORPORATION" + "'", str3.equals("oRACLE#CORPORATION"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.0 0.0 1.0 100.0", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str3.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Jv Pltform API Specifiction", 52, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jv Pltform API Specifiction#########################" + "'", str3.equals("Jv Pltform API Specifiction#########################"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("uS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1-1-1", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(":", "                                                                                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) (short) 0, (int) (short) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "14-14040410040" + "'", str14.equals("14-14040410040"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1 -1 0 0 100 0" + "'", str16.equals("1 -1 0 0 100 0"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "444444444444444444444444-1 4444444444444444444444444", 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str10.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", "1#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3" + "'", str2.equals("1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("class [C", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "clss [C" + "'", str2.equals("clss [C"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        int[] intArray1 = new int[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ", (int) '#', 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(":", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, (int) (byte) 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                         ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         " + "'", str2.equals("                         "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "US", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 'a', (double) 34, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 34, 52L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", (java.lang.CharSequence) "                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#-1#0#0#100#0" + "'", str1.equals("#-1#0#0#100#0"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "\n", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass2 = javaVersion1.getClass();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion1.toString();
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment    ", (java.lang.CharSequence) "4aaa ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1#0#-1#-1#100", "ORACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#0#-1#-1#100" + "'", str2.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("96.0432.0435.0412.041.7", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Jv Pltform API Specifiction#########################", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv Pltform AP" + "'", str2.equals("Jv Pltform AP"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" ", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                             10.14.3");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("14-14040410040", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-14040410040" + "'", str2.equals("14-14040410040"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1#0#-1#-1#100", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#0#-1#-1#100" + "'", str3.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "104104-1", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28.0f, 1.2000000476837158d, (double) 1.2f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2000000476837158d + "'", double3 == 1.2000000476837158d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.CPrinterJosun.l", "2.80-b11");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) (byte) 10, (int) (short) 0);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hie/Library/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJosun.l", "Oracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("X OS Mc");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("n.lwawt.macosx.CPrinterJosun.l", "Mac OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n.lwawt.macosx.CPrinterJosun.l" + "'", str2.equals("n.lwawt.macosx.CPrinterJosun.l"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "us");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 88, 31.0d, (double) 27);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 27.0d + "'", double3 == 27.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7", 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("U");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                ", (int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                " + "'", str3.equals("                                "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "uS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Mac OS", "/44444444444444444444444444444444447.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7.0_80-b7", "7.0_80-b");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS" + "'", str3.equals("Mac OS"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1 0 -1 -1 100");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "2.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, 0.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "14-14040410040", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("24.80-b11", "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/", "10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0", "10.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########", "-1-1-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########" + "'", str2.equals("##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/", (java.lang.CharSequence) "sun.lwawt.maJava HotSpot(TM) 64-Bit Server VM", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1", "\n");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "mixed mode");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.3       ", "J");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "     ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                        ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                        " + "'", str2.equals("                                                                                        "));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT", (java.lang.CharSequence) "                         ", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("              -1                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "en", (java.lang.CharSequence) "Jv Pltform AP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("e");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10 10 -1", "Java(TM) SE Runtime Environment", "#aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1010-1" + "'", str3.equals("1010-1"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "10a10a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("51.0", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray8, strArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '4', (int) 'a', (int) (short) 0);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ORACLE CORPORATION", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0" + "'", str4.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "51.0" + "'", str12.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "/4444444444444444444444444444444444" + "'", str19.equals("/4444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ORACLE CORPORATION" + "'", str21.equals("ORACLE CORPORATION"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 65, (long) ' ', 3L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 65L + "'", long3 == 65L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 12, 12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("RACLE CORPORATION", "J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RACLE CORPORATION" + "'", str2.equals("RACLE CORPORATION"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "", (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1.0f), (double) 1L, (double) 9L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                        ", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaaa");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "    :    ", (int) ' ', 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "#-1#0#0#100#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.2", "oRACLE#CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long[] longArray6 = new long[] { ' ', (-1), (byte) 10, 12, (byte) 10, (short) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (short) 1, (int) (short) -1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "RACLE CORPORATION", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "2a100a3a1", (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                             10.14.3", (java.lang.CharSequence) "Jv Pltform API Specifiction");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15", "10#10#-1", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0, "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("44a4 ", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaa44a4 " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaa44a4 "));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!7.0_80-bhi!7.0_80-bhi!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("oRACLE#CORPORATION", "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE#CORPORATION" + "'", str2.equals("oRACLE#CORPORATION"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("44444444444444444444444444444444444444http://java.oracle.com/444444444444444444444444444444444444444", 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                         X OS Mc                         X OS Mc                         ", "jAVA pLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "jAVA pLATFORM api sPECIFICATION" + "'", str2.equals("jAVA pLATFORM api sPECIFICATION"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(88L, (long) 26, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("2.80-b11", "                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2.80-b11" + "'", str2.equals("2.80-b11"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        int[] intArray4 = new int[] { 2, (short) 100, 3, 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2a100a3a1" + "'", str6.equals("2a100a3a1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2#100#3#1" + "'", str9.equals("2#100#3#1"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44a4 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                         ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 9, 28.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Oracle Corporation", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444..." + "'", str2.equals("444444444..."));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { '4', 'a', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        java.lang.Class<?> wildcardClass8 = charArray6.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#aa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4aaa " + "'", str10.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 'a', (double) 9);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("2.80-b11", 88, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                2.80-b11" + "'", str3.equals("                                                                                2.80-b11"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", "2a100a3a1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "444444444444444444444444-1 4444444444444444444444444", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', (int) (byte) 100, (int) (short) 1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15", (java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1" + "'", str2.equals("10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("  # a   4", (int) (byte) 10, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  # a   4" + "'", str3.equals("  # a   4"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("MIXED MODE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("x86_64", 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("USUSUSUSUSUSUSUSUSUS", 27, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }
}

