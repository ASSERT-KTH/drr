import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Jv Pltform AP", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv Pltform AP" + "'", str2.equals("Jv Pltform AP"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Mac OS", "...14.31.7.0_801...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS" + "'", str2.equals("Mac OS"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "h00p://jv7!0i.i7i!b/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("96.0#32.0#35.0#12.0#1.7", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "96.0#32.0#35.0#12.0#" + "'", str2.equals("96.0#32.0#35.0#12.0#"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        char[] charArray5 = new char[] { ' ', 'a', 'a', '4', 'a' };
        char[] charArray11 = new char[] { ' ', 'a', 'a', '4', 'a' };
        char[] charArray17 = new char[] { ' ', 'a', 'a', '4', 'a' };
        char[] charArray23 = new char[] { ' ', 'a', 'a', '4', 'a' };
        char[] charArray29 = new char[] { ' ', 'a', 'a', '4', 'a' };
        char[][] charArray30 = new char[][] { charArray5, charArray11, charArray17, charArray23, charArray29 };
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join(charArray30);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray17);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertNotNull(charArray29);
        org.junit.Assert.assertNotNull(charArray30);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "    :    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("class [C", 80, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "eeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        int[] intArray6 = new int[] { 0, 9, (-1), (byte) 0, 9, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 9 -1 0 9 1" + "'", str8.equals("0 9 -1 0 9 1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0a9a-1a0a9a1" + "'", str10.equals("0a9a-1a0a9a1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 9 -1 0 9 1" + "'", str13.equals("0 9 -1 0 9 1"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Jv Pltform API Specifiction#########################Mc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Mac OS X" + "'", charSequence2.equals("Mac OS X"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java Virtual Machine Specification", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("9191", "10a10a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9191" + "'", str2.equals("9191"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#A01A#A-A1A#A0A#A0A#A100A#AOARACLE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "jAVApLATFORMapisPECIFICATION", "S1EEEEEEEEEEEEEEEEEEEEEEE...");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "96.0432.0435.0412.041.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa" + "'", str2.equals("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" 1", (int) (short) 10, "-1-1-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1-1-1-1 1" + "'", str3.equals("-1-1-1-1 1"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaa"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.444444444444444E99d + "'", double1.equals(4.444444444444444E99d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Jv Pltform API Specifiction");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "ORACLEJv Pltform API SpecifictionCORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                         X OS Mc                         X OS Mc                         ", "eeeeeeeeeeeeeeeeeee", 0, 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "eeeeeeeeeeeeeeeeeee                        X OS Mc                         X OS Mc                         " + "'", str4.equals("eeeeeeeeeeeeeeeeeee                        X OS Mc                         X OS Mc                         "));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "0 9 -1 0 9 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1404-14-14100", "Oracle corporationA10AA10AA1Oracle corporationA10AA10AA1Oracle corporationA10AA10AA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "10#10#-1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#", "Su");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#" + "'", str2.equals("#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#http://java.oracle.com/#"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 137, 100);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1#0#-1#-1#100", (java.lang.CharSequence) "########## desrodne / bil / erj / emoH / stnetnoC / kdj . 08 _ 0 . 7 . 1 kdj / senihcaM lautriV avaJ / avaJ / yrarbiL /##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 123 + "'", int2 == 123);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "X OS Mc", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        long[] longArray6 = new long[] { ' ', (-1), (byte) 10, 12, (byte) 10, (short) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (short) 1, (int) (short) -1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32#-1#10#12#10#1" + "'", str14.equals("32#-1#10#12#10#1"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "", 28);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.Class<?> wildcardClass5 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", "   -1     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;" + "'", str2.equals("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("32#-1#10#12#10#1", "44444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32#-1#10#12#10#1" + "'", str2.equals("32#-1#10#12#10#1"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("##USUSUSUSUSUSUSUSUSU##", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##USUSUSUSUSUSUSUSUSU##" + "'", str3.equals("##USUSUSUSUSUSUSUSUSU##"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("0 9 -1 0 9 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0 9 -1 0 9 1" + "'", str1.equals("0 9 -1 0 9 1"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', (int) (byte) 100, 35);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1#0#-1#-1#100" + "'", str14.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        char[] charArray7 = new char[] { '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', (int) (byte) 100, 28);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "############", charArray7);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.AWT.cgRAPHICSeNVIRONMENT    ", (int) (byte) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT    " + "'", str3.equals("SUN.AWT.cgRAPHICSeNVIRONMENT    "));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...", "Jv Plt", "-1 ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444", "/", (int) (short) 10);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "35.0#1.0#0.0#-1.0#1.0", (java.lang.CharSequence[]) strArray9);
        java.lang.Class<?> wildcardClass11 = strArray9.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "jAVApLATFORMapisPECIFICATION", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857", "oracle corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1", "X86_64", 0, 27);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1" + "'", str4.equals("X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str12.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str14.equals("0.0a0.0a1.0a100.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("oRACLE CORPORATIONa10aa10aa1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               " + "'", str2.equals("                               "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("                                                                                           0", "############################################################# sun.awt.CGraphicsEnvironment      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           0" + "'", str2.equals("                                                                                           0"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 80, 65);
        float float16 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str10.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 100.0f + "'", float16 == 100.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) 8, 34L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJo", '4');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str8.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.7d, 0.0d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "RACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1" + "'", str2.equals("0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1#0#-1#-1#100", "US");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "14-14040410040", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#0#-1#-1#100" + "'", str5.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', (int) (short) 0, (int) (short) 1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4', (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("clss [C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "clss [C" + "'", str1.equals("clss [C"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("http://jv.orcle.com/", "4.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://jv.orcle.com/" + "'", str2.equals("http://jv.orcle.com/"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", (java.lang.CharSequence) "                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1554 + "'", int2 == 1554);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "#####################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        long[] longArray6 = new long[] { ' ', (-1), (byte) 10, 12, (byte) 10, (short) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "2#100#3#1", (java.lang.CharSequence) "-1-1-1-1 1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1 100", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("OrHcle CorporHtioOrHcle CorporHtion", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OrHcle CorporHtioOrHcle CorporHtion" + "'", str2.equals("OrHcle CorporHtioOrHcle CorporHtion"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "##USUSUSUSUSUSUSUSUSU##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                              /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                              /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str1.equals("                              /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "-1-1-1", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                           0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                           0" + "'", str1.equals("                                                                                           0"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                                               UTF-8-UTF-81UTF-8", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################:#####################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                              ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                              " + "'", str2.equals("                                                              "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification", "                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "2#100#3#1", (java.lang.CharSequence) "  # a   4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Oaraclea aCaorporation", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oaraclea aCaorporation" + "'", str2.equals("Oaraclea aCaorporation"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "#aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#" + "'", str3.equals("#"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str5 = javaVersion3.toString();
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean8 = javaVersion3.atLeast(javaVersion7);
        boolean boolean9 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.3" + "'", str5.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("          1          4          0          4          -          1          4          -          1          4          1          0          0          ", "                                              Mc OS X                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1          4          0          4          -          1          4          -          1          4          1          0          0" + "'", str2.equals("1          4          0          4          -          1          4          -          1          4          1          0          0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("#aa", (int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        long[] longArray6 = new long[] { ' ', (-1), (byte) 10, 12, (byte) 10, (short) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 31, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("OrHcle CorporHtion");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0" + "'", str11.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0" + "'", str13.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10.0" + "'", str16.equals("10.0"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ORACLEJv Pltform API SpecifictionCORPORATIO");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORACLEJv Pltform API SpecifictionCORPORATIO\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", (java.lang.CharSequence) "JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification", 1430);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1-1-1-1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1-1-1-1 1" + "'", str1.equals("-1-1-1-1 1"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str6 = javaVersion5.toString();
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = null;
        try {
            boolean boolean10 = javaVersion5.atLeast(javaVersion9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.3" + "'", str6.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", (java.lang.CharSequence) " ###a# #4", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", (java.lang.CharSequence) "##########/444444444444444444444444", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ", 5, 18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             " + "'", str3.equals("             "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4aaa ", "################################################################################################", 93);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444...", "Jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        float[] floatArray3 = new float[] { 93, 'a', 96 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 97.0f + "'", float4 == 97.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32#-1#10#12#10#1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11                                                                                2.80-b11");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", "sun.awt.CGraphicsEnvironment    ", " sun.awt.CGraphicsEnvironment      ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("clss [C", "1.6");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("324-141041241041", "aaaaaaaaaa...", 2);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray8, strArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '4', (int) 'a', (int) (short) 0);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray11);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "sun.lwawt.macosx.LWCToolkit");
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "51.0" + "'", str12.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "/4444444444444444444444444444444444" + "'", str19.equals("/4444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "/4444444444444444444444444444444444" + "'", str21.equals("/4444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..." + "'", str22.equals("XOSMcXOSMc                       XOSMcXOSMc                       XOSMc..."));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("14-14040410040");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/uSERS/SOPHIE", "hi!7.0_80-bhi!7.0_80-bhi!", "Jv Plt", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/uSERS/SOPHIE" + "'", str4.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "2a100a3a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("RACLE CORPORATION");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                         X OS Mc                         X OS Mc                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                         X OS Mc                         X OS Mc                         " + "'", str1.equals("                         X OS Mc                         X OS Mc                         "));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://jv.orcle.com/", (java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) '4', (double) 12.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "clss [C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "HTTP://JV.ORCLE.COM/44444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                  sun.lwawt.macosx.CPrinterJob                                   ");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(34.0f, (float) 1456, (float) 65);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1456.0f + "'", float3 == 1456.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("USUSUSUSUSUSUSUSUSUS");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("S1EEEEEEEEEEEEEEEEEEEEEEE...", "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", 96);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "S EEEEEEEEEEEEEEEEEEEEEEE..." + "'", str5.equals("S EEEEEEEEEEEEEEEEEEEEEEE..."));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT" + "'", str2.equals("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "                                                                                        ", "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA" + "'", str3.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(" sun.awt.CGraphicsEnvironment      ", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " sun.awt.CGraphicsEnvironment     " + "'", str2.equals(" sun.awt.CGraphicsEnvironment     "));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444442a100a3a1444http://java.oracle.com/444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", 7, "###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        char[] charArray11 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray11);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', 0, (int) (byte) 0);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_6", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", charArray11);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                           ", "en");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1", 4336);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.3       ", charSequence1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-1-1-1-1 1", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    10#10#-1                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        int[] intArray1 = new int[] { (byte) 0 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 6, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "MacOSX", (java.lang.CharSequence) "0.0 0.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MacOSX                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                           XSOcaM" + "'", str1.equals("                                                           XSOcaM"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray8 = new char[] { '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-b11", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 23 + "'", int15 == 23);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("USUoRACLE CORPORATIONa10aa10aa1USUS", "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUoRACLE CORPORATIONa10aa10aa1USUS" + "'", str2.equals("USUoRACLE CORPORATIONa10aa10aa1USUS"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1-1-1-1 1", (java.lang.CharSequence) "    :    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oaraclea aCaorporation" + "'", str5.equals("Oaraclea aCaorporation"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("0.0a0.0a1.0a100.0", "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str2.equals("0.0a0.0a1.0a100.0"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        int[] intArray4 = new int[] { 2, (short) 100, 3, 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2a100a3a1" + "'", str6.equals("2a100a3a1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" # a   4", "SUN.AWT.cgRAPHICSeNVIRONMENT", 93);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.8");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + " # a   4" + "'", str5.equals(" # a   4"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "JavaPlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1 0 -1 -1 100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                   ", "                               ", 71);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                   " + "'", str3.equals("                                   "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("# 4  ", "   -1     ", 137);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("10a10a-1", "#aa", 56, 92);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10a10a-1#aa" + "'", str4.equals("10a10a-1#aa"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1", "oRACLE#CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hie/Librry/", "ORACLEJava Platform API SpecificationCORPORATION", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h/lbnny/" + "'", str3.equals("h/lbnny/"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray7 = new char[] { '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "44444444", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("N");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N" + "'", str1.equals("N"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0", 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80-b15", "J", 20, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "J" + "'", str4.equals("J"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt", "1 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0a0.0a1.0a100.0" + "'", str12.equals("0.0a0.0a1.0a100.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 100.0f + "'", float14 == 100.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "1 -1 0 0 100 0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "l ss org. ", (java.lang.CharSequence) "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "##########/444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "e", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("MacOSX                                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacOSX" + "'", str1.equals("MacOSX"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "9191", (java.lang.CharSequence) "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        char[] charArray8 = new char[] { '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (byte) 100, 28);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.9", charArray8);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "IRONMENT", charArray8);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 19, 2);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa", 19, "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                   1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                           #-1#0#0#100#0                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                                                                                  1.7.0_80-b151.3                            ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaa...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa..." + "'", str2.equals("aaaaaaaaaa..."));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "neration/randoop-current.jar" + "'", str2.equals("neration/randoop-current.jar"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"################################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "IRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("7.0_80-b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.0_80-b" + "'", str1.equals("7.0_80-b"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("rH le CorporHtion", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 1, (long) 10, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment    ", (java.lang.CharSequence) "S EEEEEEEEEEEEEEEEEEEEEEE...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("##USUSUSUSUSUSUSUSUSU##");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("444444MacOSX                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1" + "'", str2.equals("0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ORACLEJava Platform API SpecificationCORPORATION", 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "USUSUSUSUSUSUSUSUSUS", "N");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Nsers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/ystem/Library/Java/Extensions:/usr/lib/jav" + "'", str3.equals("/Nsers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/ystem/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", charArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "X86_", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("S EEEEEEEEEEEEEEEEEEEEEEE...", (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        char[] charArray7 = new char[] { '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        java.lang.Class<?> wildcardClass9 = charArray7.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "us", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "m", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#-1#0#0#100#0", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        char[] charArray6 = new char[] { '4', 'a', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "2a100a3a1", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4aaa " + "'", str10.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "aaaaaaaaaaaa", " # a   4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "ORACLEJava Platform API SpecificationCORPORATIO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "ORACLEJava Platform API SpecificationCORPORATIO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        float[] floatArray5 = new float[] { 96, 32, 35L, 12, 1.7f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.7f + "'", float6 == 1.7f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 96.0f + "'", float7 == 96.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "96.0432.0435.0412.041.7" + "'", str9.equals("96.0432.0435.0412.041.7"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "96.0#32.0#35.0#12.0#1.7" + "'", str11.equals("96.0#32.0#35.0#12.0#1.7"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 96.0f + "'", float12 == 96.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-14", 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-14) + "'", int2 == (-14));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, (int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaa", 0, (-14));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("104104-1", "24.80-b111.21.21.21.21.21", 2367);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "104104-1" + "'", str3.equals("104104-1"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1" + "'", str3.equals("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("10#10#-110#10#-110#10#-110#10#-110#1CORPORATIONAPHICSENVIRONMENT10#10#-110#10#-110#10#-110#10#-110#1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.6", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa11", "             ", (-14));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (java.lang.CharSequence) "ORACLEJv Pltform API SpecifictionCORPORATIO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("96.0#32.0#35.0#12.0#", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X" + "'", str1.equals("MAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS XMAC OS X"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("MacOSX", "4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MacOSX" + "'", str2.equals("MacOSX"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0.0#0.0#1.0#100.0", "1.7.0_80-b15", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0" + "'", str11.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0" + "'", str14.equals("10.0"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', 137, (int) 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        char[] charArray5 = new char[] {};
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", charArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray5);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "X OS Mc", charArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment    ", (-14));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle Corporation", "ines/jdk1.7.0_80.jdk/Cont");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hi!7.0_80-bhi!7.0_80-bhi", "sun.awt.cgraphicsenvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "4RA4LE444RP4RATI4N", (java.lang.CharSequence) "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment", 56);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 0, (byte) -1, (byte) -1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sun.awt.CGraphicsEnvironment    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" # a   4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " # a   4" + "'", str1.equals(" # a   4"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                              ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                             " + "'", str1.equals("                                                             "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1a0a-1a-1a100" + "'", str15.equals("1a0a-1a-1a100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1 0 -1 -1 100" + "'", str17.equals("1 0 -1 -1 100"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "TNEMNORIVNeSCIHPARgc.TWA.NUS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("444444444...", "35.0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 20, (long) 28, (long) 4336);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "eeeeeeeeeeeeeeeeeeeeeraphicsEnvironment", (java.lang.CharSequence) "eihpos", 137);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "oRACLE CORPORATIONa10aa10aa1", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                            ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "2a100a3a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "/uSERS/...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.3", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaaaaaaaa...", "-1 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa..." + "'", str2.equals("aaaaaaaaa..."));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass6 = javaVersion5.getClass();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass10 = javaVersion9.getClass();
        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass12 = javaVersion9.getClass();
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean14 = javaVersion4.atLeast(javaVersion9);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        boolean boolean16 = javaVersion0.atLeast(javaVersion9);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.8", 7, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    1.8" + "'", str3.equals("    1.8"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1 0 -1 -1 100", "   -1     ", (int) '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("clss [C", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1 0 -1 -1 100" + "'", str6.equals("1 0 -1 -1 100"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "clss [C" + "'", str7.equals("clss [C"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "XOSMcXOSMc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str10.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0#0.0#1.0#100.0" + "'", str14.equals("0.0#0.0#1.0#100.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0.040.041.04100.0" + "'", str16.equals("0.040.041.04100.0"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        java.lang.String[] strArray5 = new java.lang.String[] { "h00p://jv7!0i.i7i!b/", "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", "                                             10.14.3", "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "McaOSaX" };
        java.lang.String[] strArray11 = new java.lang.String[] { "h00p://jv7!0i.i7i!b/", "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", "                                             10.14.3", "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "McaOSaX" };
        java.lang.String[] strArray17 = new java.lang.String[] { "h00p://jv7!0i.i7i!b/", "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", "                                             10.14.3", "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "McaOSaX" };
        java.lang.String[] strArray23 = new java.lang.String[] { "h00p://jv7!0i.i7i!b/", "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", "                                             10.14.3", "0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1", "McaOSaX" };
        java.lang.String[][] strArray24 = new java.lang.String[][] { strArray5, strArray11, strArray17, strArray23 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(strArray24);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(strArray24);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("444444444...", "oRACLE CORPORATION", 34, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oRACLE CORPORATION" + "'", str4.equals("oRACLE CORPORATION"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("2a100a3a1", 1456, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#Oracle Corporation1#-1#0#0#100#01#-1#0#0#100#01#-1#0#0#100#", (java.lang.CharSequence) "USUoRACLE CORPORATIONa10aa10aa1USUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1Java HotSpo", (java.lang.CharSequence) "##########/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Library44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Java44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Virtual44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Machines44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444144444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444_444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444448044444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444.44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jdk44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Contents44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444Home44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444jre44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444lib44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444endorsed44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4066 + "'", int2 == 4066);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ORACLEJAVA PLATFORM API SPECIFICATIONCORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1#0#-1#-1#100", "US");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X86_64", (int) '#', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64                             " + "'", str3.equals("X86_64                             "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("  # a   4  # a   4  # a  sers/so");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# a   4  # a   4  # a  sers/so" + "'", str1.equals("# a   4  # a   4  # a  sers/so"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "ORACLEJv Pltform API SpecifictionCORPORATIO", (java.lang.CharSequence) "A4 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-110#10#-1", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "...14.31.7.0_801...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.3", 20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.3" + "'", str2.equals("1.3"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8UTF-8UTF-8UTF-8U/Users/sophie", 94, "1.8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.81.81.81.81.81.81.81.81.81.8UTF-8UTF-8UTF-8UTF-8U/Users/sophie1.81.81.81.81.81.81.81.81.81.8" + "'", str3.equals("1.81.81.81.81.81.81.81.81.81.8UTF-8UTF-8UTF-8UTF-8U/Users/sophie1.81.81.81.81.81.81.81.81.81.8"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("UTF-8", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(" # a   4", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " # a   4" + "'", str2.equals(" # a   4"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass5 = javaVersion4.getClass();
        boolean boolean6 = javaVersion3.atLeast(javaVersion4);
        boolean boolean7 = javaVersion1.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("h/lbnny/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h/lbnny/" + "'", str1.equals("h/lbnny/"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification96.0#32.0#35.0#12.0#1.7JavaPlatformAPISpecification", (java.lang.CharSequence) "aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", 123);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        char[] charArray8 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (byte) 100, (int) (short) 10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "    :    ", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                              Mc OS X                                               ", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + " a#aaa a4" + "'", str17.equals(" a#aaa a4"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("# a   4  # a   4  # a  sers/so", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10.0", (java.lang.CharSequence) "M");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "http://jv.orcle.com/#Mc OS X", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1 0 -1 -1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "001 1- 1- 0 1" + "'", str1.equals("001 1- 1- 0 1"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("http://jv.orcle.com/#Mc OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://jv.orcle.com/#mc os x" + "'", str1.equals("http://jv.orcle.com/#mc os x"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#-1#0#0#100#0", (java.lang.CharSequence) "S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "oRACLE#CORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 8, 52L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0", 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "  # a   4  # a   4  # a  sers/so");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaa...", "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1", "1.2", 56);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1" + "'", str3.equals("X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 11.2X86_64eeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1 -1 0 0 100 0", "MacOSX");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1-1-1-1 1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1-1-1-1 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 94, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt" + "'", str1.equals("Sun.lwawt"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("UTF-8UTF-8UTF-8UTF-8U/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8UTF-8UTF-8UTF-8U/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "#aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", charSequence1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "SOPHIE", (java.lang.CharSequence) "                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', (int) (short) 100, 0);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("...14.31.7.0_801...", "", "# a   4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "# a   4.# a   4.# a   4.# a   41# a   44# a   4.# a   43# a   41# a   4.# a   47# a   4.# a   40# a   4_# a   48# a   40# a   41# a   4.# a   4.# a   4.# a   4" + "'", str3.equals("# a   4.# a   4.# a   4.# a   41# a   44# a   4.# a   43# a   41# a   4.# a   47# a   4.# a   40# a   4_# a   48# a   40# a   41# a   4.# a   4.# a   4.# a   4"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Jv Pltform API Specifiction#########################Mc OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "jv Pltform API Specifiction#########################Mc OS X" + "'", str1.equals("jv Pltform API Specifiction#########################Mc OS X"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        byte[] byteArray3 = new byte[] { (byte) 1, (byte) 10, (byte) 1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a', 96, (-1));
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "M");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: M");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("35.0#1.0#0.0#-1.0#1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35.0#1.0#0.0#-1.0#1.0" + "'", str1.equals("35.0#1.0#0.0#-1.0#1.0"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "aaaaaaaaaa...", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        int[] intArray4 = new int[] { 2, (short) 100, 3, 1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2a100a3a1" + "'", str6.equals("2a100a3a1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "     ", (java.lang.CharSequence) "##########/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed##########", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        char[] charArray10 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray10);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', (int) (byte) 100, (int) (short) 10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_64", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "324-141041241041", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "OrHcle CorporHtioOrHcle CorporHtion", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        char[] charArray7 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', (int) (byte) 100, (int) (short) 10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857", charArray7);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '#', 6, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "################################################################################################", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "    :    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "  # a   4  # a   4  # a  srs/so", 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        int[] intArray3 = new int[] { (short) 10, 10, (short) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', (int) (short) 100, 0);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10#10#-1" + "'", str5.equals("10#10#-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1Java HotSpo", "hi!", "                            ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1Java HotSpo" + "'", str3.equals("1Java HotSpo"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Mac OS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "14-14040410040" + "'", str10.equals("14-14040410040"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("##########/-Library-/-Java-/-Java-Virtual-Machines-/-jdk--.-7-.-0-_-0-.-jdk-/-Contents-/-Home-/-jre-/-lib-/-endorsed-##########", 6, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########/-Library-/-Java-/-Java-Virtual-Machines-/-jdk--.-7-.-0-_-0-.-jdk-/-Contents-/-Home-/-jre-/-lib-/-endorsed-##########" + "'", str3.equals("##########/-Library-/-Java-/-Java-Virtual-Machines-/-jdk--.-7-.-0-_-0-.-jdk-/-Contents-/-Home-/-jre-/-lib-/-endorsed-##########"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa", (long) 94);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8L, (double) 80, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "X86_64", (java.lang.CharSequence) "u");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("USUSUSUSUSUSUSUSUSUS", "USUSUSUSUSUSUSUSUSUS", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUSUSUSUSUSUSUSUSUS" + "'", str3.equals("USUSUSUSUSUSUSUSUSUS"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "u", 123, 19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ####http://java.oracle.com/###4aaa ###", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4aaa ###" + "'", str2.equals("4aaa ###"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMc...", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("         ", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         " + "'", str2.equals("         "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/4444444444444444444444444444444444", '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray3, strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "51.0" + "'", str7.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/4444444444444444444444444444444444" + "'", str9.equals("/4444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/4444444444444444444444444444444444" + "'", str11.equals("/4444444444444444444444444444444444"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: mixed mode is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                         ", "/");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1404-14-14100", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Jv Pltform API Specifiction#########################Mc OS X");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 59 + "'", int1 == 59);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(28.0f, 9.0f, Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        short[] shortArray0 = new short[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#", "444444444444444444444444-1 4444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test337");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm", (java.lang.CharSequence) "1 0 -1 -1 100", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str4 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str6 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean8 = javaVersion5.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass11 = javaVersion10.getClass();
        boolean boolean12 = javaVersion9.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass15 = javaVersion14.getClass();
        boolean boolean16 = javaVersion13.atLeast(javaVersion14);
        java.lang.Class<?> wildcardClass17 = javaVersion14.getClass();
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean19 = javaVersion9.atLeast(javaVersion14);
        java.lang.String str20 = javaVersion14.toString();
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass23 = javaVersion22.getClass();
        boolean boolean24 = javaVersion21.atLeast(javaVersion22);
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion26 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass27 = javaVersion26.getClass();
        boolean boolean28 = javaVersion25.atLeast(javaVersion26);
        java.lang.Class<?> wildcardClass29 = javaVersion26.getClass();
        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion26);
        boolean boolean31 = javaVersion21.atLeast(javaVersion26);
        boolean boolean32 = javaVersion14.atLeast(javaVersion21);
        boolean boolean33 = javaVersion7.atLeast(javaVersion14);
        boolean boolean34 = javaVersion2.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.4" + "'", str20.equals("1.4"));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion26 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion26.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Mc#OS#X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mc#OS#X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "McaOSaX", (java.lang.CharSequence) "X86_64", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT" + "'", str2.equals("S1EEEEEEEEEEEEEEEERACLE CORPORATIONAPHICSENVIRONMENT"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a10a9a-1a0a9a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixJd modJ", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1a10a1", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("OrHcle CorporHtion", "Mac OS X", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "rH le CorporHtion" + "'", str5.equals("rH le CorporHtion"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "rH4le4CorporHtion" + "'", str7.equals("rH4le4CorporHtion"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Mc OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "              -1                ", (java.lang.CharSequence) "104104-1", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("a#a01a#a-a1a#a0a#a0a#a100a#aOaracle", "X OS Mc");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#a01a#a-a1a#a0a#a0a#a100a#aOaracle" + "'", str2.equals("a#a01a#a-a1a#a0a#a0a#a100a#aOaracle"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0 9 -1 0 9 1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("mixed mode", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80-b15", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80-b15" + "'", str5.equals("1.7.0_80-b15"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("2.80-b11                                                                                  1.7.0_80-b151.3");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#', 1554, (int) '#');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 -1 0 0 100 0" + "'", str10.equals("1 -1 0 0 100 0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1 -1 0 0 100 0" + "'", str12.equals("1 -1 0 0 100 0"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", 4336, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1 -1 0 0 100 0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 6, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", 20, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE", 4066, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50094_1560276857/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0" + "'", str10.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1" + "'", str4.equals("-1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Jv Pltform API Specifiction#########################Mc OS X", "/uSERS/...", 36);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "m", (java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444mACosx                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444mACosx                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444mACosx                                                           44444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "Oaraclea aCaorporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "S EEEEEEEEEEEEEEEEEEEEEEE...", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("# a   4  # a   4  # a  sers/so");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/uSERS/SOPHIE", "1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.Class<?> wildcardClass4 = javaVersion3.getClass();
        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
        java.lang.Class<?> wildcardClass6 = javaVersion3.getClass();
        boolean boolean7 = javaVersion0.atLeast(javaVersion3);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(61, 56, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 61 + "'", int3 == 61);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1oRACLE CORPORATIONa10aa10aa1");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = javaVersion1.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.3" + "'", str3.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.6" + "'", str7.equals("1.6"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a10a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10.0" + "'", str9.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10.0" + "'", str11.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.0" + "'", str15.equals("10.0"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str2.equals("HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee" + "'", str1.equals("1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSENVIRONMENT", (java.lang.CharSequence) "raj.tnerruc-poodnar/noitareneg/noitareneg_tset/bil/krowemarf/j4stcefed/stnemucoD/eihpos/sresU/:sessalc/tegrat/7586720651_49005_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1010-1", (java.lang.CharSequence) "0.9", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "S1EEEEEEEEEEEEEEEEEEEEEEE...", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                                          1.3                                           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                          1.3                                           " + "'", str1.equals("                                          1.3                                           "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("444447.0_80-b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444447.0_80-b" + "'", str1.equals("444447.0_80-b"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "X86_64                             ", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "0.15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x" + "'", str1.equals("mAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os xmAC os x"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 92, 23);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#-1#0#0#100#0" + "'", str11.equals("1#-1#0#0#100#0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Mc#OS#X", 27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSU", (java.lang.CharSequence) "EDOM DEXIM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "0.0a0.0a1.0a100.0", "http://jv.orcle.com/#Mc OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1404-14-14100" + "'", str13.equals("1404-14-14100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "444444444444444444444444-1 4444444444444444444444444");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "                              /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (short) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       ", "2.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       " + "'", str2.equals("                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       XOSMcXOSMc                       "));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                        ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        float[] floatArray4 = new float[] { (short) 0, 0, 1, 100.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 32, 1);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0 0.0 1.0 100.0" + "'", str12.equals("0.0 0.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0#0.0#1.0#100.0" + "'", str14.equals("0.0#0.0#1.0#100.0"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.81.81.81.81.81.81.81.81.81.8UTF-8UTF-8UTF-8UTF-8U/Users/sophie1.81.81.81.81.81.81.81.81.81.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        char[] charArray6 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 0, (int) (byte) 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) 'a', (int) '4');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', (int) (short) -1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("96.0#32.0#35.0#12.0#", "s1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "96.0#32.0#35.0#12.0#" + "'", str2.equals("96.0#32.0#35.0#12.0#"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment    ", (java.lang.CharSequence) "ORACLEJv Pltform API SpecifictionCORPORATIO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("EDOM DEXIM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EDOM DEXIM" + "'", str1.equals("EDOM DEXIM"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "                         ", 10);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("1.3", strArray5, strArray7);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.3" + "'", str9.equals("1.3"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str12.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "0.040.041.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaa-1-1-1aaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1a10a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction" + "'", str3.equals("jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 2, 3);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 1554, (int) 'a');
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.1", "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "E", charSequence1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        char[] charArray8 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (byte) 100, (int) (short) 10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) ":                         ", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "cl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Versioncl ss org. p che.commons.l ng3.J v Version", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("3.1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.1f + "'", float1 == 3.1f);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "hicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironmentsun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 34, 34);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "UTF-8UTF-8UTF-8UTF-8U/Users/sophie", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0 1eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee -1 0 9 1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 63 + "'", int1 == 63);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                  sun.lwawt.macosx.CPrinterJob                                   ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("4444444444444444444# a   4", "UTF-8UTF-8UTF-8UTF-8U/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444# a   4" + "'", str2.equals("4444444444444444444# a   4"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("McaOSaX", "3.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "McaOSaX" + "'", str2.equals("McaOSaX"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("sophie", strArray2, strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("0.0a0.0a1.0a100.0", "EDOM DEXIM", (int) (short) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                       ", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sophie" + "'", str6.equals("sophie"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "                       " + "'", str11.equals("                       "));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT", "oracle corporatiooracle corporati              -1                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT" + "'", str2.equals("S1EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERAPHICSeNVIRONMENT"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (java.lang.CharSequence) "hie/Librry/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        char[] charArray3 = new char[] {};
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "7.0_80-b", charArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray3, '#');
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVA pLATFORM api sPECIFICATION", charArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray3);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        char[] charArray8 = new char[] { '4', 'a', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray8);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "          ", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1#-1#0#0#100#0", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/t/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4aaa " + "'", str12.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b151.7.0_80-b151.7.0_80-b15", 4336, "# a   4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b15# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# " + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b15# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# a   4# "));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_80", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" # a   4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 0, (byte) -1, (byte) -1, (byte) 100 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#0#-1#-1#100" + "'", str10.equals("1#0#-1#-1#100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1404-14-14100" + "'", str13.equals("1404-14-14100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("X86_64                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64                             " + "'", str1.equals("x86_64                             "));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":                         " + "'", str1.equals(":                         "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        char[] charArray9 = new char[] { ' ', '#', 'a', ' ', '4' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", charArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', (int) 'a', (int) '4');
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersionclass org.apache.commons.lang3.JavaVersion", charArray9);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "", charArray9);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(charArray9, ' ', 35, (int) (byte) 10);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("  # a   4  # a   4  # a  sers/so", "1.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.31.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        float[] floatArray5 = new float[] { 96, 32, 35L, 12, 1.7f };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 4336, 97);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.7f + "'", float6 == 1.7f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 96.0f + "'", float7 == 96.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "96.0432.0435.0412.041.7" + "'", str9.equals("96.0432.0435.0412.041.7"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str5 = javaVersion0.toString();
        java.lang.String str6 = javaVersion0.toString();
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("...14.31.7.0_801...", "MacOSX                                                           ", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("rH4le4CorporHtion");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        short[] shortArray6 = new short[] { (short) 1, (short) -1, (byte) 0, (short) 0, (byte) 100, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, '#');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1#-1#0#0#100#0" + "'", str12.equals("1#-1#0#0#100#0"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/uSERS/...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/..." + "'", str1.equals("/uSERS/..."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("             ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "SUN.AW...", (java.lang.CharSequence) "Mc OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        long[] longArray1 = new long[] { (short) -1 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1a-1a0a0a100a0", "aaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaa10 10 -1aaaaaaaaaaaaaaaaa", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "jv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API SpecifictionmJv Pltform API Specifiction");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1a-1a0a0a100a0" + "'", str5.equals("1a-1a0a0a100a0"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################" + "'", str2.equals("###################################"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 7, 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ophie/Library/Java/E..." + "'", str3.equals("...ophie/Library/Java/E..."));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("UTF-8UTF-8UTF-8UTF-8U/Users/sophie", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT", 8, "-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#a01a#a-a1a#a0a#a0a#a100a#aOaracle");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT" + "'", str3.equals("S1EEEEEEEEEEEEEEEERACLE4CORPORATIONAPHICSENVIRONMENT"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-B15", "", "1.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_8010.14.31.7.0_80", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-B15" + "'", str4.equals("1.7.0_80-B15"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("96.0#32.0#35.0#12.0#1.7", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("4444444444444444444# a   4", "9191", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   4" + "'", str3.equals("4444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   491914444444444444444444# a   4"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("us", 28, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "us" + "'", str3.equals("us"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("/4444444444444444444444444444444444", "                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/4444444444444444444444444444444444" + "'", str2.equals("/4444444444444444444444444444444444"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "96.0432.0435.0412.041.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4aaa hie/Library/", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("h/lbnny/", "jAVApLATFORMapisPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h/lbnny/" + "'", str2.equals("h/lbnny/"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        double[] doubleArray1 = new double[] { 10L };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 1, 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("2.80-b11                           ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("e", "10.14.3");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 71, 0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/4444444444444444444444444444444444" + "'", str1.equals("/4444444444444444444444444444444444"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("444444444444", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_50094_1560276857/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JA", "sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob104104-1sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, 2, 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 61 + "'", int3 == 61);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        char[] charArray7 = new char[] { '4', 'a', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                              /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4aaa " + "'", str11.equals("4aaa "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(52.0d, (double) 97, (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "  # a   4  # a   4  # a  sers/so", (java.lang.CharSequence) "u", 63);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("http://java.oracle.com/", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1#0#-1#-1#100", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#0#-1#-1#100" + "'", str3.equals("1#0#-1#-1#100"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " sun.awt.CGraphicsEnvironment      ", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("35.0#1.0#0.0#-1.0#1.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35.0#1.0#0.0#-1.0#1.0" + "'", str2.equals("35.0#1.0#0.0#-1.0#1.0"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("sun.awt.CGraphicsEnvironment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment    ..." + "'", str2.equals("sun.awt.CGraphicsEnvironment    ..."));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1a-1a0a0a100a0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        short[] shortArray0 = new short[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        try {
            short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }
}

