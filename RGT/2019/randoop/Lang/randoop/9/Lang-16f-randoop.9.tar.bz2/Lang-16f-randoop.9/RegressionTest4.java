import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.macosx.lwctoolkit", "\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.lwctoolkit" + "'", str2.equals("sun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mixiHdd(T)64-Bmdoxo", 12, "http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixiHdd(T)64-Bmdoxo" + "'", str3.equals("mixiHdd(T)64-Bmdoxo"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("OracleCorporation", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "OracleCorporation" + "'", str2.equals("OracleCorporation"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 1, "                                               UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.Comparable<java.lang.String>[] strComparableArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strComparableArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                    ", charSequence1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "java4HotSpot(TM)464-Bit4Server4VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS X", (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio", 179, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                " + "'", str3.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                "));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("eihpos/sresU", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/UsersJavaHotSpot(TM)64-BitServerVM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime Environment", 142);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihva/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("US");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("7.1", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1" + "'", str2.equals("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "jAVAhOTsPOT(tm)64-bITsERVERv", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "erj/emoH/stnetnoC/k", 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Mixed mode                                               UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie", "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, "\n");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray6, strArray10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Users/sophie" + "'", str12.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80" + "'", str13.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/users/sop\n/users/sop\n/users/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str1.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11                  24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         " + "'", str1.equals("         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11                  24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         24.80-B11         "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(":4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "          ", "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals(":4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("boJretnirPC.xsocam.twawl.nus    ", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("java4HotSpot(TM)464-Bit4Server4VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":snoisnetxE/avaJ/yrarbiL/eih", "7.1", "4v4j/b44/r:4/::444:4e44E/4v4J/yr4rb44/4e4:yS/::444:4e44E/4v4J/yr4rb44/4r444eN/::444:4e44E/4v4J/yr4rbe4::444:4e44E/4v4J/yr4rb44/e4hp4:/:re:U/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":snoisnetxE/avaJ/yrarbiL/eih" + "'", str3.equals(":snoisnetxE/avaJ/yrarbiL/eih"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "OracleCorporation", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie", 27, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("SUNaLWAWTaMACOSXacpRINTERjOB", "7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUNaLWAWTaMACOSXacpRINTERjOB" + "'", str2.equals("SUNaLWAWTaMACOSXacpRINTERjOB"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:iebrary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javA", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Mixed mode                                               UTF-8", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "444444444444444444444444444", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.Class<?> wildcardClass7 = strArray3.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie" + "'", str5.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie" + "'", str6.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Users/sophie" + "'", str9.equals("/Users/sophie"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 20, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...nts/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defec..." + "'", str3.equals("...nts/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defec..."));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com" + "'", str1.equals("http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM", "boJretnirPC.xsocam.twawl.nus", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM" + "'", str3.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/li//test_generation/generation/randoop-current.jar", (int) (short) 100, "edom dexim");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/li//test_generation/generation/randoop-current.jar" + "'", str3.equals("users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/li//test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("b");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"b\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/meerj/emoH/stnetnoC/kavaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/met");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                                       JavaHotSpot(TM)64-BitServerVM", "\n", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                       JavaHotSpot(TM)64-BitServerVM" + "'", str3.equals("                                                                       JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(49, 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Java Vir...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("         ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, (float) 18L, (float) 5L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n01010010.1-\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Java4HotSpot(TM)464-Bit4Server4VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV4revreS4tiB-464)MT(topStoH4avaJ" + "'", str1.equals("MV4revreS4tiB-464)MT(topStoH4avaJ"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444", (java.lang.CharSequence) "Avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, 5L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sop\n/Users/sop\n/Users/sop", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("##################################:", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(42.0f, (float) 49, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 49.0f + "'", float3 == 49.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n" + "'", str1.equals("\n"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "k/Contents/Home/jre", "...nts/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defec...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", (int) (short) 1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU" + "'", str1.equals("eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444US44444444444444444", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444US44444444444444444" + "'", str2.equals("4444444444444444US44444444444444444"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2L, (float) '4', (float) 42);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ei", "1.3", (-1), 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.3" + "'", str4.equals("1.3"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("eieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieiei", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/jv", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation", "va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("SUNaLWAWTaMACOSXacpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUNaLWAWTaMACOSXacpRINTERjOB" + "'", str1.equals("SUNaLWAWTaMACOSXacpRINTERjOB"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sun.lwawt.macosx.LWCToolkit is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":snoisnetxE/avaJ/yrarbiL/eihva/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                      http://java.oracle.com/                                       ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "snisnaxEJybiLiaJViauMainsdk170_80dkCnanasH" + "'", str3.equals("snisnaxEJybiLiaJViauMainsdk170_80dkCnanasH"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) ":snoisnetxE/avaJ/yra", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/USERS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", 'a');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.http://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Java Platform API Specification                     ", 30, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) (short) 10, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray12 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/li//test_generation/generation/randoop-current.jar", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/soph", ":SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu", "1                                                                               ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("    SUN.LWAWT.MACOSX.cpRINTERjOB", 75);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         SUN.LWAWT.MACOSX.cpRINTERjOB                      " + "'", str2.equals("                         SUN.LWAWT.MACOSX.cpRINTERjOB                      "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", ":SNOISNETXe/AVAj/YRARBIl/EIHPOS/SRESu");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("boJretnirPC.xsocam.twawl.nus    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BOJRETNIRPC.XSOCAM.TWAWL.NUS    " + "'", str1.equals("BOJRETNIRPC.XSOCAM.TWAWL.NUS    "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("7.1", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/jv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/jv" + "'", str1.equals("/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/jv"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 448 + "'", int2 == 448);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "1.7.0_80-b15");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, 'a', 37, 0);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str1.equals(":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.7.0_80                        ", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80                        " + "'", str3.equals("1.7.0_80                        "));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4v4j/b44/r:4/::444:4e44E/4v4J/yr4rb44/4e4:yS/::444:4e44E/4v4J/yr4rb44/4r444eN/::444:4e44E/4v4J/yr4rbe4::444:4e44E/4v4J/yr4rb44/e4hp4:/:re:U/", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 140 + "'", int2 == 140);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("\n", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7d + "'", double2 == 1.7d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n-1.01001010\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "SUNaLWAWTaMACOSXacpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "b" + "'", str1.equals("b"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("JavaHotSpot(TM)64-BitServerV");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaHotSpot(TM)64-BitServer" + "'", str1.equals("JavaHotSpot(TM)64-BitServer"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("    SUN.LWAWT.MACOSX.cpRINTERjOB", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java Platform API Specification", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("eihpos/sresU/", (int) (short) 100, "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoieihpos/sresU/tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snois" + "'", str3.equals("tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoieihpos/sresU/tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snois"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 27 + "'", int2 == 27);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1" + "'", str2.equals("7.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.17.1"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("          ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/", (java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                en", (java.lang.CharSequence) "                enaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                en", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                en" + "'", str2.equals("                en"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "...nts/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defec...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 97.0f, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", 1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "erj/emoH/stnetnoC/k");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "sun.lwawt.macosx.CPrinterJob", (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("mixiHdd(T)64-Bmdoxo ", strArray4, strArray10);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray10, "OracleCorporation");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str6.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "mixiHdd(T)64-Bmdoxo " + "'", str11.equals("mixiHdd(T)64-Bmdoxo "));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_64" + "'", str1.equals("X86_64"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixiHdd(T)64-Bmdoxo", 12.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "/Users/sophie/Library/Java/Extensions:/Library/Ja...");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "", 87, 5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        int[] intArray4 = new int[] { 2, (short) -1, (byte) 1, (short) 0 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 0, 413);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoieihpos/sresU/tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snois");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ei", "VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n\n\n\n\n\n\n\n01010010.1-\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", 28, 5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        char[] charArray11 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##################################:", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 18 + "'", int14 == 18);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va/Java..." + "'", str2.equals("va/Java..."));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "4v4j/b44/r:4/::444:4e44E/4v4J/yr4rb44/4e4:yS/::444:4e44E/4v4J/yr4rb44/4r444eN/::444:4e44E/4v4J/yr4rbe4::444:4e44E/4v4J/yr4rb44/e4hp4:/:re:U/");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         ", "                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         " + "'", str2.equals("         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         "));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/:snoisnetxE/avaJ/yrarbiL/eihpos/srsun.awt.CGraphicsEnvironment", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phicsEnvironmentawt.CGrarbiL/eihpos/srsun.aJ/yravarbiL/eihpos/sresU/:snoisnetxE/aJ/yrava:snoisnetxE/" + "'", str2.equals("phicsEnvironmentawt.CGrarbiL/eihpos/srsun.aJ/yravarbiL/eihpos/sresU/:snoisnetxE/aJ/yrava:snoisnetxE/"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("    SUNaLWAWTaMACOSXacpRINTERjOB", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cpRINTERjOBaMACOSXaLWAWTa    SUN" + "'", str2.equals("cpRINTERjOBaMACOSXaLWAWTa    SUN"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "SUN.AWT.cgRAPHICSeNVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "    SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.50.91.5", "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ei");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ei" + "'", str1.equals("ei"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "\n");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/li//test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie" + "'", str6.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie" + "'", str7.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("k/Contents/Home/jre", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-BORACLE CORPORATION                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                               NOITAROPROC ELCAROB-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.1" + "'", str1.equals("                                                                               NOITAROPROC ELCAROB-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.1"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("BOJRETNIRPC.XSOCAM.TWAWL.NUS    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bojretnirpc.xsocam.twawl.nus    " + "'", str1.equals("bojretnirpc.xsocam.twawl.nus    "));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jr", "sun.lwawt.macosx.lwctoolkit");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                         SUN.LWAWT.MACOSX.cpRINTERjOB                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Java4HotSpot(TM)464-Bit4Server4VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b" + "'", str1.equals("b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("    SUN.LWAWT.MACOSX.cpRINTERjOB", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AWT.MACOSX.cpRINTERjOB" + "'", str2.equals("AWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#######...", 100, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_ran#######.../Users/sophie/Documents/defects4j/tmp/run_ran" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_ran#######.../Users/sophie/Documents/defects4j/tmp/run_ran"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java4HotSpot(TM)464-Bit4Server4VM", (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence) "aaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Lcb a yJlataJlatac mualpachcnavJjdk1.7.0_80.jdkJCrnmanmvJormaJj");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sophiesoJava Vir...sophiesop", 413);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                 sophiesoJava Vir...sophiesop" + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                 sophiesoJava Vir...sophiesop"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EN" + "'", str1.equals("EN"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "en", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("-1va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre100va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre100.0va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jresun.lwawt.macosx.CPrinterJobva/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre4", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 448, 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str4.equals("-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mixed mode                                               UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sophiesoJava Vir...sophiesop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, 253, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 253 + "'", int3 == 253);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.50.91.5", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion[] javaVersionArray3 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion1, javaVersion2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(javaVersionArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertNotNull(javaVersionArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.50.91.5" + "'", str4.equals("1.50.91.5"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.50.91.5" + "'", str5.equals("1.50.91.5"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        double[] doubleArray4 = new double[] { (byte) 10, (-1L), (-1.0f), 10.0d };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("5", 2, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "54" + "'", str3.equals("54"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/", 37, "    SUNaLWAWTaMACOSXacpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/" + "'", str3.equals("HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Ja...", 42, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Ja..." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Ja..."));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre1va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre100va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre100.0va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jresun.lwawt.macosx.CPrinterJobva/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre4", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         ", (java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/:snoisnetxE/avaJ/yrarbiL/eihpos/srsun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(42, (int) (short) 10, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 42 + "'", int3 == 42);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("us", " ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", (java.lang.CharSequence) "1                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":snoisnetxE/avaJ/yra");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n-1.01001010\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", "sun.lwawt.macosx.LWCToolkit");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 35, (int) (short) 1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "1.7.0_80-/Users/soph15");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n-1.01001010\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" + "'", str8.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n-1.01001010\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("eieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieiei", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieiei" + "'", str3.equals("eieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieiei"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("en", '#');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.50.91.5");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java4HotSpot(TM)464-Bit4Server4VM", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "en" + "'", str7.equals("en"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "    SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, (int) (byte) 1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        char[] charArray12 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Mac OS X", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eih", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("b##########", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                en", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("OracleCorporation", "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", 52, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "OracleCorporationhttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str4.equals("OracleCorporationhttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/jv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/j" + "'", str1.equals("/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/j"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.4", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        1.4" + "'", str2.equals("        1.4"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Users/sophie/Library/Java/Extensions:/Library/Ja...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus    ", (java.lang.CharSequence[]) strArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT", (java.lang.CharSequence[]) strArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eih", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..", (int) ' ', 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA.." + "'", str4.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA.."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aa", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa" + "'", str3.equals("aa"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("##################################:", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SUNaLWAWTaMACOSXacpRINTERjOB", (java.lang.CharSequence) "                                                                               NOITAROPROC ELCAROB-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 174 + "'", int2 == 174);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "JavaHotSpot(TM)64-BitServer", 253);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4v4j/b44/r:4/::444:4e44E/4v4J/yr4rb44/4e4:yS/::444:4e44E/4v4J/yr4rb44/4r444eN/::444:4e44E/4v4J/yr4rbe4::444:4e44E/4v4J/yr4rb44/e4hp4:/:re:U/", "K/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                ", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                " + "'", str2.equals("0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation", "Lcb a yJlataJlatac mualpachcnavJjdk1.7.0_80.jdkJCrnmanmvJormaJj");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation" + "'", str2.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:iebrary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javA", (java.lang.CharSequence) "1.7.0_80                        ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/" + "'", str1.equals("eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                         SUN.LWAWT.MACOSX.cpRINTERjOB                      ", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         SUN.LWAWT.MACOSX.cpRINTERjOB                      " + "'", str2.equals("                         SUN.LWAWT.MACOSX.cpRINTERjOB                      "));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Ja...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("MV4revreS4tiB-464)MT(topStoH4avaJ", "b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b" + "'", str1.equals("b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "sophiesoJava Vir...sophiesop");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "CGraphicsEnvironme", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaa", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mixed mode                                               UTF-8", "/Users/sophie/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed mode                                               UTF-8" + "'", str2.equals("xed mode                                               UTF-8"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80                        ", "http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/", "mixiHdd(T)64-Bmdoxo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80                        " + "'", str3.equals("1.7.0_80                        "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "K/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "K/CONTENTS/HOME/JRE" + "'", str2.equals("K/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 0, 75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 37, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str3.equals("tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "mixed mode                                               UTF-8", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("JavaHotSpot(TM)64-BitServerVM", "sun/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaawt/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaC/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaGraphics/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str2.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("BOJRETNIRPC.XSOCAM.TWAWL.NUS    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BOJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str1.equals("BOJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                       JavaHotSpot(TM)64-BitServerVM", (java.lang.CharSequence) "sophiesoJava Vir...sophiesop", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sop\ne", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 27, "mixiHdd(T)64-Bmdoxo");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixiHdd(T)64-BmdoxomixiHdd(" + "'", str3.equals("mixiHdd(T)64-BmdoxomixiHdd("));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                enaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                enaaaaaaaaaaaaaaaaa" + "'", str1.equals("                enaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", "          ", 27);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1.01001010", (java.lang.CharSequence) ":snoisnetxE/avaJ/yra");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 140);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(":snoisnetxE/avaJ/yrarbiL/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU" + "'", str1.equals(":snoisnetxE/avaJ/yrarbiL/eihpos/sresU"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT" + "'", str2.equals(":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sun.awt.CGraphicsEnvironment");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 27, 12);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sunaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaawtaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaGraphicsaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEnvironment" + "'", str3.equals("sunaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaawtaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaGraphicsaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEnvironment"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 18.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 18.0f + "'", float3 == 18.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n", (java.lang.CharSequence) "Java Vir...", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 4, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("sun.lwawt.macosx.CPrinterJob", "X86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.50.91.5");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM", "                                                                       JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM" + "'", str2.equals("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", "eihpos/sresU/", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4444444444444444US44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("    sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Users/sophie/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 60);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Users/sophie/Library/Java/JavaVirtualMachin..." + "'", str2.equals("/Users/sophie/Users/sophie/Library/Java/JavaVirtualMachin..."));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("X86_64", "JavaHotSpot(TM)64-BitServer", 42);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X86_64" + "'", str3.equals("X86_64"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1                                                                               ", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1                                                                               " + "'", str2.equals("1                                                                               "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("bojretnirpc.xsocam.twawl.nus    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bojretnirpc.xsocam.twawl.nus" + "'", str1.equals("bojretnirpc.xsocam.twawl.nus"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(":4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("b", "BOJRETNIRPC.XSOCAM.TWAWL.NUS    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                      http://java.oracle.com/                                       ", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444" + "'", str1.equals("444444444444444444444444444"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51.0", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "java4HotSpot(TM)464-Bit4Server4VM", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "xed mode                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "s");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                                      http://java.oracle.com/                                       ", (java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                      http://java.oracle.com/                                       " + "'", charSequence2.equals("                                      http://java.oracle.com/                                       "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 413, (long) 17, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Lcb a yJlataJlatac mualpachcnavJjdk1.7.0_80.jdkJCrnmanmvJormaJj", (java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihva/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 448);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "MV4revreS4tiB-464)MT(topStoH4avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "OracleCorporationhttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/", (java.lang.CharSequence) "CGraphicsEnvironme");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                en", ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                en" + "'", str2.equals("                en"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS XMac OS XMaeiXMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(42L, (long) (byte) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("b", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "b" + "'", str2.equals("b"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU", "users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        char[] charArray12 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray12);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray12);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...", charArray12);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "eihpos/sresU/eihpo                enaaaaaaaaaaaaaaaaasresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU/eihpos/sresU", charArray12);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "    SUNaLWAWTaMACOSXacpRINTERjOB", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                                                                                                                                                                                                                                                                                                                                                                                 sophiesoJava Vir...sophiesop", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "toolkit", (java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-BORACLE CORPORATION                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int[] intArray6 = new int[] { (byte) -1, 42, 42, 37, 179, 2 };
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbei:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "en", 83);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MV4revreS4tiB-464)MT(topStoH4avaJ", "", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        char[] charArray14 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray14);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM", charArray14);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", charArray14);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray14);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80", charArray14);
        java.lang.Class<?> wildcardClass22 = charArray14.getClass();
        int int23 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                ", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 84 + "'", int23 == 84);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://j", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 18 + "'", int2 == 18);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4v4j/b44/r:4/::444:4e44E/4v4J/yr4rb44/4e4:yS/::444:4e44E/4v4J/yr4rb44/4r444eN/::444:4e44E/4v4J/yr4rbe4::444:4e44E/4v4J/yr4rb44/e4hp4:/:re:U/", (java.lang.CharSequence) "/Users/sop\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Users/sophie/Library/Java/Extensions:/Library/Ja...", "us", (int) ' ', 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Users/sophie/Library/Java/Extensuss:/Library/Ja..." + "'", str4.equals("Users/sophie/Library/Java/Extensuss:/Library/Ja..."));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 0, (double) (short) -1, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), (long) 4, 97L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                               UTF-8", "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               UTF-8" + "'", str2.equals("                                               UTF-8"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("bojretnirpc.xsocam.twawl.nus    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"bojretnirpc.xsocam.twawl.nus    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("USUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUSUJavaHotSpot(TM)64-BitServerVM", "HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JavaHotSpot(TM)64-BitServerVM", (int) (short) -1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaHotSpot(TM)64-BitServerVM" + "'", str3.equals("JavaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "    SUN.LWAWT.MACOSX.cpRINTERjOB", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        char[] charArray11 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                 sophiesoJava Vir...sophiesop", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 32, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        short[] shortArray2 = new short[] { (byte) -1, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporatio                                                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracleCorporatio" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracleCorporatio"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("    SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaawt/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java./Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaC/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaGraphics/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javaEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Library/Java/Extensions:iebrary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/javA", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("k/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("VirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "    SUNaLWAWTaMACOSXacpRINTERjOB", 35, 38);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VirtualMachines/jdk1.7.0_80.jdk/Con    SUNaLWAWTaMACOSXacpRINTERjOBts/Home/jre/lib/endorsed" + "'", str4.equals("VirtualMachines/jdk1.7.0_80.jdk/Con    SUNaLWAWTaMACOSXacpRINTERjOBts/Home/jre/lib/endorsed"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("va/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("US", 18L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "444444444444444444444444444", (java.lang.CharSequence) "mixed mode                                               UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                       JavaHotSpot(TM)64-BitServerVM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"JavaHotSpot(TM)64-BitServerVM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Uer/phe/brry/Jv/Ee:/brry/Jv/JvVrMhe/jd170_80jd/e/He/jre/b/e:/brry/Jv/Ee:/Ner/brry/Jv/Ee:/Sye/brry/Jv/Ee:/r/b/jv", "snisnaxEJybiLiaJViauMainsdk170_80dkCnanasH", 32);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray2 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray2);
        java.lang.Class<?> wildcardClass4 = stringUtilsArray2.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray2);
        org.junit.Assert.assertNotNull(stringUtilsArray2);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X", (java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "en                                                                                               ", 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("     /Users/sophie", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     /Users/sophie" + "'", str2.equals("     /Users/sophie"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 42L, (double) 2, (double) 20);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.0d + "'", double3 == 42.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        java.lang.Class<?> wildcardClass1 = systemUtils0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b", ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT", "OracleCorporationhttp://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b" + "'", str3.equals("b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b1.3b"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 174, (long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 174L + "'", long3 == 174L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", 0, 201);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "users/sophie/documents/defects4j/tmp/run_randoop.pl_94848_1560209674/target/classes:/users/sophie/documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT", 18, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT" + "'", str3.equals(":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("u/:", "MV4revreS4tiB-464)MT(topStoH4avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "u/:" + "'", str2.equals("u/:"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) ":snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com", "                                                                                    7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com" + "'", str2.equals("http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixiHdd(T)64-Bmdoxo ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Mac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS XMac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com/http://jJvJ.orJcle.com", "1.", 2);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja..", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        char[] charArray10 = new char[] { 'a', '4', ' ', ' ', ' ', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-b15", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                    ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/soph", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("UTF-8");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-BORACLE CORPORATION                                                                               ");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "", (int) ' ');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "eihpos/sresU", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween(":snoisnetxE/avaJ/yrarbiL/eihva/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "Java4HotSpot(TM)464-Bit4Server4VM", "sophiesoJava Vir...sophiesop");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 83, (double) 35, (double) 448);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 448.0d + "'", double3 == 448.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("sunaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaawtaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaGraphicsaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sunaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaawtaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaGraphicsaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS    ", (java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java4HotSpot(TM)464-Bit4Server4VM", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4Server4VM" + "'", str2.equals("4Server4VM"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Oracle Corporation", "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoieihpos/sresU/tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snois");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("####################################################", "                                                                               NOITAROPROC ELCAROB-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.151B-08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####################################################" + "'", str2.equals("####################################################"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.1", "u/:", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "eieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieieiei", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mixiHdd(T)64-BmdoxomixiHdd(");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("4Server4VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MV4revreS4" + "'", str1.equals("MV4revreS4"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR", (java.lang.CharSequence) "HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR" + "'", charSequence2.equals("VA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JR"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("cpRINTERjOBaMACOSXaLWAWTa    SUN", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          ", "en                                                                                               ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "SERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "          " + "'", str4.equals("          "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "          " + "'", str6.equals("          "));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "edom dexim", "1.50.91.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j", (java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1L, (float) (byte) 100, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "desrodne/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("en", 87);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen" + "'", str2.equals("enenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenenen"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j" + "'", str1.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "b##########", (java.lang.CharSequence) "         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) (byte) 1, (long) 87);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("EN", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "CGraphicsEnvironme", (java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "OracleCorporation", "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JavaHotSpot(TM)64-BitServerV");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         ", 35, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         " + "'", str3.equals("         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         24.80-b11         "));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("boJretnirPC.xsocam.twawl.nus", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Java Platform API Specification                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, 35, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.4", "EN", "          ", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("edom dexim");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "4444444444444444US44444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', (int) 'a', 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#', 10, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie" + "'", str5.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie" + "'", str6.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation" + "'", str1.equals("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-bOracle Corporation"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.io.File[] fileArray0 = new java.io.File[] {};
        java.io.File[] fileArray1 = new java.io.File[] {};
        java.io.File[][] fileArray2 = new java.io.File[][] { fileArray0, fileArray1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(fileArray2);
        org.junit.Assert.assertNotNull(fileArray0);
        org.junit.Assert.assertNotNull(fileArray1);
        org.junit.Assert.assertNotNull(fileArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Oracle Corporation", "1                                                                               ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation" + "'", str3.equals("Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation1                                                                               Oracle Corporation"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("BOJRETNIRPC.XSOCAM.TWAWL.NUS", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BOJRETNIRPC.XSOCAM.TWAWL.NUS" + "'", str2.equals("BOJRETNIRPC.XSOCAM.TWAWL.NUS"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java4HotSpot(TM)464-Bit4Server4VM", (java.lang.CharSequence) "aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..", (java.lang.CharSequence) "1.4", 448);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("java4HotSpot(TM)464-Bit4Server4VM", 52, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 32, (long) 50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 50L + "'", long3 == 50L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("VirtualMachines/jdk1.7.0_80.jdk/Con    SUNaLWAWTaMACOSXacpRINTERjOBts/Home/jre/lib/endorsed", "", "\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, (double) (byte) 10, (double) 179.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Ja..", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("k/Contents/Home/jre", "tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoieihpos/sresU/tsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snois");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "k/Contents/Home/jre" + "'", str2.equals("k/Contents/Home/jre"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mixed mode                                               UTF-8", "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4v4j/b44/r:4/::444:4e44E/4v4J/yr4rb44/4e4:yS/::444:4e44E/4v4J/yr4rb44/4r444eN/::444:4e44E/4v4J/yr4rbe4::444:4e44E/4v4J/yr4rb44/e4hp4:/:re:U/");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                               UTF-8", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        boolean boolean8 = javaVersion2.atLeast(javaVersion5);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        boolean boolean12 = javaVersion2.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sophiesoJava Vir...sophiesop");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sophiesoJava Vir...sophiesop\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/avaJ/yrarbiL/ei", 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("cpRINTERjOBaMACOSXaLWAWTa    SUN");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cpRINTERjOBaMACOSXaLWAWTa    SUN" + "'", str1.equals("cpRINTERjOBaMACOSXaLWAWTa    SUN"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 448);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################################################################################################################################################################################################################################################################################################################################################################################################################################################" + "'", str2.equals("################################################################################################################################################################################################################################################################################################################################################################################################################################################################"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JA..", 84);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("mixiHdd(T)64-BmdoxomixiHdd(");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixiHdd(T)64-BmdoxomixiHdd(" + "'", str1.equals("mixiHdd(T)64-BmdoxomixiHdd("));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_94848_1560209674");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80-b15", "b");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/soph");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80-/Users/soph15" + "'", str4.equals("1.7.0_80-/Users/soph15"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "mixed mode                                               UTF-8", "/Users/sophie/Users/sophie/Library/Java/JavaVirtualMachin...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, charSequence1, 75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Users/sophie/Library/Java/Extensions:/Library/Ja...", "                en");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("K/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Co\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "\n");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "444444444444444444444444444", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "/Users/sophie" + "'", str6.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("54", "JavaHotSpot(TM)64-BitServerVM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "54" + "'", str2.equals("54"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80-b15", "jAVAhOTsPOT(tm)64-bITsERVERv");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("####################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"####################################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("7.1", "Mac OS X");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "mixiHdd(T)64-Bmdoxo", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/", 448, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.7.0_80-b15", (int) '#', 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "    SUNaLWAWTaMACOSXacpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "SUN.AWT.cgRAPHICSeNVIRONMENT", (java.lang.CharSequence) ":4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("eihpos/sresU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos/sresU" + "'", str1.equals("eihpos/sresU"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("erj/emoH/stnetnoC/k");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("Oracle Corporation", 60, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("boJretnirPC.xsocam.twawl.nus    ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocam.twawl.nus    " + "'", str2.equals("boJretnirPC.xsocam.twawl.nus    "));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(":SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRESU/:SNOISNETXE/AVAJ/YRARBIL/EIHPOS/SRSUN.AWT.CGRAPHICSENVIRONMENT", 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace(":snoisnetxE/avaJ/yra", "", ":snoisnetxE/avaJ/yra");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":snoisnetxE/avaJ/yra" + "'", str3.equals(":snoisnetxE/avaJ/yra"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "", 100);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence[]) strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                               UTF-8", (java.lang.CharSequence[]) strArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', 37, (int) (byte) 10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Ja...", (java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n/\n");
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strArray17);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.awt.CGraphicsEnvironment", "Java Virtual Machine Specification", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                    ", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444/44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         " + "'", str1.equals("         "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "snisnaxEJybiLiaJViauMainsdk170_80dkCnanasH", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) ":4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "\n\n\n\n\n\n\n\n01010010.1-\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.50.91.5");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification", "sunaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaawtaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaCaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaGraphicsaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaEnvironment", 142);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate(":snoisnetxE/avaJ/yra", 97, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("OacayuaCtamtaclltv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OacayuaCtamtaclltv" + "'", str1.equals("OacayuaCtamtaclltv"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("jAVAhOTsPOT(tm)64-bITsERVERv");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javahotspot(tm)64-bitserverv" + "'", str1.equals("javahotspot(tm)64-bitserverv"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa       " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa       "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444", "HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/HTTP://JJVJ.ORJCLE.COM/", "JavaHotSpot(TM)64-BitServerV", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444" + "'", str4.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/444444444444444444444444444444444"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                       JavaHotSpot(TM)64-BitServerVM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" ", 413, 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        short[] shortArray2 = new short[] { (short) 0, (byte) 0 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }
}

