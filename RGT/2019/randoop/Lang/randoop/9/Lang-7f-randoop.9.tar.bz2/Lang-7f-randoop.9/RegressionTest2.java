import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) " aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aa4aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa" + "'", str1.equals("aa4aaa"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase(" aaa4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " AAA4A" + "'", str1.equals(" AAA4A"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAA4A", (java.lang.CharSequence) "     3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("4a444a", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("class [Ljava.lang.String;class [C", "1.7               ", "        US");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("AAA4A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAA4A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Users/sophie/Library/Java/Extensions:/Library/Java/", "35 0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "08_0.7.1", 0, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, (int) 'a', (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("US    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.70.90.91.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (byte) 100, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("35404524100452");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35404524100452" + "'", str1.equals("35404524100452"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4a" + "'", str1.equals("a4a"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaa4aa", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa4aa" + "'", str3.equals("aaa4aa"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "4a444a", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " AAA4A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "  a 4 a", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("7.0_80-b15", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "US    ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", "aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8" + "'", str2.equals("#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("US    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US    " + "'", str1.equals("US    "));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("C[ ssalc;gnirtS.gnal.avajL[ ssalc", "08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "C[ ssalc;gnirtS.gnal.avajL[ ssalc" + "'", str2.equals("C[ ssalc;gnirtS.gnal.avajL[ ssalc"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " .7.0_80", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " ", (java.lang.CharSequence) "10.0a0.0a32.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 2, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US    ", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US    " + "'", str3.equals("US    "));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int[] intArray2 = new int[] { (short) 10, 30 };
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.6", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", " 4a444a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaa4aa", "100.0#97.0#-1.0#0.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aa" + "'", str2.equals("aaa4aa"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                      35a0a52a100a52", (java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                      35a0a52a100a52" + "'", charSequence2.equals("                                                                                      35a0a52a100a52"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100a100a0a10a-1", (java.lang.CharSequence) "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie", 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "100.0 97.0 -1.0 0.0 10.0", (java.lang.CharSequence) "-1#0#1", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                      35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("aaaaaaaaaaaaa/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4a444a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a444" + "'", str1.equals("4a444"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray12 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7.0_80" + "'", str16.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.7.0_80" + "'", str18.equals("1.7.0_80"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0 97.0 -1.0 0.0 10.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a10.0a10.0", "1.1");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "4a444a", (int) (byte) -1, 103);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                      35a0a52a100a52", (int) (short) 100);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", " aaa4aa", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("100.0 97.0 -1.0 0.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str1.equals("100.0 97.0 -1.0 0.0 10.0"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "/Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.6", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.0 10.0 10.0 10.0", (java.lang.CharSequence) "a", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("hi! 35a0a52a100a52", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi! 35a0a52a100a52" + "'", str2.equals("hi! 35a0a52a100a52"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/hie", "1.3", "-1#0#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/hie" + "'", str3.equals("/hie"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (int) '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", " ", 4);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "35#0#52#100#52", (java.lang.CharSequence[]) strArray16);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", strArray4, strArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                                                 1.1", "", 18);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100a100a0a10a-1", (java.lang.CharSequence) "100.0497.04-1.040.0410.0", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(" .7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " .7.0_80" + "'", str1.equals(" .7.0_80"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("SUN.LWAWT.MACOSX.LWCTOOLKIT", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", (java.lang.CharSequence) "10", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.0a0.0a32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/Users/sophie", "3.041.040.042.0410.0", "1.70.90.91.6");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "aa4aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8" + "'", str1.equals("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("32a1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32a1a-1" + "'", str1.equals("32a1a-1"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US##############################", (int) (byte) 1, 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "class [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaa4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAA4AA" + "'", str1.equals("AAA4AA"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aa4aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aa4aaa " + "'", str1.equals("aa4aaa "));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", 51);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "aaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("HI!", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   HI!    " + "'", str2.equals("   HI!    "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4a444", "1.7               ", (int) '4', 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7               " + "'", str4.equals("1.7               "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaa4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("     3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "     3.041.040.042.0410.0     " + "'", str1.equals("     3.041.040.042.0410.0     "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa", 2, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa" + "'", str3.equals("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray12 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "  a 4 a", (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.7", charSequence1, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a4a", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.1" + "'", str1.equals("08_0.7.1"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "10.14.3", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("-1a1a3", "-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a1a3" + "'", str2.equals("-1a1a3"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                 1.1", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 1.1" + "'", str2.equals("                                                                                                 1.1"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "    3.041.040.042.0410.0     ", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("\n", "01", "    3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" AAA4A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " AAA4A" + "'", str1.equals(" AAA4A"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                                    ", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" ", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, 0.0f, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("0.0a10.0a10.0a10.0", "35 0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str2.equals("0.0a10.0a10.0a10.0"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444" + "'", str2.equals("44444444444444"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("35#0#52#100#52", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52" + "'", str2.equals("35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (-1), 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaa" + "'", str1.equals("aaaaaa"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "44444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray14 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray10);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "1004100404104-1");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("aaa4aa", strArray6, strArray19);
        boolean boolean21 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "7.0_80-b15", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "aaa4aa" + "'", str20.equals("aaa4aa"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444444444", "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52", 3, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444" + "'", str4.equals("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("4a444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a444" + "'", str1.equals("4a444"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 1, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str9.equals("100.0#97.0#-1.0#0.0#10.0"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa" + "'", str1.equals("aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) 10, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "#a#4#a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) 97, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3.041.040.042.0410.0");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.041.040.042.0410.0" + "'", str2.equals("3.041.040.042.0410.0"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1 0 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" 4a444a", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              4a444a" + "'", str2.equals("                                                                                              4a444a"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("   HI!    ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HI!" + "'", str2.equals("HI!"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.9" + "'", str3.equals("0.9"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" 4a444a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a444a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 14, (long) (short) 100, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str1.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "    3.041.040.042.0410.0     ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Aaaaaaaaaa", (java.lang.CharSequence) "-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/uSERS/SOPHIE", "                  35404524100452");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) " aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aa4aaa", "100a100a0a10a-1");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", " ", 4);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JavaaPlatformaAPIaSpecification" + "'", str6.equals("JavaaPlatformaAPIaSpecification"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0 10.0 10.0 10.0", (java.lang.CharSequence) " aaa4aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.7", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aa4aaa", "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/uSERS/SOPHIE", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("10.0a0.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a0.0a32.0" + "'", str1.equals("10.0a0.0a32.0"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        char[] charArray5 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', 0, (int) (short) 1);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                              4a444a", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " aaa4aa" + "'", str7.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "  a 4 a" + "'", str9.equals("  a 4 a"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " " + "'", str13.equals(" "));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "44444444444444", "class [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#a#4#a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a#4#a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 103, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#######################################################################################################" + "'", str3.equals("#######################################################################################################"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.70.90.91.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java HotSpot(TM) 64-Bit Server VM", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("a 4 a", "7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a 4 a" + "'", str2.equals("a 4 a"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd(" aaa4a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaa4a" + "'", str2.equals(" aaa4a"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ', 0, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java Virtual Machine Specification", "3.0a1.0a0.0a2.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str2.equals("3.0a1.0a0.0a2.0a10.0"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Aaaaaaaaaa", "AAA4AA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("  a 4 a", (int) (short) 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  a 4 a" + "'", str3.equals("  a 4 a"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str5.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                      35a0a52a100a52");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "10.0a0.0a32.0", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.USER_TIMEZONE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" aaa4aa", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "us");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("US", "aa4aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 18, "e");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Aaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (-1), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" 4a444a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("35a0a52a100a52", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########35a0a52a100a52#########" + "'", str3.equals("#########35a0a52a100a52#########"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("3.041.040.042.0410.0", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8" + "'", str1.equals("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100 -1 -1 100 -1 0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        char[] charArray6 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4a444a", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " aaa4aa" + "'", str8.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " 4a444a" + "'", str10.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(":", "1.5", "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4a444a", (double) 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" aaa4a", (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 103L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) 100.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("AAA4A");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa4a" + "'", str1.equals("aaa4a"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4a444a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4a444a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" aaa4aa                                                                                             ", "us");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("A4a");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", "     3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     3.041.040.042.0410.0     " + "'", str2.equals("     3.041.040.042.0410.0     "));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                    ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.3", "0.0 10.0 10.0 10.0", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.3" + "'", str3.equals("0.3"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7               ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7               " + "'", str3.equals("1.7               "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/hie", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("UTF-8", "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US##############################", "\n", "AAA4A");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US##############################" + "'", str3.equals("US##############################"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 1, "    3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.3", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray7 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", "a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, (float) 35L, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "#########35a0a52a100a52#########", (java.lang.CharSequence) "1.7", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                     100#100#0#10#-1", "aaaaaaaaaa", "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                     100#100#0#10#-1" + "'", str3.equals("                                                                                     100#100#0#10#-1"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi! 35a0a52a100a52", (java.lang.CharSequence) " AAA4AA", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("3.0a1.0a0.0a2.0a10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                                                                                      35a0a52a100a52", (java.lang.CharSequence) "-1", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd(" ", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("   HI!    ", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   HI!    " + "'", str2.equals("   HI!    "));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hi!35a0a52a100a52", (java.lang.CharSequence) "Mac OS X", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80-B15", (java.lang.CharSequence) "0.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4a444a", "US", 103);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1004100404104-1", charSequence1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1L), (float) 32L, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "a", (java.lang.CharSequence) "100.0 97.0 -1.0 0.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("     3.041.040.042.0410.0     ", 103, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " AAA4AA", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "44444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "US    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.awt.CGraphicsEnvironment", "aaa4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4a" + "'", str2.equals("aaa4a"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("32a1a-1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#0#1", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n", (int) (byte) 100, 2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("32a1a-1", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444" + "'", str2.equals("44444444444444"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        char[] charArray6 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "51.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " aaa4aa" + "'", str8.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " 4a444a" + "'", str10.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "     3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/hie", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa" + "'", str2.equals(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie" + "'", str1.equals("/Users/sophie"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3.041.040.042.0410.0");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("100.0 97.0 -1.0 0.0 10.0", "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaa4a", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Mac OS X", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\n", " AAA4A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (byte) -1, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "Java Platform API Specification", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "  a 4 a", 35);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "A4a", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 3, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa" + "'", str3.equals("aaa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie", (int) (byte) 10, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...ie/hie/hie/hie/hie/hie/hie/hi..." + "'", str3.equals("...ie/hie/hie/hie/hie/hie/hie/hi..."));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "#########35a0a52a100a52#########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1a1a3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a1a3" + "'", str1.equals("-1a1a3"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", (int) (short) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" .7.0_80", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", "100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aa4aaa ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa4aaa " + "'", str2.equals("aa4aaa "));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("10", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), 1.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', (int) (short) -1, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "                                                                                     100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "7.0_80-b15", (java.lang.CharSequence) "    3.041.040.042.0410.0     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32.0f, 0.0d, (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a 4 a", "44444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("35404524100452", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) " .7.0_80", (java.lang.CharSequence) "0.0 10.0 10.0 10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", (java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.5", "/Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa", " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 54, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java Platform API Specification", "aaa4aa", 51);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "435#0#5..." + "'", str2.equals("435#0#5..."));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 6, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("A4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A4a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(" aaa4aa                                                                                             ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae" + "'", str1.equals("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("\n", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("-1a1a32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a1a32" + "'", str1.equals("-1a1a32"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100 -1 -1 100 -1 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100 -1 -1 100 -1 0" + "'", str1.equals("100 -1 -1 100 -1 0"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aa4aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa4aa" + "'", str1.equals("aaa4aa"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                35 0                                                ", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("     3.041.040.042.0410.0     ", 0, " AAA4AA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     3.041.040.042.0410.0     " + "'", str3.equals("     3.041.040.042.0410.0     "));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a 4 a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a 4 a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "#a#4#a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1040435410", "e", "sophie");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("32a1a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 52, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "1.6", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "Aaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4a444a", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.70.90.91.6", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1#0#1", (java.lang.CharSequence) "4a444a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "   HI!    ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                                    ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100#100#0#10#-1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#100#0#10#-1" + "'", str2.equals("100#100#0#10#-1"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("   HI!    ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("08_0.7.1", "                  35404524100452", (int) ' ');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a1a3", 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "100#100#0#10#-1", (java.lang.CharSequence) "aaaaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_80-B15", 54);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1a1a32", "Users/sophie/Library/Java/Extensions:/Library/Java/");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Users/sophie/Library/Java/Extensions:/Library/Java/", "100 -1 -1 100 -1 0", "01");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52, 0.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("US##############################", "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US##############################" + "'", str2.equals("US##############################"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                      35a0a52a100a52", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aa4aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aa4aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad(" #a#4#a", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " #a#4#a" + "'", str2.equals(" #a#4#a"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("UTF-8", "aaa4a", "4a444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n" + "'", str3.equals("aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        char[] charArray6 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100 -1 -1 100 -1 0", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " aaa4aa" + "'", str8.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java(TM)SERuntimeEnvironment", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM)SERuntimeEnvironment" + "'", str2.equals("Java(TM)SERuntimeEnvironment"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob", "\n", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaa" + "'", str1.equals("aaaaaaaaa"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "100.0");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.6", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "44444444444444", (java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("35404524100452", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 14, "hi! 35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1.0f, (double) (byte) 100, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) ":", "a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   " + "'", str2.equals("   "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.3", "...ie/hie/hie/hie/hie/hie/hie/hi...", "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7               " + "'", str1.equals("1.7               "));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100a100a0a10a-1", (java.lang.CharSequence) "AAA4AA", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "\n", 4, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.1", 0, 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("35404524100452", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452" + "'", str2.equals("354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaa4aa", "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aa" + "'", str2.equals("aaa4aa"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("        US", "1.6", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("class [Ljava.lang.String;class [C");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100a100a0a10a-1", 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("100 -1 -1 100 -1 0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100 -1 -1 100 -1 0" + "'", str2.equals("100 -1 -1 100 -1 0"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 35, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.7.0_80-B15", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aa4aaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray13 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "1004100404104-1");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("aaa4aa", strArray5, strArray18);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray20, ' ');
        int int23 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray20);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "aaa4aa" + "'", str19.equals("aaa4aa"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.7.0_80" + "'", str22.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("    3.041.040.042.0410.0     ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    3.041.040.042.0410.0     " + "'", str2.equals("    3.041.040.042.0410.0     "));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/uSERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/uSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a-1a-1a100a-1a0" + "'", str14.equals("100a-1a-1a100a-1a0"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase(":", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4a444", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100404104-1" + "'", str10.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100#100#0#10#-1" + "'", str13.equals("100#100#0#10#-1"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie", (int) '4', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                       " + "'", str3.equals("/Users/sophie                                       "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("-1a1a3", "AAA4AA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a1a3" + "'", str2.equals("-1a1a3"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456", "", "        US");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "   HI!    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n", "                                                35 0                                                ", 68, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                35 0                                                " + "'", str4.equals("                                                35 0                                                "));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("        US", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("us", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "hi!", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "        US", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a###4# ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a###4#" + "'", str1.equals("a###4#"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "10.14.3", "35 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: " + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        char[] charArray8 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray8);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "-1a1a3", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " aaa4aa" + "'", str10.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " 4a444a" + "'", str12.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "C[ ssalc;gnirtS.gnal.avajL[ ssalc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (java.lang.CharSequence) "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35404524100452", "Java HotSpot(TM) 64-Bit Server VM", 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', (-1), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid(" aaa4aa                                                                                             ", 51, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(100.0d, (double) 52L, 6.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        char[] charArray5 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " aaa4aa" + "'", str7.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "  a 4 a" + "'", str9.equals("  a 4 a"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "  a 4 a" + "'", str11.equals("  a 4 a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "#########35a0a52a100a52#########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32L, (double) 18, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1.6");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaa", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "0.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52" + "'", str1.equals("35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100a100a0a10a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Oracle Corporation" + "'", str1.equals("/Oracle Corporation"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1" + "'", str8.equals("-1 0 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0a1" + "'", str11.equals("-1a0a1"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "0.0 10.0 10.0 10.0", (java.lang.CharSequence) "US##############################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", (int) (byte) 1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0.0a10.0a10.0a10.0", "                  35404524100452", "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str3.equals("0.0a10.0a10.0a10.0"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "100a100a0a10a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("US", "a###4# ", "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52", (java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "us    ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 52, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED", (java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "\n", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA" + "'", str1.equals("AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", "hi!", "hi!                                                                                      35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8" + "'", str3.equals("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52", "sun.awt.CGraphicsEnvironment", "a");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1 0 1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.Class<?> wildcardClass10 = floatArray5.getClass();
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 3, 103);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3.041.040.042.0410.0" + "'", str9.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "08_0.7.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) 3, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaa", "x86_64", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaa" + "'", str3.equals("aaaaaaaaa"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie                                       ", " AAA4A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "-1 0 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        char[] charArray6 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass11 = charArray6.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.70.90.91.6", charArray6);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b15", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("SUN.LWAWT.MACOSX.LWCTOOLKIT", "US##############################", 97, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US##############################" + "'", str4.equals("US##############################"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!                                                                                      35a0a52a100a52");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi! \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0.9", "100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aa4aaa ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                  35404524100452", "1.6", "0.0 10.0 10.0 10.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1a1a32", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/uSERS/SOPHIE", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "a###4# ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(10.0f, 32.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("a4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4a" + "'", str1.equals("a4a"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v# HotSpot(TM) 64-Bit Server VM######################################################################" + "'", str3.equals("J#v# HotSpot(TM) 64-Bit Server VM######################################################################"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" .7.0_80", "0.3", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("us    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.5", "aaaaaaaaaaaaa/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1004100404104-1", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("10", "1.7.0_80-B15", "-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE" + "'", str1.equals("/uSERS/SOPHIE"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  35404524100452", "0.0a10.0a10.0a10.0", 14);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }
}

