import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("mixed mode", 350.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 350.0d + "'", double2 == 350.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 2, 4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float18 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str10.equals("100.0#97.0#-1.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.040.0" + "'", str15.equals("-1.040.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str17.equals("100.0#97.0#-1.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + (-1.0f) + "'", float18 == (-1.0f));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1 10 -1 1 100", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 2, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        java.lang.String str4 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        boolean boolean11 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10 0 4 3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 0 4 3" + "'", str1.equals("10 0 4 3"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.0a0.0a32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a0.0a32.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("444a", "-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456", (java.lang.CharSequence[]) strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3.041.040.042.0410.0");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray14, strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray9, strArray14);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", strArray3, strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Java Virtual Machine Specification" + "'", str18.equals("Java Virtual Machine Specification"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:." + "'", str19.equals("/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:."));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " 4a444a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdkt.7.-_8-.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdkt.7.-_8-.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdkt.7.-_8-.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1 10 -1 1 100", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "us");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 10 -1 1 100" + "'", str3.equals("-1 10 -1 1 100"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100.0 1.0 0.0 100.0 10.0 0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 1.0 0.0 100.0 10.0 0.0" + "'", str1.equals("100.0 1.0 0.0 100.0 10.0 0.0"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("444a", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:.", "08_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:." + "'", str2.equals("ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:."));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        char[] charArray8 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a###4# ", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " aaa4aa" + "'", str10.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " 4a444a" + "'", str12.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + " #a#4#a" + "'", str17.equals(" #a#4#a"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi! 35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi! 35a0a52a100a52" + "'", str1.equals("hi! 35a0a52a100a52"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', (int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.CharSequence charSequence5 = null;
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence5, (java.lang.CharSequence[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray4, strArray8);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a10.0a10.0", "1.1");
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.70.90.91.6", strArray4, strArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 8");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "en" + "'", str11.equals("en"));
        org.junit.Assert.assertNotNull(strArray14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(94, 103, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 103 + "'", int3 == 103);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", (java.lang.CharSequence) "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10a0a35a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a0a35a1" + "'", str1.equals("10a0a35a1"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str12.equals("3.0a1.0a0.0a2.0a10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 10.0f + "'", float13 == 10.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray12 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray4, strArray8);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "\n");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray17);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7.0_80" + "'", str16.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.7.0_80" + "'", str18.equals("1.7.0_80"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(13, 2, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie", (-1), '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie" + "'", str3.equals("/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10a0a35a10", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("us    ");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaa4aa", "/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE/HIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aa" + "'", str2.equals("aaa4aa"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("j#v# HotSpot(TM) 64-Bit Server VM######################################################################");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.0 10.0 10.0 10.0", (java.lang.CharSequence) "hie/Library/Java/Extensions:", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("    3.041.040.042.0410.0     ", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    3.041.040.042.0410.0     " + "'", str2.equals("    3.041.040.042.0410.0     "));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAA4A");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA", "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA" + "'", str2.equals("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "44444444444444", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaa"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "           100.0 1.0 0.0 100.0 10.0 0.0            ", (java.lang.CharSequence) "100 100 0 10 -1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 38 + "'", int2 == 38);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("10.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1" + "'", str12.equals("-1"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("           100.0 1.0 0.0 100.0 10.0 0.0            ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:.", (java.lang.CharSequence) "4 a", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        char[] charArray9 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " aaa4aa                                                                                             ", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaa", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) ":", charArray9);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 51, 14);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.0 97.0 -1.0 0.0 10.0", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " aaa4aa" + "'", str11.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " 4a444a" + "'", str13.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaa4a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("################################", "", "4AAAAA4AAAAA4AAAAA4");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("100.0#97.0#-1.0#0.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str1.equals("100.0#97.0#-1.0#0.0#10.0"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.041.040.042.0410.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("3.041.040.042.0410.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("35#0#52#100#52", 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Aaaaaaaaaa", "sophie");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("-1#0#1", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#0#1" + "'", str8.equals("-1#0#1"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("aa4aaa ", "4a444a", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a###4#", "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("3.0 1.0 0.0 2.0 10.0", "", 345);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("us", strArray3, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "us" + "'", str8.equals("us"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10 0 4 3", (java.lang.CharSequence) "mixed mode", 33);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "US                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("US##############################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 24, (float) 35L, 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 24.0f + "'", float3 == 24.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.0 10.0 10.0 10.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("e", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.reflect.AnnotatedElement[] annotatedElementArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\nMac OS Xaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "97#0#35#-1#52#30");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA", 200);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA" + "'", str2.equals(" PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        char[] charArray10 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 0, (int) (byte) -1);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " aaa4aa", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "100.0#97.0#-1.0#0.0#10.0", charArray10);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "-1a1a32", charArray10);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10a10a0", charArray10);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "  # a a" + "'", str22.equals("  # a a"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("AAA042.0-1a0a1", "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA042.0-1a0a1" + "'", str2.equals("AAA042.0-1a0a1"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100 -1 -1 100 -1 0", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "#a#4#a", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " AAA4A", (java.lang.CharSequence) "a4#444 ", 22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100a-1a-1a100a-1a0" + "'", str17.equals("100a-1a-1a100a-1a0"));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) 100 + "'", byte18 == (byte) 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "        US");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10a0a35a10", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                      35a0a52a100a52", "E", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "hie/Library/Java/Extensions:", (java.lang.CharSequence) "97#0#35#-1#52#30");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10a0a35a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4a444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100#100#0#10#-1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" AAA4AA");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "E");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "aa4aaa ", (-1));
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) " AAA4A", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "http://java.oracle.com/" + "'", str6.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("A", (int) (byte) 10, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("US    ");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.7               ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4AAAAA4AAAAA4AAAAA4", 9, "a 4 a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4AAAAA4AAAAA4AAAAA4" + "'", str3.equals("4AAAAA4AAAAA4AAAAA4"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("\n", 175);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                       \n                                                                                       " + "'", str2.equals("                                                                                       \n                                                                                       "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("35#0#52#100#52", "AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA", "100.0 1.0 0.0 100.0 10.0 0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35#0#52#100#52" + "'", str3.equals("35#0#52#100#52"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.70.90.91.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1#0#1-1#0#1/var/folders/_v/6v597zmnsun.lwawt.macosx.LWCToolkit1#0#1-1#0#1/var/folders/_v/6v597zmn", 2, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10a10a0", (java.lang.CharSequence) "javavirtualmachinespecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Oracle Corporation", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        double[] doubleArray6 = new double[] { (byte) 100, (byte) 1, 0.0f, 100.0f, (byte) 10, 0 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 1, (int) (byte) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "A4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4a", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean7 = javaVersion5.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass8 = javaVersion6.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean10 = javaVersion6.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion[] javaVersionArray11 = new org.apache.commons.lang3.JavaVersion[] { javaVersion0, javaVersion1, javaVersion4, javaVersion6 };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(javaVersionArray11);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Enum<org.apache.commons.lang3.JavaVersion>[]) javaVersionArray11);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(javaVersionArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.70.90.91.6" + "'", str12.equals("1.70.90.91.6"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.70.90.91.6" + "'", str13.equals("1.70.90.91.6"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ", "35");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa " + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa "));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "a 4 a", (java.lang.CharSequence) "01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass11 = javaVersion9.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion9.atLeast(javaVersion12);
        boolean boolean14 = javaVersion7.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        java.lang.String str17 = javaVersion15.toString();
        java.lang.String str18 = javaVersion15.toString();
        java.lang.String str19 = javaVersion15.toString();
        boolean boolean20 = javaVersion7.atLeast(javaVersion15);
        boolean boolean21 = javaVersion4.atLeast(javaVersion15);
        java.lang.String str22 = javaVersion15.toString();
        java.lang.String str23 = javaVersion15.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.5" + "'", str17.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.5" + "'", str18.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.5" + "'", str19.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.5" + "'", str22.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.5" + "'", str23.equals("1.5"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        char[] charArray9 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "AAA4A", charArray9);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " aaa4aa" + "'", str11.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " 4a444a" + "'", str13.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 45 + "'", int18 == 45);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("#################", "    3.041.040.042.0410.0     ", "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52", 30);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#################" + "'", str4.equals("#################"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("US    ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "######################################################################C[ ssalc;gnirtS.gnal.avajL[ ssalc", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA" + "'", str2.equals("AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.0a0.0a32.0", 6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "C[ SSALC;G/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 32, 1);
        short short19 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 0, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100404104-1" + "'", str10.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a100a0a10a-1" + "'", str13.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 100 + "'", short19 == (short) 100);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        double[] doubleArray4 = new double[] { 0, (short) 10, 10.0d, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) '4', (int) (short) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double17 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str6.equals("0.0 10.0 10.0 10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str8.equals("0.0a10.0a10.0a10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str15.equals("0.0 10.0 10.0 10.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a###4# ", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Aaaaaaaaaa", charArray9);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray9, '#');
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " aaa4aa" + "'", str11.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " 4a444a" + "'", str13.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + " #a#4#a" + "'", str19.equals(" #a#4#a"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1.0#52.0#-1.0#10.0#10.0#32.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("X SO caM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray16 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray12, strArray16);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray12);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "1004100404104-1");
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEach("aaa4aa", strArray8, strArray21);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray23, ' ');
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" AAA4AA", strArray2, strArray23);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "aaa4aa" + "'", str22.equals("aaa4aa"));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1.7.0_80" + "'", str25.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + " AAA4AA" + "'", str26.equals(" AAA4AA"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456" + "'", str27.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.7               ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7               " + "'", str2.equals("1.7               "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence1, (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 75 + "'", int7 == 75);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1040435410" + "'", str7.equals("1040435410"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1040435410" + "'", str9.equals("1040435410"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.7.0_80-B15", "#a#4#a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aa4aaJava", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALC");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aa4aaJava" + "'", charSequence2.equals("aa4aaJava"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (byte) 100, (int) '#');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a', (int) (short) 100, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray10, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                 1.");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US444444444444" + "'", str1.equals("US444444444444"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1a0a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALC", (java.lang.CharSequence) "  a 4 a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8" + "'", str2.equals("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100.0#1.0#0.0#100.0#10.0#0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 38, (float) (short) -1, (float) 52);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("100a100a0a10a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a100a0a10a-1" + "'", str1.equals("100a100a0a10a-1"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1" + "'", str16.equals("-1"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "AAAAAAAAA", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  35404524100452");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1.0a52.0a-1.0a10.0a10.0a32.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                 1.1", " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 1.1" + "'", str2.equals("                                                                                                 1.1"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35404524100452", "Java HotSpot(TM) 64-Bit Server VM", 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "#a#4#a");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        char[] charArray7 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " aaa4aa" + "'", str9.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " 4a444a" + "'", str11.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                                              4a444a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                              4A444A" + "'", str1.equals("                                                                                              4A444A"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        double[] doubleArray6 = new double[] { (byte) 100, (byte) 1, 0.0f, 100.0f, (byte) 10, 0 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 97, 5);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', 51, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        char[] charArray7 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "32a1a-1", charArray7);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', 22, 0);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA", (java.lang.CharSequence) "100.0a1.0a0.0a100.0a10.0a0444a", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1.0 52.0 -1.0 10.0 10.0 32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                  35404524100452", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "35 0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "1004100404104-1");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4", "/Users/sophie/Libr4ry/J4v4/Extensions:/Libr4ry/J4v4/Extensions:/Network/Libr4ry/J4v4/Extensions:/System/Libr4ry/J4v4/Extensions:/usr/lib/j4v4:.", "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN#_V31CQ2N2X1N#FC0000GN/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "D" + "'", str3.equals("D"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "a 4 a", (java.lang.CharSequence) "#########35a0a52a100a52#########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, (int) (short) 0, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        char[] charArray8 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "e", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java Virtual Machine Specification", charArray8);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " aaa4aa" + "'", str10.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " 4a444a" + "'", str12.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + " #a#4#a" + "'", str17.equals(" #a#4#a"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + " #a#4#a" + "'", str20.equals(" #a#4#a"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str13.equals("3.0a1.0a0.0a2.0a10.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3.0#1.0#0.0#2.0#10.0" + "'", str15.equals("3.0#1.0#0.0#2.0#10.0"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.1", "                                                                                       \n                                                                                       ", "-1a1a32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100#100#0#10#-", "10a0a35a1", "class [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#0#10#-" + "'", str3.equals("100#100#0#10#-"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALCaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALCaa" + "'", str1.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALCaa"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1004100404104-1", (java.lang.CharSequence) "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "us");
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "�" + "'", str10.equals("�"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.0 10.0 10.0 10.0", "100 100 0 10 -1", "javavirtualmachinespecification", 50);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str4.equals("0.0 10.0 10.0 10.0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hie/Library/Java/Extensions:", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("x86_64", "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 100, 10L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("32a1a-1", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa32a1a-1" + "'", str3.equals("aaa32a1a-1"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1#0#1-1#0#1/var/folders/_v/6v597zmnsun.lwawt.macosx.LWCToolkit1#0#1-1#0#1/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0#1-1#0#1/var/folders/_v/6v597zmnsun.lwawt.macosx.LWCToolkit1#0#1-1#0#1/var/folders/_v/6v597zmn" + "'", str1.equals("1#0#1-1#0#1/var/folders/_v/6v597zmnsun.lwawt.macosx.LWCToolkit1#0#1-1#0#1/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                rt n                                                ", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                rt n                                                " + "'", charSequence2.equals("                                                rt n                                                "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10a10a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        java.lang.String str3 = javaVersion1.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        java.lang.Class<?> wildcardClass12 = javaVersion10.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean14 = javaVersion10.atLeast(javaVersion13);
        boolean boolean15 = javaVersion8.atLeast(javaVersion10);
        boolean boolean16 = javaVersion5.atLeast(javaVersion8);
        boolean boolean17 = javaVersion1.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion19 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean20 = javaVersion18.atLeast(javaVersion19);
        boolean boolean21 = javaVersion8.atLeast(javaVersion18);
        boolean boolean22 = javaVersion0.atLeast(javaVersion18);
        java.lang.String str23 = javaVersion18.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion19 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion19.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0.9" + "'", str23.equals("0.9"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("435#0#5...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "435#0#5..." + "'", str1.equals("435#0#5..."));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "utf-8444444444444444444444444444444", (java.lang.CharSequence) "1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("AAA042.0-1a0a1", 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        AAA042.0-1a0a1" + "'", str2.equals("                        AAA042.0-1a0a1"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1041040", 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (java.lang.CharSequence) "a 4 a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 0, (float) 38, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("US                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"US\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi", "D");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100.0", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0" + "'", str2.equals("100.0"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "C[ ssalc;gnirtS.gnal.avajL[ ssalc", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("042.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "042.0410.0" + "'", str1.equals("042.0410.0"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaa4a", "0.0#10.0#10.0#10.0", 38);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa4a" + "'", str3.equals("aaa4a"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " AAA4A", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa4aaa", (java.lang.CharSequence) "435#0#5...", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaa", (java.lang.CharSequence) "class [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "D", (java.lang.CharSequence) "                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        double[] doubleArray6 = new double[] { (byte) 100, (byte) 1, 0.0f, 100.0f, (byte) 10, 0 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', 10, 0);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) ' ', 103);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("J#v# HotSpot(TM) 64-Bit Server VM######################################################################", "1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J HtSpt(M) Bit S VM" + "'", str3.equals("J HtSpt(M) Bit S VM"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2L, 345.0d, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 345.0d + "'", double3 == 345.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.70.90.91.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "32a1a-1", (java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456", (java.lang.CharSequence) "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52###########");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("350", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "350aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("350aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1#.#6             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#.#6" + "'", str1.equals("1#.#6"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "e", (int) '4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("141", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a10a0", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaa", "10.14.3");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        char[] charArray11 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray11);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a###4# ", charArray11);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Aaaaaaaaaa", charArray11);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Oracle Corporation", charArray11);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aa4aaJava", charArray11);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "24.80-b11", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " aaa4aa" + "'", str13.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " 4a444a" + "'", str15.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + " 4a444a" + "'", str21.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("...ie/hie/hie/hie/hie/hie/hie/hi...", "-14-141410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...ie/hie/hie/hie/hie/hie/hie/hi..." + "'", str2.equals("...ie/hie/hie/hie/hie/hie/hie/hi..."));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1", (java.lang.CharSequence) "-1a1a32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "100.0a1.0a0.0a100.0a10.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1#0#1");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4', 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass12 = charArray7.getClass();
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/uSERS/SOPHIE", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + " 4#4a4a" + "'", str17.equals(" 4#4a4a"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10a0a35a1", 22);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      10a0a35a1       " + "'", str2.equals("      10a0a35a1       "));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("hia!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hia!" + "'", str1.equals("hia!"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) " AAA4A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aa4aaJava", "35 0                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 10, 38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 0, (long) 'a', (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "us444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("j#v# HotSpot(TM) 64-Bit Server VM######################################################################", " 4a444a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 18, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "1#.#6");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1#.#6");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 103 + "'", int2 == 103);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ", "1.1", 200);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 50);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 1, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "141" + "'", str5.equals("141"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" aaa4aa                                                                                             ", 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) 345L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion2);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi", 51, 345);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi" + "'", str3.equals("/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        boolean boolean7 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str8 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion13);
        java.lang.String str15 = javaVersion13.toString();
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion17 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion18 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean19 = javaVersion17.atLeast(javaVersion18);
        java.lang.Class<?> wildcardClass20 = javaVersion18.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean22 = javaVersion18.atLeast(javaVersion21);
        boolean boolean23 = javaVersion16.atLeast(javaVersion18);
        boolean boolean24 = javaVersion13.atLeast(javaVersion16);
        boolean boolean25 = javaVersion9.atLeast(javaVersion16);
        java.lang.String str26 = javaVersion16.toString();
        java.lang.String str27 = javaVersion16.toString();
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean29 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
        java.lang.String str30 = javaVersion28.toString();
        boolean boolean31 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion28);
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean33 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion32);
        java.lang.String str34 = javaVersion32.toString();
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion36 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean38 = javaVersion36.atLeast(javaVersion37);
        java.lang.Class<?> wildcardClass39 = javaVersion37.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion40 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean41 = javaVersion37.atLeast(javaVersion40);
        boolean boolean42 = javaVersion35.atLeast(javaVersion37);
        boolean boolean43 = javaVersion32.atLeast(javaVersion35);
        boolean boolean44 = javaVersion28.atLeast(javaVersion35);
        boolean boolean45 = javaVersion16.atLeast(javaVersion35);
        boolean boolean46 = javaVersion0.atLeast(javaVersion16);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.8" + "'", str8.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.5" + "'", str11.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.5" + "'", str15.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion17 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion17.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion18 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion18.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1.8" + "'", str26.equals("1.8"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1.8" + "'", str27.equals("1.8"));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.5" + "'", str30.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1.5" + "'", str34.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion36 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion36.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + javaVersion40 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion40.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa     0.0140.240.040.140.3     ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: " + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: "));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10a0a35a10" + "'", str7.equals("10a0a35a10"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("50");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "50" + "'", str1.equals("50"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 0, 2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', (int) 'a', (int) (byte) 1);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', (int) 'a', 24);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "35 0" + "'", str12.equals("35 0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "35404524100452" + "'", str14.equals("35404524100452"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("3.041.040.042.0410.0     ene", (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "", "/Users/sophie                                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                       " + "'", str3.equals("/Users/sophie                                       "));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        int[] intArray3 = new int[] { ' ', (byte) 1, (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 100, (int) (byte) 0);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32a1a-1" + "'", str5.equals("32a1a-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "aaa4a", (java.lang.CharSequence) "AAA042.0-1a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "      52.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 345);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 345.0f + "'", float2 == 345.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        int[] intArray3 = new int[] { ' ', (byte) 1, (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.Class<?> wildcardClass8 = intArray3.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32a1a-1" + "'", str5.equals("32a1a-1"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#########35a0a52a100a52#########", 35, 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "350aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("sun.lwawt.macosx.LWCToolkit", (int) (short) -1, 94);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 345);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                         " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                         "));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.1" + "'", str5.equals("1.1"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        org.apache.commons.lang3.StringUtils[] stringUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 100, 6);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                 " + "'", str2.equals("                                 "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b1" + "'", str1.equals("1.7.0_80-b1"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " 0 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "-1a0a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10 0 4 3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("103.0 14.0 18.0", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', 54, 7);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("hi!", "1.5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.math.BigDecimal[] bigDecimalArray0 = new java.math.BigDecimal[] {};
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(bigDecimalArray0);
        org.junit.Assert.assertNotNull(bigDecimalArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 3, 1);
        short short21 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#10#-1" + "'", str11.equals("100#100#0#10#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004100404104-1" + "'", str13.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a100a0a10a-1" + "'", str15.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 100 + "'", short21 == (short) 100);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("10a10a0", "http://java.oracle.com/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100404104-1" + "'", str10.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a100a0a10a-1" + "'", str13.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100#100#0#10#-1" + "'", str16.equals("100#100#0#10#-1"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                 /lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                            aa4aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                            aa4aaa " + "'", str1.equals("                                            aa4aaa "));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        double[] doubleArray2 = new double[] { 52, 51 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 0, (int) (short) 1);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 68, 22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52.0" + "'", str7.equals("52.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 52.0d + "'", double8 == 52.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 52.0d + "'", double9 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                rt n                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                n tr                                                " + "'", str1.equals("                                                n tr                                                "));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("X SO caM", 52, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caM############################################" + "'", str3.equals("X SO caM############################################"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                                 1.1", (java.lang.CharSequence) "                                                                                              4A444A");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "us    ", (java.lang.CharSequence) "-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        double[] doubleArray4 = new double[] { 0, (short) 10, 10.0d, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) '4', (int) (short) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str6.equals("0.0 10.0 10.0 10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str8.equals("0.0a10.0a10.0a10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0#10.0#10.0#10.0" + "'", str15.equals("0.0#10.0#10.0#10.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.0#10.0#10.0#10.0", 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 18.0f, (double) 1L, 0.3d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2L, (double) 5, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXT...", 75, 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi", (int) 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...re/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi" + "'", str3.equals("...re/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(51.0d, (double) 52L, 0.3d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                               -1                                                ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     -1                                                " + "'", str2.equals("                                     -1                                                "));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10 0 35 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "A4a", (java.lang.CharSequence) "a###4#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("�");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        char[] charArray6 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                  35404524100452", charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " aaa4aa" + "'", str8.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " aaa4aa" + "'", str11.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 103, (float) 200L, 350.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 350.0f + "'", float3 == 350.0f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 12, 12);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100a-1a-1a100a-1a0" + "'", str17.equals("100a-1a-1a100a-1a0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("J HtSpt(M) Bit S VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java(TM)SERuntimeEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM)SERuntimeEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", (java.lang.CharSequence) "3.0#1.0#0.0#2.0#10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", (java.lang.CharSequence) "US444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#######################################################################################################", "\n", 345);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("A4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4a" + "'", str1.equals("A4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4aA4a"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("35 0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("042.0410.0cle Corporation", "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "042.0410.0cle Corporation" + "'", str2.equals("042.0410.0cle Corporation"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("  # a a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(3.0f, 100.0f, (float) 5L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3", (java.lang.CharSequence) "/hie", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a10.0a10.0", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4', (int) (byte) 100, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass11 = javaVersion9.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion9.atLeast(javaVersion12);
        boolean boolean14 = javaVersion7.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        java.lang.String str17 = javaVersion15.toString();
        java.lang.String str18 = javaVersion15.toString();
        java.lang.String str19 = javaVersion15.toString();
        boolean boolean20 = javaVersion7.atLeast(javaVersion15);
        boolean boolean21 = javaVersion4.atLeast(javaVersion15);
        java.lang.String str22 = javaVersion4.toString();
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.5" + "'", str17.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.5" + "'", str18.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.5" + "'", str19.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.3" + "'", str22.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                       -1                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', (int) (byte) 100, 10);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10a0a35a10" + "'", str9.equals("10a0a35a10"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444", " 4a444a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi!                                                                                      35a0a52a100a52", "100a100a0a10a-1", (int) (short) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.3", 103);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a', (int) '#', (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaa32a1a-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa32a1a-1" + "'", str2.equals("aaa32a1a-1"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("0.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.3" + "'", str1.equals("0.3"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaa4aa", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                       -1                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    " + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "32a1a-1", "AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                n tr                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 32, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("##########################################25a001a25a0a53!ih#########################################", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########################################25a001a25a0a53!ih#########################################" + "'", str2.equals("##########################################25a001a25a0a53!ih#########################################"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) 'a', (int) 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 54, 0);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "1.8");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.8");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "-1.0#52.0#-1.0#10.0#10.0#32.0", "5 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                                                n tr                                                ", "#35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52###########", "D");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "#########################################hi!35a0a52a100a52##########################################", (java.lang.CharSequence) "                                                                                              x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float13 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str9.equals("100.0#97.0#-1.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0497.04-1.040.0410.0" + "'", str11.equals("100.0497.04-1.040.0410.0"));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 100.0f + "'", float13 == 100.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("AAA4AA", 45);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4AA" + "'", str2.equals("AAA4AA"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("35 0                          ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35 0                          " + "'", str2.equals("35 0                          "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "435#0#5...", (java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java                                                                                    x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Users/sophie/Library/Java/Extensions:/Library/Java/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SOPHIE" + "'", str1.equals("SOPHIE"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1 0 1", "US##############################Use");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   444444444444444444444444444444444444444444444444", 32, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "44444444444444", (java.lang.CharSequence) "MIXED MODE", 345);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "US                                                 ", "01");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "100.0#97.0#-1.0#0.0#10.0", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8Spec aaa4a", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        int[] intArray6 = new int[] { 97, (short) 0, 35, (short) -1, '4', 30 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, '#');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97#0#35#-1#52#30" + "'", str8.equals("97#0#35#-1#52#30"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#0#35#-1#52#30" + "'", str10.equals("97#0#35#-1#52#30"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        char[] charArray7 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " aaa4aa                                                                                             ", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, '#');
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " aaa4aa" + "'", str9.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " 4a444a" + "'", str11.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " #a#4#a" + "'", str15.equals(" #a#4#a"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa     0.0140.240.040.140.3     ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "J#v# HotSpot(TM) 64-Bit Server VM######################################################################", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1a1a32", "Users/sophie/Library/Java/Extensions:/Library/Java/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " aaa4aa                    ...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-1a1a32" + "'", str4.equals("-1a1a32"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hia!", 7, 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                       \n                                                                                       ", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        char[] charArray10 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray10, '4');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a###4# ", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Aaaaaaaaaa", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "0.9", charArray10);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10 0 4 3", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " aaa4aa" + "'", str12.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " 4a444a" + "'", str14.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "us    ", (java.lang.CharSequence) "-1#0#1aaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B151.7.0_80-B15", 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", "3/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.2/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa" + "'", str2.equals("aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("#########################################hi!35a0a52a100a52##########################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################################hi!35a0a52a100a52##########################################" + "'", str2.equals("#########################################hi!35a0a52a100a52##########################################"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean4 = javaVersion2.atLeast(javaVersion3);
        java.lang.Class<?> wildcardClass5 = javaVersion3.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean7 = javaVersion3.atLeast(javaVersion6);
        java.lang.String str8 = javaVersion6.toString();
        boolean boolean9 = javaVersion1.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion11);
        boolean boolean14 = javaVersion1.atLeast(javaVersion11);
        boolean boolean15 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.3" + "'", str8.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("35#0#52#100#52", "100 100 0 10 -1", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("utf-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", (java.lang.CharSequence) "SOPHIE", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3.041.040.042.0410.0" + "'", str12.equals("3.041.040.042.0410.0"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.0#200.0#35.0#3.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("                                                                                             aa4aaa ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                             aa4aaa " + "'", str1.equals("                                                                                             aa4aaa "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXT...", (java.lang.CharSequence) "3.041.040.042.0410.0     ene");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                       0.0 10.0 10.0 10.0                                        ", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       0.0 10.0 10.0 10.0                                        " + "'", str2.equals("                                       0.0 10.0 10.0 10.0                                        "));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        short[] shortArray1 = new short[] { (short) 0 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) '4', 0);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                  35404524100452");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "HI!", 94);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 79 + "'", int3 == 79);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaa", 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "\n", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "#1#0#1-1#0#1/var/folders/_v/6v597zmnsun.lwawt.macosx.LWCToolkit1#0#1-1#0#1/var/folders/_v/6v597zmn########hi!35a0a52a100a52##########################################", (java.lang.CharSequence) "/Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("US    ", "10.0.35.10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US    " + "'", str2.equals("US    "));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/USERS/SOPHIE/LIBRARY/JAVA/EXT...", "3.041.040.042.0410.0", 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT..." + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT...3.041.040.042.0410.0/USERS/SOPHIE/LIBRARY/JAVA/EXT..."));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#0#1aaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                            aa4aaa ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaa" + "'", str1.equals("aaaaaa"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("SUN.LWAWT.MACOSX.LWCTOOLKIT", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0, 38);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("           100.0 1.0 0.0 100.0 10.0 0.0            ", 17, "1#.#6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "           100.0 1.0 0.0 100.0 10.0 0.0            " + "'", str3.equals("           100.0 1.0 0.0 100.0 10.0 0.0            "));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444444"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(5.0f, (float) 35L, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 54, (double) (byte) -1, (double) 33.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("3", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3" + "'", str2.equals("3"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(79, 100, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100.0497.04-1.040.0410.0", (java.lang.CharSequence) "-1a0a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "a###4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("-1.0a52.0a-1.0a10.0a10.0a32.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa     0.0140.240.040.140.3     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA     0.0140.240.040.140.3     " + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA     0.0140.240.040.140.3     "));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("http://java.oracle.com/", "44444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean11 = javaVersion9.atLeast(javaVersion10);
        java.lang.Class<?> wildcardClass12 = javaVersion10.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean14 = javaVersion10.atLeast(javaVersion13);
        boolean boolean15 = javaVersion8.atLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        java.lang.String str18 = javaVersion16.toString();
        java.lang.String str19 = javaVersion16.toString();
        java.lang.String str20 = javaVersion16.toString();
        boolean boolean21 = javaVersion8.atLeast(javaVersion16);
        boolean boolean22 = javaVersion5.atLeast(javaVersion16);
        boolean boolean23 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion24 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion25 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        java.lang.String str27 = javaVersion25.toString();
        boolean boolean28 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion25);
        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
        java.lang.String str31 = javaVersion29.toString();
        org.apache.commons.lang3.JavaVersion javaVersion32 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean35 = javaVersion33.atLeast(javaVersion34);
        java.lang.Class<?> wildcardClass36 = javaVersion34.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion37 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean38 = javaVersion34.atLeast(javaVersion37);
        boolean boolean39 = javaVersion32.atLeast(javaVersion34);
        boolean boolean40 = javaVersion29.atLeast(javaVersion32);
        boolean boolean41 = javaVersion25.atLeast(javaVersion32);
        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion43 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean44 = javaVersion42.atLeast(javaVersion43);
        boolean boolean45 = javaVersion32.atLeast(javaVersion42);
        boolean boolean46 = javaVersion24.atLeast(javaVersion42);
        boolean boolean47 = javaVersion5.atLeast(javaVersion24);
        java.lang.Class<?> wildcardClass48 = javaVersion24.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.5" + "'", str18.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.5" + "'", str19.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.5" + "'", str20.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + javaVersion24 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion24.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion25 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion25.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1.5" + "'", str27.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1.5" + "'", str31.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion32 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion32.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + javaVersion37 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion37.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion43 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion43.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        char[] charArray5 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                  35404524100452", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ', 175, 50);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " aaa4aa" + "'", str7.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " aaa4aa" + "'", str10.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "#########35a0a52a100a52#########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "       ", (java.lang.CharSequence) "100a100a0a10a-1", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("us    ", " PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us    " + "'", str2.equals("us    "));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    ", "-1.0a52.0a-1.0a10.0a10.0a32.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4", "#a#4#a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4" + "'", str2.equals("a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("hi!                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!                                " + "'", str1.equals("hi!                                "));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1.0 52.0 -1.0 10.0 10.0 32.0", "0.0#200.0#35.0#3.0", "hi!                                                                                      35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1ih   ih -1ih 1hih 1hih   ih" + "'", str3.equals("-1ih   ih -1ih 1hih 1hih   ih"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040" + "'", str2.equals("104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Users/sophie", "10.0.35.10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("100a-1a-1a100a-1a0", "C[ SSALC;G/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:C", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a-1a-1a100a-1a0" + "'", str3.equals("100a-1a-1a100a-1a0"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "a4a", (java.lang.CharSequence) "aaa4a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', (int) '4', 30);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', 51, (int) (byte) 1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', 33, (int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("a # 4  ", "aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "J HtSpt(M) Bit S VM", 103);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("...re/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi", "                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("10a0a35a1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a0a35a1" + "'", str2.equals("10a0a35a1"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1#0#1", "US##############################Use");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#0#1" + "'", str2.equals("-1#0#1"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("042.0410.0", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "j#v# HotSpot(TM) 64-Bit Server VM######################################################################");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("sun.awt.CGraphicsEnvironment", "J HtSpt(M) Bit S VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1#0#1-1#0#1/var/folders/_v/6v597zmnsun.lwawt.macosx.LWCToolkit1#0#1-1#0#1/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "cle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("-1 10 -1 1 100", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "AAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) " 0 ", (java.lang.CharSequence) "AAA4AA", 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) 6, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("US", (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAAAAAAAA");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("0.0 10.0 10.0 10.0", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str4.equals("0.0 10.0 10.0 10.0"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("##########################################25a001a25a0a53!ih#########################################", "100.0a1.0a0.0a100.0a10.0a0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US##############################Us", "                                                n tr                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("C[ SSALC;G/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C[ SSALC;G/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:C" + "'", str1.equals("C[ SSALC;G/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:C"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass8 = byteArray1.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "3.041.040.042.0410.0");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '#', (int) (byte) 100, (int) (short) -1);
        java.lang.Class<?> wildcardClass16 = strArray11.getClass();
        char[] charArray24 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(charArray24, 'a');
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.join(charArray24, '4');
        boolean boolean29 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray24);
        boolean boolean30 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray24);
        boolean boolean31 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a###4# ", charArray24);
        java.lang.Class<?> wildcardClass32 = charArray24.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion33 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion34 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion35 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean36 = javaVersion34.atLeast(javaVersion35);
        java.lang.Class<?> wildcardClass37 = javaVersion35.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion38 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean39 = javaVersion35.atLeast(javaVersion38);
        boolean boolean40 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion38);
        org.apache.commons.lang3.JavaVersion javaVersion41 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion42 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion43 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean44 = javaVersion42.atLeast(javaVersion43);
        java.lang.Class<?> wildcardClass45 = javaVersion43.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion46 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean47 = javaVersion43.atLeast(javaVersion46);
        boolean boolean48 = javaVersion41.atLeast(javaVersion43);
        org.apache.commons.lang3.JavaVersion javaVersion49 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean50 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion49);
        java.lang.String str51 = javaVersion49.toString();
        java.lang.String str52 = javaVersion49.toString();
        java.lang.String str53 = javaVersion49.toString();
        boolean boolean54 = javaVersion41.atLeast(javaVersion49);
        boolean boolean55 = javaVersion38.atLeast(javaVersion49);
        boolean boolean56 = javaVersion33.atLeast(javaVersion38);
        org.apache.commons.lang3.JavaVersion javaVersion57 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion58 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean59 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion58);
        java.lang.String str60 = javaVersion58.toString();
        boolean boolean61 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion58);
        org.apache.commons.lang3.JavaVersion javaVersion62 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean63 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion62);
        java.lang.String str64 = javaVersion62.toString();
        org.apache.commons.lang3.JavaVersion javaVersion65 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion66 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion67 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean68 = javaVersion66.atLeast(javaVersion67);
        java.lang.Class<?> wildcardClass69 = javaVersion67.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion70 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean71 = javaVersion67.atLeast(javaVersion70);
        boolean boolean72 = javaVersion65.atLeast(javaVersion67);
        boolean boolean73 = javaVersion62.atLeast(javaVersion65);
        boolean boolean74 = javaVersion58.atLeast(javaVersion65);
        org.apache.commons.lang3.JavaVersion javaVersion75 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion76 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean77 = javaVersion75.atLeast(javaVersion76);
        boolean boolean78 = javaVersion65.atLeast(javaVersion75);
        boolean boolean79 = javaVersion57.atLeast(javaVersion75);
        boolean boolean80 = javaVersion38.atLeast(javaVersion57);
        java.lang.Class<?> wildcardClass81 = javaVersion57.getClass();
        java.lang.reflect.GenericDeclaration[] genericDeclarationArray82 = new java.lang.reflect.GenericDeclaration[] { wildcardClass8, wildcardClass16, wildcardClass32, wildcardClass81 };
        java.lang.String str83 = org.apache.commons.lang3.StringUtils.join(genericDeclarationArray82);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(charArray24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + " aaa4aa" + "'", str26.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + " 4a444a" + "'", str28.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + javaVersion33 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion33.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion34 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion34.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion35 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion35.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + javaVersion38 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion38.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + javaVersion41 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion41.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion42 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion42.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion43 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion43.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + javaVersion46 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion46.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + javaVersion49 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion49.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.5" + "'", str51.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1.5" + "'", str52.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1.5" + "'", str53.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + javaVersion57 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion57.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion58 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion58.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1.5" + "'", str60.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + javaVersion62 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion62.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "1.5" + "'", str64.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion65 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion65.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion66 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion66.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion67 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion67.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + javaVersion70 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion70.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + javaVersion75 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion75.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion76 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion76.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(genericDeclarationArray82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "class [Bclass [Ljava.lang.String;class [Cclass org.apache.commons.lang3.JavaVersion" + "'", str83.equals("class [Bclass [Ljava.lang.String;class [Cclass org.apache.commons.lang3.JavaVersion"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "aa4aaa ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 5, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "AAA4A", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "100 -1 -1 100 -1 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b151.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                              4A444A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  a 4 a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  a 4 a" + "'", str2.equals("  a 4 a"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("C[ SSALC;G/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:C", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("4AAAAA4AAAAA4AAAAA4", "3/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.2/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/HI aaa4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/HI aaa4aa" + "'", str1.equals("/HI aaa4aa"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100.0#97.0#-1.0#0.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("100#100#0#10#-", "J HtSpt(M) Bit S VM", 17, 17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100#100#0#10#-J HtSpt(M) Bit S VM" + "'", str4.equals("100#100#0#10#-J HtSpt(M) Bit S VM"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x86_64", "01");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1), (float) 18L, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.70.90.91.6", " .7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.70.90.91.6" + "'", str2.equals("1.70.90.91.6"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "utf-8444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, (int) '#', 175);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "http://java.oracle.com/", "141", 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/hie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 1, 0L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100.0f, 350.0d, (double) 103L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 350.0d + "'", double3 == 350.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("US##############################Use", "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US##############################Use" + "'", str2.equals("US##############################Use"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', (int) (byte) 10, (int) (short) 10);
        byte byte18 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "35");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 35");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + byte18 + "' != '" + (byte) -1 + "'", byte18 == (byte) -1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("a 4 a", 79);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                     a 4 a                                     " + "'", str2.equals("                                     a 4 a                                     "));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("0.0#200.0#35.0#3.0", "103.0 14.0 18.0", 200);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 13, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 68, 17);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("AAA042.0-1a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aAA042.0-1a0a1" + "'", str1.equals("aAA042.0-1a0a1"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("           100.0 1.0 0.0 100.0 10.0 0.0            ", "104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040104104010410401041040");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           100.0 1.0 0.0 100.0 10.0 0.0            " + "'", str2.equals("           100.0 1.0 0.0 100.0 10.0 0.0            "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                       0.0 10.0 10.0 10.0                                        ", 38, "hi!                                                                                      35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                       0.0 10.0 10.0 10.0                                        " + "'", str3.equals("                                       0.0 10.0 10.0 10.0                                        "));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/HI aaa4aa", "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/HI aaa4aa" + "'", str2.equals("/HI aaa4aa"));
    }
}

