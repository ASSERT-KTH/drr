import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                                                                              x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sophie", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Aaaaaaaaaa                                                                                                                                                                                                                                                                                     -1                                                ", "10.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Aaaaaaaaaa                                                                                                                                                                                                                                                                                     -1                                                " + "'", str3.equals("Aaaaaaaaaa                                                                                                                                                                                                                                                                                     -1                                                "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "35404524100452", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 10, 0);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4, (double) 24, (double) 345.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 345.0d + "'", double3 == 345.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Aaaaaaaaaa                                                                                                                                                                                                                                                                                     -1                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaa-1" + "'", str1.equals("Aaaaaaaaaa-1"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "103.0a14.0a18.0", (int) (short) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10a0a35a1", "", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("AAA4A7.0_80-b15AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA", "utf-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4A7.0_80-b15AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA" + "'", str2.equals("AAA4A7.0_80-b15AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/HI aaa4aa", "#########35a0a52a100a52#########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/HI aaa4aa" + "'", str2.equals("/HI aaa4aa"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                  35404524100452", "0.0a10.0a10.0a10.0", 14);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "                  354 4524   452" + "'", str6.equals("                  354 4524   452"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("AAA4AA", (float) 103L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 103.0f + "'", float2 == 103.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("X SO caM", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa     0.0140.240.040.140.3     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java                                                                                    x86_64");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/hie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8Spec aaa4a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.3", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", "                                                                                      35a0a52a100a52", 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray11);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("103.0a14.0a18.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "103.0A14.0A18.0" + "'", str1.equals("103.0A14.0A18.0"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1d + "'", double1.equals(1.1d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8Spec aaa4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8Spec aaa4a" + "'", str1.equals("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8Spec aaa4a"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        char[] charArray8 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4', 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass13 = charArray8.getClass();
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/uSERS/SOPHIE", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Aaaaaaaaaa", charArray8);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                             aa4aaa ", (java.lang.CharSequence) "j#v# HotSpot(TM) 64-Bit Server VM######################################################################", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("32a1a-1", "ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32a1a-1" + "'", str2.equals("32a1a-1"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "######################################################################C[ ssalc;gnirtS.gnal.avajL[ ssalc");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10404443", (java.lang.CharSequence) "1.7.0_80-b1", 14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "10.0.35.10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "0.9", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:" + "'", str3.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 9, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1040435410" + "'", str10.equals("1040435410"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "   /HI aaa4aa    ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdkt.7.-_8-.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("cle Corporation", "/USERS/SOPHIE/LIBRARY/JAVA/EXT...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "    3.041.040.042.0410.0     ene", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALC", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                          4AAAAA4AAAAA4AAAAA4                                                                                           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100#100#0#10#-1", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#10#0#100#100" + "'", str2.equals("-1#10#0#100#100"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Hie/Library/Java/Extensions:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("08_0.7.1", "A4a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "A4a", (java.lang.CharSequence) "Mac OS X", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("#################", 30, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                                                                          4AAAAA4AAAAA4AAAAA4                                                                                           ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa" + "'", str2.equals("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.CharSequence charSequence6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence6, (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray5, strArray9);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "   HI!    ", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray17, "\n", (int) (byte) 100, 2);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray17, "\n");
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEach("100 100 0 10 -1", strArray5, strArray17);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "en" + "'", str12.equals("en"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100 100 0 10 -1" + "'", str24.equals("100 100 0 10 -1"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "En" + "'", str1.equals("En"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1#.#6", "a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#.#6" + "'", str2.equals("1#.#6"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, (long) 6, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { 'a', '#', '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (byte) 1);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "35a0a52a100a52", charArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', 45, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 45");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a" + "'", str11.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "aa4aaa ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sun.lwawt.macosx.CPrinterJob", 9, "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("j#v# HotSpot(TM) 64-Bit Server VM######################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("US", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("0.3", "us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.3" + "'", str2.equals("0.3"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae" + "'", str2.equals("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b1", "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN#_V31CQ2N2X1N#FC0000GN/T/-1#0#1UTF-8", "/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b1" + "'", str3.equals("1.7.0_80-b1"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALCaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALCaa" + "'", str1.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALCaa"));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test065");
//        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaHome();
//        java.io.File file1 = org.apache.commons.lang3.SystemUtils.getUserDir();
//        java.io.File file2 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
//        java.io.File[] fileArray3 = new java.io.File[] { file0, file1, file2 };
//        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(fileArray3);
//        org.junit.Assert.assertNotNull(file0);
//        org.junit.Assert.assertNotNull(file1);
//        org.junit.Assert.assertNotNull(file2);
//        org.junit.Assert.assertNotNull(fileArray3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 0, 2);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "35 0" + "'", str12.equals("35 0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "35404524100452" + "'", str14.equals("35404524100452"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "35a0a52a100a52" + "'", str18.equals("35a0a52a100a52"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3", "", 97, 94);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.70.90.91.", "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[SSALC;GNIRTS.GNAL.AVAJL[SSALC", "5 0                          ", 94);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.70.90.91." + "'", str4.equals("1.70.90.91."));
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test069");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
//        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
//        boolean boolean7 = javaVersion0.atLeast(javaVersion2);
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 35404524100452L, (double) 3, 345.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.5404524100452E13d + "'", double3 == 3.5404524100452E13d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Hie/Library/Java/Extensions:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hie/library/java/extensions:" + "'", str1.equals("hie/library/java/extensions:"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10 0 35 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0 0 35 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "0.0a10.0a10.0a10.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaen");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str9.equals("100.0#97.0#-1.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Aaaaaaaaaa-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaa-1" + "'", str1.equals("Aaaaaaaaaa-1"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1 10 -1 1 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 10 -1 1 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("E");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("AAAAAAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 103, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', (int) '4', 30);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', 51, (int) (byte) 1);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 103, 0);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "35a0a52a100a52" + "'", str22.equals("35a0a52a100a52"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                          4AAAAA4AAAAA4AAAAA4                                                                                           ", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("10.0a0.0a32.0", "", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform A");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "-1 10 -1 1 100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n", (java.lang.CharSequence) "   444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "MIXED MODE", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " AAA4A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 99, (-1));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#-1#-1#100#-1#0" + "'", str10.equals("100#-1#-1#100#-1#0"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "", 6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray19 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray15, strArray19);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray11, strArray15);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "1004100404104-1");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("aaa4aa", strArray11, strArray24);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray26, ' ', 2, (int) (byte) 1);
        boolean boolean31 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray26);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("AAAAAAAAA", strArray4, strArray26);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "aaa4aa" + "'", str25.equals("aaa4aa"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AAAAAAAAA" + "'", str32.equals("AAAAAAAAA"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.Class<?> wildcardClass9 = shortArray5.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray10 = new java.lang.reflect.AnnotatedElement[] { wildcardClass9 };
        short[] shortArray16 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray16, '4');
        short short19 = org.apache.commons.lang3.math.NumberUtils.min(shortArray16);
        java.lang.Class<?> wildcardClass20 = shortArray16.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray21 = new java.lang.reflect.AnnotatedElement[] { wildcardClass20 };
        short[] shortArray27 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(shortArray27, '4');
        short short30 = org.apache.commons.lang3.math.NumberUtils.min(shortArray27);
        java.lang.Class<?> wildcardClass31 = shortArray27.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray32 = new java.lang.reflect.AnnotatedElement[] { wildcardClass31 };
        short[] shortArray38 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.join(shortArray38, '4');
        short short41 = org.apache.commons.lang3.math.NumberUtils.min(shortArray38);
        java.lang.Class<?> wildcardClass42 = shortArray38.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray43 = new java.lang.reflect.AnnotatedElement[] { wildcardClass42 };
        short[] shortArray49 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str51 = org.apache.commons.lang3.StringUtils.join(shortArray49, '4');
        short short52 = org.apache.commons.lang3.math.NumberUtils.min(shortArray49);
        java.lang.Class<?> wildcardClass53 = shortArray49.getClass();
        java.lang.reflect.AnnotatedElement[] annotatedElementArray54 = new java.lang.reflect.AnnotatedElement[] { wildcardClass53 };
        java.lang.reflect.AnnotatedElement[][] annotatedElementArray55 = new java.lang.reflect.AnnotatedElement[][] { annotatedElementArray10, annotatedElementArray21, annotatedElementArray32, annotatedElementArray43, annotatedElementArray54 };
        java.lang.String str56 = org.apache.commons.lang3.StringUtils.join(annotatedElementArray55);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(annotatedElementArray10);
        org.junit.Assert.assertNotNull(shortArray16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1004100404104-1" + "'", str18.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) -1 + "'", short19 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(annotatedElementArray21);
        org.junit.Assert.assertNotNull(shortArray27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1004100404104-1" + "'", str29.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) -1 + "'", short30 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(annotatedElementArray32);
        org.junit.Assert.assertNotNull(shortArray38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1004100404104-1" + "'", str40.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short41 + "' != '" + (short) -1 + "'", short41 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(annotatedElementArray43);
        org.junit.Assert.assertNotNull(shortArray49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1004100404104-1" + "'", str51.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short52 + "' != '" + (short) -1 + "'", short52 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(annotatedElementArray54);
        org.junit.Assert.assertNotNull(annotatedElementArray55);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1#0#1aaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aaa4aajava platform api specification aaa4aajava platform api specification aaa4aajava platform a", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass4 = javaVersion2.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean6 = javaVersion2.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion5.toString();
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        java.lang.String str9 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3" + "'", str7.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.4" + "'", str9.equals("1.4"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1041040", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/", 38);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                     100#100#0#10#-1", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', 33, 79);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1" + "'", str8.equals("-1 0 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/USERS/SOPHIE/LIBRARY/JAVA/EXT...", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", (int) (short) 1);
        java.lang.CharSequence charSequence6 = null;
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence6, (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("sun.lwawt.macosx.LWCToolkit", strArray5, strArray9);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "10#10#0", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str12.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10, "350");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#10#0#100#100", (java.lang.CharSequence) "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100#100#0#10#-J HtSpt(M) Bit S VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#10#-JHtSpt(M)BitSVM" + "'", str1.equals("100#100#0#10#-JHtSpt(M)BitSVM"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        int[] intArray4 = new int[] { 10, 0, 4, 3 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 0, 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 194, (-1));
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "           100.0 1.0 0.0 100.0 10.0 0.0            ", (java.lang.CharSequence) "-14-141410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("class [Bclass [Ljava.lang.String;class [Cclass org.apache.commons.lang3.JavaVersion", "     3.041.040.042.0410.0     ", "10.14.3");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class1[Bclass1[Ljava3lang3String;class1[Cclass1org3apache3commons3lang.3JavaVersion" + "'", str3.equals("class1[Bclass1[Ljava3lang3String;class1[Cclass1org3apache3commons3lang.3JavaVersion"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "24.80-b11");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split(":", 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray11);
        java.lang.Class<?> wildcardClass13 = strArray11.getClass();
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray28 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray24, strArray28);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray20, strArray24);
        java.lang.String[] strArray35 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray39 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray35, strArray39);
        boolean boolean41 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1004100404104-1", (java.lang.CharSequence[]) strArray35);
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray24, strArray35);
        java.lang.String[] strArray48 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str49 = org.apache.commons.lang3.StringUtils.join(strArray48);
        java.lang.String[] strArray51 = org.apache.commons.lang3.StringUtils.stripAll(strArray48, "24.80-b11");
        java.lang.String[] strArray54 = org.apache.commons.lang3.StringUtils.split(":", 'a');
        java.lang.String str55 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray48, strArray54);
        int int56 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray54);
        java.lang.String str57 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", strArray35, strArray54);
        java.lang.String str58 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("50", strArray11, strArray35);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80" + "'", str6.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str12.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "51.0" + "'", str42.equals("51.0"));
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1.7.0_80" + "'", str49.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str55.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str57.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "50" + "'", str58.equals("50"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hiea/aLaibrarya/aJaavaa/aEaxtensionsa:/aLaibrarya/aJaavaa/aJaavaaVairtualaMaachinesa/ajdka1a.a7a.a0a_a80a.ajdka/aCaontentsa/aHaomea/ajrea/aliba/aexta:/aLaibrarya/aJaavaa/aEaxtensionsa:/aNaetworka/aLaibrarya/aJaavaa/aEaxtensionsa:/aSaystema/aLaibrarya/aJaavaa/aEaxtensionsa:/ausra/aliba/ajav" + "'", str3.equals("hiea/aLaibrarya/aJaavaa/aEaxtensionsa:/aLaibrarya/aJaavaa/aJaavaaVairtualaMaachinesa/ajdka1a.a7a.a0a_a80a.ajdka/aCaontentsa/aHaomea/ajrea/aliba/aexta:/aLaibrarya/aJaavaa/aEaxtensionsa:/aNaetworka/aLaibrarya/aJaavaa/aEaxtensionsa:/aSaystema/aLaibrarya/aJaavaa/aEaxtensionsa:/ausra/aliba/ajav"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n", "x86_64");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "US                                                 ", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "-1 10 -1 1 100", 0, 79);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("    3.041.040.042.0410.0     ene", '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    3.041.040.042.0410.0     ene" + "'", str3.equals("    3.041.040.042.0410.0     ene"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "class1[Bclass1[Ljava3lang3String;class1[Cclass1org3apache3commons3lang.3JavaVersion");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("en", "aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("AAA4A7.0_80-b15AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA", "51.0", 31);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 194);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("4 4 4", "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                         ", (java.lang.CharSequence) "e");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 345 + "'", int2 == 345);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "10.0.35.10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, 0, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(":", "US                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        double[] doubleArray6 = new double[] { (-1.0f), 52.0f, (-1L), 10L, 10.0d, 32.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 100, (int) (short) 100);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double17 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double18 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a52.0a-1.0a10.0a10.0a32.0" + "'", str16.equals("-1.0a52.0a-1.0a10.0a10.0a32.0"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 52.0d + "'", double17 == 52.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-1.0" + "'", str22.equals("-1.0"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "a###4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("us", "hiea/aLaibrarya/aJaavaa/aEaxtensionsa:/aLaibrarya/aJaavaa/aJaavaaVairtualaMaachinesa/ajdka1a.a7a.a0a_a80a.ajdka/aCaontentsa/aHaomea/ajrea/aliba/aexta:/aLaibrarya/aJaavaa/aEaxtensionsa:/aNaetworka/aLaibrarya/aJaavaa/aEaxtensionsa:/aSaystema/aLaibrarya/aJaavaa/aEaxtensionsa:/ausra/aliba/ajav");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us" + "'", str2.equals("us"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 54, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "                                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 35, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4", "a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1.040.0", "a # 4  ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("    3.041.040.042.0410.0     e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    3.041.040.042.0410.0     e" + "'", str1.equals("    3.041.040.042.0410.0     e"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100.0a1.0a0.0a100.0a10.0a0.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004100404104-1" + "'", str13.equals("1004100404104-1"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("100.0#1.0#0.0#100.0#10.0#0.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0#1.0#0.0#100.0#10.0#0.0" + "'", str1.equals("100.0#1.0#0.0#100.0#10.0#0.0"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("US##############################Use", "08_0.7.1", "100#100#0#10#-J HtSpt(M) Bit S VM");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                       0.0 10.0 10.0 10.0                                        ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                       0.0 10.0 10.0 10.0                                        " + "'", str2.equals("                                       0.0 10.0 10.0 10.0                                        "));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform A");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform A");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100.0a1.0a0.0a100.0a10.0a0.0", (int) ' ', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0a1.0a0.0a100.0a10.0a0.0    " + "'", str3.equals("100.0a1.0a0.0a100.0a10.0a0.0    "));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str12.equals("3.0a1.0a0.0a2.0a10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "3.0#1.0#0.0#2.0#10.0" + "'", str14.equals("3.0#1.0#0.0#2.0#10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str16.equals("3.0a1.0a0.0a2.0a10.0"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0" + "'", str1.equals("100.0"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("100 -1 -1 100 -1 0", "0.0 10.0 10.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 -1 100 -1 0" + "'", str2.equals("-1 -1 100 -1 0"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("us    ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "0.0a10.0a10.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass3 = javaVersion1.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        java.lang.Class<?> wildcardClass11 = javaVersion9.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean13 = javaVersion9.atLeast(javaVersion12);
        boolean boolean14 = javaVersion7.atLeast(javaVersion9);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion15);
        java.lang.String str17 = javaVersion15.toString();
        java.lang.String str18 = javaVersion15.toString();
        java.lang.String str19 = javaVersion15.toString();
        boolean boolean20 = javaVersion7.atLeast(javaVersion15);
        boolean boolean21 = javaVersion4.atLeast(javaVersion15);
        java.lang.String str22 = javaVersion15.toString();
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        boolean boolean25 = javaVersion15.atLeast(javaVersion23);
        boolean boolean26 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion23);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.5" + "'", str17.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.5" + "'", str18.equals("1.5"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.5" + "'", str19.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1.5" + "'", str22.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaa4aajava platform api specification aaa4aajava platform api specification aaa4aajava platform a", (java.lang.CharSequence) "AAA4A");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444", (java.lang.CharSequence) " 4a444a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "-14-141410");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("US##############################Us", "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java Virtual Machine Specification");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("   3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   3" + "'", str1.equals("   3"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10 0 4 3", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "     " + "'", str2.equals("     "));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35404524100452", "Java HotSpot(TM) 64-Bit Server VM", 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "#a#4#a");
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray12, '#');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "                                                                                                                                                                                                                                                                                                       -1                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", 103, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae" + "'", str3.equals("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("X SO caM############################################", 345, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, 18, 45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("35", 94);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            35" + "'", str2.equals("                                                                                            35"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", "/uSERS/SOPHIE", "1040435410");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC" + "'", str3.equals("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', (int) '4', 18);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        char[] charArray7 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, '4');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray7);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " aaa4aa" + "'", str9.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " 4a444a" + "'", str11.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aAA042.0-1a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa042.0-1a0a1" + "'", str1.equals("aaa042.0-1a0a1"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1040435410", 7, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1040435410" + "'", str3.equals("1040435410"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.5", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC" + "'", str1.equals("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 45, 103);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "1.70.90.91.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1#10#0#100#100", (int) (byte) 0, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#10#0#100#100" + "'", str3.equals("-1#10#0#100#100"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 68, (float) 2, (float) 38);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 68.0f + "'", float3 == 68.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "us    ", (java.lang.CharSequence) "   /HI aaa4aa    ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4a444a", (java.lang.CharSequence) "Aaaaaaaaaa-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        short[] shortArray3 = new short[] { (short) 10, (byte) 10, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "-1.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.3", (java.lang.CharSequence[]) strArray5);
        int int8 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "7.0_80-b15", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "4a444a");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("100#100#0#10#-J HtSpt(M) Bit S VM", 35, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "                                                                                      35a0a52a100a52", 7, 24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                      35a0a52a100a52" + "'", str4.equals("                                                                                      35a0a52a100a52"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("35a0a52a100a52", (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100a100a0a10a-1", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a100a0a10a-1" + "'", str2.equals("100a100a0a10a-1"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', 2, 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 103, 14);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str9.equals("100.0#97.0#-1.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0497.04-1.040.0410.0" + "'", str11.equals("100.0497.04-1.040.0410.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXT...", (java.lang.CharSequence) "   HI!    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("a###4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a###4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("a###4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                               -1                                                ", "Aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "US    ", (java.lang.CharSequence) "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) '#', 30);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#10#-1" + "'", str11.equals("100#100#0#10#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004100404104-1" + "'", str13.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a100a0a10a-1" + "'", str15.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("3.0a1.0a0.0a2.0a10.0", "", "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str3.equals("3.0a1.0a0.0a2.0a10.0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        int[] intArray4 = new int[] { 10, 0, 4, 3 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("103.0A14.0A18.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "103.0A14.0A18.0" + "'", str1.equals("103.0A14.0A18.0"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100#100#0#10#-J HtSpt(M) Bit S VM");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        double[] doubleArray6 = new double[] { (-1.0f), 52.0f, (-1L), 10L, 10.0d, 32.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 100, (int) (short) 100);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 17, 10);
        double double21 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a52.0a-1.0a10.0a10.0a32.0" + "'", str16.equals("-1.0a52.0a-1.0a10.0a10.0a32.0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.0d) + "'", double21 == (-1.0d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 35);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100.0", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              100.0                                              " + "'", str2.equals("                                              100.0                                              "));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 35, (int) (byte) 0);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 10.0f + "'", float14 == 10.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aaa32a1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "E");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1#.#6             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52###########", (java.lang.CharSequence) "AAA4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie", " aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100404104-1" + "'", str10.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a100a0a10a-1" + "'", str13.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 100 + "'", short14 == (short) 100);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", (int) (short) 100, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10 0 4 3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 0 4 3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "      10a0a35a1       ", (java.lang.CharSequence) "utf-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (short) 10, (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float17 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str16.equals("3.0a1.0a0.0a2.0a10.0"));
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 10.0f + "'", float17 == 10.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        char[] charArray5 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        java.lang.Class<?> wildcardClass10 = charArray5.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray5, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 100, (int) (short) 100);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a');
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "97#0#35#-1#52#30", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + " aaa4aa" + "'", str7.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " 4a444a" + "'", str9.equals(" 4a444a"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " #a#4#a" + "'", str12.equals(" #a#4#a"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + " aaa4aa" + "'", str18.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("a###4# ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A###4# " + "'", str1.equals("A###4# "));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.0", 97, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.0" + "'", str3.equals("10.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.0"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10 0 4 3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 0 4 3" + "'", str1.equals("10 0 4 3"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                                                                             aa4aaa ", 175);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM)SERuntimeEnvironment", "100#100#0#10#-JHtSpt(M)BitSVM", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "\n", (int) (byte) 100, 2);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a", "aaaaaaaaaaaaa/", 103);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("#a#4#a", strArray5, strArray13);
        int int15 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aa4aaa ", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#a#4#a" + "'", str14.equals("#a#4#a"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("103.0a14.0a18.0", "100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "103.0a14.0a18.0" + "'", str2.equals("103.0a14.0a18.0"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) " PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA", (java.lang.CharSequence) "254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "1.7.0_80-b15", "/uSERS/SOPHIE");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "en", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        double[] doubleArray6 = new double[] { (byte) 100, (byte) 1, 0.0f, 100.0f, (byte) 10, 0 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 1, (int) (byte) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double16 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.Class<?> wildcardClass17 = doubleArray6.getClass();
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100.0 1.0 0.0 100.0 10.0 0.0" + "'", str15.equals("100.0 1.0 0.0 100.0 10.0 0.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100.0#1.0#0.0#100.0#10.0#0.0" + "'", str19.equals("100.0#1.0#0.0#100.0#10.0#0.0"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("a # 4  ", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a # 4  " + "'", str2.equals("a # 4  "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "US##############################Us", (java.lang.CharSequence) "100.0#1.0#0.0#100.0#10.0#0.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        double[] doubleArray6 = new double[] { (-1.0f), 52.0f, (-1L), 10L, 10.0d, 32.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 100, (int) (short) 100);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double17 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double18 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 52.0d + "'", double14 == 52.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1.0a52.0a-1.0a10.0a10.0a32.0" + "'", str16.equals("-1.0a52.0a-1.0a10.0a10.0a32.0"));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 52.0d + "'", double17 == 52.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1.0a52.0a-1.0a10.0a10.0a32.0" + "'", str20.equals("-1.0a52.0a-1.0a10.0a10.0a32.0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("10#10#0", "52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.03540452410045210.0a0.0a32.0", "A###4# ", 38);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0a0.0a32.0354A###4# 5210.0a0.0a32.0" + "'", str3.equals("10.0a0.0a32.0354A###4# 5210.0a0.0a32.0"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                                                              4a444a", 99, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a" + "'", str3.equals("a"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "class [Bclass [Ljava.lang.String;class [Cclass org.apache.commons.lang3.JavaVersion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("103.0 14.0 18.0", "HI!", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "103.0 14.0 18.0" + "'", str3.equals("103.0 14.0 18.0"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4444444444aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa44444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "US    ", charSequence1, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        float[] floatArray3 = new float[] { 103, 14, 18 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 14.0f + "'", float4 == 14.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 14.0f + "'", float5 == 14.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "103.0 14.0 18.0" + "'", str7.equals("103.0 14.0 18.0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "103.0a14.0a18.0" + "'", str9.equals("103.0a14.0a18.0"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("a###4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A###4#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("A###4#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "    3.041.040.042.0410.0     e", (java.lang.CharSequence) "a4a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (int) ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "ULBAYJAVAXTNN:LBAYJAVAXTNN:NTWKLBAYJAVAXTNN:YTMLBAYJAVAXTNN:ULBJAVA:.");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("   ", (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                               -1                                                ", 200);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               -1                                                                                                                                                       " + "'", str2.equals("                                               -1                                                                                                                                                       "));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.0140.240.040.140.3"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B15" + "'", str1.equals("1.7.0_80-B15"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "100.0a1.0a0.0a100.0a10.0a0444a", 33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("   ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass11 = charArray6.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:", charArray6);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "A#A#AAJAVAJALATFARM APAAVPEAPEACT######################################################################", (java.lang.CharSequence) "a 4 a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.1", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        double[] doubleArray4 = new double[] { 0, (short) 10, 10.0d, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) '4', (int) (short) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str6.equals("0.0 10.0 10.0 10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str8.equals("0.0a10.0a10.0a10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str15.equals("0.0a10.0a10.0a10.0"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaa32a1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray8 = new char[] { 'a', '#', '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "35 0", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a###4# " + "'", str11.equals("a###4# "));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "a###4# " + "'", str14.equals("a###4# "));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                       0.0 10.0 10.0 10.0                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0 10.0 10.0 10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4", "       ", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10a10a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10a10a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "97#0#35#-1#52#30");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#100#0#10#-1", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa", (java.lang.CharSequence) "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/-1#0#1UTF-8", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaa042.0-1a0a1", 75, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#", "US##############################Us");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!                                                                                      35a0a52a100a52", "Mac OS X", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray5, '4', 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass10 = charArray5.getClass();
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray5, '#', 12, 175);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + " 4#4a4a" + "'", str13.equals(" 4#4a4a"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "100.0a1.0a0.0a100.0a10.0a0444a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("141", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141" + "'", str2.equals("141"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1#.#6             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("100.0a1.0a0.0a100.0a10.0a0444a", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a0444a" + "'", str2.equals("0a0444a"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(5, 194, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN#_V31CQ2N2X1N#FC0000GN/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN#_V31CQ2N2X1N#FC0000GN/T/-1#0#1UTF-8" + "'", str1.equals("#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN#_V31CQ2N2X1N#FC0000GN/T/-1#0#1UTF-8"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("100.0497.04-1.040.0410.0", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0497.04-1.040.0410.0" + "'", str2.equals("100.0497.04-1.040.0410.0"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("a4a           100.0 1.0 0.0 100.0 10.0 0.0            ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "35 0                          ", "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean8 = javaVersion6.atLeast(javaVersion7);
        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
        java.lang.Class<?> wildcardClass10 = javaVersion6.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("141");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141" + "'", str1.equals("141"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "�", (java.lang.CharSequence) "AAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AAAAA042.0410.04042.0410.0AA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                 1.");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.0f + "'", number1.equals(1.0f));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        int[] intArray4 = new int[] { 10, 0, 4, 3 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 0, 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10 0 4 3" + "'", str12.equals("10 0 4 3"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str13.equals("3.0a1.0a0.0a2.0a10.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3.0#1.0#0.0#2.0#10.0" + "'", str15.equals("3.0#1.0#0.0#2.0#10.0"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("3.041.040.042.0410.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.041.040.042.0410.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("3.041.040.042.0410.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "en", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "hi!                                ", (int) (byte) 10, 194);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80", "hi!                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) (byte) 100, (int) '#');
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, 'a', (int) (short) 100, 0);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hiea/aLaibrarya/aJaavaa/aEaxtensionsa:/aLaibrarya/aJaavaa/aJaavaaVairtualaMaachinesa/ajdka1a.a7a.a0a_a80a.ajdka/aCaontentsa/aHaomea/ajrea/aliba/aexta:/aLaibrarya/aJaavaa/aEaxtensionsa:/aNaetworka/aLaibrarya/aJaavaa/aEaxtensionsa:/aSaystema/aLaibrarya/aJaavaa/aEaxtensionsa:/ausra/aliba/ajav", (java.lang.CharSequence[]) strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 290 + "'", int16 == 290);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.awt.CGraphicsEnvironment", 24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "awt.CGraphicsEnvironment" + "'", str2.equals("awt.CGraphicsEnvironment"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        char[] charArray7 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ');
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "08_0.7.1", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", charArray7);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1040435410", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + " aaa4aa" + "'", str9.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "  a 4 a" + "'", str11.equals("  a 4 a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) " aaa4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10a0a35a1", "x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64x86_64", "10.0a0.0a32.0354A###4# 5210.0a0.0a32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a0a35a1" + "'", str3.equals("10a0a35a1"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "103.0A14.0A18.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("    3.041.040.042.0410.0     ", "141", 103, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "141" + "'", str4.equals("141"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU", (java.lang.CharSequence) "-1a1a32", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100.0a97.0a-1.0a0.0a10.0", 33, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0a97.0a-1.0a0.0a10.0aaaaaaaaa" + "'", str3.equals("100.0a97.0a-1.0a0.0a10.0aaaaaaaaa"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("AAA4AA", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) -1);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "aaaaaaaaaa", 3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("3.0 1.0 0.0 2.0 10.0", strArray5, strArray9);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "-1.0a52.0a-1.0a10.0a10.0a32.0", (java.lang.CharSequence[]) strArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "", 17, 0);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3.0 1.0 0.0 2.0 10.0" + "'", str12.equals("3.0 1.0 0.0 2.0 10.0"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        float[] floatArray5 = new float[] { 3, 1.0f, 0.0f, 2, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', (int) (short) 10, (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (byte) 10, 0);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 30, (int) (byte) 10);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4');
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 9, 4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3.041.040.042.0410.0" + "'", str7.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", str16.equals("3.0a1.0a0.0a2.0a10.0"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "3.041.040.042.0410.0" + "'", str26.equals("3.041.040.042.0410.0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10#0#4#3", (java.lang.CharSequence) "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("j#v# HotSpot(TM) 64-Bit Server VM######################################################################", "                                                                                            35");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j#v# HotSpot(TM) 64-Bit Server VM######################################################################" + "'", str2.equals("j#v# HotSpot(TM) 64-Bit Server VM######################################################################"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.awt.CGraphicsEnvironment" + "'", str1.equals("Sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 345);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 345 + "'", int3 == 345);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "#35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52###########", (java.lang.CharSequence) "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n", 194);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "AAA4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(Double.POSITIVE_INFINITY, 2.0d, (double) 290);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0a97.0a-1.0a0.0a10.0", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:txe/bil/erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "A4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a', 79);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("        us");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "J HtSpt(M) Bit S VM");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "#");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        J HtSpt(M) Bit S VMus" + "'", str3.equals("        J HtSpt(M) Bit S VMus"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", "                  354 4524   452", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0.0 10.0 10.0 10.0", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("-1", "  a 4 a");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa", (java.lang.CharSequence[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa" + "'", str11.equals(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Mac OS X", "...re/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi", 175, 200);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mac OS X...re/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi" + "'", str4.equals("Mac OS X...re/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("SUN.LWAWT.MACOSX.LWCTOOLKIT", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str3.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, 35404524100452L, (long) 290);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean5 = javaVersion1.atLeast(javaVersion4);
        java.lang.String str6 = javaVersion4.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        double[] doubleArray4 = new double[] { 0, (short) 10, 10.0d, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', 100, 0);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str6.equals("0.0 10.0 10.0 10.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1" + "'", str8.equals("-1 0 1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 0 1" + "'", str11.equals("-1 0 1"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("D");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "D" + "'", str1.equals("D"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 103, 1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 345, (int) '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1040435410" + "'", str7.equals("1040435410"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "MIXED MODE");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                         ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444", (java.lang.CharSequence) "10 0 35 10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10a0a35a10", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 50, 4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aa4aaa", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("J HtSpt(M) Bit S VM", "042.0410.0cle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J HtSpt(M) Bit S VM" + "'", str2.equals("J HtSpt(M) Bit S VM"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "E");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.0 1.0 0.0 100.0 10.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aa4aaa ", "4a444a", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 37");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("Java Virtual Machine Specification", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "irtual Machine Specification" + "'", str2.equals("irtual Machine Specification"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "08_0.7.1", (java.lang.CharSequence) "        J HtSpt(M) Bit S VMus");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7               ", "100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray5, '4', 2, 4);
        float float16 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str10.equals("100.0#97.0#-1.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1.040.0" + "'", str15.equals("-1.040.0"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 100.0f + "'", float16 == 100.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 5, 35L, (long) 51);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 51L + "'", long3 == 51L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("�");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(97.0d, (double) 17, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcarO" + "'", str1.equals("noitaroproC elcarO"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        int[] intArray3 = new int[] { 'a', 'a', 0 };
        int[] intArray7 = new int[] { 'a', 'a', 0 };
        int[] intArray11 = new int[] { 'a', 'a', 0 };
        int[] intArray15 = new int[] { 'a', 'a', 0 };
        int[] intArray19 = new int[] { 'a', 'a', 0 };
        int[][] intArray20 = new int[][] { intArray3, intArray7, intArray11, intArray15, intArray19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray20);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) intArray20, "");
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("3.041.040.042.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0140.240.040.140.3" + "'", str1.equals("0.0140.240.040.140.3"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444mixed mode444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        char[] charArray6 = new char[] { ' ', '#', 'a', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (byte) -1);
        java.lang.Class<?> wildcardClass11 = charArray6.getClass();
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.70.90.91.6", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + " ###a#a" + "'", str15.equals(" ###a#a"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        float[] floatArray5 = new float[] { 100L, 'a', (-1L), 0.0f, 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.Class<?> wildcardClass9 = floatArray5.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str7.equals("100.0 97.0 -1.0 0.0 10.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a97.0a-1.0a0.0a10.0" + "'", str11.equals("100.0a97.0a-1.0a0.0a10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0#97.0#-1.0#0.0#10.0" + "'", str13.equals("100.0#97.0#-1.0#0.0#10.0"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("   HI!    ", "1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", "10#0#35#10");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("US444444444444", "0.0a10.0a10.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US444444444444" + "'", str2.equals("US444444444444"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("4a444a", "", "aa4aaJava");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specification" + "'", str1.equals("Java Platform API Specification"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }
}

