import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 51, (long) 97, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "01");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4a444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35404524100452", "Java HotSpot(TM) 64-Bit Server VM", 100);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray5, strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "#a#4#a");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("HI!");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("1.7.0_80", strArray12, strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.7.0_80" + "'", str15.equals("1.7.0_80"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie", 1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1a1a3", "08_0.7.1", "-1 0 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-aa3" + "'", str3.equals("-aa3"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 35L, (float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-1 0 1", "-1a0a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 0 " + "'", str2.equals(" 0 "));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 68, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1.7", "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                    ", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.14.3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) (short) 1, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        short[] shortArray3 = new short[] { (short) 10, (byte) 10, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 14, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "Java Platform API Specification", 18, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("#a#4#a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#100#0#10#-1" + "'", str1.equals("100#100#0#10#-1"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) " 4a444a", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452", "aaa", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452" + "'", str3.equals("354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-aa3", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 14, 54);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                     100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "-1a0a1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 0, "aaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 51, (int) (short) 1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "1.70.90.91.6");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.70.90.91.6");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " aaa4aa", (java.lang.CharSequence) "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X", 1, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "1.7.0_80-b15", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4" + "'", str1.equals("AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                                                                                                    ", "100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-aa3", "-1a0a1", "                                                                                      35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   3" + "'", str3.equals("   3"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("en", "...ie/hie/hie/hie/hie/hie/hie/hi...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 52, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(strArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', (int) (byte) 100, (int) '#');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray15, '4');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                                    ", strArray12, strArray15);
        int int20 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "hi!                                                                                      35a0a52a100a52", (java.lang.CharSequence[]) strArray12);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80" + "'", str6.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "                                                                                                    " + "'", str19.equals("                                                                                                    "));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 103 + "'", int20 == 103);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie                                       ", (int) (byte) -1, "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                       " + "'", str3.equals("/Users/sophie                                       "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100a-1a-1a100a-1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a-1a-1a100a-1a0" + "'", str1.equals("100a-1a-1a100a-1a0"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 2, 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1.70.90.91.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "3.0a1.0a0.0a2.0a10.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 3.0a1.0a0.0a2.0a10.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.LWCTOOLKIT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("US    ", "0.0 10.0 10.0 10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US    " + "'", str2.equals("US    "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35a0a52a100a52" + "'", str1.equals("35a0a52a100a52"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "4a444", (java.lang.CharSequence) "a 4 a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie                                       ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                       " + "'", str3.equals("/Users/sophie                                       "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("HI!", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HI!" + "'", str3.equals("HI!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie", "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0#97.0#-1.0#0.0#10.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "0.0a10.0a10.0a10.0", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 'a', (float) 32L, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1004100404104-1" + "'", str9.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("aaa4aa", "AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaa", (java.lang.CharSequence) "1.7.0_80", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "x86_64", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double[] doubleArray6 = new double[] { (byte) 100, (byte) 1, 0.0f, 100.0f, (byte) 10, 0 };
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 1, (int) (byte) 0);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b1" + "'", str1.equals("1.7.0_80-b1"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "0.0 10.0 10.0 10.0", 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 10, 103);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("x86_64", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                              x86_64" + "'", str2.equals("                                                                                              x86_64"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "100.0497.04-1.040.0410.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("en", "100.0497.04-1.040.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("24.80-b11", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaa/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("35a0a52a100a52", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("3.041.040.042.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.041.040.042.0410.0" + "'", str1.equals("3.041.040.042.0410.0"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", (java.lang.CharSequence) "#a#4#a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 345 + "'", int2 == 345);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "0.0a10.0a10.0a10.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) " aaa4aa                                                                                             ", (java.lang.CharSequence) "   3", 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("   3", 32, "-1#0#1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1" + "'", str3.equals("-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a 4 a", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("24.80-b11", 54);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("aaa", (int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa" + "'", str3.equals("aaa"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100404104-1" + "'", str10.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a100a0a10a-1" + "'", str13.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 100 + "'", short16 == (short) 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100 100 0 10 -1" + "'", str18.equals("100 100 0 10 -1"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "a 4 a", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(" 4a444a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4a444a" + "'", str1.equals("4a444a"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "24.80-b11");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Java Virtual Machine Specification");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.7.0_80" + "'", str11.equals("1.7.0_80"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("AAA4AA", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA" + "'", str2.equals("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1", 97, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               -1                                                " + "'", str3.equals("                                               -1                                                "));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavaVirtualMachineSpecification" + "'", str1.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "\n", (int) (byte) 100, 2);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "\n");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) " AAA4AA", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                                                                     100#100#0#10#-1", (java.lang.CharSequence) "US    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" aaa4a", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, 0L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100#100#0#10#-1" + "'", str11.equals("100#100#0#10#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1004100404104-1" + "'", str13.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100a100a0a10a-1" + "'", str15.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100a100a0a10a-1" + "'", str17.equals("100a100a0a10a-1"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "44444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("10", "/Users/sophie                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("US##############################", (-1), "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US##############################" + "'", str3.equals("US##############################"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", "10.0a0.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (int) (byte) 0, 3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                  35404524100452", "", (int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("0.9", "100 100 0 10 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.9" + "'", str2.equals("0.9"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aa4aaa ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 18, (long) '4', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { 'a', '#', '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', 0, (int) (byte) 1);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "a" + "'", str11.equals("a"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" AAA4AA", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " AAA4AA" + "'", str4.equals(" AAA4AA"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                      35a0a52a100a52", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "a###4#", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("   3", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "#########35a0a52a100a52#########", (java.lang.CharSequence) "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 200 + "'", int2 == 200);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "0.0a10.0a10.0a10.0", (java.lang.CharSequence) "1004100404104-1", 345);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("Java Virtual Machine Specification", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35404524100452", "Java HotSpot(TM) 64-Bit Server VM", 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "-1a1a3", 54, 54);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453" + "'", str1.equals("254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100a-1a-1a100a-1a0", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.9", (double) 14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9d + "'", double2 == 0.9d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("10.14.3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Java(TM) SE Runtime Environment is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "24.80-b11");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split(":", 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray5, strArray11);
        int int13 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray11);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "\n");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.7.0_80" + "'", str6.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str12.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + ":" + "'", str15.equals(":"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 6, (double) (byte) 10, (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("C[ ssalc;gnirtS.gnal.avajL[ ssalc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC" + "'", str1.equals("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("#########35a0a52a100a52#########", "hi! 35a0a52a100a52", "1.7               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########35a0a52a100a52#########" + "'", str3.equals("#########35a0a52a100a52#########"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("AAA4AA", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4AA" + "'", str2.equals("AAA4AA"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "35a0a52a100a52", 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "-1a1a3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie                                       ", 97, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie                                       " + "'", str3.equals("/Users/sophie                                       "));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                    ", ' ');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray11 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray7, strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "-1#0#1");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaa/", strArray3, strArray11);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8" + "'", str14.equals("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aaaaaaaaaaaaa/" + "'", str15.equals("aaaaaaaaaaaaa/"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444", "JavaVirtualMachineSpecification", "aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444" + "'", str3.equals("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("35#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#52");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.6", "", "hi! 35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/-1#0#1UTF-8" + "'", str1.equals("#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/-1#0#1UTF-8"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 345, 200);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10", " 4a444a", "97#0#35#-1#52#30", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 52, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a###4# ", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "24.80-b11");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split(":", 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray4, strArray10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str11.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + ":" + "'", str12.equals(":"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1a0a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a0a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaa4a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa4a" + "'", str1.equals("aaa4a"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.LWCTOOLKIT", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "100.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/hie", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/hie" + "'", str3.equals("/hie"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "                  35404524100452");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/hie" + "'", str7.equals("/hie"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                               -1                                                ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                               -1                                                " + "'", str2.equals("                                               -1                                                "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaa4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaa4a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaa", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                                                                 1.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 1." + "'", str1.equals("                                                                                                 1."));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("    3.041.040.042.0410.0     ", 32, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    3.041.040.042.0410.0     ene" + "'", str3.equals("    3.041.040.042.0410.0     ene"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("   3", (int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("UTF-8", "aa4aaa ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1.7.0_80-B15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("        US", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', 32, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "3.0a1.0a0.0a2.0a10.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaa/uSERS/SOPHIEaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "3.0a1.0a0.0a2.0a10.0" + "'", charSequence2.equals("3.0a1.0a0.0a2.0a10.0"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "1004100404104-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                35 0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.7.0_80-B15", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", "7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US", 3, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(strArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4aaaaa4\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("100#100#0#10#-1", (int) (short) 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100#100#0#10#-1" + "'", str3.equals("100#100#0#10#-1"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "97#0#35#-1#52#30", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java Platform API Specification", "aa4aaa ", (int) (byte) -1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1004100404104-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaa4aa", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aa" + "'", str2.equals("aaa4aa"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray13 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray9, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray9);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "1004100404104-1");
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEach("aaa4aa", strArray5, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray18);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "aaa4aa" + "'", str19.equals("aaa4aa"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.7.0_80" + "'", str20.equals("1.7.0_80"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(" ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("    3.041.040.042.0410.0     ene");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"    3.041.040.042.0410.0     ene\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence) " aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!                                                                                      35a0a52a100a52", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                " + "'", str2.equals("hi!                                "));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie/hie", "/Users/sophie                                       ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("a4a", 4, 103);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Aaaaaaaaaa" + "'", str1.equals("Aaaaaaaaaa"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaa4aa", 200);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaa4aa" + "'", str2.equals("aaa4aa"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "  a 4 a", 35);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6, "-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a320.0 10.0 10.0 10.0-1a1a32");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", strArray4, strArray6);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str9.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("   3", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   3" + "'", str2.equals("   3"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "#0#1-1#0#1/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/-1#0#1UTF-8", 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a 4 a", "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", 30);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) ":", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("HI!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a###4# ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a###4#" + "'", str2.equals("a###4#"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) (byte) 0, 200);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensi"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453254001425404532540014254045325400142540453");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aa4aaa ", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa4aaa " + "'", str3.equals("aa4aaa "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 18, 10L, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("-1 0 1", 68);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 0 1" + "'", str2.equals("-1 0 1"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "32a1a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 51, (float) 345);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 345.0f + "'", float3 == 345.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100.0#97.0#-1.0#0.0#10.0", (java.lang.CharSequence) "#a#4#a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) " #a#4#a", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("-1a1a32", 6, "10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a1a32" + "'", str3.equals("-1a1a32"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java(TM) SE Runtime Environment", "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                               -1                                                ", 345);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                       -1                                                " + "'", str2.equals("                                                                                                                                                                                                                                                                                                       -1                                                "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "HI!", (int) (short) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "class [Ljava.lang.String;class [C", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("JavaaPlatformaAPIaSpecification", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaaPlatformaAPIaSpecification" + "'", str2.equals("JavaaPlatformaAPIaSpecification"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("3.0a1.0a0.0a2.0a10.0", "class [Ljava.lang.String;class [C");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "3/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.2/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0" + "'", str4.equals("3/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.2/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "a4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        java.lang.Class<?> wildcardClass8 = byteArray1.getClass();
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                               -1                                                ", 3, "100 100 0 10 -1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               -1                                                " + "'", str3.equals("                                               -1                                                "));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.1", 0, 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        char[] charArray6 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) '#', (int) ' ');
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " aaa4aa" + "'", str8.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " 4a444a" + "'", str10.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("a");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("1.7.0_80", "Users/sophie/Library/Java/Extensions:/Library/Java/", (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "\n", (int) (byte) 100, 2);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "\n");
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray20 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray16, strArray20);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1004100404104-1", (java.lang.CharSequence[]) strArray16);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, ' ');
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, 'a');
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                 1.1", strArray5, strArray16);
        java.lang.String[] strArray33 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(strArray33);
        java.lang.String[] strArray36 = org.apache.commons.lang3.StringUtils.stripAll(strArray33, "24.80-b11");
        java.lang.String[] strArray39 = org.apache.commons.lang3.StringUtils.split(":", 'a');
        java.lang.String str40 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray33, strArray39);
        int int41 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray39);
        java.lang.String str42 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaa", strArray5, strArray39);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "                                                                                                 1.1" + "'", str27.equals("                                                                                                 1.1"));
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1.7.0_80" + "'", str34.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str40.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa4aaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "aaaaaaaaa" + "'", str42.equals("aaaaaaaaa"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "                                                35 0                                                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray2 = null;
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceEach("x86_64", strArray1, strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Oracle Corporation", " aaa4a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100.0#97.0#-1.0#0.0#10.0", (java.lang.CharSequence) " .7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("mixed mode", "51.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray6, '4', 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1 0 1" + "'", str8.equals("-1 0 1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1 0 1" + "'", str10.equals("-1 0 1"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("us    ", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us                                                 " + "'", str2.equals("us                                                 "));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("3.041.040.042.0410.0", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "042.0410.0" + "'", str2.equals("042.0410.0"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("01", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int[] intArray5 = new int[] { 35, 0, '4', 100, '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', 54, (int) (byte) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 97, 18);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35a0a52a100a52" + "'", str8.equals("35a0a52a100a52"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35#0#52#100#52" + "'", str11.equals("35#0#52#100#52"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444", "aaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444" + "'", str2.equals("435#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5235#0#52#100#5244444444444"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("a 4 a", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", "HI!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        char[] charArray6 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray6);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100 100 0 10 -1", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " aaa4aa" + "'", str8.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " 4a444a" + "'", str10.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#########35a0a52a100a52#########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"########35a0a52a100a52#########\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("35 0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "350" + "'", str2.equals("350"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 10.0f, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("32a1a-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32a1a-1" + "'", str1.equals("32a1a-1"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", (int) 'a', "Users/sophie/Library/Java/Extensions:/Library/Java/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC" + "'", str3.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Ljava.lang.String;class [C", (java.lang.CharSequence) "100.0497.04-1.040.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) -1, (byte) -1, (byte) 100, (byte) -1, (byte) 0 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.Class<?> wildcardClass8 = byteArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) (short) -1, (int) (byte) -1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 35, 2);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 0, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-aa3", 97, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("hi!                                                                                      35a0a52a100a52", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                                                                      35a0a52a100a52" + "'", str2.equals("hi!                                                                                      35a0a52a100a52"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "us", (java.lang.CharSequence) "en", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) '#', 32.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("350", "a 4 a", "UTF-8");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("AAA4AA", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4" + "'", str3.equals("4"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("35 0", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35 0" + "'", str2.equals("35 0"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/", (java.lang.CharSequence) "3.0 1.0 0.0 2.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", (java.lang.CharSequence) "354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "\n", "AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456", 6, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".../sop..." + "'", str3.equals(".../sop..."));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("10.14.3", "01", "042.0410.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java HotSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.6", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("    3.041.040.042.0410.0     ene", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("3.0 1.0 0.0 2.0 10.0", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.0 1.0 0.0 2.0 10.0" + "'", str2.equals("3.0 1.0 0.0 2.0 10.0"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100#100#0#10#-1", "aa4aaa ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("-1#0#1", 0, "A4a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#0#1" + "'", str3.equals("-1#0#1"));
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest3.test314");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        java.lang.String str2 = javaVersion0.toString();
//        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
//        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
//        java.lang.Class<?> wildcardClass7 = javaVersion5.getClass();
//        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
//        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
//        boolean boolean10 = javaVersion3.atLeast(javaVersion5);
//        boolean boolean11 = javaVersion0.atLeast(javaVersion3);
//        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
//        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
//        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("   ", 51, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   444444444444444444444444444444444444444444444444" + "'", str3.equals("   444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "3/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.2/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0", (java.lang.CharSequence) " 0 ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("100.0", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0" + "'", str3.equals("100.0"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                35 0                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("JavaVirtualMachineSpecification", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaVirtualMachineSpecification" + "'", str3.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("US##############################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US##############################" + "'", str1.equals("US##############################"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', 6, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("SUN.LWAWT.MACOSX.LWCTOOLKIT", (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452354045241004523540452410045235404524100452");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa", (java.lang.CharSequence) "042.0410.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaa" + "'", str1.equals("aaaaaa"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-1#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", '#');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("e");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e" + "'", str1.equals("e"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1004100404104-1", "3/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.1/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.2/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.10/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004100404104-1" + "'", str2.equals("1004100404104-1"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "51.0", 345);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "-aa3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "US##############################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, charSequence1);
        org.junit.Assert.assertNull(charSequence2);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "25a001a25a0a53aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("C[ ssalc;gnirtS.gnal.avajL[ ssalc");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C[ ssalc;gnirtS.gnal.avajL[ ssalc" + "'", str1.equals("C[ ssalc;gnirtS.gnal.avajL[ ssalc"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "350", (int) (short) 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA", 103);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA" + "'", str2.equals("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixed mode" + "'", str1.equals("mixed mode"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44444444444444", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(" aaa4aa                                                                                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                             aa4aaa " + "'", str1.equals("                                                                                             aa4aaa "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.CharSequence charSequence4 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/hie", "-1");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence4, (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("en", strArray3, strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "en" + "'", str10.equals("en"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/hie" + "'", str12.equals("/hie"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "class [Ljava.lang.String;class [C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/j");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                                 1.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double[] doubleArray6 = new double[] { (-1.0f), 52.0f, (-1L), 10L, 10.0d, 32.0d };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 100, (int) (short) 100);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.0d + "'", double12 == 52.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: ", "aaaaaaaaaaaaa/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: " + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java: "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie                                       ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie                                       " + "'", str2.equals("/Users/sophie                                       "));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.7.0_80", "", (int) '#');
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray14 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray10, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray6, strArray10);
        java.lang.String[] strArray21 = org.apache.commons.lang3.StringUtils.split("", ' ');
        java.lang.String[] strArray25 = new java.lang.String[] { "-1#0#1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "UTF-8" };
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray21, strArray25);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1004100404104-1", (java.lang.CharSequence[]) strArray21);
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("51.0", strArray10, strArray21);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray21, ' ');
        java.lang.String[] strArray31 = null;
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray21, strArray31);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "51.0" + "'", str28.equals("51.0"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str32.equals("...otSpot(TM) 64-Bit Server VMaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                                                                                                    ", "a###4#", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    " + "'", str3.equals("                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    a###4#                                                                                                    "));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AAJAVA PLATFORM API SPECIFICATION AAA4AA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] { "1040435410" };
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " aaa4a", charSequenceArray2);
        org.junit.Assert.assertNotNull(charSequenceArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "mixed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double[] doubleArray2 = new double[] { 100, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (byte) 1, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1" + "'", str1.equals("-1"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "UTF-8", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 35, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "JavaaPlatformaAPIaSpecification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference(" aaa4aa                                                                                             ", "AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA" + "'", str2.equals("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("35 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35 0" + "'", str1.equals("35 0"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("   444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   444444444444444444444444444444444444444444444444" + "'", str1.equals("   444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.0_80-b15" + "'", str1.equals("7.0_80-b15"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("JavaaPlatformaAPIaSpecification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                             aa4aaa ", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Users/sophie", "35404524100452");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie" + "'", str2.equals("/Users/sophie"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int[] intArray5 = new int[] { (byte) -1, (byte) 10, (byte) -1, (byte) 1, 100 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', (int) '#', 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 10 -1 1 100" + "'", str11.equals("-1 10 -1 1 100"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("US    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":", 2, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 52.0f, (double) 345.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1040435410" + "'", str12.equals("1040435410"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "3.041.040.042.0410.0");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', (int) (byte) 100, (int) (short) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/" + "'", str8.equals("/"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/" + "'", str10.equals("/"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("        US", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        US" + "'", str2.equals("        US"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aaJavaUTF-8PlatformUTF-8APIUTF-8SpecificationUTF-8aaa4aa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "100.0a1.0a0.0a100.0a10.0a0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                                                              4a444a", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("35 0", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35 0                          " + "'", str2.equals("35 0                          "));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ", 0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa " + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        java.lang.Class<?> wildcardClass7 = javaVersion5.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        boolean boolean9 = javaVersion5.atLeast(javaVersion8);
        boolean boolean10 = javaVersion3.atLeast(javaVersion5);
        boolean boolean11 = javaVersion0.atLeast(javaVersion3);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1#0#1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("042.0410.0", " aaa4aa                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "042.0410.0" + "'", str2.equals("042.0410.0"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        long[] longArray4 = new long[] { 10L, 0, '#', (short) 10 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '4');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1040435410" + "'", str7.equals("1040435410"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                                 1.", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 1." + "'", str2.equals("                                                                                                 1."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM)SERuntimeEnvironment", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, 4.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HI!", (java.lang.CharSequence) "aaa4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4" + "'", str1.equals("AA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("    3.041.040.042.0410.0     ", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "    3.041.040.042.0410.0     " + "'", str3.equals("    3.041.040.042.0410.0     "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 3, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAA" + "'", str1.equals("AAAAAAAAA"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 345.0f, (double) '4', (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 345.0d + "'", double3 == 345.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("   HI!    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:    HI!     is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8", (java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "100a100a0a10a-1", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "#0#1-1#0#1/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/-1#0#1UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "100#100#0#10#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "100.0 97.0 -1.0 0.0 10.0", (java.lang.CharSequence) " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("01");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', 54, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 54 + "'", int3 == 54);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) " aaa4aa", (java.lang.CharSequence) "-1 10 -1 1 100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.LWCToolkit", " aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Librry/Jv/JvVirtulMchines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "1.5", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("35404524100452", "Java HotSpot(TM) 64-Bit Server VM", 100);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray7);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50561_1560277456"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("e", "1.2", "UTF-8");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double[] doubleArray3 = new double[] { 345, (byte) 1, 4 };
        double[] doubleArray7 = new double[] { 345, (byte) 1, 4 };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray7 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV" + "'", str1.equals("HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.70.90.91.6", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.70.90.91.6" + "'", str3.equals("1.70.90.91.6"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("  a 4 a", "a###4#", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  a 4 a" + "'", str3.equals("  a 4 a"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 0, (int) (short) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 200, (int) (byte) 10);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double[] doubleArray4 = new double[] { (byte) 0, 200, 35L, 3L };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', (int) (short) 1, (int) (short) 1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) (short) 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { 'a', '#', '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "JavaaPlatformaAPIaSpecification", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 0, (int) '#');
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 200);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int[] intArray4 = new int[] { 1, (short) 1, 35, 2 };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "3.041.040.042.0410.0", 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1#0#1", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, (int) (byte) 10, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long[] longArray3 = new long[] { (short) -1, 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ', (int) (byte) 0, (int) (short) 1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#0#1" + "'", str5.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100.0 97.0 -1.0 0.0 10.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 97.0 -1.0 0.0 10.0" + "'", str2.equals("100.0 97.0 -1.0 0.0 10.0"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1 0 1", 200);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("aaaaaaaaa", "/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae/Jae");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaa" + "'", str2.equals("aaaaaaaaa"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("AAA4A", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A" + "'", str2.equals("A"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "    3.041.040.042.0410.0     ene");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    3.041.040.042.0410.0     ene" + "'", str2.equals("    3.041.040.042.0410.0     ene"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("US    ", (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "    3.041.040.042.0410.0     ene", (-1), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "-1a1a3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("3.0 1.0 0.0 2.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.0 1.0 0.0 2.0 10.0" + "'", str1.equals("3.0 1.0 0.0 2.0 10.0"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        short[] shortArray5 = new short[] { (short) 100, (byte) 100, (byte) 0, (byte) 10, (byte) -1 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short15 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short16 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1004100404104-1" + "'", str7.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1004100404104-1" + "'", str10.equals("1004100404104-1"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a100a0a10a-1" + "'", str13.equals("100a100a0a10a-1"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) -1 + "'", short14 == (short) -1);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 100 + "'", short15 == (short) 100);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) -1 + "'", short16 == (short) -1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                  35404524100452", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35404524100452" + "'", str2.equals("35404524100452"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JavaaPlatformaAPIaSpecification", (int) (byte) 1, "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JavaaPlatformaAPIaSpecification" + "'", str3.equals("JavaaPlatformaAPIaSpecification"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "JavaaPlatformaAPIaSpecification", (java.lang.CharSequence) "97#0#35#-1#52#30", 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.1", "100.0a1.0a0.0a100.0a10.0a0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.5", " #a#4#a", "     3.041.040.042.0410.0     ", 18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 0, 0, 200);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 200 + "'", int3 == 200);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "HIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split(" aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aaJava Platform API Specification aaa4aa");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("-aa3", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 37");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.70.90.91.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.70.90.91.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                                      35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "35a0a52a100a52" + "'", str1.equals("35a0a52a100a52"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, (long) (-1), (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("US", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa35a0a52a100a52"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, 0.0f, 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0a52.0a-1.0a10.0a10.0a32.0", (java.lang.CharSequence) "     3.041.040.042.0410.0     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specification", (int) '#', 51);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "us                                                 ", 54);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("   444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   444444444444444444444444444444444444444444444444" + "'", str1.equals("   444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1040435410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "-1#0#1-1#0#1-1   3-1#0#1-1#0#1-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Oracle Corporation");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Oracle Corporation\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC" + "'", str2.equals("Users/sophie/Library/Java/Extensions:/Library/Java/Users/sophie/C[ SSALC;GNIRTS.GNAL.AVAJL[ SSALC"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("3.0 1.0 0.0 2.0 10.0", "01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3.0 1.0 0.0 2.0 10.0" + "'", str2.equals("3.0 1.0 0.0 2.0 10.0"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        char[] charArray8 = new char[] { ' ', 'a', '4', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " AAA4AA", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "a###4# ", charArray8);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7               ", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " aaa4aa" + "'", str10.equals(" aaa4aa"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + " 4a444a" + "'", str12.equals(" 4a444a"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.70.90.91.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("us                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US                                                 " + "'", str1.equals("US                                                 "));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 3, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("AAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA", "7.0_80-b15", 5, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AAA4A7.0_80-b15AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA" + "'", str4.equals("AAA4A7.0_80-b15AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AAAAA4AA"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!                                ", 103L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103L + "'", long2 == 103L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1.0a52.0a-1.0a10.0a10.0a32.0", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0a52.0a-1.0a10.0a10.0a32.0" + "'", str2.equals("-1.0a52.0a-1.0a10.0a10.0a32.0"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Oracle Corporation", (java.lang.CharSequence) "hi!                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0.0a10.0a10.0a10.0", "100.0a1.0a0.0a100.0a10.0a0.0", "A");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("        US", "1.3", "a###4# ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double[] doubleArray4 = new double[] { 0, (short) 10, 10.0d, (byte) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 52, (int) (short) 10);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0 10.0 10.0 10.0" + "'", str6.equals("0.0 10.0 10.0 10.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0a10.0a10.0a10.0" + "'", str8.equals("0.0a10.0a10.0a10.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0#10.0#10.0#10.0" + "'", str14.equals("0.0#10.0#10.0#10.0"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaa4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaa4a is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }
}

