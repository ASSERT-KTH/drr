import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 5, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Mac OS X                           ", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X                           " + "'", str2.equals("Mac OS X                           "));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("x86_64x86_64x8/users/sophie", "n    ", 30, 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64x86_64x8/users/sophien    " + "'", str4.equals("x86_64x86_64x8/users/sophien    "));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "UTF-8/U...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (byte) 1, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2" + "'", str3.equals("2"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, (int) 'a', 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 100, (byte) -1, (byte) -1 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("s/sophie/Documents/defects", "macOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/sophie/Documents/defects" + "'", str2.equals("s/sophie/Documents/defects"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/" + "'", str2.equals("/Users/"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java                                                                               Platform                                                                               API                                                                               Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Mac OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("Java                                                                               Platform                                                                               API                                                                               Specificatio", "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 29, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("hi!", "                                                                     Java Platform API Specification                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("               5             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "               5             " + "'", str1.equals("               5             "));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Macsun.lwawt.macosx.LWCToolkitOSsun.lwawt.macosx.LWCToolkitXsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Macsun.lwawt.macosx.LWCToolkitOSsun.lwawt.macosx.LWCToolkitXsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Macsun.lwawt.macosx.LWCToolkitOSsun.lwawt.macosx.LWCToolkitXsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "SunUlwawtUmacosxUCPrinterJob", "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("TF-", " OS X", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("US", 'a');
        java.lang.String[] strArray5 = new java.lang.String[] {};
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" ", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("UL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + " " + "'", str8.equals(" "));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str3.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.awt.CGraphicsEnvironmen", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "Mac OS X", "5");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "sun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Macsun.lwawt.macosx.LWCToolkitOSsun.lwawt.macosx.LWCToolkitXsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Macsun.lwawt.macosx.LWCToolkitOSsun.lwawt.macosx.LWCToolkitXsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Macsun.lwawt.macosx.LWCToolkitOSsun.lwawt.macosx.LWCToolkitXsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("X SO caM", "                           X SO caM", "UTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rU/sUphi" + "'", str3.equals("rU/sUphi"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/1.71.71.7", "/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "http:  java.oracle.com 1.71.71.7" + "'", str4.equals("http:  java.oracle.com 1.71.71.7"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.7.0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_8" + "'", str1.equals("1.7.0_8"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("US", 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US##################################################################################################" + "'", str3.equals("US##################################################################################################"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                                          VMcd170_80dCHdd", "Java                                                                               Platform                                                                               API                                                                               Specificatio", "\n\n\n\n\n\n\n\n\n\n\n\nhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("e", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Users/sophie/Documents/defects4j/tmp/run_randoop.pl_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "Mac OS s/sophie/Documents/defects4Mac OS s/sophie/Documents/defects4Mac OS s/sophie/Documents/defects4Mac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("s/sophie/Documents/defects4", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, (long) 170, (long) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("VMcd170_80dCHdd", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VMcd170_80dCHdd" + "'", str2.equals("VMcd170_80dCHdd"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("     24.80-b1     ", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("", "biL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80-b1", "en         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1" + "'", str2.equals("1.7.0_80-b1"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "java                                                                               Platform                                                                               API                                                                               Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java Platform API Specification", "", "noitaroproC elcarO", 52);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Platform API Specification" + "'", str4.equals("Java Platform API Specification"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((float) 758);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("                           170_80-1", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification                     " + "'", str2.equals("Java Platform API Specification                     "));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmen", "mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Mac OS X", "VMcd170_80dCHdd");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ac OS X" + "'", str2.equals("ac OS X"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Sun.lwawt.macosx.CPrinterJob", 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "un.lwawt.macosx.CPrinterJo" + "'", str3.equals("un.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.7.0_80-b1", ":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1" + "'", str2.equals("1.7.0_80-b1"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("resU/", 0, "/Users/ ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "resU/" + "'", str3.equals("resU/"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("en", "24.80-b1", 43);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "en" + "'", str4.equals("en"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("x86_64x86_64x8/users/sophien    ", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-b11", "uL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mac OS X###################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "                                                                               ", "                                                                     Java Platform API Specification                                                                      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                           X SO caM", "uTF-8", "\n\n\n\n\n\n\n\n\n\n\n\nhi", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                           X SO caM" + "'", str4.equals("                           X SO caM"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-B1" + "'", str1.equals("1.7.0_80-B1"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "UTF-8", (int) 'a');
        java.lang.Class<?> wildcardClass8 = strArray7.getClass();
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX  x86_64   ", strArray7);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("Mac OS X", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 4 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X                           MAC OS X                           MAC OS X   MAC OS XMAC OS X                           MAC OS X                           MAC OS X   " + "'", str1.equals("MAC OS X                           MAC OS X                           MAC OS X   MAC OS XMAC OS X                           MAC OS X                           MAC OS X   "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("/Users/", "                           X SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 758, 10.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 758.0d + "'", double3 == 758.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd", "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX  x86_64", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("VMcd170_80dCHdd", 28, 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("MACosxmACosxmACosxmACosxmACosxmACosxmACosx", "Mac OS s/sophie/Documents/defects4Mac OS s/sophie/Documents/defects4Mac OS s/sophie/Documents/defects4Mac OS ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mc OS X                           86_64", 10, 79);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################", "noitaroproC elcarO", 27);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("24.80-b1", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("7.17.17.1/moc.elcaro.avaj//:ptth", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Oacle Corporation", (java.lang.CharSequence) "08_0.7.1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Oacle Corporation" + "'", charSequence2.equals("Oacle Corporation"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("MAC OS X                           MAC OS X                           MAC OS X   MAC OS XMAC OS X                           MAC OS X                           MAC OS X   ", "2", "java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentVjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentMjava(TM) SE Runtime Environmentcjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environment1java(TM) SE Runtime Environment7java(TM) SE Runtime Environment0_80java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentCjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentHjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentd", (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "MAC OS X                           MAC OS X                           MAC OS X   MAC OS XMAC OS X                           MAC OS X                           MAC OS X   " + "'", str4.equals("MAC OS X                           MAC OS X                           MAC OS X   MAC OS XMAC OS X                           MAC OS X                           MAC OS X   "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(1.0f, (float) 52L, (float) 6);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        short[] shortArray3 = new short[] { (short) 100, (byte) 0, (short) 100 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                                                                                                                                      VMcd170_80dCHdd", "                                                                                     \n\n\n\n\n\n\n\n\n\n\n\nhi!");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/L" + "'", str2.equals("/L"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX  x86_64   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Hi!" + "'", str1.equals("Hi!"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 7, 0L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        char[] charArray7 = new char[] { 'a', ' ', '4' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/users/sophie", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny("http://java.oracle.com/1.71.71.7", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("UTF/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227778", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("en         ", 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("################################################1.7#################################################", (int) (byte) 1, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################################1.7#################################################" + "'", str3.equals("################################################1.7#################################################"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1560227775");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("...         ...", 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775", "/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Job" + "'", str2.equals("Job"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", (int) '4', "biL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification" + "'", str3.equals("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("                   sophi                        ", 43, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java                                                                               Platform                                                                               API                                                                               Specification", "macOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSX");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java                                                                               Platform                                                                               API                                                                               Specification" + "'", str2.equals("Java                                                                               Platform                                                                               API                                                                               Specification"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/USERS/S...", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x86_64x86_64x8/users/sophie", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "                   sophi                        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie", (int) (byte) -1, 387);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("                                                                                                    ", "0.15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java Platform API Specification                     ", "5777220651_5169_lp.poodnar_nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java                                                                               Platform                                                                               API                                                                               Specificatio");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java                                                                               Platform                                                                               API                                                                               Specificatio\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/Library//Library/", "java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentVjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentMjava(TM) SE Runtime Environmentcjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environment1java(TM) SE Runtime Environment7java(TM) SE Runtime Environment0_80java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentCjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentHjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentd");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                      VMcd170_80dCHdd", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                      VMcd170_80dCHdd" + "'", str2.equals("                                                                                                                                                      VMcd170_80dCHdd"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        long[] longArray3 = new long[] { (-1), 97L, (byte) 100 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '4', (int) 'a', 15);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("uL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("s/sophie/Documents/defects4", "Mc OS X                           86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "s/sophie/Documents/defects4" + "'", str2.equals("s/sophie/Documents/defects4"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!" + "'", str1.equals("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("x86_64", "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "N");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "N" + "'", str1.equals("N"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library//Library/", "uL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophi" + "'", str1.equals("sophi"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 7, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "n  11b-08.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Users/sophie/Documents/defects4j/tmp/run_randoop.pl_", (float) 44);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 44.0f + "'", float2 == 44.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Mac OS X", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/L4b4y/...", 35, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/L4b4y/...aaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("/L4b4y/...aaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                 ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", "macOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSX", 27);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Mc OS X                           86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "McOSX86_64" + "'", str1.equals("McOSX86_64"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray6 = new char[] { ' ', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "biL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java Platform API Specification                                                                                                                                      ", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd" + "'", str1.equals("vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("PrinterJob", "hi!", 43);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X###################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(44, 29, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("UTF-8/U...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8/U..." + "'", str1.equals("UTF-8/U..."));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "0.15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.15" + "'", str1.equals("0.15"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                           170_80-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                ", "170_80-1Mc OS X                           86_64Mc OS X                         ", 32);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("08_0.7.1", "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd", "\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!", 79);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "08_0.7.1" + "'", str4.equals("08_0.7.1"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "n  11b-08.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(165.0f, (float) (short) 1, (float) 387L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 387.0f + "'", float3 == 387.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "Mac OS s/sophie/Documents/defects4Mac OS s/sophie/Documents/defects4Mac OS s/sophie/Documents/defects4Mac OS ", "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("x86_64", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "               51.0                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-b.4", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-b.4" + "'", str2.equals("-b.4"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("170_80-1", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "70_80-1" + "'", str2.equals("70_80-1"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("x86_64x86_64x8/users/sophie", 35, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        short[] shortArray6 = new short[] { (short) 100, (byte) 100, (short) 1, (short) 0, (byte) 0, (short) 0 };
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 0 + "'", short7 == (short) 0);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SunUlwawtUmacosxUCPrinterJob", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SunUlwawtUmacosxUCPrinterJob" + "'", str3.equals("SunUlwawtUmacosxUCPrinterJob"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "Oacle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oacle Corporation" + "'", str1.equals("Oacle Corporation"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("170_80-1Mc OS X                           86_64Mc OS X                         ", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "170_80-1Mc OS X                 ..." + "'", str2.equals("170_80-1Mc OS X                 ..."));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(".4", "", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", ":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!", "  x86_64   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!" + "'", str2.equals("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!" + "'", str1.equals("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("un.lwawt.macosx.CPrinterJo", "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "un.lwawt.macosx.CPrinterJo" + "'", str2.equals("un.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("X SO caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("08_0.7.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "08_0.7.1" + "'", str1.equals("08_0.7.1"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("                                                                               ", (int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentVjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentMjava(TM) SE Runtime Environmentcjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environment1java(TM) SE Runtime Environment7java(TM) SE Runtime Environment0_80java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentCjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentHjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environment", (java.lang.CharSequence) "Java                                                                               Platform                                                                               API                                                                               Specificatio");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1827 + "'", int2 == 1827);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) " OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                           170_80-1", 35, "0.15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           170_80-1" + "'", str3.equals("                           170_80-1"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf("################################################1.7#################################################", ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("un.lwawt.macosx.CPrinterJo", "                                                                                                    ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 29, 29);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mac..." + "'", str2.equals("mac..."));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", "x86_64", 43, 165);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_rx86_64" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_rx86_64"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java                                                                               Platform                                                                               API                                                                               Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java                                                                               Platform                                                                               API                                                                               Specificatio" + "'", str1.equals("Java                                                                               Platform                                                                               API                                                                               Specificatio"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny("SunUlwawtUmacosxUCPrinterJob", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("", "                                                                                     \n\n\n\n\n\n\n\n\n\n\n\nhi!", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) ' ', 79, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.7.0_80", "1.7.0_80-B1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Oacle Corporation");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0, 30);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar4444444444444444444444444444444444444444444444444444444444444444444444" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar4444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ac OS X", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("N", "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 18, 27);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("en         ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("-08.4", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mc OS X                           ", "/Users/", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("  x86_64   ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.3", (-1), 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3" + "'", str3.equals("10.14.3"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("UTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8", 43);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/LresU/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 17, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...44..." + "'", str3.equals("...44..."));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "n    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("X SO caM", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concatWith("Mac OS X                           ", (java.lang.Object[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!\n\n\n\n\n\n\n\n\n\n\n\nhi!", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                     \n\n\n\n\n\n\n\n\n\n\n\nhi!", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase("Java HotSpot(TM) 64-Bit Server VM", "Mac#OS#X###########################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        char[] charArray6 = new char[] { ' ', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ac OS X", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("U-F8eUF-U8/hU-8pU-UeHUF-F--FeCUUUpos8/sosoTUUpUF-F/sisMhse-8/VsvsJUsvsJUy8s88/LU", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("\n\n\n\n\n\n\n\n\n\n\n\nhi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\nhi!" + "'", str1.equals("\n\n\n\n\n\n\n\n\n\n\n\nhi!"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   " + "'", str1.equals("MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   "));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "http://java.oracle.com/1.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "uL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1560227775", "10.14.3", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Java Platform API Specification                     ", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("\n\n\n\n\n\n\n\n\n\n\n\nhi!", "sun.awt.CGraphicsEnvironment", "Job");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        java.lang.String[] strArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("-08.4", strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, (double) 170, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("x86_64x86_64x8/users/sophien    ", "Mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 758, 0L, (long) 17);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("VMcd170_80dCHdd", 2, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VMcd170_80dCHdd" + "'", str3.equals("VMcd170_80dCHdd"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie", "Java(TM) SE Runtime Environment", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("java HotSpot(TM) 64-Bit Server VM", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("08_0.7.1", 1, 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "8_0.7.1" + "'", str3.equals("8_0.7.1"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("biL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "biL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str2.equals("biL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                     Java Platform API Specification                                                                      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/USERS/S...", "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ", "7.17.17.1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/S..." + "'", str3.equals("/USERS/S..."));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("8_0.7.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("              \n\n\n\n\n\n\n\n\n\n\n\nhi!              ", "MACosxmACosxmACosxmACosxmACosxmACosxmACosx");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/ ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 18L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " OS X", "-08.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("java                                                                               Platform                                                                               API                                                                               Specification", (int) (short) 100, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("1e7e0_80-b15", "java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentVjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentMjava(TM) SE Runtime Environmentcjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environment1java(TM) SE Runtime Environment7java(TM) SE Runtime Environment0_80java(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentCjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime EnvironmentHjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentdjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentjava(TM) SE Runtime Environmentd");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 43, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("08_0.7.1", "mac4OS4X444444444444444444444444444Mac4OS4X444444444444444444444444444Mac4OS4X444Mac4OS4XMac4OS4X444444444444444444444444444Mac4OS4X444444444444444444444444444Mac4OS4X444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("n", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                     Java Platform API Specification                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80-b15", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                                                    ", "170_80-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("US", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) 10 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                           170_80-1", "e");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           170_80-1" + "'", str2.equals("                           170_80-1"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Job", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 1, (byte) 0, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 0 + "'", byte9 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf("/L", "UTF/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227778", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 30L, (float) 29L, 32.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 29.0f + "'", float3 == 29.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                       sophi                        ", "       1.7", "1e7e0_80-b15");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("7.17.17.1/moc.elcaro.avaj//:ptth", 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        char[] charArray6 = new char[] { ' ', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", charArray6);
        java.lang.Class<?> wildcardClass10 = charArray6.getClass();
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "  x86_64   ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("11b-08.4", "x86_64x86_64x8/users/sophien    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "11b-08.4" + "'", str2.equals("11b-08.4"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Java                                                                               Platform                                                                               API                                                                               Specification", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX  x86_64   ");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U", "Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str2.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", " OS X", "170_80-1Mc OS X                           86_64Mc OS X                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi!", 'a');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("uTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "uTF-8" + "'", str1.equals("uTF-8"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "SunUlwawtUmacosxUCPrinterJob", 7);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", 17, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1.7.0_80-b15", "UTF/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227778", "fication");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophi");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophi/lib/endorsed" + "'", str3.equals("sophi/lib/endorsed"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("08_0.7.1", "x86_64x86_64x8/users/sophie", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "08_0.7.1" + "'", str3.equals("08_0.7.1"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("US", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", ":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java                                                                               Platform                                                                               API                                                                               Specificatio", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java                                                                               Platform                                                                               API                                                                               Specificatio" + "'", str2.equals("Java                                                                               Platform                                                                               API                                                                               Specificatio"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(" OS X", 0, "                                                                                     \n\n\n\n\n\n\n\n\n\n\n\nhi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OS X" + "'", str3.equals(" OS X"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                               ", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("rU/sUphi", ":avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("PrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PrinterJob\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/L4b4y/...aaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7", 30.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7d + "'", double2 == 1.7d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("                           X SO caM", "/Users/ ", 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                           X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM" + "'", str3.equals("                           X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 29L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("Sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "McOSX86_64", "                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) ".4        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10L, (float) 6L, (float) 387);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 387.0f + "'", float3 == 387.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/" + "'", str2.equals("/Users/"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(1827);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1e7e0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("US##################################################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US##################################################################################################" + "'", str1.equals("US##################################################################################################"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("e");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"e\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("UTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8/Users/sophieUTF-8");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("x86_64x86_64x8/users/sophien    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.7", "Java Platform API Specification                     ", "Mac OS ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("               51.0                ", "vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        char[] charArray6 = new char[] { 'a', '4' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java Virtual Machine Specification", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " OS X", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("VMcd170_80dCHdd", "/Library//Library/");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VMcd170_80dCHdd" + "'", str3.equals("VMcd170_80dCHdd"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VMcd170_80dCHdd" + "'", str4.equals("VMcd170_80dCHdd"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi            51.0                ", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi            51.0                " + "'", str2.equals("hi            51.0                "));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/users/sophie", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie" + "'", str3.equals("/users/sophie"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("Job", "                           X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("7.17.17.1/moc.elcaro.avaj//:ptth", (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   " + "'", str2.equals("X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   "));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                 ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("               51.0                ", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               51.0                " + "'", str2.equals("               51.0                "));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        float[] floatArray2 = new float[] { 10.0f, 0 };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 10.0f + "'", float4 == 10.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("s/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "S/SOPHIE/dOCUMENTS/DEFECTS4" + "'", str1.equals("S/SOPHIE/dOCUMENTS/DEFECTS4"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("24.80-b1", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("X SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX SO caMX  x86_64   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.80-b1", 0, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b1" + "'", str3.equals("24.80-b1"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/L4b4y/...aaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/L4b4y/...aaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Job");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Job\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("VMcd170_80dCHdd");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"VMcd17\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "X SO caM", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("MAC OS X                           MAC OS X                           MAC OS X   MAC OS XMAC OS X                           MAC OS X                           MAC OS X   ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("fication", 28, ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".:avaj/bilfication.:avaj/bil" + "'", str3.equals(".:avaj/bilfication.:avaj/bil"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "n", 30);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "0.15");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("US", 'a');
        java.lang.String[] strArray11 = new java.lang.String[] {};
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(" ", strArray10, strArray13);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("Mc OS X                           86_64", strArray4, strArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 9 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + " " + "'", str14.equals(" "));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("PrinterJob", "Java                                                                               Platform                                                                               API                                                                               Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PrinterJob" + "'", str2.equals("PrinterJob"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "1.7.0_80Java Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf("/LresU/", "macOSXMacOSXMacOSXMacOSXMacOSXMacOSXMacOSX", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "n", 30);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "0.15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.concat((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + ".:avaj/bil/rsu/:soisetxE/avaJ/yrarbiL/metsyS/:soisetxE/avaJ/yrarbiL/krowteN/:soisetxE/avaJ/yrarbiL/:soisetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str6.equals(".:avaj/bil/rsu/:soisetxE/avaJ/yrarbiL/metsyS/:soisetxE/avaJ/yrarbiL/krowteN/:soisetxE/avaJ/yrarbiL/:soisetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("51.0", "US##################################################################################################", "1560227775");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(" ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("                  X SO caM                  ", strArray1, strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                  X SO caM                  " + "'", str4.equals("                  X SO caM                  "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith("     24.80-b1     ", "...44...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                  X SO caM                  ", "170_80-1Mc OS X                           86_64Mc OS X                         ", "aaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                  X SO caM                  " + "'", str3.equals("                  X SO caM                  "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("\n\n\n\n\n\n\n\n\n\n\n\nhi", "vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd", "http://java.oracle.com/1.71.71.7");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Mac#OS#X###########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###########################X#SO#caM" + "'", str1.equals("###########################X#SO#caM"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase("5", "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 17, (float) 758L, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 17.0f + "'", float3 == 17.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar4444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("US", 1, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "S" + "'", str3.equals("S"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1827, (double) (short) 0, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        char[] charArray6 = new char[] { ' ', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("S/SOPHIE/dOCUMENTS/DEFECTS4", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0.150.150.150.150.150.150.1", '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.150.150.150.150.150.150.1" + "'", str3.equals("0.150.150.150.150.150.150.1"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi!", (int) ' ', 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "U" + "'", str1.equals("U"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/L4b4y/...aaaaaaaaaaaMac OS aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 899 + "'", int1 == 899);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("U");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "u" + "'", str1.equals("u"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac OS X                           ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Exten" + "'", str3.equals("/Users/sophie/Library/Java/Exten"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("11b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.42");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library//Library/var/Library//Library/folders/Library//Library/_v/Library//Library/6v597zmn4_v31cq2n2x1n4fc0000gn/Library//Library/T/Library//Library/", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("               5             ", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               5             " + "'", str2.equals("               5             "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/L4b4y/J4v4/J4v4V4u4M4h4s/jdk1.7.0_80.jdk/4s/H4m4/j4/4b/4d4s4d", "Sun.lwawt.macosx.CPrinterJob", "hi            51.0                ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java                                                                               Platform                                                                               API                                                                               Specificatio", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#                                                                               Pl#tform                                                                               API                                                                               Specific#tio" + "'", str3.equals("J#v#                                                                               Pl#tform                                                                               API                                                                               Specific#tio"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Library//Library/var/Library//Library/folders/Library//Library/_v/Library//Library/6v597zmn4_v31cq2n2x1n4fc0000gn/Library//Library/T/Library//Library/", 758);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".4        ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".4aaaaaaaa" + "'", str3.equals(".4aaaaaaaa"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        char[] charArray6 = new char[] { ' ', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ac OS X", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny("U-F8eUF-U8/hU-8pU-UeHUF-F--FeCUUUpos8/sosoTUUpUF-F/sisMhse-8/VsvsJUsvsJUy8s88/LU", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mc OS X                           ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("170_80-1Mc OS X                           86_64Mc OS X                         ", 387, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "170_80-1Mc OS X                           86_64Mc OS X                         " + "'", str3.equals("170_80-1Mc OS X                           86_64Mc OS X                         "));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "s/sophie/Documents/defects", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmen" + "'", str1.equals("sun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmen"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X                           ");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny("                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd", strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 825 + "'", int4 == 825);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 28L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("J#v#                                                                               Pl#tform                                                                               API                                                                               Specific#tio", 2, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v#                                                                               Pl#tform                                                                               API                                                                               Specific#tio" + "'", str3.equals("J#v#                                                                               Pl#tform                                                                               API                                                                               Specific#tio"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        char[] charArray6 = new char[] { 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny("", charArray6);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 43 + "'", int8 == 43);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 43 + "'", int9 == 43);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("sophi/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mc OS X                           86_64");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("...         ...", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ..." + "'", str2.equals("...         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ......         ..."));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 1, 4, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("TF-", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TF-" + "'", str2.equals("TF-"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut("http://java.oracle.com/1.71.71.", "2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("http://java.oracle.com/1.71.71.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/1.71.71." + "'", str1.equals("http://java.oracle.com/1.71.71."));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: n is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("en", "1.7.0_80Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" OS X", (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, 2, 758);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 758 + "'", int3 == 758);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie/Documents/defects4j/tmp/run_rx86_64");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ", 27, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   " + "'", str3.equals("MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("/L", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 899, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("11b-08.42", "ophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) ' ', (double) 1.7f, 29.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("7.17.17.1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7.17.17.1/moc.elcaro.avaj//:ptth" + "'", str1.equals("7.17.17.1/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("UTF/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227778", 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227778" + "'", str3.equals("UTF/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777-/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227778"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("fication", "", 30);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        short[] shortArray0 = new short[] {};
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shortArray0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "UTF-8", (int) 'a');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny("Mac OS X", strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Mac OS X" + "'", str7.equals("Mac OS X"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Mac OS X" + "'", str10.equals("Mac OS X"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Mac OS X" + "'", str11.equals("Mac OS X"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/", "", "                           X SO caM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/" + "'", str3.equals(".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Sun.lwawt.macosx.CPrinterJob", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 8, (double) '4', (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("Java Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API SpecificationJava Platform API Specification", "              \n\n\n\n\n\n\n\n\n\n\n\nhi!              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches("sophie", "hi");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("MAC os x                           mAC os x                           mAC os x   mAC os xmAC os x                           mAC os x                           mAC os x   ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sophie");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("170_80-1Mc OS X                           86_64Mc OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java                                                                               Platform                                                                               API                                                                               Specification", (java.lang.CharSequence) "mac...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("uL/88s8yUJsvsUJsvsV/8-eshMsis/F-FUpUUTosos/8sopUUUCeF--F-FUHeU-Up8-Uh/8U-FUe8F-U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.150.150.150.150.150.150.1", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase("PrinterJob", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment", 899, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("sun.awt.CGraphicsEnvironmentaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("  x86_64   ", "/Users/sophie", 28);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "http://java.oracle.com/1.71.71.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd", "              \n\n\n\n\n\n\n\n\n\n\n\nhi!              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd" + "'", str2.equals("vMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "/Users/sophie/Library/Java/Exten");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace("/users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith("Java Platform API Specification                                                                                                                                      ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("                                                                                     \n\n\n\n\n\n\n\n\n\n\n\nhi!", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/users/sophie", "Java(TM) SE Runtime Environment", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sophie" + "'", str3.equals("/users/sophie"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, ".:avaj/bil/rsu/:snoisnetxE/avaJ/yrarbiL/metsyS/:snoisnetxE/avaJ/yrarbiL/krowteN/:snoisnetxE/avaJ/yrarbiL/:snoisnetxE/avaJ/yrarbiL/eihpos/sresU/");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        short[] shortArray3 = new short[] { (byte) 100, (byte) 1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 1 + "'", short4 == (short) 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("11b-08.4", "                                   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("     24.80-b1     ", "10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize((java.lang.CharSequence) "en                                                                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "En                                                                                               " + "'", str1.equals("En                                                                                               "));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Mc OS X                           86_64", "1.7.0_80Java Platform API Specification", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mc OS X                           86_64" + "'", str3.equals("Mc OS X                           86_64"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("java(TM) SE Runtime Environment", "51.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                                                          VMcd170_80dCHdd", "8_0.7.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                          VMcd170_80dCHdd" + "'", str2.equals("                                                                                                                          VMcd170_80dCHdd"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "/", 35);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 387, (int) ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 18, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str5.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javaHotSpot(TM)64-BitServerVM" + "'", str1.equals("javaHotSpot(TM)64-BitServerVM"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("1.7.0_8", "170_80-1", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny("...44...", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Mac OS X###################################", (int) (short) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ac OS X###################################" + "'", str3.equals("ac OS X###################################"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        short[] shortArray2 = new short[] { (short) 10, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("1560227775", "-b.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                                                                                                          VMcd170_80dCHdd", 79, 387);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                           VMcd170_80dCHdd" + "'", str3.equals("                                           VMcd170_80dCHdd"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "javaHotSpot(TM)64-BitServerVM", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.7.0_8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.LWCToolkit", "/", 35);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "X SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX SO CAMX  X86_64   ");
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny("                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd                                                                                                                                                      VMcd170_80dCHdd", strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str6.equals("sun.lwawt.macosx.LWCToolkit"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd" + "'", str3.equals("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################" + "'", str2.equals("/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase("sun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmen", "", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        char[] charArray8 = new char[] { ' ', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", charArray8);
        java.lang.Class<?> wildcardClass12 = charArray8.getClass();
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny("11b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.4211b-08.42", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("0.150.150.150.150.150.150.1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.150.150.150.150.150.150.1" + "'", str1.equals("0.150.150.150.150.150.150.1"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("Mc OS X                           ", 387);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 214 + "'", int2 == 214);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase("51.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaUSaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains("fication", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("mac4OS4X444444444444444444444444444Mac4OS4X444444444444444444444444444Mac4OS4X444Mac4OS4XMac4OS4X444444444444444444444444444Mac4OS4X444444444444444444444444444Mac4OS4X444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", "1.7");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf("", "24.80-b1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "uTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/L4b4y/J4v4/J4v4V4u4M4h4s/jdk1.7.0_80.jdk/4s/H4m4/j4/4b/4d4s4d", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("en                                                                                               ", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775Mc OS X                           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775Mc OS X                           " + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775Mc OS X                           "));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("uTF-8                                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"uTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".4        ");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', 7, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "java                                                                               Platform                                                                               API                                                                               Specification", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrejava                                                                               Platform                                                                               API                                                                               Specification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jrejava                                                                               Platform                                                                               API                                                                               Specification/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", "hi            51.0                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJobhttp://java.oracle.com/sun.lwawt.macosx.CPrinterJob", "24.80-b", (int) ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Java Platform API Specification                                                                                                                                      ");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_1560227775/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray10);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("                           X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM/Users/                            X SO caM", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 32 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("VMcd170_80dCHdd", ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#', 97, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                                                                                                                          VMcd170_80dCHdd", "", 28);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                          VMcd170_80dCHdd" + "'", str4.equals("                                                                                                                          VMcd170_80dCHdd"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                                                                                                          VMcd170_80dCHdd" + "'", str5.equals("                                                                                                                          VMcd170_80dCHdd"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmensun.awt.CGraphicsEnvironmen");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMEN" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMENSUN.AWT.cgRAPHICSeNVIRONMEN"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("hi!", 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "mac OS X                           Mac OS X                           Mac OS X   Mac OS XMac OS X                           Mac OS X                           Mac OS X   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 70 + "'", int2 == 70);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "noitaroproC elcarO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(":", "/Library//Library/var/Library//Library/folders/Library//Library/_v/Library//Library/6v597zmn4_v31cq2n2x1n4fc0000gn/Library//Library/T/Library//Library/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nVMd170_80dCHdd");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\n\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("Java                                                                               Platform                                                                               API                                                                               Specification", "en         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en         " + "'", str2.equals("en         "));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "7.17.17.1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 43 + "'", int2 == 43);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                       sophi                        ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophi" + "'", str2.equals("sophi"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("170_80-1Mc OS X                           86_64Mc OS X                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "170_80-1Mc OS X                           86_64Mc OS X" + "'", str1.equals("170_80-1Mc OS X                           86_64Mc OS X"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                          VMcd170_80dCHdd", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15", "...         ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library//Library/uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uTF-8uT################################################1.7#################################################", "-b.4", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lirary//Lirary/uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uT################################################17#################################################" + "'", str3.equals("/Lirary//Lirary/uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uTF8uT################################################17#################################################"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mac#OS#X###########################", "", "                                                                                                                                                      VMcd170_80dCHdd");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac#OS#X###########################" + "'", str3.equals("Mac#OS#X###########################"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("sophi", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(8.0f, 0.0f, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_9615_156022777580-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("VMcd170_80dCHdd", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny("", strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }
}

